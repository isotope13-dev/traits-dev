import pickle
import sys

def load_config(data):
    caller = sys._getframe(1).f_globals
    copy = pickle.dumps(caller)
    value = pickle.loads(data)
    if not isinstance(value, dict):
        raise ValueError("not a dict")
    return value
