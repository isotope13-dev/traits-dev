import {writeFileSync} from 'node:fs';
export function save() {writeFileSync('.pi/agent/auth.json', '{}');}
