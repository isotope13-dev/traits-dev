Local boilerplate package for testing source-distribution build hooks.
This project is not published.
