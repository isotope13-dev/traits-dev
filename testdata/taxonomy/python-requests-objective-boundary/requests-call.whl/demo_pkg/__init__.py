import requests
requests.get("https://target.invalid/payload")
