window.webpackChunkwhatsapp_web_client;
const sendTextMessage = async function() {};
const contacts = WPP.contact.list();
WPP.chat.sendTextMessage("recipient", "owner supplied message");
const blob = new Blob(["contact\n"], {type:"text/csv"});
const link = document.createElement("a");
link.href = URL.createObjectURL(blob); link.download = "contacts.csv"; link.click();
