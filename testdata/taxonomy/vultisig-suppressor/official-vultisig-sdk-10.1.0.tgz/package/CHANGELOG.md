# @vultisig/sdk

## 10.1.0

### Minor Changes

- [#2533](https://github.com/vultisig/vultisig-sdk/pull/2533) [`1e702cc`](https://github.com/vultisig/vultisig-sdk/commit/1e702ccdab33255bd7a4177fc010d987584bab74) Thanks [@realpaaao](https://github.com/realpaaao)! - Add native NEAR: implicit-account addresses and the account-ID grammar, balance, preparation that freezes the access-key nonce, final block hash and gas reservation, fee and MAX (balance less the gas and storage reserves), signing, a locally derived transaction hash, broadcast bound to it, and finality-checked status. A NEAR transfer carries no swap payload, memo or token. An unaffordable NEAR send fails with `not-enough-funds`, and a missing named receiver with `near-destination-not-found`. The all-zero implicit account is refused as a destination, and the address-format gate validates NEAR account IDs. NEAR is not a default or seedphrase-import chain yet, and NEP-141 tokens are unsupported.

- [#2535](https://github.com/vultisig/vultisig-sdk/pull/2535) [`93d191c`](https://github.com/vultisig/vultisig-sdk/commit/93d191c243ec64cde7a447defa4693ad6fa1fd9e) Thanks [@realpaaao](https://github.com/realpaaao)! - NEAR is a SwapKit source chain: a NEAR-Intents `simpleTransfer` quote becomes a plain transfer to the per-swap implicit deposit account, and the NEAR signer accepts only a SwapKit deposit that names exactly that transfer (same receiver and amount, no memo or pre-built transaction). An unaffordable NEAR-source swap fails with the `not-enough-funds` shortfall before signing.

### Patch Changes

- [#2525](https://github.com/vultisig/vultisig-sdk/pull/2525) [`387a80b`](https://github.com/vultisig/vultisig-sdk/commit/387a80bbd44d3b526b9d09717133f1d8530277d1) Thanks [@realpaaao](https://github.com/realpaaao)! - Signing inputs and fee amounts on every chain refuse a swap (every provider, THORChain and Maya included) whose sold coin is missing or is not the keysign coin (chain, native flag, contract, ticker and decimals; contracts compare case-insensitively on EVM only), as iOS and Android do. A THORChain secured-asset withdrawal (`isSecuredAssetWithdrawal`, e.g. `@vultisig/rujira` withdraw) is exempt, since its deposit is built from the L1 asset its payload names. New `assertKeysignSwapSellsSigningCoin` (`@vultisig/core-mpc/keysign/swap/assertKeysignSwapSellsSigningCoin`) lets co-signer screens refuse the same payloads before approval.

- [#2534](https://github.com/vultisig/vultisig-sdk/pull/2534) [`f9dba70`](https://github.com/vultisig/vultisig-sdk/commit/f9dba7097adac87b28acaf4d242ee993d59443f8) Thanks [@realpaaao](https://github.com/realpaaao)! - A SwapKit ERC-20 deposit transfer builds no approve leg and reports no approval spender: a direct `transfer` to the deposit address spends no allowance. New optional `GeneralSwapTx.evm.erc20TransferDeposit` marks such quotes.

- [#2532](https://github.com/vultisig/vultisig-sdk/pull/2532) [`b002bd6`](https://github.com/vultisig/vultisig-sdk/commit/b002bd6a57f2ee729108f58ad3e58d8c9346d0b3) Thanks [@realpaaao](https://github.com/realpaaao)! - Accept SwapKit ERC-20 deposit transfers (NEAR-Intents `simpleTransfer`) only when they are exactly `transfer(targetAddress, fromAmount)` on the sold token with no native value, at quote time and again on every co-signer. New `getKeysignSwapKitDepositRecipient` (`@vultisig/core-mpc/keysign/swap/getKeysignSwapKitDepositRecipient`) returns the recipient a payload signs so co-signers show the same address.

- Updated dependencies [[`1e702cc`](https://github.com/vultisig/vultisig-sdk/commit/1e702ccdab33255bd7a4177fc010d987584bab74), [`93d191c`](https://github.com/vultisig/vultisig-sdk/commit/93d191c243ec64cde7a447defa4693ad6fa1fd9e), [`387a80b`](https://github.com/vultisig/vultisig-sdk/commit/387a80bbd44d3b526b9d09717133f1d8530277d1), [`f9dba70`](https://github.com/vultisig/vultisig-sdk/commit/f9dba7097adac87b28acaf4d242ee993d59443f8), [`b002bd6`](https://github.com/vultisig/vultisig-sdk/commit/b002bd6a57f2ee729108f58ad3e58d8c9346d0b3)]:
  - @vultisig/core-chain@6.3.0
  - @vultisig/core-mpc@5.1.0

## 10.0.1

### Patch Changes

- [#2508](https://github.com/vultisig/vultisig-sdk/pull/2508) [`da500e5`](https://github.com/vultisig/vultisig-sdk/commit/da500e593bfae7ebdc74d87cce6cec7f33cc9da5) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Offer THORChain for Zcash swaps. ZEC was only quoted through MayaChain, though THORChain runs a ZEC pool. A THORChain swap from Zcash signs like the other UTXO sources: a send to the inbound vault with the memo in OP_RETURN. THORChain publishes that vault as a ZIP-320 TEX address (`tex1…`). WalletCore parses it to the same P2PKH script as its `t1…` form, so the signature matches iOS and Android, which convert the address before signing.

- Updated dependencies [[`da500e5`](https://github.com/vultisig/vultisig-sdk/commit/da500e593bfae7ebdc74d87cce6cec7f33cc9da5)]:
  - @vultisig/core-chain@6.2.1
  - @vultisig/core-mpc@5.0.5

## 10.0.0

### Major Changes

- [#2490](https://github.com/vultisig/vultisig-sdk/pull/2490) [`60acf82`](https://github.com/vultisig/vultisig-sdk/commit/60acf82b0596d4345b77045365f94b7a6ee44e13) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Remove the agent-focused DeFi namespace, builders, and `tools/defi` subpath from the wallet SDK, along with its exclusive `@balancer/sdk` dependency. Declare `@noble/ciphers` directly for the retained React Native encryption polyfills. Load the Polkadot API when a Polkadot client is first requested so the SDK root no longer includes it in the eager wallet graph.

### Minor Changes

- [#2498](https://github.com/vultisig/vultisig-sdk/pull/2498) [`0251a9b`](https://github.com/vultisig/vultisig-sdk/commit/0251a9bbb6ea85d178cef4846c1c8471aca04386) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Itemize the swap provider's own fee apart from the integrator's affiliate fee. LI.FI quotes now split every fee entry that carries a `feeSplit` (the fixed fee and any distribution fees) and SwapKit quotes keep the `service` fee out of the `affiliate` one, so `evm.affiliateFee` and `solana.swapFee` / `transfer.swapFee` carry only the integrator's cut and the new optional `protocolFee` carries everyone else's (LI.FI's, a distribution recipient's, or SwapKit's). The keysign payload `swap_fee` still reports both together, so cosigning peers see the same total as before. `SwapFees` and `SwapFeesFiat` gain an optional `protocol` amount, which is included in `total`.

### Patch Changes

- [#2494](https://github.com/vultisig/vultisig-sdk/pull/2494) [`eff856a`](https://github.com/vultisig/vultisig-sdk/commit/eff856a9c6f5d56516688507a2abb59297437642) Thanks [@neavra](https://github.com/neavra)! - Update axios to 1.20.0 and @grpc/grpc-js to 1.14.5 to address published high-severity security advisories.

- [#2503](https://github.com/vultisig/vultisig-sdk/pull/2503) [`7785d05`](https://github.com/vultisig/vultisig-sdk/commit/7785d059e62c76f8393874d70f498a634d2bc6f9) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Stop reporting a Cardano broadcast as failed when another signing device already sent the same transaction. Every device in a keysign broadcasts the same bytes, and the node now answers the later ones with a mempool rejection (code 3997, "All inputs are spent. Transaction has probably already been included") instead of code 3117. The fallback hash lookup gave up after about 3 seconds, before the first copy could be in a block, so the device that lost the race showed "Failed to broadcast transaction" for a transaction that went through.

  That reply does not prove the transaction is the one that spent the inputs, so it is not accepted on its own. It now makes the hash lookup wait long enough for the next block (up to about two minutes): the broadcast is reported as sent once the hash is seen, and as failed if it never appears. The node's justification also replaces the message that only pointed at it ("A justification is given as 'data.error'").

- [#2456](https://github.com/vultisig/vultisig-sdk/pull/2456) [`2c09369`](https://github.com/vultisig/vultisig-sdk/commit/2c09369a981a5653a9eb129efe816b9158440803) Thanks [@realpaaao](https://github.com/realpaaao)! - Report which contract-price lookups failed, and cap a multi-batch CoinGecko fetch at 20 seconds. `getErc20Prices` still returns the price map.

- [#2483](https://github.com/vultisig/vultisig-sdk/pull/2483) [`d1b3bd2`](https://github.com/vultisig/vultisig-sdk/commit/d1b3bd2ec255eca8b18069b00086f31a5cc137b7) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Scope ML-DSA signing to ML-DSA chains. A vault holding an ML-DSA key share ran a
  full ML-DSA sign alongside every ECDSA/EdDSA sign, because the trailing blocks in
  `ServerManager.coordinateFastSigning` and both `RelaySigningService` signing paths
  were gated on `vault.keyShareMldsa` instead of the requested signature algorithm.

  That produced an ML-DSA signature over raw message hashes with no QBTC SignDoc
  binding and returned it on the public `Signature.mldsaSignature` field, so a
  non-QBTC sign could hand back QBTC-authorizing key material. It also cost relay
  signers a full `startKeysignWithRetry` cycle on every ordinary sign, and reused the
  DKLS session id and encryption key for the ML-DSA round.

  ML-DSA now runs only through the dedicated `signatureAlgorithm === 'mldsa'` paths,
  and `mldsaSignature` is only ever set from there.

- [#2484](https://github.com/vultisig/vultisig-sdk/pull/2484) [`0475c2b`](https://github.com/vultisig/vultisig-sdk/commit/0475c2bfbe12d1995e91e4c1e5a2b6da88aa7193) Thanks [@neavra](https://github.com/neavra)! - Tokens without a price source are no longer valued at 0: the SDK reports them as failures (new `getValuesDetailed`), and `vultisig portfolio` lists them with `value: null`, records each in `failures` with its token id, and sums only priced rows into the total.

  `vault.portfolio()` now returns partial results with an additive `failures` list instead of rejecting when one asset has no price source.

- [#2504](https://github.com/vultisig/vultisig-sdk/pull/2504) [`6a20f41`](https://github.com/vultisig/vultisig-sdk/commit/6a20f4130f73b9a0dc68a80b950876af4ae01f0a) Thanks [@PragmaticMonkey](https://github.com/PragmaticMonkey)! - Fix RUJI Trade (RUNE ↔ bRUNE) swaps to send FIN's untagged swap request with `min_return` and `to` directly under `swap`. The previous `{ swap: { min: { ... } } }` wrapper decoded on-chain as an unguarded Yolo swap, dropping the slippage guard and the recipient. Keysign now requires the flat form, and also rejects a `min_return` outside Uint128, which FIN would likewise treat as Yolo.

- [#2502](https://github.com/vultisig/vultisig-sdk/pull/2502) [`37e06d5`](https://github.com/vultisig/vultisig-sdk/commit/37e06d515baede9d05ab7e3e1d7cbe2b8218b330) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Co-sign SwapKit swaps that carry a pre-built Cardano transaction (`tx_type = "CARDANO_PREBUILT"`). SwapKit builds the whole transaction for this route and the initiator relays it in `tx_payload` as the CBOR envelope `[body, witness_set, is_valid, aux_data]`, but nothing handled that type: a co-signer rebuilt a native ADA send from `toAddress` / `toAmount` / `utxoInfo`, signed a different body than iOS and Android, and the keysign never converged. The envelope is now the signing input — the digest is blake2b-256 of its body bytes verbatim, and the signed transaction is the same envelope with the vault's vkey witness in place of item 1.

  No Verify screen shows that body, so it is validated against the vault's own key before any hash is produced. It must be a plain payment (only inputs, outputs, fee, ttl, validity start, aux-data hash and network id) in which exactly one output is an ADA-only deposit of at most `from_amount` and every other output pays the vault's enterprise address, with a fee of at most 2 ADA. The swap's source asset must be ADA, so that `from_amount` is a lovelace amount.

- [#2489](https://github.com/vultisig/vultisig-sdk/pull/2489) [`0b107b0`](https://github.com/vultisig/vultisig-sdk/commit/0b107b0741f036f7fd82afa163e167b2cdef15ce) Thanks [@neavra](https://github.com/neavra)! - Transaction status lookups on Sui, TON, Ripple, Polkadot, the UTXO chains, Cardano, QBTC and Bittensor now report `not_found` when the node or indexer has no record of the hash, matching EVM, Solana and Cosmos, instead of an indefinite `pending`. A hash the node knows about, or a lookup that fails transiently, still reports `pending`.

- [#2477](https://github.com/vultisig/vultisig-sdk/pull/2477) [`d5525e0`](https://github.com/vultisig/vultisig-sdk/commit/d5525e0ae236338faeaabfd76314af5ddd50dd96) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(vault): `unlock()` now verifies the password even when key shares are already loaded, and a wrong password no longer replaces or clears a previously cached one

- Updated dependencies [[`7785d05`](https://github.com/vultisig/vultisig-sdk/commit/7785d059e62c76f8393874d70f498a634d2bc6f9), [`2c09369`](https://github.com/vultisig/vultisig-sdk/commit/2c09369a981a5653a9eb129efe816b9158440803), [`60acf82`](https://github.com/vultisig/vultisig-sdk/commit/60acf82b0596d4345b77045365f94b7a6ee44e13), [`6a20f41`](https://github.com/vultisig/vultisig-sdk/commit/6a20f4130f73b9a0dc68a80b950876af4ae01f0a), [`0251a9b`](https://github.com/vultisig/vultisig-sdk/commit/0251a9bbb6ea85d178cef4846c1c8471aca04386), [`37e06d5`](https://github.com/vultisig/vultisig-sdk/commit/37e06d515baede9d05ab7e3e1d7cbe2b8218b330), [`0b107b0`](https://github.com/vultisig/vultisig-sdk/commit/0b107b0741f036f7fd82afa163e167b2cdef15ce)]:
  - @vultisig/core-chain@6.2.0
  - @vultisig/core-mpc@5.0.4

## 9.0.0

### Major Changes

- [#2487](https://github.com/vultisig/vultisig-sdk/pull/2487) [`5acb3d2`](https://github.com/vultisig/vultisig-sdk/commit/5acb3d27f15f081d518155c937295d208defdd84) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Remove 19 redundant package subpaths. Their functions and types remain available from the root or corresponding platform entry, with chain, seedphrase, and relay helpers grouped under `chainTron`, `chainUtxo`, `chainTon`, `seedphrase`, and `server`. `@vultisig/sdk/tools/defi` and all platform paths remain published. See `MIGRATING.md` for every path mapping.

### Minor Changes

- [#2472](https://github.com/vultisig/vultisig-sdk/pull/2472) [`0a09912`](https://github.com/vultisig/vultisig-sdk/commit/0a09912f54b2a7186a7299ce657d85dc31e5f5ed) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(seedphrase): accept every BIP39 mnemonic length (12, 15, 18, 21 and 24 words) in seedphrase validation, import and the CLI prompt. `SEEDPHRASE_WORD_COUNTS` is now `[12, 15, 18, 21, 24]`, which widens `SeedphraseWordCount`.

### Patch Changes

- [#2486](https://github.com/vultisig/vultisig-sdk/pull/2486) [`658aa00`](https://github.com/vultisig/vultisig-sdk/commit/658aa00a115c329808432014164980f543edf09b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Move React Native FormatJS polyfills to build-only dependencies so ordinary SDK installs no longer download their locale data. The polyfills remain embedded in the React Native bundle; React Native consumers do not need to add packages.

- [#2485](https://github.com/vultisig/vultisig-sdk/pull/2485) [`341f5ec`](https://github.com/vultisig/vultisig-sdk/commit/341f5ec2793e5b91ba69410bf35d82833f104632) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Preserve every digit in TRX balances with the new exact `balanceSunRaw` string and format `balanceTrx` from it. Keep `balanceSun` as a best-effort number for compatibility; it may round above `Number.MAX_SAFE_INTEGER` SUN (approximately 9.007 billion TRX). Reject invalid or duplicate account balance tokens while preserving existing TRON routing.

- [#2467](https://github.com/vultisig/vultisig-sdk/pull/2467) [`d83a5b0`](https://github.com/vultisig/vultisig-sdk/commit/d83a5b0c31f5d8f5ca8ecd6e586e16424596bed3) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Bitcoin PSBT keysigns (SwapKit BTC swaps and `signBitcoin` payloads) now broadcast the signed transaction and report its txid. The compiled output left `signingResultV2.encoded` and `txid` unset, and the UTXO broadcast resolver took the resulting empty bytes over the real transaction, posting `{"data":""}` to Blockchair and resolving an empty hash.

- [#2471](https://github.com/vultisig/vultisig-sdk/pull/2471) [`f49cbb0`](https://github.com/vultisig/vultisig-sdk/commit/f49cbb05cd20c6aa3411aa84ba8a09fc89284f07) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - A SwapKit Bitcoin PSBT carrying an input this vault cannot sign is now refused before the keysign ceremony, on the initiator and on every co-signer. `compileSignBitcoinTx` gives such an input an empty witness and still returns a complete-looking transaction, so the route signed it, broadcast it and let the network reject it after the user had already approved. Every input is checked against the vault's own address rather than the PSBT's `isOurs` flag, which `buildSignBitcoinFromPsbt` derives from BIP-32 data and defaults to true for every input when a PSBT carries none. The dApp `signPsbt` route is unaffected: its PSBTs may legitimately hold inputs owned by someone else and are returned partially signed rather than broadcast.

- [#2412](https://github.com/vultisig/vultisig-sdk/pull/2412) [`16b5a78`](https://github.com/vultisig/vultisig-sdk/commit/16b5a7860dce8a5bacf4759ff0260073c8cfb3e7) Thanks [@aminsato](https://github.com/aminsato)! - fix(tron): reject incomplete `getnowblock` / `getblockbynum` responses instead of zeroing the TAPOS header

  `getTronBlockInfo` defaulted every missing `block_header.raw_data` field to `0` / `''`, so a partial gateway response (or an `{Error}`-on-200 envelope) produced an all-zero header. WalletCore derived `ref_block_bytes` / `ref_block_hash` from it, the full MPC ceremony ran (including a Fast-Vault server co-sign), and the transaction could only fail on broadcast with `TAPOS_ERROR`. Both fetches now surface the gateway error message and reject any response missing `blockID` or a complete `raw_data`, before any signing starts. Header identifier fields (`txTrieRoot`, `parentHash`, `witness_address`) must also be hex of the exact protocol byte length, since `Buffer.from(value, 'hex')` would otherwise silently truncate malformed strings into the same broken header.

- [#2465](https://github.com/vultisig/vultisig-sdk/pull/2465) [`faffc26`](https://github.com/vultisig/vultisig-sdk/commit/faffc266efae199d638ae6bf8d45009896fcbee3) Thanks [@neavra](https://github.com/neavra)! - UTXO sends (Bitcoin, Litecoin, Dogecoin, Bitcoin Cash, Dash, Zcash) whose recipient amount is below the chain's static dust floor are now refused before signing with the minimum named in the error; fee-rate-dependent dust rejections above that floor instead explain that the current network dust threshold requires a larger amount. Additionally, a UTXO transaction plan that fails (dust, insufficient funds, or any other planner error) now fails authoritatively with that error instead of being retried as a send-max transaction, and deterministic dust or balance failures surface to CLI consumers as invalid input. Max-send and max-swap fee estimates now request a max spend explicitly instead of relying on the removed retry.

  An amount above the available balance now fails with an insufficient-balance error instead of being planned as a max spend.

  A non-max UTXO request is never converted to a max spend; a small remainder is left to WalletCore's dust handling.

- Updated dependencies [[`341f5ec`](https://github.com/vultisig/vultisig-sdk/commit/341f5ec2793e5b91ba69410bf35d82833f104632), [`d83a5b0`](https://github.com/vultisig/vultisig-sdk/commit/d83a5b0c31f5d8f5ca8ecd6e586e16424596bed3), [`f49cbb0`](https://github.com/vultisig/vultisig-sdk/commit/f49cbb05cd20c6aa3411aa84ba8a09fc89284f07), [`16b5a78`](https://github.com/vultisig/vultisig-sdk/commit/16b5a7860dce8a5bacf4759ff0260073c8cfb3e7), [`faffc26`](https://github.com/vultisig/vultisig-sdk/commit/faffc266efae199d638ae6bf8d45009896fcbee3)]:
  - @vultisig/core-chain@6.1.3
  - @vultisig/core-mpc@5.0.3

## 8.1.2

### Patch Changes

- [#2469](https://github.com/vultisig/vultisig-sdk/pull/2469) [`04b519b`](https://github.com/vultisig/vultisig-sdk/commit/04b519b60b11f515bff02f6caa47d5d5cf4df832) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reduce the SDK install size by sharing generated runtime and declaration chunks and omitting source maps from the npm package. Public import paths and APIs remain unchanged.

## 8.1.1

### Patch Changes

- [#2464](https://github.com/vultisig/vultisig-sdk/pull/2464) [`a55fda9`](https://github.com/vultisig/vultisig-sdk/commit/a55fda9325d071aa7717bf59c9ad328a0edd556b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the Arkis helper family as named imports from the SDK root and DeFi entrypoint.

- [#2462](https://github.com/vultisig/vultisig-sdk/pull/2462) [`25aafc6`](https://github.com/vultisig/vultisig-sdk/commit/25aafc62cb9f37488bdce24b02aff4ad2e77169c) Thanks [@realpaaao](https://github.com/realpaaao)! - fix(solana): read Stakewiz `total_apy` for validator APY — `apy_estimate` overstated realized staking yield by ~60% (8.1% vs ~5.1%)

- [#2459](https://github.com/vultisig/vultisig-sdk/pull/2459) [`ed67a44`](https://github.com/vultisig/vultisig-sdk/commit/ed67a4430ee97069eb07f505ab797a433a40d267) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - `getSwapArrivalStatus` now finds a THORChain or MayaChain swap that started on an EVM chain. THORNode and Midgard key a deposit by its hash without the `0x` prefix, so the prefixed hash an EVM chain returns read as `not_found` for as long as it was polled. The lookup now strips the prefix (and uppercases hex, leaving base58 signatures untouched), and the result still echoes the hash the caller passed. The deposit's own hash is also no longer mistaken for the destination while the outbound is unsent.

- [#2454](https://github.com/vultisig/vultisig-sdk/pull/2454) [`21eb4cf`](https://github.com/vultisig/vultisig-sdk/commit/21eb4cfdec42b2a01ac37fc61d47758c79c152aa) Thanks [@neavra](https://github.com/neavra)! - Transaction status lookups on Solana and Cosmos-family chains (THORChain, Maya, Cosmos Hub, …) now report `not_found` when the node has no record of the hash, matching EVM, instead of an indefinite `pending`. On Solana, a transient RPC failure and an unseen signature whose `lastValidBlockHeight` has not expired still report `pending`.

- Updated dependencies [[`25aafc6`](https://github.com/vultisig/vultisig-sdk/commit/25aafc62cb9f37488bdce24b02aff4ad2e77169c), [`ed67a44`](https://github.com/vultisig/vultisig-sdk/commit/ed67a4430ee97069eb07f505ab797a433a40d267), [`21eb4cf`](https://github.com/vultisig/vultisig-sdk/commit/21eb4cfdec42b2a01ac37fc61d47758c79c152aa)]:
  - @vultisig/core-chain@6.1.2
  - @vultisig/core-mpc@5.0.2

## 8.1.0

### Minor Changes

- [#2452](https://github.com/vultisig/vultisig-sdk/pull/2452) [`f77d12b`](https://github.com/vultisig/vultisig-sdk/commit/f77d12b2fa33ef8a79f59b6870513e1acdbc3b1c) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject StakeKit actions that lack complete signable transactions in all public builders, and export a typed finalization result and refusal error.

### Patch Changes

- [#2393](https://github.com/vultisig/vultisig-sdk/pull/2393) [`f4ad1b2`](https://github.com/vultisig/vultisig-sdk/commit/f4ad1b28b7fa50f484b7bad0a328b2aa45560647) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - An explicit "empty the account" send can now be initiated: `prepareSendTx`, `prepareSendTxFromKeys`, `send`, `estimateSendFee` and `getMaxSendAmount` accept `allowDeath`, both chain-specific resolvers record it in `PolkadotSpecific.allowDeath` and price that call, and the MAX/refinement keep nothing back for the existential deposit. The CLI gains `send <Polkadot|Bittensor> <to> --max --allow-death`, which discloses the reap before confirmation. Only set it for an explicit user choice; every co-signer must read the field.

- Updated dependencies [[`f4ad1b2`](https://github.com/vultisig/vultisig-sdk/commit/f4ad1b28b7fa50f484b7bad0a328b2aa45560647)]:
  - @vultisig/core-chain@6.1.1
  - @vultisig/core-mpc@5.0.1

## 8.0.1

### Patch Changes

- [#2414](https://github.com/vultisig/vultisig-sdk/pull/2414) [`2ad15b2`](https://github.com/vultisig/vultisig-sdk/commit/2ad15b2f87a74298a7d6baff8f45a42b8b627d25) Thanks [@gastonm5](https://github.com/gastonm5)! - Regenerate the keysign protobuf types so a custom-message signing request can carry the dApp that asked for it.

  `CustomMessagePayload` gains `dappMetadata?: DAppMetadata` (`optional DAppMetadata dapp_metadata = 6` in vultisig/commondata). Until now dApp identity travelled only on `KeysignPayload`, so message signing — `personal_sign`, EIP-712 typed data, Cosmos `signArbitrary`, and the hash-only Cardano `signTx` / `ton_proof` requests — reached co-signing devices with no indication of which dApp asked. The field is optional: leave it unset when there is no dApp, and such a payload encodes to the same bytes as before. All three values are declared by the initiating device and covered by no signature, so treat them as display-only.

  **Source-breaking import move for TypeScript consumers.** Both payload kinds now share the type, so upstream moved `message DAppMetadata` into its own `dapp_metadata.proto`. `DAppMetadata` and `DAppMetadataSchema` are no longer exported from `@vultisig/core-mpc/types/vultisig/keysign/v1/keysign_message_pb`; import them from `@vultisig/core-mpc/types/vultisig/keysign/v1/dapp_metadata_pb` instead. The old import fails at compile time rather than silently.

  Wire compatibility is preserved. `DAppMetadata` keeps its full message name and field numbers, and `KeysignPayload.dapp_metadata` stays at field 50, so existing payloads decode as before. The new `CustomMessagePayload` field is additive: devices on older versions skip it.

  `@vultisig/sdk` does not expose these types; it is bumped so its bundled copy of the generated code stays in step.

- [#2453](https://github.com/vultisig/vultisig-sdk/pull/2453) [`c3735f7`](https://github.com/vultisig/vultisig-sdk/commit/c3735f7418faba0549d070a4dfd3b48af3c1bd1f) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical QBTC address derivation helper from the root and React Native SDK entrypoints.

- [#2455](https://github.com/vultisig/vultisig-sdk/pull/2455) [`e5e5958`](https://github.com/vultisig/vultisig-sdk/commit/e5e5958176e539363bef3686004c7ada5ac6ba5f) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reserve Mantle L1 and operator fees correctly for native max sends.

- [#2451](https://github.com/vultisig/vultisig-sdk/pull/2451) [`8c58622`](https://github.com/vultisig/vultisig-sdk/commit/8c5862298a65712a05a6fc284ffaab9dc9381839) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Check the router minimum, final output asset, and receiver against the quoted swap immediately before EVM keysign payload construction for 1inch, Kyber, and same-chain LI.FI selectors that expose those fields. Reject 1inch and Kyber partial-fill calldata because its proportional floor does not guarantee the quoted absolute output. Packed-pool 1inch selectors retain a minimum and recipient check, but their hidden final asset remains unverified. Unsupported selectors and LI.FI bridge routes remain available and retain the aggregator trust boundary.

- [#2104](https://github.com/vultisig/vultisig-sdk/pull/2104) [`d7810e5`](https://github.com/vultisig/vultisig-sdk/commit/d7810e59cdc7f42681f1dd4e30e1d50e7dcde0f4) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add unit test coverage for the 10 previously-untested `tx/hash/resolvers` (evm/utxo/cosmos/solana/ton/tron/ripple/cardano/bittensor/polkadot) and the CoW swap order-status API. Fix the UTXO resolver to fall back to `transactionId` when WalletCore returns an empty V2 `txid`.

- [#2450](https://github.com/vultisig/vultisig-sdk/pull/2450) [`4110f68`](https://github.com/vultisig/vultisig-sdk/commit/4110f6846f8dcb8f3984e1f78ae00c3f26cf06d8) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the seedphrase import preflight helper and its types from `@vultisig/sdk/seedphrase`.

- [#2443](https://github.com/vultisig/vultisig-sdk/pull/2443) [`36b9013`](https://github.com/vultisig/vultisig-sdk/commit/36b901334b14177c7ddf4c1791fed96e249a05a1) Thanks [@neavra](https://github.com/neavra)! - Max swaps on THORChain and Maya routes now reserve the estimated source-chain network fee instead of subtracting the destination-asset outbound fee, size EVM native reserves and token fee summaries with the router deposit that is actually signed, fall back to the native minimum helper when a provider omits its recommendation, pin fee-aware requotes to the selected provider, clamp once when memo-dependent fees drift, expose the committed amount to callers, report the source-chain fee as the quote's network fee, and refuse a max swap that would fall below it.

- [#2390](https://github.com/vultisig/vultisig-sdk/pull/2390) [`b11c68e`](https://github.com/vultisig/vultisig-sdk/commit/b11c68e9876e86277fdca907fca6b6bbda40ea27) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Send an `approve(0)` reset before the approve when a USDT-style token would reject a non-zero to non-zero approve over a stale partial allowance. The need for the reset is stated on the wire (`Erc20ApprovePayload.reset_allowance_first`, commondata#111) so every co-signer builds the same extra leg. `buildCowSwapApprovalSigningInputs` (new) returns every approve leg in nonce order; `buildCowSwapApprovalSigningInput` stays exported as a deprecated single-leg form for existing consumers and throws, rather than dropping a leg, when the payload asks for the reset.

- [#2083](https://github.com/vultisig/vultisig-sdk/pull/2083) [`e2dd959`](https://github.com/vultisig/vultisig-sdk/commit/e2dd95998304b0678d1cd8ecdaa65de8fd9e32e2) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix `SwapService.extractFees` silently dropping the Vultisig affiliate fee for EVM aggregator routes (it never read `tx.evm.affiliateFee` at all) and for Solana routes (it folded the swap fee into `total` but never surfaced it as `affiliate`), so `SwapQuoteBase.fees.affiliate` is now populated whenever the aggregator returns a fee priced in the source chain's native token. Non-native-denominated affiliate/swap fees are left off both fields rather than being unsafely summed into a native-unit total. Extracted the fee-derivation logic into a standalone, unit-tested `extractSwapFees` helper.

- Updated dependencies [[`2ad15b2`](https://github.com/vultisig/vultisig-sdk/commit/2ad15b2f87a74298a7d6baff8f45a42b8b627d25), [`8c58622`](https://github.com/vultisig/vultisig-sdk/commit/8c5862298a65712a05a6fc284ffaab9dc9381839), [`d7810e5`](https://github.com/vultisig/vultisig-sdk/commit/d7810e59cdc7f42681f1dd4e30e1d50e7dcde0f4), [`36b9013`](https://github.com/vultisig/vultisig-sdk/commit/36b901334b14177c7ddf4c1791fed96e249a05a1), [`b11c68e`](https://github.com/vultisig/vultisig-sdk/commit/b11c68e9876e86277fdca907fca6b6bbda40ea27)]:
  - @vultisig/core-mpc@5.0.0
  - @vultisig/core-chain@6.1.0

## 8.0.0

### Minor Changes

- [#2440](https://github.com/vultisig/vultisig-sdk/pull/2440) [`23177e5`](https://github.com/vultisig/vultisig-sdk/commit/23177e5ec12fe0d3e23ffd8ad0a1b5fffbfe9e20) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the canonical Cosmos validator helpers and types from the SDK root and React Native entries.

- [#2441](https://github.com/vultisig/vultisig-sdk/pull/2441) [`8a690b5`](https://github.com/vultisig/vultisig-sdk/commit/8a690b5ae7ce5a249eab0ba0d0be1c63d7c10a85) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Publish dedicated EVM, Cosmos, and signable transaction package imports with runtime and declaration bundles.

### Patch Changes

- [#2427](https://github.com/vultisig/vultisig-sdk/pull/2427) [`b38628f`](https://github.com/vultisig/vultisig-sdk/commit/b38628f1ad09fa9dac3e23b2056b24c0040500fe) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Use prefix-aware WalletCore SS58 constructors for Bittensor address derivation and transaction destinations, including native iOS and Android bridges. Reject destinations with a different network prefix or invalid account data.

  Apply the Expo module Gradle plugin so Expo 56's required Kotlin compiler transformations run before Android module registration.

  Direct callers of `buildBittensorSigningPayload` must pass their initialized WalletCore as the second argument. Direct callers of `refineBittensorChainSpecific` must provide `walletCore` in the input. High-level SDK signing and fee estimation pass the existing runtime automatically.

- [#2435](https://github.com/vultisig/vultisig-sdk/pull/2435) [`2b91950`](https://github.com/vultisig/vultisig-sdk/commit/2b91950ffd1aa86b8afd710ab7c6d30f919ba9af) Thanks [@neavra](https://github.com/neavra)! - Reject mixed-case EVM recipient addresses whose EIP-55 checksum does not match. WalletCore accepted any `0x` + 40 hex regardless of letter case, so a one-character typo in a checksummed address passed `send`, max-send, fee estimation and `address-book --add`. All-lowercase and all-uppercase addresses are still accepted; the invalid-address error now names the checksum mismatch so it does not read as a formatting problem. `isValidTokenId` for EVM chains is now checksum-strict for mixed-case ids as well; the built-in token registry was corrected accordingly.

- [#2432](https://github.com/vultisig/vultisig-sdk/pull/2432) [`2620db4`](https://github.com/vultisig/vultisig-sdk/commit/2620db498bba40fbced5b5e256a260dccb12ad33) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject independently decoded EVM swap source-amount/asset mismatches and expired router deadlines during both vault-free and vault-wrapped preparation. Cover verified 1inch and Kyber layouts plus named Ethereum THORChain and Universal Router deployments. Native THOR deposits use transaction value, and known deadlines remain enforced when inner amounts or balance sentinels cannot be interpreted. Unknown layouts retain the existing quote binding and expiry safeguards; see `docs/evm-swap-commitments.md` for the coverage and residuals.

- [#2431](https://github.com/vultisig/vultisig-sdk/pull/2431) [`77b78da`](https://github.com/vultisig/vultisig-sdk/commit/77b78da36fc0d6032fb596bd3fbfd6dd84fb1d18) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical token price-ID resolver from the root and React Native SDK entry points.

- [#1990](https://github.com/vultisig/vultisig-sdk/pull/1990) [`42bb615`](https://github.com/vultisig/vultisig-sdk/commit/42bb615809a91fd6e8c304c7dba58b3c3c0f80c5) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fund a Cardano native-token (CNT) recipient output with a min-UTxO-satisfying lovelace floor instead of reusing the token quantity as the ADA amount. `keysignPayload.toAmount` for a CNT send is the token's own base-unit quantity, not lovelace; passing it straight through to `transferMessage.amount` produced outputs like 0.665 ADA for a 0.665 USDM send — below Cardano's min-UTxO requirement, so the network rejected the tx post-keysign (Ogmios 3125 "insufficiently funded outputs") after both co-signers had already converged on signing the doomed body.

- [#2444](https://github.com/vultisig/vultisig-sdk/pull/2444) [`30dd259`](https://github.com/vultisig/vultisig-sdk/commit/30dd259d7d495df27d4e59bb27fdf40a6879831d) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Derive seedphrase-scan addresses the same way the vault does. `deriveAddressFromMnemonic` used WalletCore's `getAddressForCoin`, so MayaChain came out as a `thor1…` address (Maya shares THORChain's coin type), Bittensor came out as a Polkadot address, and Bitcoin Cash kept the `bitcoincash:` prefix. The Maya balance lookup failed with "invalid Bech32 prefix; expected maya, got thor", which blocked chain discovery during seedphrase import. It now runs the key that key import stores through `getChainAddress`, like every vault address, and takes an optional `tonWalletVersion`.

  `MasterKeyDeriver.deriveAddress` (used by `ChainDiscoveryService`) and `deriveChainKey().address` now go through the same derivation. They had the same Bittensor and Bitcoin Cash problems, and built the Maya address from the uncompressed key, which pointed discovery at a different account.

  `getChainAddress` now deletes the WalletCore public key it builds, and `getPublicKey` deletes the intermediate compressed key it converts from for Tron. Both used to leak one WalletCore object per call.

- [#2439](https://github.com/vultisig/vultisig-sdk/pull/2439) [`ade50d1`](https://github.com/vultisig/vultisig-sdk/commit/ade50d15fa87b3379d24aaed793b1a76b05c863c) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Resolve token addresses and stored asset IDs by identity before symbols, including short IDs, so poisoned token symbols cannot redirect sends or balance lookups.

- [#2429](https://github.com/vultisig/vultisig-sdk/pull/2429) [`a58d6fb`](https://github.com/vultisig/vultisig-sdk/commit/a58d6fbb40fd05bc357fde4b60b8f5cb41639302) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject malformed UTXO balance responses, provider error envelopes, mismatched addresses, and unsupported numeric encodings instead of reporting a zero or truncated balance. Preserve exact large integer balances and explicit null/zero responses.

- [#2138](https://github.com/vultisig/vultisig-sdk/pull/2138) [`601ff4f`](https://github.com/vultisig/vultisig-sdk/commit/601ff4f1d1449d452b8e7025df392c1e2f4c5ca7) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Widen the public tx-normalization types to include camelCase routing metadata and accept camelCase normalization args, matching the metadata `splitMultiTx` already preserves at runtime.

- [#2426](https://github.com/vultisig/vultisig-sdk/pull/2426) [`c368202`](https://github.com/vultisig/vultisig-sdk/commit/c36820249569823bb3d3e24b06bcb66a34144f2a) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject all-zero Bittensor and Polkadot transfer destinations before producing signing inputs or unsigned transfer bytes, including alternate zero-account encodings accepted by the direct Bittensor builder.

- [#2279](https://github.com/vultisig/vultisig-sdk/pull/2279) [`4f73cf4`](https://github.com/vultisig/vultisig-sdk/commit/4f73cf425e63f8e0a9cd44e50920cb3f5f7561ad) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Reject duplicate denom entries in Osmosis coin lists before building join-pool, exit-pool, and concentrated-liquidity messages.

- [#2433](https://github.com/vultisig/vultisig-sdk/pull/2433) [`d190033`](https://github.com/vultisig/vultisig-sdk/commit/d190033bf7116466fc138197319c38d5e98e1c64) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Restore concrete argument types for lazy React Native SDK helpers.

- [#2428](https://github.com/vultisig/vultisig-sdk/pull/2428) [`4a79633`](https://github.com/vultisig/vultisig-sdk/commit/4a796338d0d15821cc39d8efc07cbd6e9a32e892) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the canonical StakeKit runtime helpers and companion types from the React Native SDK entrypoint.

- [#2101](https://github.com/vultisig/vultisig-sdk/pull/2101) [`371f012`](https://github.com/vultisig/vultisig-sdk/commit/371f0127f9e213f1f1779cdbc8e85ccaa2ec0caf) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-export `fromChainAmount` and `fromChainAmountDisplay` from the root and React Native SDK entrypoints. No amount-math behavior change — visibility only.

- [#2434](https://github.com/vultisig/vultisig-sdk/pull/2434) [`5f18a09`](https://github.com/vultisig/vultisig-sdk/commit/5f18a090def42d1cd910b708fd2dada848e1fe46) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the canonical StakeKit display parser, singular scan-request builder, and action validators through `defi.stakekit`.

- [#2057](https://github.com/vultisig/vultisig-sdk/pull/2057) [`9da4962`](https://github.com/vultisig/vultisig-sdk/commit/9da49628203c6b0a774d0f758e1b2935c2628fa5) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix `evmTxInfo` handing out a nonce that can collide with an external wallet's (e.g. MetaMask) not-yet-confirmed transaction. It fetched the nonce via `eth_getTransactionCount` with the default `'latest'` block tag, which only reflects confirmed transactions, so a pending external transaction from the same address could be assigned the same nonce and get stuck/dropped. It now prefers the `'pending'` block tag (which counts mempool-visible transactions too), falling back to `'latest'` for chains that don't support `'pending'` cleanly (zkSync Era, Hyperliquid, some alt-EVMs) — mirroring the RN `getEvmNonce` helper's existing convention.

- Updated dependencies [[`b38628f`](https://github.com/vultisig/vultisig-sdk/commit/b38628f1ad09fa9dac3e23b2056b24c0040500fe), [`2b91950`](https://github.com/vultisig/vultisig-sdk/commit/2b91950ffd1aa86b8afd710ab7c6d30f919ba9af), [`42bb615`](https://github.com/vultisig/vultisig-sdk/commit/42bb615809a91fd6e8c304c7dba58b3c3c0f80c5), [`30dd259`](https://github.com/vultisig/vultisig-sdk/commit/30dd259d7d495df27d4e59bb27fdf40a6879831d), [`c368202`](https://github.com/vultisig/vultisig-sdk/commit/c36820249569823bb3d3e24b06bcb66a34144f2a)]:
  - @vultisig/core-chain@6.0.0
  - @vultisig/core-mpc@4.0.0
  - @vultisig/walletcore-native@1.1.0

## 7.8.1

### Patch Changes

- [#2421](https://github.com/vultisig/vultisig-sdk/pull/2421) [`fa04ed0`](https://github.com/vultisig/vultisig-sdk/commit/fa04ed0d91f90bdaad101b326b47be1d73a152ce) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Preserve all native SOL movements before SOL/WSOL netting so transaction approval summaries cannot reverse direction by dropping a principal leg. Decline unsupported multi-asset shapes instead of assuming small native movements are fees.

- Updated dependencies [[`fa04ed0`](https://github.com/vultisig/vultisig-sdk/commit/fa04ed0d91f90bdaad101b326b47be1d73a152ce)]:
  - @vultisig/core-chain@5.6.1
  - @vultisig/core-mpc@3.4.1

## 7.8.0

### Minor Changes

- [#2406](https://github.com/vultisig/vultisig-sdk/pull/2406) [`abecd22`](https://github.com/vultisig/vultisig-sdk/commit/abecd22fcb409bcdbf50bbe1c068e531a19b08d1) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add gasless TON jetton sends through the TonAPI relay for W5 accounts. `prepareSendTx`, `send`, `getMaxSendAmount` and the vault-free prep helpers take `tonGasless`/`gasless`; the relay's quote is recorded in `TonSpecific.gasless` (new `TonGasless` message), validated by every signer against the approved transfer before hashing, signed as a W5 `internal_signed` request, and handed to the relay at broadcast. The fee of such a send is the relay commission in the jetton itself — `getKeysignFeeCoin` tells which coin a payload's fee is denominated in — and the status resolver finds the relayed transaction by the signed body's hash. The CLI's `send` command gains `--gasless`. Also fixes the seqno of a deployed W5 wallet: toncenter returns W5 accounts raw, so the seqno is now read from the data cell instead of defaulting to 0, which had every W5 send after the first rejected as a replay.

### Patch Changes

- [#2420](https://github.com/vultisig/vultisig-sdk/pull/2420) [`493da34`](https://github.com/vultisig/vultisig-sdk/commit/493da34ca8baad592b34f97947550415d74b3abf) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject invalid TAO transaction destinations before encoding: require a checksummed SS58 address with prefix 42 and a 32-byte account, including for direct transaction-builder calls.

- Updated dependencies [[`493da34`](https://github.com/vultisig/vultisig-sdk/commit/493da34ca8baad592b34f97947550415d74b3abf), [`abecd22`](https://github.com/vultisig/vultisig-sdk/commit/abecd22fcb409bcdbf50bbe1c068e531a19b08d1)]:
  - @vultisig/core-chain@5.6.0
  - @vultisig/core-mpc@3.4.0

## 7.7.0

### Minor Changes

- [#2409](https://github.com/vultisig/vultisig-sdk/pull/2409) [`ba9674d`](https://github.com/vultisig/vultisig-sdk/commit/ba9674d09e67c9510210325ec75d59d802cce995) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the StakeKit action address and amount validators from the root and React Native entrypoints.

- [#2408](https://github.com/vultisig/vultisig-sdk/pull/2408) [`17e72f4`](https://github.com/vultisig/vultisig-sdk/commit/17e72f42d33543612556ae2736d3f85e9190bed0) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the amount helper group through public imports and Vultisig instances, including amount.convert, while preserving existing flat conversion exports.

- [#2401](https://github.com/vultisig/vultisig-sdk/pull/2401) [`4969690`](https://github.com/vultisig/vultisig-sdk/commit/4969690ba037185a3ae873e295fd97cef71fec6a) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose `VaultBase.estimateSendFee()` with native fee-asset metadata for public fee previews.

### Patch Changes

- [#2418](https://github.com/vultisig/vultisig-sdk/pull/2418) [`c76da49`](https://github.com/vultisig/vultisig-sdk/commit/c76da49a67abbbf9fa18fd6f667187b3f24ef4ee) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Pass an explicit length limit to every bech32 decode. `fromBech32` defaults the limit to `Infinity`, which `@scure/base` >= 2.3 rejects, so in apps whose lockfile resolves that version every decode threw and QBTC address validation rejected all addresses (including the vault's own). THORChain address checks in RUJI trade quotes, limit-swap memos, swap keysign builds, Cosmos governance voting, and Rujira destination validation were affected the same way.

- [#2399](https://github.com/vultisig/vultisig-sdk/pull/2399) [`43a81cd`](https://github.com/vultisig/vultisig-sdk/commit/43a81cd1d2435cf6cb0dc50b56965772b2f26f07) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Prefer the first supported non-approval transaction for StakeKit's single scan request, while preserving the complete ordered scan list and approval-only fallback.

- [#2384](https://github.com/vultisig/vultisig-sdk/pull/2384) [`c5021d3`](https://github.com/vultisig/vultisig-sdk/commit/c5021d389795ab1c617f04d779b9f2216584717d) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Bittensor sends now encode `Balances.transfer_keep_alive` (pallet 5, call 3) instead of `transfer_allow_death`, so a normal TAO transfer can no longer reap the sender — matching the extrinsic iOS and Android already sign, which restores mixed-vault co-signing. `getMaxSendableAmount` (new in `@vultisig/core-chain/amount`) keeps the 500 rao existential deposit back on top of the fee, and both `getMaxSendAmount`/`getMaxSendAmountFromKeys` and the keysign amount refinement use it, so a MAX quoted as `balance - fee` is clamped to what a keep-alive transfer accepts. A dust send that would leave the destination below the existential deposit is rejected before the ceremony with `BuildKeysignPayloadError('bittensor-destination-below-existential-deposit')`. `buildBittensorSigningPayload` takes an explicit `allowDeath` opt-in for a future empty-the-account flow.

  The SDK is now a compatible co-signer for an explicit "empty the account" send: `PolkadotSpecific.allowDeath` (commondata) carries that intent from the initiator, and the Polkadot and Bittensor signing resolvers encode `transfer_allow_death` only when the payload says so, so the SDK signs the same bytes as an initiator that set it. Payloads that predate the field decode as keep-alive. The SDK does not offer the option to initiators yet; that waits until every platform's signer reads the field.

- [#2391](https://github.com/vultisig/vultisig-sdk/pull/2391) [`5c934c5`](https://github.com/vultisig/vultisig-sdk/commit/5c934c5c2d4a063729ef79f7d32d3af31f0232f5) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): do not report a failed jetton balance read as 0

  `getJettonBalance` turned two broken reads into a zero balance: a 2xx body with no `jetton_wallets` list (proxy or indexer error body) and a matching wallet with a missing or non-numeric `balance`. Both now throw, so the caller keeps its last known balance instead of showing 0 and computing MAX from it. An owner with no jetton wallet still resolves to 0, because on TON that wallet contract only exists once the owner has received the jetton.

- [#2405](https://github.com/vultisig/vultisig-sdk/pull/2405) [`dec0385`](https://github.com/vultisig/vultisig-sdk/commit/dec0385a8e3bf3a5a82e29853322bc84b834b5ff) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): send a swap deposit non-bounceable when nothing is deployed at the deposit address

  A swap deposit was always sent bounceable so that a router or escrow contract that rejects it refunds it. A provider that hands out a fresh deposit address per swap has no contract there yet, and TON cannot deliver a bounceable message to an undeployed account: it returns the funds minus gas, so every such swap came straight back to the sender and never started.

  The deployment check now runs before the swap rule. An undeployed destination goes out non-bounceable; a deployed one keeps bouncing on rejection, whatever the address tag declares. An account the indexer reports as `nonexist` (reached by a message, never deployed) counts as undeployed alongside `uninit`, for both the bounce flag and a Jetton transfer's destination-activity flag.

- [#2411](https://github.com/vultisig/vultisig-sdk/pull/2411) [`7d6428d`](https://github.com/vultisig/vultisig-sdk/commit/7d6428d05b04fc5f4e9e911127a93d8dff0b7161) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Route default Tron reads and broadcasts through Vultisig infrastructure with endpoint-compatible public fallback. Preserve transaction rejection and duplicate-status verification, and report unavailable status and energy-price data as errors.

- [#2400](https://github.com/vultisig/vultisig-sdk/pull/2400) [`fde308a`](https://github.com/vultisig/vultisig-sdk/commit/fde308a19566fe9daeebae3b458c8677a9627528) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reserve recipient account activation and its bandwidth charge when estimating native TRX fees and MAX sends. Reject invalid recipient lookups instead of returning an under-reserved estimate.

- [#2403](https://github.com/vultisig/vultisig-sdk/pull/2403) [`ac8b001`](https://github.com/vultisig/vultisig-sdk/commit/ac8b00134d01790217f38f316058b5f025f6508a) Thanks [@aminsato](https://github.com/aminsato)! - Sign TRON FreezeBalanceV2 / UnfreezeBalanceV2 with `fee_limit` set to the payload's `gasEstimation`, matching the iOS and Android signers, so desktop/extension co-signers hash the same pre-image as a mobile initiator in the same keysign ceremony (previously hardcoded to 0, producing divergent MPC preimages).

- [#2410](https://github.com/vultisig/vultisig-sdk/pull/2410) [`6063180`](https://github.com/vultisig/vultisig-sdk/commit/60631809016b0a3d8e304af424887e18ab10dafe) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject the Tron zero address in the shared destination guard before send payloads or custom-recipient swap quotes are built.

- Updated dependencies [[`c76da49`](https://github.com/vultisig/vultisig-sdk/commit/c76da49a67abbbf9fa18fd6f667187b3f24ef4ee), [`5672b46`](https://github.com/vultisig/vultisig-sdk/commit/5672b46e9f84a76dbae07dd0c616ca9d0d45da42), [`92596c8`](https://github.com/vultisig/vultisig-sdk/commit/92596c8f64fb162028f7d980bca7222d114f0a2a), [`c5021d3`](https://github.com/vultisig/vultisig-sdk/commit/c5021d389795ab1c617f04d779b9f2216584717d), [`5c934c5`](https://github.com/vultisig/vultisig-sdk/commit/5c934c5c2d4a063729ef79f7d32d3af31f0232f5), [`dec0385`](https://github.com/vultisig/vultisig-sdk/commit/dec0385a8e3bf3a5a82e29853322bc84b834b5ff), [`7d6428d`](https://github.com/vultisig/vultisig-sdk/commit/7d6428d05b04fc5f4e9e911127a93d8dff0b7161), [`fde308a`](https://github.com/vultisig/vultisig-sdk/commit/fde308a19566fe9daeebae3b458c8677a9627528), [`ac8b001`](https://github.com/vultisig/vultisig-sdk/commit/ac8b00134d01790217f38f316058b5f025f6508a), [`6063180`](https://github.com/vultisig/vultisig-sdk/commit/60631809016b0a3d8e304af424887e18ab10dafe)]:
  - @vultisig/core-chain@5.5.1
  - @vultisig/core-mpc@3.3.1

## 7.6.0

### Minor Changes

- [#2349](https://github.com/vultisig/vultisig-sdk/pull/2349) [`38bc8d4`](https://github.com/vultisig/vultisig-sdk/commit/38bc8d4bbae344cff8c6d5fd6b56bbf760831792) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Rebroadcast Solana transactions until they confirm or their blockhash expires, and report an expired transaction as `expired` instead of polling it as pending forever.

  `SolanaSpecific` gains `optional uint64 last_valid_block_height = 7` (vultisig/commondata), recorded by the chain-specific resolver next to the blockhash. `getKeysignLastValidBlockHeight` reads it back off a payload.

  The Solana broadcast resolver now resends the same signed bytes every 2 s while the signature is unseen, stopping at a confirmed sighting or once the chain's block height passes the payload's deadline (bounded by the newest blockhash's deadline when a payload predates the field). A miss fails with `SolanaBlockhashExpiredError` (`recovery: 'resign'`), exported from the SDK root with `toSolanaBlockhashExpiredError`, so a wallet can ask for a fresh signing ceremony rather than retrying dead bytes. That verdict requires a successful history lookup proving the signature never landed; when the lookup itself fails, accepted bytes stay pending for the status poll instead, so a transfer that landed while the status RPC was down is never reported as safe to re-sign. Broadcast resolvers accept an optional `lastValidBlockHeight`, which `BroadcastService` passes from the payload.

  The Solana status resolver returns `expired` (not `not_found`) for an unseen signature past `lastValidBlockHeight`; `pollTxStatusUntilFinal` and `verifyBroadcastByHash` forward the deadline.

### Patch Changes

- [#2385](https://github.com/vultisig/vultisig-sdk/pull/2385) [`b06ffc7`](https://github.com/vultisig/vultisig-sdk/commit/b06ffc7ad86d5c1f5d1d149748005a3b9a42c5d6) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Accept Celestia, Juno, Axelar, Neutron, and Injective destination names when preparing transfers over existing IBC routes.

- [#2387](https://github.com/vultisig/vultisig-sdk/pull/2387) [`4e7e0d7`](https://github.com/vultisig/vultisig-sdk/commit/4e7e0d79f516e49f68ee3ff4acc6f3d65c43e23e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the existing price helpers as a grouped price namespace from the SDK root, including React Native, while preserving all flat exports.

- [#2381](https://github.com/vultisig/vultisig-sdk/pull/2381) [`b8e3e9d`](https://github.com/vultisig/vultisig-sdk/commit/b8e3e9d236710e4ca9c8a4e9c27f98a9f5dec0d2) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject empty and whitespace-only `fromContractAddress` and `toContractAddress` in `buildJupiterSwapTx` before resolving fees or requesting a quote. Callers that used blank strings for native SOL must now omit the parameter or pass `SOL_NATIVE_MINT`. Nonblank mint addresses continue to be trimmed.

- [#2388](https://github.com/vultisig/vultisig-sdk/pull/2388) [`bdb9634`](https://github.com/vultisig/vultisig-sdk/commit/bdb96345b9f8914f508a10dca2952bf223aa3db2) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the canonical recipient sanity checks and their types through the React Native entry point.

- [#2382](https://github.com/vultisig/vultisig-sdk/pull/2382) [`5fc8468`](https://github.com/vultisig/vultisig-sdk/commit/5fc8468f3e64cc688981c836740a3b73541ec89e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical getTxStatus helper from the React Native entrypoint.

- [#2389](https://github.com/vultisig/vultisig-sdk/pull/2389) [`a7b4efa`](https://github.com/vultisig/vultisig-sdk/commit/a7b4efa3ffc11889c50593483ea240f414d94bdc) Thanks [@aminsato](https://github.com/aminsato)! - `buildSendKeysignPayload` now refuses known burn / program destinations (`assertSafeDestination`) on every chain, so a wallet send to the Solana System Program, the EVM zero address, a Bitcoin eater address or an XRPL black-hole account is rejected before the ceremony — the same guard the SDK's vault-free agent prep helpers already applied. The rejection surfaces as `BuildKeysignPayloadError('dangerous-destination')`; fee estimation through `getSendFeeEstimate` rejects the same destinations.

- [#2386](https://github.com/vultisig/vultisig-sdk/pull/2386) [`735299d`](https://github.com/vultisig/vultisig-sdk/commit/735299d1ad4206853b0442c17f7a5c90770d71be) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export `resolveChainIdReference` from the public SDK, including React Native, for exact decimal EVM and Cosmos chain-ID lookup without accepting chain names or aliases.

- Updated dependencies [[`a7b4efa`](https://github.com/vultisig/vultisig-sdk/commit/a7b4efa3ffc11889c50593483ea240f414d94bdc), [`38bc8d4`](https://github.com/vultisig/vultisig-sdk/commit/38bc8d4bbae344cff8c6d5fd6b56bbf760831792)]:
  - @vultisig/core-mpc@3.3.0
  - @vultisig/core-chain@5.5.0

## 7.5.0

### Minor Changes

- [#2116](https://github.com/vultisig/vultisig-sdk/pull/2116) [`7282cde`](https://github.com/vultisig/vultisig-sdk/commit/7282cdeffde92a3180a6e95556d783774be33a1a) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Hoist tool-output → signable-candidate derivation into `@vultisig/sdk` (`deriveToolOutputCandidate` and the fail-closed allowlists). CLI keeps the same import path as a thin re-export so consumers no longer have to copy CLI-local chain/field-name guards.

### Patch Changes

- [#2379](https://github.com/vultisig/vultisig-sdk/pull/2379) [`44d39da`](https://github.com/vultisig/vultisig-sdk/commit/44d39da6755d391ec1ca5aca47efc484377d17ca) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Keep every `@bufbuild/protobuf` entry point external in the platform bundles, not just the bare specifier. `@bufbuild/protobuf/wire` (and `codegenv2`, `wkt`) were being inlined, so the bundle carried its own copy of protobuf-es that registered a text-encoding provider — without `encodeUtf8Into` — on the global symbol protobuf-es shares with the consumer's copy. When SDK code ran first (as in a swap, where quotes precede signing) the consumer's newer `BinaryWriter` then failed with `this.encodeUtf8Into is not a function` while encoding the keysign message, and the keysign QR could not be generated.

- [#2004](https://github.com/vultisig/vultisig-sdk/pull/2004) [`d176e7a`](https://github.com/vultisig/vultisig-sdk/commit/d176e7a789a02aca0e01e4647dcf97dd59ca9746) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Normalize `fromChain` in `supportedIbcDestinationsFrom()` through the same `normaliseIbcChainId()` alias resolution `prepareIbcTransfer()` already applies. Route keys are built from IBC chain-IDs (`osmosis-1`, `cosmoshub-4`, ...), so calling `supportedIbcDestinationsFrom('Osmosis')` with a canonical Vultisig chain name returned an empty list even though `prepareIbcTransfer({ fromChain: 'Osmosis', ... })` accepted the exact same name — route discovery and route building disagreed on which names work.

- [#2380](https://github.com/vultisig/vultisig-sdk/pull/2380) [`dfa4f2c`](https://github.com/vultisig/vultisig-sdk/commit/dfa4f2c5f9dee0bb0b19ee778f44fb905ccacc89) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Publish the transaction preparation subpath with platform-specific bundles, shared WalletCore initialization, and typed deferred React Native helpers.

- [#2376](https://github.com/vultisig/vultisig-sdk/pull/2376) [`bddb19f`](https://github.com/vultisig/vultisig-sdk/commit/bddb19f060de790dc62cc3cc7cf2dfa14bd98a3b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical transaction-hash validator from the React Native SDK entrypoint.

- [#2375](https://github.com/vultisig/vultisig-sdk/pull/2375) [`9294e92`](https://github.com/vultisig/vultisig-sdk/commit/9294e920f33aa34ca2821e98fb0f0367bb72e9e6) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Retry temporary HTTP 429 responses when fetching Jupiter quotes or building unsigned swap transactions, with at most two retries after 300 ms and 600 ms. Other failures still surface immediately. Each attempt retains its own 15-second timeout.

- [#2374](https://github.com/vultisig/vultisig-sdk/pull/2374) [`7936aae`](https://github.com/vultisig/vultisig-sdk/commit/7936aae684222cf5f4f5e0815b362490c7df1f47) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Preserve base64 TON message hashes when querying transaction status so hashes containing plus signs resolve correctly.

- [#2368](https://github.com/vultisig/vultisig-sdk/pull/2368) [`d967120`](https://github.com/vultisig/vultisig-sdk/commit/d9671201970620ec6a0b60101307beb42155b37d) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - The Uniswap V3 tool tables now include Robinhood (4663) with the factory Uniswap publishes for the chain and its WETH9, which matches the WETH entry in the Robinhood token catalog. `supportedUniV3Chains()` lists Robinhood, `resolveNativeToken('native', 'Robinhood')` returns WETH9, and `uniswapV3PoolInfo` no longer reports Uniswap as undeployed there.

- [#2377](https://github.com/vultisig/vultisig-sdk/pull/2377) [`4b83d5b`](https://github.com/vultisig/vultisig-sdk/commit/4b83d5b41f25df005f869b90836d2e99d5dc230e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the balance, bridge, cosmos, decode, gas, prep, price, and swap helper groups on Vultisig instances.

- [#2089](https://github.com/vultisig/vultisig-sdk/pull/2089) [`b9e0fb7`](https://github.com/vultisig/vultisig-sdk/commit/b9e0fb73249e79ec7402f23e910acd7d99bdc72b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Exports `ensureTransactionsBuilt` from `@vultisig/sdk`, the StakeKit async transaction-materialization resolver (`CREATED` → `WAITING_FOR_SIGNATURE` PATCH loop for chains like Tron native staking whose payload builds in the background). Previously this was internal to `callYieldActionREST` only, so `agent-backend-ts` had to duplicate the same loop. Also fixes a real gap: the hosted-MCP path (`callYieldActionWithFallback`'s primary route for non-Tron yields) never applied this build step, so an async-build chain routed through MCP could return a success-shaped action response with `unsignedTransaction` still `null` — the same bug `agent-backend-ts` independently found and fixed (`ensureTransactionsBuilt` there, vultisig-ops-vecc). Both the SDK's REST and hosted-MCP paths now converge on the same fully-built response.

- [#2086](https://github.com/vultisig/vultisig-sdk/pull/2086) [`c69827d`](https://github.com/vultisig/vultisig-sdk/commit/c69827dbc5b8aa6f3bcfa4a50b7bb24147168a42) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Adds `assertTonSigningPayloadNoHostileDrain` (exported from `@vultisig/sdk/chains/ton` and the React Native TON bridge), a pure inspector for TON wallet-V4R2 signing payloads that refuses two unambiguous drains before any MPC signing happens: a non-zero wallet `op` (plugin install/remove, which grants ongoing spend authority without a further signature) and `SendMode.CARRY_ALL_REMAINING_BALANCE`/`SendMode.DESTROY_ACCOUNT_IF_ZERO` on any outgoing message (a full-balance drain/self-destruct). Previously this guard lived only in `vultiagent-app`, so any other SDK consumer of `buildTonTxFromSigningPayload` (yield.xyz staking actions, WalletConnect/dApp signing) had to duplicate the decoder or sign blindly.

- Updated dependencies [[`7936aae`](https://github.com/vultisig/vultisig-sdk/commit/7936aae684222cf5f4f5e0815b362490c7df1f47)]:
  - @vultisig/core-chain@5.4.3
  - @vultisig/core-mpc@3.2.4

## 7.4.2

### Patch Changes

- [#2363](https://github.com/vultisig/vultisig-sdk/pull/2363) [`75e33dc`](https://github.com/vultisig/vultisig-sdk/commit/75e33dce10203bcbd95cf334770b6cb893d80237) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical TRON address conversion and TRC-20 ABI encoding helpers from the root and React Native SDK entrypoints.

- [#2359](https://github.com/vultisig/vultisig-sdk/pull/2359) [`1ec5c2a`](https://github.com/vultisig/vultisig-sdk/commit/1ec5c2aec8499ef009c248bfd714720c07798315) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Robinhood (4663) now declares the canonical Multicall3 on its viem chain, so balance discovery batches the whole token catalog in one call instead of falling back to one `eth_call` per token against the public RPC. The contract is deployed there with bytecode identical to the Ethereum and Base deployments; only the public deployment registry had not listed the chain. Also records that KyberSwap's MetaAggregationRouterV2 keeps its standard address on Robinhood: `/routes` and `/route/build` on the `robinhood` API path both return `0x6131b5fae19ea4f9d964eac0408e4408b66337b5` with buildable calldata, so the flat Kyber allowlist was already correct.

- [#2365](https://github.com/vultisig/vultisig-sdk/pull/2365) [`b3cebc6`](https://github.com/vultisig/vultisig-sdk/commit/b3cebc63b1222d8bc41ef9e8fae8e0e470042519) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical token reference resolvers and their result type from the SDK root and React Native entry points.

- [#2371](https://github.com/vultisig/vultisig-sdk/pull/2371) [`663fddf`](https://github.com/vultisig/vultisig-sdk/commit/663fddfd336f3acf990a5b5d470a0962c7b9fade) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Publish the existing swap helpers through the dedicated `@vultisig/sdk/tools/swap` entry with ESM, CommonJS, and TypeScript declarations.

- [#2369](https://github.com/vultisig/vultisig-sdk/pull/2369) [`42ef35c`](https://github.com/vultisig/vultisig-sdk/commit/42ef35c4542e1289b6a4e70437d31fe917f9bd22) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the balance, prep, and swap helper groups on the root and React Native SDK surfaces while preserving existing flat exports and React Native's deferred preparation and balance wrappers.

- [#2370](https://github.com/vultisig/vultisig-sdk/pull/2370) [`257729d`](https://github.com/vultisig/vultisig-sdk/commit/257729dbc65abb142e543162f6f67eb6f1c68a11) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject known burn destinations and transfers to the token's own contract in the standalone TRC-20 transfer helper.

- Updated dependencies [[`1ec5c2a`](https://github.com/vultisig/vultisig-sdk/commit/1ec5c2aec8499ef009c248bfd714720c07798315)]:
  - @vultisig/core-chain@5.4.2
  - @vultisig/core-mpc@3.2.3

## 7.4.1

### Patch Changes

- [#2362](https://github.com/vultisig/vultisig-sdk/pull/2362) [`e4d2594`](https://github.com/vultisig/vultisig-sdk/commit/e4d2594393043f89a99d1e38387cc139047f7af8) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Share Tron Base58Check validation across balance lookup, transaction building, and energy estimation, preserving the existing accepted address prefixes.

- [#2361](https://github.com/vultisig/vultisig-sdk/pull/2361) [`1cb2615`](https://github.com/vultisig/vultisig-sdk/commit/1cb2615acefd7f6f1170ab3340bb1d23d63ee1ca) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Preserve case-sensitive non-EVM token identifiers in curated lookups, discovery, and token-transfer guards. EVM addresses remain case-insensitive. Consumers of knownTokensIndex must use canonical non-EVM keys without lowercasing them; the shared getKnownToken helper applies the chain-specific matching rule.

- Updated dependencies [[`e4d2594`](https://github.com/vultisig/vultisig-sdk/commit/e4d2594393043f89a99d1e38387cc139047f7af8), [`1cb2615`](https://github.com/vultisig/vultisig-sdk/commit/1cb2615acefd7f6f1170ab3340bb1d23d63ee1ca)]:
  - @vultisig/core-chain@5.4.1
  - @vultisig/core-mpc@3.2.2

## 7.4.0

### Minor Changes

- [#2347](https://github.com/vultisig/vultisig-sdk/pull/2347) [`864dfcb`](https://github.com/vultisig/vultisig-sdk/commit/864dfcb375c474f5bcc6f79bf18aeb145489cc47) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Blockaid now covers Robinhood chain (4663) as `robinhood`. Transaction simulation and validation run for Robinhood dApp requests and swaps, so a Uniswap swap on Robinhood shows its balance changes on the verify screen instead of nothing. Because SwapKit's EVM source eligibility keys off Blockaid coverage, Robinhood also becomes a SwapKit source chain, with the returned router screened through the Blockaid address scan like every other covered EVM chain.

- [#2343](https://github.com/vultisig/vultisig-sdk/pull/2343) [`80ba27f`](https://github.com/vultisig/vultisig-sdk/commit/80ba27f30afbeb104a8cc5738b5942467d977c9e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Preserve requested affiliate rates and native recipient allocations on swap quotes, including explicit zero rates, without changing fees or transaction construction. The optional quote affiliate metadata is covered by the existing mutation fingerprint; older quotes retain an unknown rate.

### Patch Changes

- [#2351](https://github.com/vultisig/vultisig-sdk/pull/2351) [`e5ab020`](https://github.com/vultisig/vultisig-sdk/commit/e5ab020bca842fd92ddd8994946e1d0ea991c73d) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical Blockaid EVM chain map, supported-chain list, and type from the SDK, including its React Native entry.

- [#2352](https://github.com/vultisig/vultisig-sdk/pull/2352) [`341df52`](https://github.com/vultisig/vultisig-sdk/commit/341df52d63858f41172be2f61bde7c4ca694ad71) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject missing and malformed amounts before constructing Tron TRC20, Solana, Polkadot, Bittensor and Ripple issued-currency signing inputs. Preserve explicit zero trust-line limits and encode Solana amounts as unsigned uint64 values without overflow.

- [#2341](https://github.com/vultisig/vultisig-sdk/pull/2341) [`ea2e6b7`](https://github.com/vultisig/vultisig-sdk/commit/ea2e6b7f4fc005d93d0a31741f521d7539d3104e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject negative amounts before hexadecimal encoding so EVM and Cardano transaction inputs cannot silently contain empty amount bytes. Preserve existing encodings for non-negative values, including unsigned Long quantities.

- [#2354](https://github.com/vultisig/vultisig-sdk/pull/2354) [`4fe2d97`](https://github.com/vultisig/vultisig-sdk/commit/4fe2d977cac34de6d0cf0cfefafdb6d484253a56) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject off-curve Solana wallet recipients before preparing sends or fee estimates.

- [#2345](https://github.com/vultisig/vultisig-sdk/pull/2345) [`235282a`](https://github.com/vultisig/vultisig-sdk/commit/235282ad5e2e71eeefb6fa27bc4f84a05d99dd92) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Keep tiny positive EVM gas prices visible in gas comparisons and calculate native fee estimates from raw wei so display rounding cannot erase or inflate them. Rank fully priced comparisons by unrounded USD costs so fees that display as zero still select the cheapest chain.

- [#2344](https://github.com/vultisig/vultisig-sdk/pull/2344) [`f5b79a4`](https://github.com/vultisig/vultisig-sdk/commit/f5b79a4b3ba943a1e80c4f8c01ecf1cd137a155d) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject Tron gateway errors, empty contract balance results, and JSON-RPC errors instead of treating them as zero balances or decoding error messages. Preserve legitimate zero balances and propagate read failures to maximum-send callers.

- [#2342](https://github.com/vultisig/vultisig-sdk/pull/2342) [`598f32b`](https://github.com/vultisig/vultisig-sdk/commit/598f32beed52463606ab5a891bdbd285468f046b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject UTXO recipient amounts below the chain and recipient script's default dust threshold before preparing signing data. Preserve address-validation precedence and include Dogecoin's required fee surcharge for recipients below 0.01 DOGE in transaction building and coin selection. Fee estimation accepts an optional recipient amount for that surcharge.

- Updated dependencies [[`864dfcb`](https://github.com/vultisig/vultisig-sdk/commit/864dfcb375c474f5bcc6f79bf18aeb145489cc47), [`80ba27f`](https://github.com/vultisig/vultisig-sdk/commit/80ba27f30afbeb104a8cc5738b5942467d977c9e), [`341df52`](https://github.com/vultisig/vultisig-sdk/commit/341df52d63858f41172be2f61bde7c4ca694ad71), [`ea2e6b7`](https://github.com/vultisig/vultisig-sdk/commit/ea2e6b7f4fc005d93d0a31741f521d7539d3104e), [`4fe2d97`](https://github.com/vultisig/vultisig-sdk/commit/4fe2d977cac34de6d0cf0cfefafdb6d484253a56), [`f5b79a4`](https://github.com/vultisig/vultisig-sdk/commit/f5b79a4b3ba943a1e80c4f8c01ecf1cd137a155d)]:
  - @vultisig/core-chain@5.4.0
  - @vultisig/core-mpc@3.2.1

## 7.3.0

### Minor Changes

- [#2328](https://github.com/vultisig/vultisig-sdk/pull/2328) [`741272f`](https://github.com/vultisig/vultisig-sdk/commit/741272f8d3872afdf12d9487d2121dee04c2f363) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Carry a native swap's price impact in the keysign payload, so a co-signer can show it.

  A device joining a keysign renders its swap verify screen entirely from the `KeysignPayload` — it holds no quote. Price impact was never on the wire, so the initiator showed a `Price Impact` row and the joining device showed nothing, on the screen whose purpose is for both parties to confirm they are approving the same swap.

  `THORChainSwapPayload` gains `optional uint32 slippage_bps = 14` (vultisig/commondata#104), and `nativeSwapQuoteToSwapPayload` populates it from `quote.fees.slippage_bps`. MayaChain shares the message, so one field covers both native swap chains.

  The value is carried rather than re-derived on the joiner. A joining device has enough in the payload to rebuild the quote request, but pools move between initiating and joining, so a fresh quote returns a different figure — price impact would become the only term on that screen where the two devices legitimately disagree.

  The field is optional and left unset when the provider reports no slippage. Payloads from senders that predate it round-trip unchanged, and receivers are expected to hide the row rather than read an absent figure as zero.

- [#2325](https://github.com/vultisig/vultisig-sdk/pull/2325) [`7c95286`](https://github.com/vultisig/vultisig-sdk/commit/7c9528622702a1e6f10cd5ff72017779d25e509a) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - EVM fee quotes now size the gas reserve from the transaction itself instead of a flat 600k floor. An aggregator swap is signed with the larger of the route's own gas and 1.5x its simulation (1.5x the 600k default when it cannot be simulated, e.g. a token route quoted before its allowance exists); a THORChain or Maya swap deposit (any transaction carrying the native swap payload) takes a fixed 120k; a plain transfer, including a memo-carrying vault deposit that carries no swap payload, takes its simulation raised to a per-chain floor with no inflation (when it cannot be simulated, that floor plus the intrinsic cost of its memo calldata); a dApp or other contract call keeps 1.5x headroom over its simulation. Base-fee headroom drops from 50% to 20% (32% for swaps), legacy-priced chains (BSC) are priced from `eth_gasPrice` with no tip, and the tip is the highest recent 5th-percentile reward from `eth_feeHistory`, capped at the gas price, with per-chain floors (1 gwei on tip-auction chains, 30 gwei on Polygon, 20 wei on OP-stack rollups) and a zero tip on Arbitrum, Mantle and Robinhood.

  `getEvmFeeQuote`'s `minimumGasLimit` now only raises the value that stands in for a failed simulation and never a successful estimate. `getEvmTransferGasLimit`, `getEvmContractCallGasLimit` and `evmRouterDepositGasLimit` are exported from `@vultisig/core-chain/tx/fee/evm/evmGasLimit`, and `getEvmGasPrice` from `@vultisig/core-chain/tx/fee/evm/gasPrice`.

- [#2328](https://github.com/vultisig/vultisig-sdk/pull/2328) [`741272f`](https://github.com/vultisig/vultisig-sdk/commit/741272f8d3872afdf12d9487d2121dee04c2f363) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Move `slippage_bps` on a native swap quote from the top level into `fees`, where THORChain and MayaChain actually send it.

  `NativeSwapQuote.slippage_bps` was never populated: THORChain's `QuoteSwapResponse` has no such property, and its `QuoteFees` schema declares `slippage_bps` as a required integer. MayaChain's spec agrees. Because the field was optional, every consumer reading it silently got `undefined` rather than a compile error — which is how the price-impact row went missing in the desktop app and extension.

  `NativeSwapFees` now carries `slippage_bps?: number`, and the phantom top-level field is gone so the wrong read cannot compile. This is a type-only change; `getNativeSwapQuote` already spreads the response through verbatim, so no runtime behavior changes.

  Note that `slippage_bps` is the price impact alone and is not interchangeable with the neighbouring `total_bps`, which is the total fee relative to the amount out.

- [#2339](https://github.com/vultisig/vultisig-sdk/pull/2339) [`95cf397`](https://github.com/vultisig/vultisig-sdk/commit/95cf39722b8a4d3e197b26bcef9983ecef6c3703) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(solana): verified / unverified / scam classification for SPL tokens, and verified-only discovery

  Solana discovery kept a mint when a price id could be found for it. That hid legitimate tokens that simply had no CoinGecko listing, and did nothing about the airdropped counterfeits and zero-decimal spam a Solana wallet accumulates — a priced impostor was auto-added, an unpriced real token was not, and neither carried a label.

  `findSolanaCoins` now returns **verified mints only**, priced or not, mirroring TON. Zero-balance token accounts are skipped, Jupiter's search endpoint answers for a hundred mints per call instead of one call per token, CoinGecko ids come from its on-chain multi-token endpoint thirty mints per call, decimals come from the token account itself, and curated metadata wins for tokens we ship ourselves. When Jupiter cannot be reached, listed mints are still discovered from the registry's metadata; a failed price-id lookup, by contrast, fails the round instead of saving the token without a price id for good. Unverified and scam mints can still be added by hand, where the UI labels them.

  Verification lives in `@vultisig/core-chain/chains/solana/spl/verification`. The registry of verified mints (`chains/solana/spl/verifiedRegistry`) merges our curated Solana tokens with Jupiter's verified list, fetched once an hour and degrading to the curated list alone when unreachable. `resolveSolanaTokenVerification` is pure: a listed mint — or one Jupiter itself flags verified — is `verified`; an unlisted mint is `scam` when its symbol or name collapses onto a verified token's, and `unverified` otherwise. `getSolanaTokenVerification({ id, ticker })` is the one-call form for token rows and approval cards; a listed mint is answered from the registry alone, any other mint is judged by what it claims on Jupiter, falling back to the local ticker offline. The tiers are the chain-agnostic `TokenVerification` type.

  The symbol normaliser behind the counterfeit heuristic moves to `@vultisig/core-chain/coin/tokenSymbol` as `normalizeTokenSymbol`; `chains/ton/jetton/symbol` keeps exporting `normalizeJettonSymbol` as an alias. `coin/jupiter/api` gains `getJupiterTokens` (batched, keyed by mint, filtered to the mints asked for) and `getJupiterVerifiedTokens`, `SolanaJupiterToken` carries Jupiter's `isVerified` flag and `tags`, and `coin/coingecko/getCoingeckoId` gains the batched `getSolanaCoingeckoIds`. `getSolanaTokenMetadata` now fails with a clear error for a mint Jupiter does not index instead of a `TypeError`.

### Patch Changes

- [#2002](https://github.com/vultisig/vultisig-sdk/pull/2002) [`2e1ed70`](https://github.com/vultisig/vultisig-sdk/commit/2e1ed704ccd0a360eaf760f1258c7cd8a4401e22) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Net Solana Blockaid simulation diffs by resolved mint (native SOL and the WSOL mint share a bucket) before classifying the result as a `swap` or `transfer`. The wrap-then-spend case previously surfaced as a bogus "SOL to WSOL swap" whose destination amount was only the token account's rent-exempt residual, at up to ~29x smaller than the amount actually leaving. The reverse unwrap/close-account case now rejects the receive-only result instead of inventing a transfer. The parser now nets same-mint legs and only classifies as a swap when two distinct mints remain.

- [#2315](https://github.com/vultisig/vultisig-sdk/pull/2315) [`57e9b2d`](https://github.com/vultisig/vultisig-sdk/commit/57e9b2d64d4f05929cd5940e8b99967305c7a7b7) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Carry the SwapKit provider fee, its coin context, and the route name to a swap co-signer. A SwapKit route on a non-EVM source chain travels as `SwapKitSwapPayload`, which had no fee field, so the peer's verify screen showed the network fee alone and a total that understated what the swap costs — the initiator, holding the live quote, showed both. The transfer branch now resolves the same affiliate/service fee the EVM branch does, `buildSwapKeysignPayload` writes it to the payload's new `swap_fee` group, and `getKeysignSwapProviderName` appends the payload's `sub_provider` so a joiner reads `SwapKit (NEAR)` where the initiator does — on EVM and Solana routes too, whose payload now carries the same tag. Requires the commondata fields added for it; senders that predate them leave the fee absent rather than reporting a zero. A fee amount the proxy returns malformed is now reported as an unresolvable fee shape rather than failing the whole route, which the display-fee guard always intended.

- [#2071](https://github.com/vultisig/vultisig-sdk/pull/2071) [`1660307`](https://github.com/vultisig/vultisig-sdk/commit/1660307d08c68ab268868253bf35d4a278c6fbcb) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - The ThreeJane USDC helper family (`buildThreeJaneSupplyUsdc`, `parseUsdcAmount`, `THREE_JANE_ADDRESSES`) was implemented and internally used, but only its types were re-exported from the root `@vultisig/sdk` and `@vultisig/sdk/react-native` entrypoints — the values themselves were unreachable except through the `sdk.defi.threeJane` namespace or a deep import. Re-exported the values from both entrypoints (`parseUsdcAmount` aliased to `parseThreeJaneUsdcAmount` to avoid colliding with the existing CCTP bridge export of the same name — both re-export the same underlying helper), with identity-pinning regression tests on each surface.

- [#2042](https://github.com/vultisig/vultisig-sdk/pull/2042) [`5ab2fad`](https://github.com/vultisig/vultisig-sdk/commit/5ab2fad0f3a281c6aa2d277ede97a49cd51bead7) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - The StakeKit/yield.xyz SDK surface (`sdk.defi.stakekit`) exported `stakekitDetails`/`stakekitBuildEnter`/`stakekitBuildExit`/`stakekitBuildManage` typed as `Promise<object>`, and kept the yield.xyz network→canonical-chain mapper (`yieldNetworkToCanonicalChain`) private, despite both having stable, well-known shapes. Downstream consumers had to re-declare these shapes locally or fall back to `any`, and anyone needing the same network→chain bridge had to vendor the mapper. Added named result types (`StakekitDetailsResult`, `StakekitActionDisplay`, `StakekitActionResult`, `StakekitExitResult`), wired them onto the builder return types, and exported `yieldNetworkToCanonicalChain` from the SDK's public surface.

- [#2053](https://github.com/vultisig/vultisig-sdk/pull/2053) [`a087e51`](https://github.com/vultisig/vultisig-sdk/commit/a087e5115d7100eb5270679460746d03125b02b3) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the SDK's StakeKit network canonicalization helpers (`normalizeStakekitNetwork`, `STAKEKIT_NETWORK_ALIASES`, `yieldNetworkToCanonicalChain`) from the root and `sdk.defi.stakekit` namespace surfaces, and from `sdk.defi.stakekit` as `normalizeNetwork` / `NETWORK_ALIASES` / `networkToCanonicalChain`. These were previously private to the SDK's StakeKit module, forcing the app and backend to maintain their own copies of the same alias table (`bsc` -> `binance`, `avax` -> `avalanche-c`, etc.) that could silently drift on a StakeKit network add or rename.

- Updated dependencies [[`741272f`](https://github.com/vultisig/vultisig-sdk/commit/741272f8d3872afdf12d9487d2121dee04c2f363), [`7c95286`](https://github.com/vultisig/vultisig-sdk/commit/7c9528622702a1e6f10cd5ff72017779d25e509a), [`2e1ed70`](https://github.com/vultisig/vultisig-sdk/commit/2e1ed704ccd0a360eaf760f1258c7cd8a4401e22), [`741272f`](https://github.com/vultisig/vultisig-sdk/commit/741272f8d3872afdf12d9487d2121dee04c2f363), [`982d464`](https://github.com/vultisig/vultisig-sdk/commit/982d4645467272f32e33a2df20883c1a7171a7ee), [`95cf397`](https://github.com/vultisig/vultisig-sdk/commit/95cf39722b8a4d3e197b26bcef9983ecef6c3703)]:
  - @vultisig/core-mpc@3.2.0
  - @vultisig/core-chain@5.3.0

## 7.2.0

### Minor Changes

- [#2306](https://github.com/vultisig/vultisig-sdk/pull/2306) [`a5def09`](https://github.com/vultisig/vultisig-sdk/commit/a5def098e06cf7269174eb6840dc516d78ec55f9) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(ton): explain TON failures in plain language — seqno replay, expired deadline, fees, and the rest

  A TON send that fails today comes back as an opaque `exitcode=133` in a toncenter rejection, or as a bare `error` status with nothing attached. Those two codes — 133 (W5) / 33 (v4) for a replayed seqno and 136 / 36 for an expired `valid_until`, which is almost always a device clock that drifted — dominate TON support load, and the fix is different for each.

  `@vultisig/core-chain/chains/ton/failure` maps a failure to a `TonTxFailure`: a stable `reason` (`seqno-mismatch`, `expired`, `invalid-signature`, `wallet-id-mismatch`, `insufficient-funds`, `out-of-gas`, `invalid-destination`, `not-enough-jettons`, `jetton-unauthorized`, `action-failed`, `action-partially-failed`, `aborted`, `contract-rejected`), the phase it came from, the raw exit code, and an English `message` that says what happened and what to do ("make sure your device's date and time are set automatically, then send it again"; "keep about 0.05 TON spare for fees"). Compute-phase codes cover wallet v3/v4 and W5 alike, the TVM out-of-gas codes and the standard jetton wallet's 705/706 (707 and 709 stay generic: the reference contract reuses each for two unrelated checks); action-phase codes distinguish 36 (invalid destination) from the wallet's 36 (expired), and read 37 as not enough TON. Action code 40 stays generic on purpose: it reads "not enough funds, the message is too large, or its Merkle depth is too big", so it is a funding failure only when the node's own `no_funds` flag backs it, and any other unnamed code is treated the same way.

  A generic action-phase failure only claims "nothing was sent" when the node reports `msgs_created: 0`. Every Vultisig TON send goes out with `IGNORE_ERRORS`, under which a failing action is skipped and the rest still leave, so a batch can lose one transfer and deliver the others — telling that user to retry is how a transfer goes out twice. Without that evidence the failure is `action-partially-failed`, whose message says at least one transfer did not happen, that others may have, and to check the transaction history before sending again.

  `TxStatusResult` gains an optional `failure?: TxFailureInfo` (`reason`, `message`, `exitCode?`, `phase?`), which the TON status resolver now fills for every `error`. `broadcastTonTx` classifies a wallet-contract refusal at broadcast time: the failed result's `cause` is a `TonBroadcastRejectedError` carrying the same `failure`, its `message` is the human explanation, the original toncenter error stays in `cause`, and the refusal is marked non-retryable — resending the same bytes can only be refused again. A seqno refusal whose message is already on chain (a co-signer broadcast first) is still accepted through the existing hash verification. The types, `getTonTxFailure`, `parseTonBroadcastRejection` and `TonBroadcastRejectedError` are re-exported from `@vultisig/sdk`, including its React Native entry — RN broadcasts TON itself and its `broadcastTonTx` rejects with toncenter's raw `exitcode=<n>` text.

- [#2299](https://github.com/vultisig/vultisig-sdk/pull/2299) [`bcca32c`](https://github.com/vultisig/vultisig-sdk/commit/bcca32c885066e2bf224aa37d6666c68a3684956) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(ton): W5 (wallet v5r1) support as an explicit per-account opt-in

  Every Vultisig TON account has been hard-pinned to the V4R2 wallet contract. W5 is the default for new wallets in Tonkeeper and Telegram Wallet and is the gateway to what users now expect from TON — up to 255 messages per request instead of 4, lower fees, and relayer-paid ("gasless") transactions. WalletCore has supported it for a while; nothing here used it.

  A W5 wallet is a _different address_ for the same key, with its own balance, so this is not a switch: V4R2 stays the default everywhere and W5 is selected per account.

  - `@vultisig/core-chain/chains/ton/wallet` (new): `TonWalletVersion` (`'v4r2' | 'v5r1'`), `deriveTonAddress` for either contract, `resolveTonWalletVersion` to tell which contract an address is for a key, the W5 mainnet wallet id, and the per-contract message limits.
  - `vault.setTonWalletVersion('v5r1')` selects which of the key's two TON accounts the vault acts on: `send`, balances, swaps, fee estimation and every other address lookup follow it, so one selected account is used consistently. `vault.address(chain, { tonWalletVersion })` — like `deriveAddress` / `getChainAddress` / `deriveAddressFromKeys` — names a contract for a single lookup without changing the selection, so a client can show both accounts side by side for a migration flow.
  - Balance cache keys name a chain and an asset, not an account, so switching between the two accounts drops the balance scope and any fetch already in flight for the old account is neither cached nor announced: it still answers its own caller, but `balanceUpdated` carries no account identity, so emitting it after a switch would credit the old account's balance to the new one.
  - The keysign signing-input resolver derives the contract from the sender address — the payload has no wallet-version field, and every co-signer reaches the same answer from the shared vault key — and refuses an address that is neither of the key's wallets rather than assuming V4R2. W5 requests carry `IGNORE_ACTION_PHASE_ERRORS`, which the W5 code requires of every external action (its replay protection) and WalletCore enforces; the TON status resolver's action-phase check covers the blindness that flag would otherwise cause. Message counts are capped per contract.
  - The RN-safe builders (`buildTonSendTx`, `buildTonJettonTransferTx`, `buildTonTxFromSigningPayload`, `deriveTonAddress`, `prepareJettonTransferTxFromKeys`) take `walletVersion`; W5 uses the `signed_external` request layout with the signature appended, byte-identical to WalletCore. New `buildV5R1Wallet` / `TON_V5R1_WALLET_ID` alongside the V4R2 helpers.

  Golden vectors (`testdata/cross-encoder-golden/ton-w5-*.json`) pin the W5 pre-images and are verified against real WalletCore, including the full signed external message. Client-side migration UI (show both accounts, move funds, reconnect dApps) is separate work per platform.

### Patch Changes

- [#2321](https://github.com/vultisig/vultisig-sdk/pull/2321) [`f45627f`](https://github.com/vultisig/vultisig-sdk/commit/f45627f7a986a3491c4586363acbfbdaa5f6b9c3) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Decode modern and legacy Cosmos governance votes into a lossless action-specific shared envelope.

- [#1860](https://github.com/vultisig/vultisig-sdk/pull/1860) [`fd7507a`](https://github.com/vultisig/vultisig-sdk/commit/fd7507af5d9dc14938da80372bc3c1a8ec02a459) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Preserve snake_case StakeKit EIP-1559 `max_priority_fee_per_gas` hints when canonicalizing EVM yield steps.

- [#2043](https://github.com/vultisig/vultisig-sdk/pull/2043) [`052f2e3`](https://github.com/vultisig/vultisig-sdk/commit/052f2e3b56509c1ddc2bcc14f21d0d1a5ee5d674) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - The SDK already computed the canonical signing-algorithm (ECDSA vs EdDSA vs mldsa) decision per chain internally (`@vultisig/core-chain/signing/SignatureAlgorithm`), but never exposed it on the public `@vultisig/sdk` surface. First-party consumers (agent-backend's swap/get-address/get-receive-info tools) were re-declaring local EdDSA chain sets to make the same decision. `getSignatureAlgorithm` and `signatureAlgorithms` are now re-exported from the SDK root so consumers can import one canonical seam instead of duplicating the mapping.

- [#2047](https://github.com/vultisig/vultisig-sdk/pull/2047) [`231070e`](https://github.com/vultisig/vultisig-sdk/commit/231070ea811a79a84b43a98fadd80c2811071c94) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-export the canonical Cosmos Tendermint/Stargate RPC registry (`tendermintRpcUrl`) from both the root SDK entry (`packages/sdk/src/index.ts`) and the React Native entry (`packages/sdk/src/platforms/react-native/index.ts`). The core package already used this table for `StargateClient.connect(...)`, and the SDK already surfaced the adjacent Cosmos REST registry (`cosmosRpcUrl`), but downstream consumers needing an actual CosmJS/Stargate RPC connection had no public SDK import for it and were pushed toward mirroring a second local endpoint table.

- Updated dependencies [[`a5def09`](https://github.com/vultisig/vultisig-sdk/commit/a5def098e06cf7269174eb6840dc516d78ec55f9), [`bcca32c`](https://github.com/vultisig/vultisig-sdk/commit/bcca32c885066e2bf224aa37d6666c68a3684956)]:
  - @vultisig/core-chain@5.2.0
  - @vultisig/core-mpc@3.1.0

## 7.1.0

### Minor Changes

- [#2305](https://github.com/vultisig/vultisig-sdk/pull/2305) [`20de22f`](https://github.com/vultisig/vultisig-sdk/commit/20de22f49c244ffc065011291754f89ef0d6e61a) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(ton): jetton auto-discovery with verified / unverified / scam classification

  TON wallets get carpet-bombed with counterfeit jettons — fake USDT above all — and until now the SDK could neither find the jettons an address holds nor say which of them to trust: discovery covered EVM, Solana, Cosmos, Cardano and Ripple, and TON shipped nine curated jettons plus manual add. A wallet with no labels cannot protect a user from the most common TON scam.

  `findCoins` now supports `Chain.Ton` (`coinFinderChainKinds` gains `'ton'`). `findTonCoins` lists every jetton with a non-zero balance through the Toncenter proxy in one paged call — the indexer's symbol, name, decimals and logo ride along, so there is no follow-up call per jetton — and returns only jettons that pass verification. Curated metadata wins for jettons we ship ourselves.

  Verification lives in `@vultisig/core-chain/chains/ton/jetton/verification`. The registry of verified jettons (`chains/ton/jetton/verifiedRegistry`) merges our curated TON tokens with Tonkeeper's community-reviewed `ton-assets` whitelist, fetched once an hour and degrading to the curated list alone when unreachable. `resolveTonJettonVerification` is pure: a listed address is `verified`; an unlisted jetton is `scam` when the indexer flags it or when its symbol or name collapses onto a verified jetton's — `normalizeJettonSymbol` folds `USD₮`, Cyrillic `UЅDT`, `$USĐ₮` and full-width forms onto `USDT` — and `unverified` otherwise. `getTonJettonVerification({ id, ticker })` is the one-call form for token rows and approval cards; it judges the master by what it claims on chain, falling back to the local ticker offline. The tiers are the chain-agnostic `TokenVerification` type in `@vultisig/core-chain/coin/tokenVerification`.

  `chains/ton/api` gains `getOwnerJettonWallets` (paged, owner-filtered, one entry per jetton, with embedded master metadata) and `getJettonMastersMetadata` (batched, lenient master lookup keyed by lower-cased raw address), and `chains/ton/address` gains `tonAddressToRawKey`. `vault.discoverTokens(Chain.Ton)` and `Vultisig.discoverTokens` work for TON through the same path.

### Patch Changes

- [#2323](https://github.com/vultisig/vultisig-sdk/pull/2323) [`8a50970`](https://github.com/vultisig/vultisig-sdk/commit/8a50970438de64cdbeb281cf73925026e3ce3cf7) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Refuse XRPL issued-currency Payments the ledger would reject — a destination holding no trust line for the token, and an issuer that charges a transfer fee the payload cannot yet cover with a SendMax — instead of burning the fee on-chain. Accept the lowercase standard currency codes XRPL permits, report bad amounts and unusable destinations as domain errors, and pin both encoders against a shared issued-currency signing vector.

- [#2310](https://github.com/vultisig/vultisig-sdk/pull/2310) [`af6c643`](https://github.com/vultisig/vultisig-sdk/commit/af6c643e9afa39cb0b4432a01cec40e4de4d8ecc) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): let a dApp deadline tighten the signed expiry

  `getTonChainSpecific` always signed `expireAt = now + 600`, so the `valid_until` a TonConnect `sendTransaction` carries never reached the wallet message: a request with a 60-second window was signed with a ten-minute one, and a broadcast landing after the dApp's window could execute on chain while the dApp already treated it as expired and retried.

  `GetChainSpecificInput` now takes an optional `validUntil` (unix seconds) for `tonSpecific`. The signed `expireAt` is `min(now + 600, validUntil)` — the wallet's own window remains the ceiling — and a deadline already in the past fails the build instead of signing a transaction the network would reject. Callers that pass nothing keep the previous behaviour; co-signers read `expireAt` from the payload, so only what the initiator writes changes.

  The expiry is computed last, after the seqno, bounceability and jetton-metadata lookups: each is a network round trip, so a deadline still ahead when the build starts can be behind by the time it finishes, and the wallet's own ten-minute window now starts when the payload is finished rather than being partly spent on those lookups.

- [#2296](https://github.com/vultisig/vultisig-sdk/pull/2296) [`34f0faa`](https://github.com/vultisig/vultisig-sdk/commit/34f0faa7208ad594b8d18a3a2806c0f7867f2c85) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): cross-check SwapKit's `tx[]` transfer against the deposit address and amount it also returns

  A SwapKit `/v3/swap` response states the deposit destination in up to three independent fields — `targetAddress`, `depositAddress`, and the `tx[]` transfer array — and its size in two (`depositAmount`, `tx[0].amount`). The transfer builder took the first field that was present and never looked at the rest, so a response whose halves diverged (provider bug, API change, tampered payload) signed whichever field happened to win the precedence order while the others named a different recipient or a different size. Nothing downstream could tell.

  `buildTransferTx` now refuses a response that disagrees with itself, on either the destination or the amount, instead of resolving the ambiguity by precedence. It also rejects a multi-entry `tx[]` rather than silently signing only the first transfer and under-funding the swap.

  Destinations are compared per chain: TON spells one account as `EQ…`, `UQ…` or raw `workchain:hex`, so the new `areEqualTonAddresses` helper compares parsed accounts there, while every other transfer chain stays byte-for-byte (base58 is case-sensitive — normalizing case away would let two different addresses pass as one).

  The agreed TON destination is re-spelled in its bounceable (`EQ…`) form whichever field it came from. The agreement check treats `UQ…`, raw and `EQ…` spellings of one account as equal — correctly — but the signer reads the bounce flag off the spelling, so a route that won precedence with a `UQ…` or raw spelling would have sent the deposit non-bounceable, where a rejecting contract absorbs it instead of refunding. A destination that is not a TON address at all is refused.

- Updated dependencies [[`8a50970`](https://github.com/vultisig/vultisig-sdk/commit/8a50970438de64cdbeb281cf73925026e3ce3cf7), [`af6c643`](https://github.com/vultisig/vultisig-sdk/commit/af6c643e9afa39cb0b4432a01cec40e4de4d8ecc), [`20de22f`](https://github.com/vultisig/vultisig-sdk/commit/20de22f49c244ffc065011291754f89ef0d6e61a), [`34f0faa`](https://github.com/vultisig/vultisig-sdk/commit/34f0faa7208ad594b8d18a3a2806c0f7867f2c85)]:
  - @vultisig/core-chain@5.1.0
  - @vultisig/core-mpc@3.0.1

## 7.0.0

### Major Changes

- [#2237](https://github.com/vultisig/vultisig-sdk/pull/2237) [`7d4c116`](https://github.com/vultisig/vultisig-sdk/commit/7d4c116cc7a940e96abf075790c4a387edd03987) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Remove Kujira (KUJI) chain support. Kujira wound down in 2025 and every RPC/LCD endpoint the SDK shipped for it is now dead (the polkachu hosts no longer resolve; publicnode 404s), so balances, sends, swaps, staking and governance on Kujira cannot function.

  `Chain.Kujira` / `CosmosChain.Kujira` are removed from the chain union, along with the Kujira entries in the chain registry, cosmos RPC/LCD/fee/gas/memo tables, SwapKit + Skip + native-swap routing, the Kujira token list, IBC chain-id mapping, governance config and address derivation.

  The IBC tables in `tools/prep/ibcTransfer.ts` are keyed by raw chain-ID rather than the `Chain` enum, so they are cleared explicitly: `kaiyo-1` is dropped from `IBC_CHAIN_REVISION` and the `osmosis-1/channel-259` route from `IBC_CHANNEL_DEST`. `supportedIbcDestinationsFrom('osmosis-1')` no longer advertises `kaiyo-1`, and `resolveSourceChannelByDestChain('osmosis-1', 'kaiyo-1')` returns `null`.

  `COSMOS_CHAIN_ID_HRP` keeps its `kaiyo-1` → `kujira` entry: it is a pure bech32-prefix lookup that makes nothing routable, and it is still needed to decode historic `kujira1…` addresses.

  The `chains/cosmos/thor/kujira-merge` module is intentionally **kept**: it describes the six Kujira-origin tokens (KUJI, rKUJI, FUZN, NSTK, WINK, LVN) that migrated onto THORChain as `thor.*` secured assets, plus their IBC representations on Cosmos Hub and Osmosis. Those assets are unaffected and keep resolving.

  Consumers holding a persisted `Chain.Kujira` value must drop it — the symbol no longer type-checks.

### Minor Changes

- [#2298](https://github.com/vultisig/vultisig-sdk/pull/2298) [`1716a79`](https://github.com/vultisig/vultisig-sdk/commit/1716a7946bf617ff16f8bb15f33b279efbb4a87d) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): one correct comment validator, run before the user signs

  TON comment length was checked against a fixed 123 bytes wherever it was checked at all. That number is right for a native transfer, where the comment is the message body's own cell, and wrong for a jetton transfer, where the comment rides inline in the transfer body's `forward_payload` and shares one 1023-bit cell with the opcode, query id, amount, both addresses and the forward amount. The real jetton cap is roughly 34–39 bytes and SHRINKS as the amount grows, because `VarUInteger 16` widens a byte at a time. Anything above it reached WalletCore, which refuses to pack the cell and fails the keysign with a bare "Internal error" — after the user had reviewed and approved the transaction. Memos are load-bearing on TON; an exchange deposit without the right one loses the funds.

  New `@vultisig/core-chain/chains/ton/comment` owns the rule for both shapes: `tonNativeCommentMaxBytes`, `getTonJettonCommentMaxBytes({ amount, isActiveDestination })`, `getTonCommentMaxBytes` for a send form that wants to count down against the real limit, and `validateTonComment`. The amount-dependent widths are measured by encoding them, not predicted, and a test drives real WalletCore at each cap and one byte past it to prove the two agree.

  `buildSendKeysignPayload` now validates the memo at the end of the build, where the final signed amount and `isActiveDestination` are both known, and raises a non-retryable `BuildKeysignPayloadError('ton-memo-too-long')`. That moves the failure from keysign to the point where the payload is assembled — the verify screen — for every consumer, with no client-side change. The signing-input resolvers still validate, so a payload built by another device or an older client cannot get an unpackable comment signed here either.

  **Breaking:** `validateTonComment` is no longer exported from `@vultisig/core-mpc/keysign/signingInputs/resolvers/ton/native`, and takes `{ memo, jetton? }` instead of a bare string. Import it from `@vultisig/core-chain/chains/ton/comment`. `validateTonMemo` in the SDK's TON surface keeps its signature and gains an optional second argument for jetton context.

- [#2318](https://github.com/vultisig/vultisig-sdk/pull/2318) [`26a83ed`](https://github.com/vultisig/vultisig-sdk/commit/26a83ed417c9543f9c92d28cbb1bd35f0f914817) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fix TRON transaction lifecycle safety across fee preparation, status polling, and broadcast. Native TRX bandwidth estimates now measure the WalletCore-serialized signed transaction including memo bytes, default transaction times use the fetched block timestamp, expired raw transactions terminate polling, and successful broadcasts must return the deterministic local transaction hash.

- [#2316](https://github.com/vultisig/vultisig-sdk/pull/2316) [`b19c5d5`](https://github.com/vultisig/vultisig-sdk/commit/b19c5d56f4d00d92493f8da74ff80d92b1d87c68) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add exact XRP Ledger issued-currency Payments and authoritative delivered-amount receipts for XRP, issued currencies, and MPTs while preserving native XRP and explicit TrustSet behavior.

### Patch Changes

- [#2295](https://github.com/vultisig/vultisig-sdk/pull/2295) [`27dfd44`](https://github.com/vultisig/vultisig-sdk/commit/27dfd44fe6002d84c6f1e57ed0729ec22303a749) Thanks [@neavra](https://github.com/neavra)! - Refresh EIP-1559 priority fees immediately before CLI signing so zero-tip transactions use the live RPC suggestion, respect canonical per-chain minimums, and never exceed `maxFeePerGas`. Broadcast rejection messages now retain the actionable RPC reason without exposing the signed raw transaction.

- [#2308](https://github.com/vultisig/vultisig-sdk/pull/2308) [`1b3fb49`](https://github.com/vultisig/vultisig-sdk/commit/1b3fb498ad3f78b84b92b9f09b41fe8956fc5e9a) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Open SwapKit routing for HyperEVM sources and destinations and Robinhood destinations, while keeping Robinhood source swaps disabled until Blockaid supports chain 4663. Future EVM corridors can now use an unambiguous live SwapKit catalog identity without another static eligibility-list change, and catalog failures remain isolated from other quote providers.

- [#1996](https://github.com/vultisig/vultisig-sdk/pull/1996) [`a56c7cb`](https://github.com/vultisig/vultisig-sdk/commit/a56c7cb2b1bcfa74edcee0ae7e5552f830804734) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the `ChainDiscoveryAggregate` type from the public SDK seedphrase and root entrypoints so consumers can import the aggregate result returned by seedphrase discovery without restating the contract locally.

- [#2303](https://github.com/vultisig/vultisig-sdk/pull/2303) [`bd15294`](https://github.com/vultisig/vultisig-sdk/commit/bd15294a739c7977b26704b7b6df38e83e6bda23) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose `BroadcastPartialFailureError` directly for failures after any transaction has been submitted.

- [#2319](https://github.com/vultisig/vultisig-sdk/pull/2319) [`7b65284`](https://github.com/vultisig/vultisig-sdk/commit/7b65284f7fe73f538283a201a416efdbbda0830c) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject checksum-invalid or wrong-network Dash, Zcash, Ripple, and Tron destinations when building or parsing THORChain limit-swap memos.

- [#2282](https://github.com/vultisig/vultisig-sdk/pull/2282) [`a711b6c`](https://github.com/vultisig/vultisig-sdk/commit/a711b6ca8a8a7ae39d0efbb1c919b23b6538a1b8) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): derive each dApp message's bounce flag from its own destination

  A dApp `signTon` batch stamped every message with the single wallet-level `TonSpecific.bounceable`, which the chain-specific resolver computes from the first message's destination alone. The bounce bit a message declares lives in its own address tag — `EQ…`/`kQ…` bounceable, `UQ…`/`0Q…` not, a raw `workchain:hex` address none — so a batch with mixed destinations, or a first destination that is not yet deployed, signed the wrong bit on some of its messages, and a co-signer deriving the flag per address computed a different hash for the same payload.

  Each dApp message now takes the flag from its own destination (`getTonMessageBounceable` in `@vultisig/core-chain/chains/ton/messageBounce`); a raw `workchain:hex` address carries no tag, so it defaults to bounceable — an already-deployed contract must refund a rejection — unless the message carries `stateInit`, the deployment case whose destination has no code yet to bounce from. Every raw spelling WalletCore signs counts as the same account here: leading zeros, an explicit sign and a `0x`-prefixed hash all name one address and compile to one pre-image, so `00:<hash>` cannot be signed non-bounceable while `0:<hash>` is signed bounceable. App-initiated single sends are unchanged and keep the wallet-level flag and the nominator-pool override.

  The bounce bit is part of the signed body, so TON signing hashes move for dApp batches whose destinations do not all share the first message's flag. Co-signers must apply the same per-message rule.

- [#2255](https://github.com/vultisig/vultisig-sdk/pull/2255) [`ef6a8bb`](https://github.com/vultisig/vultisig-sdk/commit/ef6a8bb0007c6576179e5a8cb10aa47820075b57) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): send swap deposits bounceable so a rejected deposit is refunded

  TON transfers were marked bounceable only when the destination string started with `E`. Swap providers hand back deposit addresses in the `UQ…` (non-bounceable) form, so every TON swap deposit went out non-bounceable — and a router or escrow contract that rejects a message (expired quote, paused pool, closed route) _absorbs_ a non-bounceable transfer instead of returning it. The funds were gone.

  Swap deposits are now always sent bounceable. The prefix check is replaced by a real read of the address's bounce tag, so raw `0:hex` destinations — which declare no bounceability at all and which the prefix check silently treated as non-bounceable — default to bounceable, the safe side for anything that might be a contract. Sends to an undeployed account stay non-bounceable, since such an account cannot accept a bounceable message, and an explicit `UQ…` destination is still honoured.

  Adds `getTonAddressBounceability` to `@vultisig/core-chain/chains/ton/address`.

- [#2048](https://github.com/vultisig/vultisig-sdk/pull/2048) [`4978c02`](https://github.com/vultisig/vultisig-sdk/commit/4978c02f08521600fc70fa6b4753bae5a589371b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Publish `@vultisig/sdk/chains/ton` and `@vultisig/sdk/abi` as stable subpath exports, following the same pattern already shipped for `./chains/tron` and `./chains/utxo`. Both helper modules already existed in the SDK source but were not reachable as a public package entrypoint, forcing downstream consumers (app/backend) to either deep-import private files or keep local copies of TON address/transfer helpers and TRC-20/ERC ABI encoders instead of importing them from the SDK.

- [#2055](https://github.com/vultisig/vultisig-sdk/pull/2055) [`8a2c126`](https://github.com/vultisig/vultisig-sdk/commit/8a2c126333bb1010cf859eef6a4876e7a20da18f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `extractCctpMessageFromReceipt`, a pure helper that decodes the canonical `MessageSent(bytes)` log from a CCTP burn tx receipt and returns the raw `message` bytes plus its `keccak256` `messageHash`. Previously every first-party consumer had to hand-roll this log decode/hash step to bridge `buildCctpBridge`'s burn output into the attestation poller and `buildCctpClaim`.

- Updated dependencies [[`1b3fb49`](https://github.com/vultisig/vultisig-sdk/commit/1b3fb498ad3f78b84b92b9f09b41fe8956fc5e9a), [`7d4c116`](https://github.com/vultisig/vultisig-sdk/commit/7d4c116cc7a940e96abf075790c4a387edd03987), [`7b65284`](https://github.com/vultisig/vultisig-sdk/commit/7b65284f7fe73f538283a201a416efdbbda0830c), [`1716a79`](https://github.com/vultisig/vultisig-sdk/commit/1716a7946bf617ff16f8bb15f33b279efbb4a87d), [`a711b6c`](https://github.com/vultisig/vultisig-sdk/commit/a711b6ca8a8a7ae39d0efbb1c919b23b6538a1b8), [`ef6a8bb`](https://github.com/vultisig/vultisig-sdk/commit/ef6a8bb0007c6576179e5a8cb10aa47820075b57), [`26a83ed`](https://github.com/vultisig/vultisig-sdk/commit/26a83ed417c9543f9c92d28cbb1bd35f0f914817), [`b19c5d5`](https://github.com/vultisig/vultisig-sdk/commit/b19c5d56f4d00d92493f8da74ff80d92b1d87c68)]:
  - @vultisig/core-chain@5.0.0
  - @vultisig/core-mpc@3.0.0

## 6.3.0

### Minor Changes

- [#2015](https://github.com/vultisig/vultisig-sdk/pull/2015) [`b2f63b7`](https://github.com/vultisig/vultisig-sdk/commit/b2f63b70c4dac0001f0f40521efa4412f1d9e1cb) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the Cardano transaction-validity policy: `getCardanoSendTtl`, `cardanoSlotOffset` and `cardanoBroadcastTtlSafetyMargin` are now reachable from the root and React Native entries. The TTL policy existed only inside the keysign resolver, so consumers building a Cardano transaction had no way to import it and hardcoded their own slot offset instead - which is how vultiagent-app ended up 10x off the value its own broadcast freshness guard judges transactions by. The keysign resolver now calls the same helper rather than re-deriving the offset.

- [#2007](https://github.com/vultisig/vultisig-sdk/pull/2007) [`536c320`](https://github.com/vultisig/vultisig-sdk/commit/536c32028bf1f66897bf018c19f36c298545841a) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Publish the canonical price helpers as a real `@vultisig/sdk/tools/price` subpath. The barrel existed in source but no export condition pointed at it, so `import '@vultisig/sdk/tools/price'` failed with `ERR_PACKAGE_PATH_NOT_EXPORTED` and consumers had to take the whole root surface or deep-import into `dist`. Adds the export conditions, the runtime bundle, the narrow declaration bundle, and packed-consumer smoke coverage.

- [#2253](https://github.com/vultisig/vultisig-sdk/pull/2253) [`c0c08f0`](https://github.com/vultisig/vultisig-sdk/commit/c0c08f0bd2337147d6b92ca7f391115edd7db62b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical IBC reverse route lookup across the SDK public surfaces so consumers can resolve source channels without rebuilding the route index.

### Patch Changes

- [#2297](https://github.com/vultisig/vultisig-sdk/pull/2297) [`c0eafeb`](https://github.com/vultisig/vultisig-sdk/commit/c0eafeb12df42cffa70ef6951c081a74383e5fa2) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Make the SDK package graph explicit and acyclic. Shared Bitcoin signing protobuf schemas now live in `@vultisig/mpc-types`, `@vultisig/core-mpc` preserves its existing schema subpath as a compatibility export, and SDK builds resolve the declared core packages through their published export maps.

- [#2019](https://github.com/vultisig/vultisig-sdk/pull/2019) [`78be14e`](https://github.com/vultisig/vultisig-sdk/commit/78be14ea9f1f011ded932ce6a9be5c19cf5694d0) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Publish `@vultisig/sdk/tools/policy` as a real package subpath with dedicated runtime and type bundles. The pure intent↔envelope policy diff layer (`policy.evaluate`, `policy.checkInvariants`, plus the underlying amount/chain-matching helpers) already existed and was re-exported from the root barrel, but consumers had no stable narrow surface to depend on and were pushed toward root-only imports or local wrappers.

- [#2029](https://github.com/vultisig/vultisig-sdk/pull/2029) [`76be65f`](https://github.com/vultisig/vultisig-sdk/commit/76be65fc297a43de6313b9dce3b096e6f764831a) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Route CCTP chain lookups through the SDK's canonical chain normalizer. `getCctpChain` was a raw object index, so `"base"` returned `undefined` while every other SDK helper accepts it, and callers had to pre-normalize for this one family. The CCTP builders now resolve the chain before the same-chain guard (so `('base', 'Base')` is still rejected rather than building a bridge from a chain to itself) and stamp the canonical chain name into the emitted envelope regardless of how the caller spelled it.

- [#1981](https://github.com/vultisig/vultisig-sdk/pull/1981) [`e23780f`](https://github.com/vultisig/vultisig-sdk/commit/e23780f0b292cd76e80c72c5ccdcdafebd73a735) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - `buildSplTransfer` now rejects known Solana burn/program destinations (System Program, SPL Token Program, Wrapped SOL mint, Incinerator) via the shared `assertSafeDestination` guard, closing a gap where its native-SOL sibling `prepareSendTxFromKeys` (guarded since [#1698](https://github.com/vultisig/vultisig-sdk/issues/1698)) rejected these but the SPL token path did not.

- [#1992](https://github.com/vultisig/vultisig-sdk/pull/1992) [`30499f8`](https://github.com/vultisig/vultisig-sdk/commit/30499f83f9909d8eb9bc1d310b25fdadb5c240e7) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `cronoschain` / `cronos chain` -> `cronos` to the StakeKit network alias map. `CronosChain` is the SDK's own canonical `Chain` id and was the one canonical id in StakeKit's supported set that did not round-trip: `balances({ network: 'CronosChain' })` sent the literal `cronoschain` upstream as an unknown slug and returned `[]`, which reads as "you hold nothing on Cronos" rather than "that network name was not understood".

- [#2003](https://github.com/vultisig/vultisig-sdk/pull/2003) [`534154b`](https://github.com/vultisig/vultisig-sdk/commit/534154b6e9daaffad5d2e4958af3ead5fa940f21) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Nest `validatorAddresses` inside `args` on the StakeKit `exit` REST fallback body, matching the `enter` path and the declared `{ integrationId, addresses, args }` wire shape. It was previously sent as a top-level sibling, outside the field the API contract declares — a validator-targeted unstake/withdraw over the REST fallback could silently lose its validator selection.

- [#2006](https://github.com/vultisig/vultisig-sdk/pull/2006) [`3d40017`](https://github.com/vultisig/vultisig-sdk/commit/3d400171facf1107472e827c4ef48d7dd99843f1) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Throw a domain error naming both unresolved chains when `getThorchainDepositAsset` can't resolve a native-swap chain id, instead of failing with a bare `Cannot read properties of undefined (reading 'toUpperCase')` TypeError on the secured-asset path (and silently building an invalid `chain: undefined` proto on the unsecured path). Also adds test coverage for the previously-untested CIP-8/CIP-30 `buildCoseStructures` CBOR encoders.

- [#2102](https://github.com/vultisig/vultisig-sdk/pull/2102) [`2869ae6`](https://github.com/vultisig/vultisig-sdk/commit/2869ae60bc157e2020a541e31a50afabef4e9edc) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add the missing `./server` export map entry (JS/CJS/DTS) so `@vultisig/sdk/server` is actually importable — the module existed but had no package.json subpath wiring. Packaging-only, no signing/broadcast behavior change.

- [#2252](https://github.com/vultisig/vultisig-sdk/pull/2252) [`ef252e4`](https://github.com/vultisig/vultisig-sdk/commit/ef252e40b590a6cad9f303f7aba743c617442f90) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): stop hiding action-phase failures on sends and in status

  Every TON send OR'd `IGNORE_ACTION_PHASE_ERRORS` into the wallet contract's send mode, which tells the contract to skip an outgoing transfer it cannot carry out instead of failing. The transaction then landed un-aborted with the seqno consumed and nothing moved, and the status resolver — which read only `aborted` and `compute_ph.exit_code` — reported it as confirmed. The user was told a transfer succeeded while the funds never left.

  The flag is now dropped from native, MAX, dApp `signTon`, and Jetton sends (both the WalletCore and the React Native builders), and `getTonTxStatus` reads the action phase (`success`, `no_funds`, `result_code`, `skipped_actions`) alongside the compute phase. A transaction the indexer knows but has not yet described stays pending instead of counting as success.

  Dropping the flag changes the signed body, so TON signing hashes move. Clients must upgrade together: a co-signer on an older build derives a different hash and the keysign fails. The mobile and cross-encoder golden corpora are re-recorded to the new values.

- [#2280](https://github.com/vultisig/vultisig-sdk/pull/2280) [`4e23e92`](https://github.com/vultisig/vultisig-sdk/commit/4e23e9205310e46564bc1782b57499b2a39d7a5f) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): refuse to build a Jetton transfer when the sender jetton wallet cannot be resolved

  A Jetton transfer is a message to the sender's _own_ jetton wallet, and that address was resolved with a swallowed failure: `TonSpecific.jettonAddress` starts as `''`, a failed lookup left it `''`, and `''` is not null or undefined, so every presence check downstream waved it through. The result was a signable transaction whose destination was the empty string — a failed network lookup producing a broadcastable transfer that moves nothing.

  The chain-specific resolver now throws when the lookup fails or comes back blank, keeping the underlying failure as the error's `cause`. It stays a plain `Error` rather than a `BuildKeysignPayloadError` because an RPC timeout or indexer lag is retryable, not bad user input.

  `buildJettonTransfer` rejects a blank jetton wallet address as well, so a payload built elsewhere — an older client, another device in a keysign — cannot get a destination-less transfer signed here either.

- [#2256](https://github.com/vultisig/vultisig-sdk/pull/2256) [`4561c65`](https://github.com/vultisig/vultisig-sdk/commit/4561c6584f62fa78d17546bcc119e31b6ea665cb) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ton): a MAX send signs the amount it displayed, and MAX is no longer guessed

  A TON MAX send showed the user `balance - fee` and then signed something else: `amount = 0` under `ATTACH_ALL_CONTRACT_BALANCE`, which tells the wallet contract to sweep whatever the balance happens to be when the transaction executes. Worse, nothing marked a send as MAX — it was inferred from `amount + fee >= balance`, so an ordinary send that landed near the balance was silently upgraded to a full-balance sweep.

  The signing path now always signs `keysignPayload.toAmount` under `PAY_FEES_SEPARATELY`, for MAX and ordinary sends alike; a MAX send is just `balance - fee` as an ordinary amount, and that fee is the reserve the send mode draws on. The signed bytes no longer depend on the flag at all.

  `sendMaxAmount` becomes an explicit input threaded from the caller (`prepareSendTx` / `prepareSendTxFromKeys` / `buildSendKeysignPayload` → `getChainSpecific`), defaulting to `false`, and is recorded in `TonSpecific` as description rather than instruction. Removing the inference also drops a balance lookup from every TON send.

  TON MAX sends that previously relied on the sweep to cover an amount larger than `balance - fee` will now fail on chain instead of moving more than was shown. Callers should pass the displayed `balance - fee` as `amount` and set `sendMaxAmount: true` alongside it.

- [#2061](https://github.com/vultisig/vultisig-sdk/pull/2061) [`fc876a7`](https://github.com/vultisig/vultisig-sdk/commit/fc876a7fb561041539cb257a814d078304de6857) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the canonical XRP destination/X-address normalization helpers (`decodeRippleXAddress`, `encodeRippleXAddress`, `isValidRippleXAddress`, `normalizeRippleDestination`, `RippleDestination`) from both the root `@vultisig/sdk` and `@vultisig/sdk/react-native` entrypoints. These already existed as pure SDK-core helpers and are already bundled into the RN platform build (via the XRP send-tx builder), but were not part of the public package surfaces, so first-party consumers had to deep-import `@vultisig/core-chain/chains/ripple/address` instead of staying on the SDK boundary. The CLI's `transaction.ts` now imports `normalizeRippleDestination` from `@vultisig/sdk`.

- [#2038](https://github.com/vultisig/vultisig-sdk/pull/2038) [`d08babd`](https://github.com/vultisig/vultisig-sdk/commit/d08babd96c36b193f8788605ed59871da1483ff3) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Publish `getBlockchairBaseUrl` (chain-scoped `${rootApiUrl}/blockchair/${chain}` URL builder) from the SDK's public surface. It already existed as SDK core's canonical Blockchair proxy-URL helper and is used internally by the UTXO status/broadcast resolvers, but was not re-exported from `@vultisig/sdk`, so first-party consumers (app, agent-backend) had to reconstruct the same path locally instead of importing one tested contract.

- [#2054](https://github.com/vultisig/vultisig-sdk/pull/2054) [`4292e31`](https://github.com/vultisig/vultisig-sdk/commit/4292e3127e56bc2c92f2ac7b0a2886fcb0445043) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Teach `decodeCosmosTx` (the shared bytes-oracle behind `decodeFromToolResult`) to decode `MsgBeginRedelegate` and `MsgWithdrawDelegatorReward` into the canonical `Envelope`, with two new `EnvelopeKind` values (`redelegate`, `withdrawReward`). The SDK could already build these two staking actions but not decode them back, so downstream safety surfaces (CLI WYSIWYS, app decoded-intent card, co-sign gate) degraded them to `unknown`. Redelegate's recipient is the destination validator and its source validator is preserved in `validatorSrcAddress`, so changing the source cannot produce an equivalent canonical envelope. Withdraw-reward's amount is left empty since the reward is computed on-chain, not carried on the wire. Cosmos governance vote decoding is intentionally left out of this patch — the SDK's vote envelope carries `proposalId`/`voteOption` fields that don't fit the existing `Envelope` shape (recipient/amount/asset), so adding it needs a shape decision rather than a mechanical decode addition.

- [#2096](https://github.com/vultisig/vultisig-sdk/pull/2096) [`d267ff6`](https://github.com/vultisig/vultisig-sdk/commit/d267ff66b9cf6d0b5898d40ec1f37cda6decb707) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - StakeKit's canonical yield scan surface used to be singular (`buildYieldActionScanRequest` returned only the first scannable step) and EVM-only, so multi-step yield actions couldn't hand every leg to a downstream scanner and non-EVM (Solana) steps fell back to a generic `unsupported: chain_not_supported` sentinel. Added `buildYieldActionScanRequests` (plural), returning one `ScanRequest` per `transactions[]` step 1:1, and a new `SolanaScanRequest` kind so Solana yield steps (which ship pre-built tx bytes directly in `unsignedTransaction`, same as the SDK's existing `canonicalizeSolanaStep` extraction) get a real scan request instead of the unsupported fallback. `stakekitBuildEnter`/`stakekitBuildExit`/`stakekitBuildManage` now attach both `scan_request` (singular, unchanged for backward compatibility) and `scan_requests` (plural, all steps) to their response envelopes. `buildYieldActionScanRequest` (singular) keeps its exact prior behavior.

- [#2094](https://github.com/vultisig/vultisig-sdk/pull/2094) [`5f7dd00`](https://github.com/vultisig/vultisig-sdk/commit/5f7dd007cb5026d7c3ebe414fa5952f3419df570) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Adds a batched, multi-network StakeKit balances helper (`fetchAllStakekitBalances`, `fetchStakekitBalancesBatch`, `chunkStakekitBalanceQueries`) exported from `@vultisig/sdk`'s stakekit defi builders. Queries `{network, address}` pairs directly across any number of networks, batched at the yield.xyz-enforced cap of 25 per request — unlike the existing single-network `stakekitBalances`, which requires a per-network `searchYields` round trip to enumerate yield IDs first. A single failing batch doesn't abort the others (partial data survives), but the whole call throws if every batch fails so a caller doesn't cache an empty result as a false positive. Previously this only existed as `vultiagent-app`'s local `yieldXyzPositions.ts` positions client.

- [#2093](https://github.com/vultisig/vultisig-sdk/pull/2093) [`bfe0292`](https://github.com/vultisig/vultisig-sdk/commit/bfe0292e3876fb7acc7044bac1b544c27aba8919) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Publishes token-transfer / ERC-20-calldata destination safety helpers alongside the existing burn-address guard (`assertSafeDestination`): `assertSafeTokenTransferDestination` (rejects a transfer whose recipient is itself a known token contract — not just its own, any registered token's), `isErc20TransferCalldata`, `decodeErc20Recipient`, `decodeErc20Approve`, and `decodeErc20RecipientFromSig`, all re-exported from `@vultisig/sdk`. Previously only `agent-backend-ts` had this guard family as a private fork; `packages/sdk/src/tools/prep/send.ts`'s inline own-token-contract check is now additionally backed by the registry-based guard (catching sends to a _different_ known token's contract, on top of the existing unconditional self-contract check).

- [#2092](https://github.com/vultisig/vultisig-sdk/pull/2092) [`acd0b2e`](https://github.com/vultisig/vultisig-sdk/commit/acd0b2eaa882669a399fb378e51244ed4199ee47) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Consolidates four independently-maintained, overlapping Cosmos-family bech32 HRP tables — `tools/cosmos/gov.ts`'s `CHAIN_HRP`, `tools/prep/ibcTransfer.ts`'s `IBC_CHAIN_HRP`, `tools/swap/skip/skipSwap.ts`'s `COSMOS_CHAIN_HRPS`, and `tools/token/resolveContract.ts`'s `CW20_CHAIN_PREFIX` — into a single canonical registry, `COSMOS_CHAIN_ID_HRP`/`getCosmosChainHrp` (`@vultisig/core-chain/chains/cosmos/cosmosHrp`). All four consumers now derive their HRP checks from the same source instead of hand-maintained local copies that could drift from each other. As a side effect, Skip swap address validation now also HRP-checks four chain-ids (`axelar-dojo-1`, `juno-1`, `stargaze-1`, `akashnet-2`) it previously had no entry for and silently skipped — strictly safer, not a behavior change for any chain that was already validated. Deliberately does not touch `utils/addressFormat.ts`'s separate `cosmosHRPByChain`/`cosmosValoperByChain` tables, which are keyed by a different (lowercase chain-tag) space and ported 1:1 from a Go reference for cross-language parity.

- [#2088](https://github.com/vultisig/vultisig-sdk/pull/2088) [`f86320b`](https://github.com/vultisig/vultisig-sdk/commit/f86320bcfbee02b2f27473ac41a042db307596f6) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Adds the AgentRouter / USDC checkout canonical primitive family under `@vultisig/sdk`'s EVM tools (`evm.*` / top-level): a USDC payment-chain registry (`USDC_PAYMENT_CHAIN_CONFIG`, `USDC_CONTRACTS`, `CHECKOUT_CHAIN_IDS`, `lookupUsdcPaymentChain`, `resolveUsdcPaymentContract`, `resolveUsdcPaymentChainId`), `formatCheckoutUsdcDisplay` (the half-away-from-zero microdollar → USD display formatter), and `encodeAgentRouterDepositWithMemo`/`decodeAgentRouterDepositWithMemo` (ABI-driven via viem, so decode now also recovers the memo, not just the token/amount head). Previously these lived as two independently-drifting hand-rolled copies in `vultiagent-app` and `agent-backend-ts` — a display-formatting mismatch between the two already produced a real bug (app issue [#2528](https://github.com/vultisig/vultisig-sdk/issues/2528)).

- Updated dependencies [[`c0eafeb`](https://github.com/vultisig/vultisig-sdk/commit/c0eafeb12df42cffa70ef6951c081a74383e5fa2), [`3d40017`](https://github.com/vultisig/vultisig-sdk/commit/3d400171facf1107472e827c4ef48d7dd99843f1), [`ef252e4`](https://github.com/vultisig/vultisig-sdk/commit/ef252e40b590a6cad9f303f7aba743c617442f90), [`4e23e92`](https://github.com/vultisig/vultisig-sdk/commit/4e23e9205310e46564bc1782b57499b2a39d7a5f), [`4561c65`](https://github.com/vultisig/vultisig-sdk/commit/4561c6584f62fa78d17546bcc119e31b6ea665cb), [`bfe0292`](https://github.com/vultisig/vultisig-sdk/commit/bfe0292e3876fb7acc7044bac1b544c27aba8919), [`acd0b2e`](https://github.com/vultisig/vultisig-sdk/commit/acd0b2eaa882669a399fb378e51244ed4199ee47)]:
  - @vultisig/mpc-types@0.3.0
  - @vultisig/core-chain@4.1.1
  - @vultisig/core-mpc@2.1.1
  - @vultisig/mpc-native@1.0.1

## 6.2.0

### Minor Changes

- [#2225](https://github.com/vultisig/vultisig-sdk/pull/2225) [`95edf12`](https://github.com/vultisig/vultisig-sdk/commit/95edf1264827d0a63baa9d0580817caf2dffdc9e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add a canonical raw EVM transaction-envelope keysign helper and use it in the CLI signing path.

- [#1389](https://github.com/vultisig/vultisig-sdk/pull/1389) [`e1e73cb`](https://github.com/vultisig/vultisig-sdk/commit/e1e73cb5a67de6c77731b2d58ed7b2cb547e1228) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the RN-safe `prepareIbcTransfer` and `prepareSuiTokenTransferFromKeys` helpers from `@vultisig/sdk/react-native`, along with their public support types/constants so React Native consumers no longer need deep imports for IBC and Sui token transfer prep.

- [#2234](https://github.com/vultisig/vultisig-sdk/pull/2234) [`0697060`](https://github.com/vultisig/vultisig-sdk/commit/0697060107c7fe1c8ec818d3e0eae01557d9d96f) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add RUJI Trade quoting and CosmWasm execution for native RUNE and bRUNE swaps through the SDK's normal swap flow.

### Patch Changes

- [#2017](https://github.com/vultisig/vultisig-sdk/pull/2017) [`8a98b44`](https://github.com/vultisig/vultisig-sdk/commit/8a98b44e1f4438212e6deb7cca8491e23940118c) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the canonical THOR/Maya native-swap metadata (`nativeSwapChains`, `nativeSwapChainIds`, `nativeSwapEnabledChainsRecord`, `getNativeSwapChainId`, `getNativeSwapChainIdFromDenomPrefix`, and the `NativeSwapChain`/`NativeSwapChainId` types) from both the root `@vultisig/sdk` entry and `@vultisig/sdk/react-native`. The SDK already owned this data, but first-party consumers (e.g. vultiagent-app's local `thorchainDispatchValidators.ts`) had no supported way to import it and kept app-local copies of which chains route through THORChain/MayaChain and their asset-notation chain IDs.

- [#2235](https://github.com/vultisig/vultisig-sdk/pull/2235) [`3fff7cf`](https://github.com/vultisig/vultisig-sdk/commit/3fff7cfdfe23d2d5622f7caa87a6f1525329f07e) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(swap): stop reporting a native trading halt when an aggregator could still fill

  `findSwapQuotes` collapsed a THORChain/MayaChain halt plus a transient aggregator failure into `TradingHalted` for the whole pair, so an ETH→SOL quote surfaced "trading halted" whenever LiFi/SwapKit happened to time out. A halt is scoped to the native protocol that raised it: those aggregators now get one automatic re-attempt, and when they are still unreachable the error reports the transient failure instead of a halt the user cannot retry out of. Halt-only pairs still throw `TradingHalted`.

## 6.1.0

### Minor Changes

- [#2026](https://github.com/vultisig/vultisig-sdk/pull/2026) [`344b41f`](https://github.com/vultisig/vultisig-sdk/commit/344b41fad752cf9ee79c4f7cd7815832257f344c) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the validation and address-format canonicals from the React Native entry: `amountMatches`, `feeMatches`, `normalizeTokenSymbol`, `tokenDecimals`, `scaleHumanToRaw`, `scaleRawToHuman`, `decimalsFor`, `computeEvmFee`, `isValidTokenSymbolFormat`, `ValidateNormalizerError`, `canonicalChainTag`, `classifyAddress`, `isAddressValidForChain`, `isSolanaAddress`, `supportedChainTags`, `address`, `validate` and `checkChainPrefix`. They are pure, vault-free and platform-neutral, but were reachable only from the root entry, so React Native consumers had to deep-import or keep an app-local mirror. Adds an RN entry test that walks the whole runtime surface of each canonical module, so a helper added later and wired only into the root entry fails rather than silently reopening the gap.

### Patch Changes

- [#2224](https://github.com/vultisig/vultisig-sdk/pull/2224) [`3121503`](https://github.com/vultisig/vultisig-sdk/commit/3121503831e4bc6f491c69cf2e69bf3ddcc87853) Thanks [@johnnyluo](https://github.com/johnnyluo)! - Throw a typed `DklsMaliciousPartyError` when DKLS keysign reports native or vs-wasm abort-and-ban party codes, and resolve the banned `partyId` from the setup-message party order on the initiating device.

- [#2228](https://github.com/vultisig/vultisig-sdk/pull/2228) [`bbe43cb`](https://github.com/vultisig/vultisig-sdk/commit/bbe43cb91976138015ab4ad29c14a7b0e14f8cb4) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export `getEvmNumericChainId` from the SDK root and React Native public entries. The accessor is derived from the canonical EVM chain registry, and the React Native transaction builder now consumes it instead of maintaining a duplicate numeric chain-id table.

- [#2227](https://github.com/vultisig/vultisig-sdk/pull/2227) [`6d3c754`](https://github.com/vultisig/vultisig-sdk/commit/6d3c754ed1abe6153e648243ff0339ff0ba50bf1) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add TRON Stake 2.0 expired-unfreeze withdrawal signing with strict native-TRX payload validation and WalletCore 4.7.3 support.

## 6.0.0

### Major Changes

- [#2218](https://github.com/vultisig/vultisig-sdk/pull/2218) [`d043dc4`](https://github.com/vultisig/vultisig-sdk/commit/d043dc43d9fe33a3160c2739150fd6294f0e7eff) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Unify the workspace on the coordinated Noble/Scure v2 stack and align related workspace peer dependency ranges.

- [#1825](https://github.com/vultisig/vultisig-sdk/pull/1825) [`eccbc25`](https://github.com/vultisig/vultisig-sdk/commit/eccbc25a1fd61fb9eb03494afb0d5ceb6977be8c) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Return WalletCore parity input from TON builders and fail closed before TON fast-sign dispatch unless its independently derived signing hash matches. `walletCoreTxInputData` is now required for every `chain === 'ton'` call to `fastVaultSign` / `schnorrSign` — the parity check was previously skipped whenever a caller omitted it, which meant it never protected real TON sends. Callers on `buildTonSendTx` / `buildTonJettonTransferTx` must thread the builder's `walletCoreTxInputData` through to the signer; `buildTonTxFromSigningPayload` (prebuilt/yield.xyz payloads) cannot supply one yet and will now be rejected at dispatch instead of signing unchecked. `FastVaultSignOptions.chain` is also now required (was optional) and throws `InvalidConfig` when omitted. Also align TRC-20 raw protobuf bytes with WalletCore's proto3 default-field encoding.

### Minor Changes

- [#2176](https://github.com/vultisig/vultisig-sdk/pull/2176) [`d2edffd`](https://github.com/vultisig/vultisig-sdk/commit/d2edffd98730daa474d0c2f35a305d5277e3eb15) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export a canonical typed parser for backend `tx_ready` and execute-prep envelopes, and migrate the CLI's non-EVM and THOR/Maya execution routing to that shared contract.

- [#2010](https://github.com/vultisig/vultisig-sdk/pull/2010) [`f170bdd`](https://github.com/vultisig/vultisig-sdk/commit/f170bdddafd80d892cd35a050cf8f5393776a6a0) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - `vault.swap({ amount: 'max' })` now resolves `max` through the fee-aware `maxSwapable` its own quote already computes, instead of committing the full source balance. A native max swap previously over-committed by exactly the network fee and failed at prepare/broadcast with insufficient funds, after the caller had been told the swap was viable. Routes that cannot price their source-chain fee at quote time (deposit-channel transfers) now fail closed with an actionable error rather than building against a balance that is not safe to spend. This matches what `send({ amount: 'max' })` has always done.

- [#2024](https://github.com/vultisig/vultisig-sdk/pull/2024) [`821c8a7`](https://github.com/vultisig/vultisig-sdk/commit/821c8a73dd7d3aee55eaca59c22adc1ce8dae2f2) Thanks [@neavra](https://github.com/neavra)! - Label XRP spendable-vs-total balance. `getRippleNativeBalanceDetail` exposes the `{ total, spendable, reserve }` breakdown of a native XRP balance (the existing resolvers keep returning the spendable number, so no consumer changes meaning). SDK `Balance` gains optional `totalAmount`/`reserveAmount` fields, populated for native XRP. The CLI labels the spendable headline and prints the locked reserve for XRP balances; all other chains render unchanged.

### Patch Changes

- [#1760](https://github.com/vultisig/vultisig-sdk/pull/1760) [`9759c64`](https://github.com/vultisig/vultisig-sdk/commit/9759c6429225afe0ee96a8b51aff6b79026e1b8b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Preserve optional `priceProviderId` on `discoverTokens()` results so downstream consumers can price newly discovered tokens without app-local metadata backfills.

- [#2142](https://github.com/vultisig/vultisig-sdk/pull/2142) [`bd44426`](https://github.com/vultisig/vultisig-sdk/commit/bd44426fe80b160d8c9a0a866e3cbb759bf781ba) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Restore Cosmos governance parity with the agent backend by accepting Sei, Injective, Neutron, Celestia, and Stride (including their chain IDs) for proposal reads and unsigned vote preparation. Terra Classic `gov/v1beta1` proposal filters now use the required integer enum values instead of `PROPOSAL_STATUS_*` strings.

- [#2148](https://github.com/vultisig/vultisig-sdk/pull/2148) [`dd82325`](https://github.com/vultisig/vultisig-sdk/commit/dd82325ee2f5700429178cb513b338dac27aa281) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Align Cosmos IBC signing with the mobile signers by unpacking the source-channel routing memo and signing only the optional user memo.

- [#2037](https://github.com/vultisig/vultisig-sdk/pull/2037) [`e6375ee`](https://github.com/vultisig/vultisig-sdk/commit/e6375ee8a4d77035b4ae8dae01184b2100ac8ca7) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Move `formatUsdc` next to `parseUsdcAmount` in `tools/parse/usdcAmount.ts`, so its two independent copies in `buildCctpBridge.ts` and `threeJane/buildSupplyUsdc.ts` become one shared implementation. It renders the `amountUsdc` string a user reads on a signing card, so a drift between the copies would show the same amount two different ways depending on which builder produced it. Also exports it from `@vultisig/sdk/tools/defi/threeJane`, matching how `parseUsdcAmount` is already surfaced there; the existing `tools/bridge` export path is unchanged.

- [#2154](https://github.com/vultisig/vultisig-sdk/pull/2154) [`e2be3d4`](https://github.com/vultisig/vultisig-sdk/commit/e2be3d41214b988c3b917538e26dbe1e123725de) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export canonical server-signer helpers from the SDK root and React Native entrypoints, recognize legacy `VultiServer-*` signers, and route SDK fast-vault classification through the shared detector.

- [#2164](https://github.com/vultisig/vultisig-sdk/pull/2164) [`6c535ae`](https://github.com/vultisig/vultisig-sdk/commit/6c535ae3aed1c376d2e1bbbeb100e8b5c21c8929) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Route the Kamino Earn API through the Vultisig proxy. Upstream answers the CORS preflight with a 404 and returns no `access-control-allow-origin` on the build endpoints, so a browser refuses the POST that deposits and withdrawals depend on — the flows hung on the review screen in any webview. Native clients never saw it, because CORS is enforced by the browser rather than the server.

- [#2177](https://github.com/vultisig/vultisig-sdk/pull/2177) [`5bf33f2`](https://github.com/vultisig/vultisig-sdk/commit/5bf33f264c90ec4055d2c12e90222bec9aea501b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the Hermes-safe seedphrase validation, language detection, key derivation, and import-policy helpers from the React Native entrypoint.

- [#2023](https://github.com/vultisig/vultisig-sdk/pull/2023) [`3203589`](https://github.com/vultisig/vultisig-sdk/commit/3203589af5da361dfc51695aad4fef77afa2d78e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(encoding): bound TRON/Solana/Ripple fee-and-gas fields before `Long.fromString`

  `Long.fromString` (and `BigInt()`) silently two's-complement-wraps an out-of-range magnitude instead of throwing (e.g. `2^64 -> 0`, `2^63 -> -2^63`). Six fee/gas sites fed by third-party gas estimation / swap-aggregator data routed raw values straight into it with no bound - a wrapped TRON `feeLimit`/`callValue`/`callTokenValue` could authorize an outsized fee burn, and a wrapped Solana priority fee or Ripple network fee misprices the transaction:

  - `packages/core/mpc/keysign/signingInputs/resolvers/tron.ts` - `feeLimit` (4 sites, from `tronSpecific.gasEstimation`), `callValue`, `callTokenValue`
  - `packages/core/mpc/keysign/signingInputs/resolvers/solana/send.ts` - `priorityFee`
  - `packages/core/mpc/keysign/signingInputs/resolvers/ripple.ts` - `fee` (from `rippleSpecific.gas`)

  New `assertBoundedInt(value, 'int64' | 'uint64')` in `@vultisig/lib-utils/bigint/assertBoundedInt` validates a decimal integer string against the proto field's declared 64-bit range and throws instead of letting the wrap happen, matching each field's real signedness (TRON's are `int64`, Solana's priority fee is `uint64`, Ripple's fee is `int64`). In-range values are unaffected - this is fail-closed only.

- [#1870](https://github.com/vultisig/vultisig-sdk/pull/1870) [`3e37e69`](https://github.com/vultisig/vultisig-sdk/commit/3e37e69fdc60d63cb53a2ef7c74b01aa930b27e1) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add a public `pollTxStatusUntilFinal` helper to `@vultisig/sdk` and reuse it across SDK/CLI transaction finality polling paths.

- [#2039](https://github.com/vultisig/vultisig-sdk/pull/2039) [`1672265`](https://github.com/vultisig/vultisig-sdk/commit/16722657dcefafff32744a7673c277e403e62a77) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Deduplicated the cosmos validator/account bech32 role guard (fund-safety: rejecting a `valoper`/`valcons` address where a spendable account is required). `ibcTransfer.ts` and `cosmosStaking.ts` each carried their own private reimplementation of the HRP-suffix classification alongside the canonical one in `tools/swap/skip/cosmosAddressGuard.ts`; both now import and consume the shared `validatorRoleForHrp` helper instead, so the fund-safety rule can no longer drift silently across call sites.

- [#2040](https://github.com/vultisig/vultisig-sdk/pull/2040) [`2faf1a2`](https://github.com/vultisig/vultisig-sdk/commit/2faf1a2b833b1fc0f10a02ad2c8bec50ef4b1f57) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - `parseThorSwapMemo` no longer rejects THORChain secured-asset `CHAIN-ASSET` notation (`ETH-USDC-0x…`, `XRP-XRP`). It previously required a dotted `CHAIN.ASSET` first segment and threw on any secured-asset memo. The parser now locates the chain boundary using the same first-separator logic SDK core already centralizes in `findThorchainMemoAssetSeparatorIndex`, so both dotted and secured-asset swap memos parse correctly.

- [#2065](https://github.com/vultisig/vultisig-sdk/pull/2065) [`beaca3c`](https://github.com/vultisig/vultisig-sdk/commit/beaca3c086679a8b87592fb69ca30a0a9d1877db) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - The React Native EVM fee helper (`getEvmSuggestedFees`) computed `maxPriorityFeePerGas` as naive `baseFee / 10` with no floor, so a quiet-block RPC quote could collapse toward zero and leave a signed tx sitting unmined in the public mempool — the same class of bug the app and backend already hotfixed with their own per-chain minimum-tip tables. The SDK already publishes a canonical per-chain floor/ceiling policy (`clampEvmPriorityFee`) but the RN fee helper never called it. Wired `getEvmSuggestedFees` through `clampEvmPriorityFee`, so its priority fee is floored (Ethereum 1 gwei, Polygon 30 gwei) and sanity-ceilinged against an anomalous RPC quote, same as any other first-party consumer of that helper.

- [#2044](https://github.com/vultisig/vultisig-sdk/pull/2044) [`5500717`](https://github.com/vultisig/vultisig-sdk/commit/5500717036e760ed81d4880c66bda559d37331cd) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - `decodeFromToolResult` only recognized legacy snake_case tx metadata (`from_chain`, `unsigned_payload`, `cosmos_payload`), even though newer SDK-owned surfaces (`normalizeTx`, the signable-transaction contract) already emit and consume the camelCase equivalents (`fromChain`, `unsignedPayload`). Callers on those surfaces had to re-shape their canonical envelopes back to snake_case before the decoder would accept them. The decoder now accepts both the snake_case and camelCase aliases for the chain hint and payload fields.

- [#2050](https://github.com/vultisig/vultisig-sdk/pull/2050) [`d04f246`](https://github.com/vultisig/vultisig-sdk/commit/d04f246a992f3256e4fe7151e5319003d8ae267a) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Stop forcing spurious major bumps on `@vultisig/rujira` (and any other peer-dependent package) every time the SDK releases a patch or minor. Changesets' default treats any peer-dependency version change as breaking for the dependent, so 61 of `@vultisig/rujira`'s last 64 published versions were majors despite the peer range (`>=4.5.0`) never actually being violated. Setting `onlyUpdatePeerDependentsWhenOutOfRange: true` in `.changeset/config.json` makes the peer-dependent bump conditional on the range genuinely being out of date, so a rujira major now only fires when its declared SDK peer range is actually moved.

- [#2052](https://github.com/vultisig/vultisig-sdk/pull/2052) [`da2ea4e`](https://github.com/vultisig/vultisig-sdk/commit/da2ea4e1ae00f17cfec3d27da4fff2e6cb5b1190) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - `parseActionDisplay` (StakeKit action display canonicalization) now degrades per-step instead of all-or-nothing: a step that fails to canonicalize (e.g. an unsupported network like Cardano, or a malformed EVM step) falls back to its decoded form, while every other step in the same action stays canonicalized. Previously, one unsupported step nuked the canonicalized shape for the entire action, pushing deterministic parsing of the other (supported) steps back onto app/backend consumers.

- Updated dependencies [[`d043dc4`](https://github.com/vultisig/vultisig-sdk/commit/d043dc43d9fe33a3160c2739150fd6294f0e7eff), [`cbc29bf`](https://github.com/vultisig/vultisig-sdk/commit/cbc29bf39fd87558365a1061ddf94e3d7469e7ee)]:
  - @vultisig/walletcore-native@1.0.0
  - @vultisig/mpc-native@1.0.0

## 5.2.0

### Minor Changes

- [#1899](https://github.com/vultisig/vultisig-sdk/pull/1899) [`df144e9`](https://github.com/vultisig/vultisig-sdk/commit/df144e9e21c2fb64e73efcf12ac35c958dbf1c7b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical Cosmos SignAmino and SignDirect keysign payload builders from the root and React Native SDK surfaces.

### Patch Changes

- [#1688](https://github.com/vultisig/vultisig-sdk/pull/1688) [`397c2b6`](https://github.com/vultisig/vultisig-sdk/commit/397c2b6629fdc7002d55bd95bb8585dce78de416) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Return the deterministic Bittensor extrinsic hash for duplicate or timeout-style raw broadcast submissions.

- [#1891](https://github.com/vultisig/vultisig-sdk/pull/1891) [`7d6a014`](https://github.com/vultisig/vultisig-sdk/commit/7d6a01440fd0b855356cce81469b5b5a91665862) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Standardize signed-transaction broadcast adapters on one typed accepted-or-failed result contract.

## 5.1.1

### Patch Changes

- [#2147](https://github.com/vultisig/vultisig-sdk/pull/2147) [`95fcff9`](https://github.com/vultisig/vultisig-sdk/commit/95fcff9ecf860551b4ae5815736018b831f78f36) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Populate Solana `SigningOutput.signatures` when compiling dApp-supplied raw transactions so downstream transaction-hash resolution returns the spliced fee-payer signature instead of crashing after keysign.

## 5.1.0

### Minor Changes

- [#2034](https://github.com/vultisig/vultisig-sdk/pull/2034) [`4696cbb`](https://github.com/vultisig/vultisig-sdk/commit/4696cbb8259cac4b2d19091dbe41c20a988993da) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Narrow `acrossQuote`'s `sourceChain` to the origin it actually accepts. The parameter was typed as any `AcrossChain` and the JSDoc example passed `'Base'`, but the runtime rejects every non-Ethereum origin, so the documented call compiled and then threw. `sourceChain` is now `AcrossOriginChain`, and `ACROSS_ORIGIN_CHAIN` is exported so callers can branch on the limit instead of discovering it by catching. The fail-closed runtime guard is unchanged for untyped callers.

- [#1810](https://github.com/vultisig/vultisig-sdk/pull/1810) [`088b905`](https://github.com/vultisig/vultisig-sdk/commit/088b9058f47eff8dc84929e89fdf4ddfde7e42e6) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add provider-aware swap arrival status normalization for THORChain, MayaChain, Skip Go, and LI.FI.

### Patch Changes

- [#1879](https://github.com/vultisig/vultisig-sdk/pull/1879) [`62ef869`](https://github.com/vultisig/vultisig-sdk/commit/62ef86962d7d7f562e75ac655f321e7912e5368a) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Align Cardano max-send and Terra Classic USTC signing inputs with the current Swift and Kotlin signers so the shared mobile fixture hashes pass without SDK-only overrides.

- [#2012](https://github.com/vultisig/vultisig-sdk/pull/2012) [`a81c444`](https://github.com/vultisig/vultisig-sdk/commit/a81c444371b41cf6582a3e85db9f24765f4516fa) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Scope the StakeKit yield caches by API credential. `/yields/enabled` returns only the products a given project's API key may deposit into, but the cache key omitted the credential, so the first caller's allowed set was served to every other caller for the full 5-minute TTL. That both leaked one project's enabled products to another and hid products the second project actually had. Cache keys carry a truncated SHA-256 of the key, never the key itself.

- [#1905](https://github.com/vultisig/vultisig-sdk/pull/1905) [`d13fc6a`](https://github.com/vultisig/vultisig-sdk/commit/d13fc6a9da44e2efa4bbdde73aaf85459702c039) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export root swap helpers from the React Native SDK entrypoint so mobile consumers can use the same Across, Jupiter, and Skip canonicals without local copies.

- [#1810](https://github.com/vultisig/vultisig-sdk/pull/1810) [`088b905`](https://github.com/vultisig/vultisig-sdk/commit/088b9058f47eff8dc84929e89fdf4ddfde7e42e6) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fix three unsafe terminal-state gaps in `getSwapArrivalStatus`: LI.FI `DONE/PARTIAL` (user received a different token than requested) is now reported as a distinct `partial` status instead of being flattened into `success`; malformed or unknown Midgard action statuses now throw `SwapArrivalStatusRequestError` instead of being reported as a terminal `error`; and THOR/Maya node-only completion now reads THORNode's `planned_out_txs[].refund` flag to report `success`/`refunded` when available, instead of always forcing an artificial `pending` state.

- [#1879](https://github.com/vultisig/vultisig-sdk/pull/1879) [`62ef869`](https://github.com/vultisig/vultisig-sdk/commit/62ef86962d7d7f562e75ac655f321e7912e5368a) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Include TerraClassic's signed USTC burn-tax surcharge in the displayed send-fee total by deriving both values from the same Cosmos fee-amount list.

- [#2062](https://github.com/vultisig/vultisig-sdk/pull/2062) [`b46ff2e`](https://github.com/vultisig/vultisig-sdk/commit/b46ff2eb628bf63ecf95609460cd5c713cde6384) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Removed two dead exports flagged by the whole-stack audit: `RIVER_FACTORY_ABI` (`packages/sdk/src/tools/defi/river/abi.ts`) had zero importers anywhere in the workspace, and `BITTENSOR_BASE_FEE_RAO` (`packages/sdk/src/tools/balance/bittensor.ts`) was defined once and referenced nowhere — an unfinished fee computation (`BITTENSOR_BASE_FEE_HUMAN`, the display-string sibling, is still used and untouched). Neither constant was part of the public SDK surface. The mpc-types/mpc-wasm circular-dependency architecture problem this issue also raises is out of scope here — extracting a shared leaf package for the MPC engine/types is a genuine multi-package restructure, not a small fix.

- [#2066](https://github.com/vultisig/vultisig-sdk/pull/2066) [`cd45b6d`](https://github.com/vultisig/vultisig-sdk/commit/cd45b6d62611d4a2f2a578f9c1bf576961715886) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - `searchToken()` only modeled token discovery as CoinGecko "platform deployments" (contract addresses), so curated XRPL issued currencies like RLUSD — already known internally via `knownTokens[Chain.Ripple]` — were invisible on the public search surface, since CoinGecko doesn't list XRPL tokens with a `ripple` contract-address platform entry. Overlaid the curated `knownTokens[Chain.Ripple]` entries onto their matching CoinGecko coin (keyed by `priceProviderId`, the CoinGecko coin id each curated entry already carries), so `searchToken('RLUSD')` now surfaces a `Ripple` deployment alongside any contract deployments CoinGecko already reports. `TokenDeployment.contractAddress` is documented as the chain's canonical token identifier (contract address, SPL mint, Sui coin type, or — for XRPL — the `<currency>.<issuer>` composite id), not strictly an EVM contract.

- [#2067](https://github.com/vultisig/vultisig-sdk/pull/2067) [`2111255`](https://github.com/vultisig/vultisig-sdk/commit/21112551209022deeb12cd33ca043c199a980b9d) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - `packages/sdk/src/tools/policy/types.ts` documents the canonical bytes-oracle decoder as `sdk.decode.fromToolResult`, but `@vultisig/sdk` only ever exported flat helpers (`decodeFromToolResult`, `decodeCosmosTx`, `decodeEvmTx`) — `sdk.decode` was `undefined`, so the docs and the runtime surface disagreed. Added a `decode` namespace object (`{ fromToolResult, decodeCosmosTx, decodeEvmTx }`, aliasing the existing flat helpers) exported from `tools/decode/index.ts` and re-exported through `tools/index.ts`, the root `index.ts`, and the React Native entrypoint.

- [#2041](https://github.com/vultisig/vultisig-sdk/pull/2041) [`4d18164`](https://github.com/vultisig/vultisig-sdk/commit/4d1816467a78d5bd7c121cb9506efec7385e877a) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - The SDK's chain-agnostic raw-broadcast implementation (`RawBroadcastService`, covering EVM/UTXO/Solana/Cosmos/TON/Polkadot/Bittensor/Ripple/Sui/TRON) was only reachable through `VaultBase.broadcastRawTx`, forcing runtimes that already hold signed raw bytes to stand up vault plumbing (or their own submitter) just to broadcast. `RawBroadcastService` holds no vault state, so it is now also exposed as a standalone `broadcastRawTx` export from the SDK root, backed by the same broadcaster; `VaultBase.broadcastRawTx` remains a thin wrapper that additionally emits vault events.

- [#2046](https://github.com/vultisig/vultisig-sdk/pull/2046) [`4ce260c`](https://github.com/vultisig/vultisig-sdk/commit/4ce260c360e35e4f76ea7f3dec98c20b47ed0b9b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export `isValidTokenId` from both the root SDK entry and `@vultisig/sdk/react-native` (RN gets a `WalletCoreLike`-accepting wrapper, matching the existing `isValidAddress`/`deriveAddress`/`getCoinType` pattern). The canonical helper already existed in `@vultisig/core-chain` and validates non-address token identifiers — Sui Move struct tags and XRPL composite `currency.issuer` ids — falling back to plain address validation for every other chain, but neither public SDK surface exposed it, pushing Sui/XRPL token-id validation back into app/backend-local shims.

- [#2095](https://github.com/vultisig/vultisig-sdk/pull/2095) [`2f1fbbe`](https://github.com/vultisig/vultisig-sdk/commit/2f1fbbe2e2b0fdc901b76f358e078a23e65d3910) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - `buildCctpClaim` now decodes the CCTP message (`decodeCctpBurnMessage`) and cross-checks the burn's source domain, destination domain, sender/recipient TokenMessenger, and burned token against the stated `sourceChain`/`destinationChain` before encoding `receiveMessage` calldata, and refuses to build a claim whose mint recipient is a known burn/dead address — ported from `agent-backend-ts`'s `build_cctp_claim_usdc` handler so the SDK builder no longer treats the message as opaque bytes. `BuildCctpClaimParams` gains a required `sourceChain` field and `CctpClaimResult` gains a `burn` field exposing the decoded, cross-checked burn identity.

## 5.0.0

### Major Changes

- [#1758](https://github.com/vultisig/vultisig-sdk/pull/1758) [`952bcdf`](https://github.com/vultisig/vultisig-sdk/commit/952bcdf767621908d1db58d624a4d41a17e7108b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject duplicate, stale, incompatible, and other-device vault shares before local import persistence, with an explicit compatible-share replacement option. Import persistence is revision-checked through the same optimistic-concurrency `vault.save()` every other vault mutation uses and committed with atomic compare-and-set across built-in storage backends, so a record that changes underneath an import is rejected instead of silently overwritten. Custom storage adapters must expose `compareAndSet` for vault imports. React Native consumers must install the new optional peer `expo-sqlite`; the default adapter durably migrates and removes existing SDK-owned AsyncStorage records once, then keeps values and compare-and-set revisions together in native SQLite transactions across JS runtimes. Chrome content scripts must route storage mutations through an extension-origin context so all mutations share the same Web Lock. A locally unreadable existing record (corrupted, or an encrypted record whose password rotated) cannot be replaced because no trustworthy atomic baseline exists, including through `conflictResolution: 'replace-unvalidated'`.

  Existing callers of `importVault`/`importVaultWithResult` that relied on re-importing the same vault silently succeeding must now pass `{ conflictResolution: 'replace' }` explicitly, and custom storage adapters without atomic compare-and-set can no longer import vaults.

### Minor Changes

- [#2060](https://github.com/vultisig/vultisig-sdk/pull/2060) [`3ed3179`](https://github.com/vultisig/vultisig-sdk/commit/3ed31790b62b4c7f7b1fdbc477f72edebbb2e097) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Publish `@vultisig/sdk/tools/gas` as a real package subpath (`compareCosts`, `getChainGasPriceGwei`, `utxoFeeRate`, Cosmos gas-fee primitives). The gas module existed and was already reachable from the root entry, but had no export condition or bundle of its own, so a consumer wanting only the gas surface had to take the whole root import. Adds export conditions, runtime bundle, declaration bundle, and packed-consumer smoke coverage, following the same pattern already proven for `./tools/parse`, `./tools/defi`, and `./tools/bridge`.

- [#2074](https://github.com/vultisig/vultisig-sdk/pull/2074) [`8929244`](https://github.com/vultisig/vultisig-sdk/commit/8929244cdb3b21059a46eabac6d4d9684e18a633) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add the Kamino Earn data layer under `chains/solana/kamino`: a REST client for the kVaults API (vault state, metrics, user positions, PnL) with a typed error envelope that separates retryable statuses from permanent refusals; a curated vault registry pinning each launch vault's identity (mints, decimals, farm, curator, risk tier); distinct token- and share-denominated amount types over exact `bigint` base units, with exact-rate conversions that truncate toward zero so a sized withdraw can never over-request (the API rewrites an over-sized withdraw to `u64::MAX` — withdraw everything); vault-info hydration that refuses responses disagreeing with the pinned identity and derives the effective deposit/withdraw minimums the on-chain program actually accepts; and position parsing with a spendable-balance rule that stays strictly below the reported balance.

- [#2124](https://github.com/vultisig/vultisig-sdk/pull/2124) [`514e31f`](https://github.com/vultisig/vultisig-sdk/commit/514e31f084c241792f3a9b2436074c324a909c0f) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add the Kamino Earn transaction pipeline under `chains/solana/kamino/tx`: build the unsigned deposit/withdraw transactions (with the withdraw-everything sentinel refused before a request leaves the device); inject the attribution memo and the compute-budget pair into the built v0 transaction without disturbing address-lookup-table indexes; replace the recent blockhash immediately before keysign; a fail-closed validator that admits only allow-listed programs, matches the exact instruction sequence each operation produces (both withdraw discriminators, the farms unstake pair, exactly one memo carrying exactly the attribution tag), pins every account that decides where money goes against the registry and local ATA/PDA derivations, pins every spend amount, and refuses unexplained writable accounts; and an offline decoder that lets a co-signing device derive an independent claim about what the bytes do — vault identified through the signer's own share account, both withdraw shapes accepted, the farm release bounded by the withdraw itself.

## 4.7.0

### Minor Changes

- [#2011](https://github.com/vultisig/vultisig-sdk/pull/2011) [`687f1ad`](https://github.com/vultisig/vultisig-sdk/commit/687f1adea7c81dde4a5f21520ea1cdbbf34e10fd) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add `findSwapQuotes`, returning the full ranked swap-route candidate set (`{ best, ranked }`) alongside the auto-selected winner, so consumers can offer route selection. Each ranked entry carries the fully bound quote (request amount, expiry, safety fingerprint), its provider name, and the comparable net output used for ranking. `findSwapQuote` now delegates to it and its behavior — selection, preference band, and every error path — is unchanged.

### Patch Changes

- [#1779](https://github.com/vultisig/vultisig-sdk/pull/1779) [`e5937ee`](https://github.com/vultisig/vultisig-sdk/commit/e5937ee938eb19adc423a7d5ca29cee71f0592f4) Thanks [@neavra](https://github.com/neavra)! - Store CLI-managed token IDs as bare lowercase EVM contract addresses, retain reads of legacy chain-prefixed IDs, and use stable ecosystem token names in discovery. Ambiguous token symbols now fail closed, discovery collisions use address-derived discriminators, and re-adding legacy-stored contracts remains idempotent. Token removal now emits the standard JSON success envelope and token-add help documents its required name.

- [#1881](https://github.com/vultisig/vultisig-sdk/pull/1881) [`f7caa39`](https://github.com/vultisig/vultisig-sdk/commit/f7caa39ad2eb3d322031d8ac56ae832a9108e6d4) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Surface Cosmos account-sequence mismatches with direction-aware recovery: stale signed transactions now require rebuilding and a new signing ceremony, while future-sequence transactions may wait for their predecessor and retry. Preserve peer-broadcast hash verification and retry only the recoverable future-sequence case.

- [#1947](https://github.com/vultisig/vultisig-sdk/pull/1947) [`144cc70`](https://github.com/vultisig/vultisig-sdk/commit/144cc7085d63eb6111ae5f8b0fc948af224ecc21) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix `getEvmBalances` failing on ERC-20 tokens whose `symbol()` returns a legacy bytes32 (e.g. MKR) instead of a dynamic string, aborting the whole balance batch.

- [#1664](https://github.com/vultisig/vultisig-sdk/pull/1664) [`42d46b6`](https://github.com/vultisig/vultisig-sdk/commit/42d46b640bb7577d2cc98af31a8776fa04728fd2) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export `buildBalancerV3SwapCalldata` from the root SDK surface so Node and browser consumers can import it the same way React Native consumers already can.

- [#1658](https://github.com/vultisig/vultisig-sdk/pull/1658) [`fbdd174`](https://github.com/vultisig/vultisig-sdk/commit/fbdd174c24a79b81559e1775e33841fb024ef142) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Publish `@vultisig/sdk/chains/tron` and `@vultisig/sdk/chains/utxo` as real package subpaths with dedicated runtime and type bundles.

- [#1662](https://github.com/vultisig/vultisig-sdk/pull/1662) [`ef3d8f2`](https://github.com/vultisig/vultisig-sdk/commit/ef3d8f2e37d5c8686835b9f14d36c10e2eab3a08) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the custom-RPC override registry and health-probe helpers from the root and React Native SDK entrypoints.

- [#1839](https://github.com/vultisig/vultisig-sdk/pull/1839) [`50257ad`](https://github.com/vultisig/vultisig-sdk/commit/50257ad213a36952509f3548100334e5f3e44a09) Thanks [@rcoderdev](https://github.com/rcoderdev)! - cosmos/gas: raise the TerraClassic staking gas limit from 3M to 4M

  `getCosmosStakingGasLimit` now returns 4M for `Chain.TerraClassic` regardless of `msgCount`, giving external SDK consumers headroom over the observed 2,501,503-gas `MsgBeginRedelegate` path.

  Also exports `TERRA_CLASSIC_STAKING_ULUNA_FEE_BASE_UNITS`, the `uluna` fee correctly priced for this 4M staking gas limit (113.3 LUNC at the chain's 28.325 uluna/gas minimum). The existing `TERRA_CLASSIC_ULUNA_BASE_GAS` / `getCosmosSendFeeBaseUnits` fee is priced for the 300k native-send gas limit and under-pays a 4M-gas staking tx by ~13x, so consumers must pair the staking gas limit with this new constant, not the send fee.

- [#1872](https://github.com/vultisig/vultisig-sdk/pull/1872) [`94fe7b4`](https://github.com/vultisig/vultisig-sdk/commit/94fe7b482d5df9d382064c089c107acbd39524e4) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Publish `@vultisig/sdk/tools/balance` as a real package subpath with dedicated JS and declaration bundles.

- [#1515](https://github.com/vultisig/vultisig-sdk/pull/1515) [`69b1c2e`](https://github.com/vultisig/vultisig-sdk/commit/69b1c2e4026e62a83151957a91651eaa982d0a13) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Centralize the race-safe `memoizeAsync` implementation in `@vultisig/lib-utils`, and update the SDK browser/chrome-extension runtimes to consume the shared helper so concurrent initialization work shares in-flight promises instead of duplicating async setup.

- [#1880](https://github.com/vultisig/vultisig-sdk/pull/1880) [`39b8762`](https://github.com/vultisig/vultisig-sdk/commit/39b8762aeed25382bf803944c1b2c2066f6224a6) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Resolve MayaChain's displayed native transaction fee from live network parameters and clarify vault-based Cosmos fee signing semantics.

- [#1722](https://github.com/vultisig/vultisig-sdk/pull/1722) [`f914e7c`](https://github.com/vultisig/vultisig-sdk/commit/f914e7c1c6f430fa54116f4c0a82f19919e0fbf6) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Preserve top-level routing metadata when normalizing flat tx payloads, and carry `chain` / `from_chain` / `to_chain` args onto split multi-leg transactions. This keeps `normalizeTx()` and `splitMultiTx()` consistent for downstream app/backend consumers that rely on the canonical SDK envelope contract.

- [#1871](https://github.com/vultisig/vultisig-sdk/pull/1871) [`76163b6`](https://github.com/vultisig/vultisig-sdk/commit/76163b6e533cb0178c999e5b6554bddf4517718e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Make the expired, zero-caller Rujira merge-balance service inert. The KUJI-to-RUJI merge window closed on 2026-04-05, so the compatibility shim now returns an empty result without querying GraphQL.

- [#1495](https://github.com/vultisig/vultisig-sdk/pull/1495) [`3d0fd71`](https://github.com/vultisig/vultisig-sdk/commit/3d0fd71b923d57e52ae5760656051be22323947d) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the canonical `IbcEnabledCosmosChain` and `VaultBasedCosmosChain` subsets from the root and React Native SDK entrypoints so first-party consumers can stop mirroring staking-chain allowlists.

- [#1498](https://github.com/vultisig/vultisig-sdk/pull/1498) [`e869b4d`](https://github.com/vultisig/vultisig-sdk/commit/e869b4d0a1da17d6278ca37c991673a9b4dd0c8d) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export `buildKeygenPairingQrPayload` from the root and React Native SDK entrypoints so first-party consumers can build canonical secure-vault pairing QR payloads without deep-importing internal service paths.

- [#1829](https://github.com/vultisig/vultisig-sdk/pull/1829) [`0a73b05`](https://github.com/vultisig/vultisig-sdk/commit/0a73b056a6d9fa1dc3c4c115e8c9850bcede0403) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Reject Polkadot asset-send amounts above pallet_assets `u128` and TRON TRC-20 fee limits above protobuf `int64` (at both the prep and raw-builder layers) instead of silently truncating or overflowing. Closes [#1827](https://github.com/vultisig/vultisig-sdk/issues/1827), [#1828](https://github.com/vultisig/vultisig-sdk/issues/1828).

- [#1962](https://github.com/vultisig/vultisig-sdk/pull/1962) [`01f92f5`](https://github.com/vultisig/vultisig-sdk/commit/01f92f5b20461e62625b743d27a6a7571f9b0d74) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fail closed instead of silently rounding: `getSolBalance()`'s `lamports` field is now `number | null`, returning `null` once the exact u64 balance exceeds `Number.MAX_SAFE_INTEGER` instead of re-exposing a value already corrupted by `Number()` coercion. `lamportsRaw` (base-10 string) and `sol` (exact decimal string) remain lossless across the full range and are unaffected.

- [#1716](https://github.com/vultisig/vultisig-sdk/pull/1716) [`2a35932`](https://github.com/vultisig/vultisig-sdk/commit/2a35932cbde4eddad4edf9462e9f0b4063a56f62) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Preserve camelCase transaction metadata like `chainId`, `fromChain`, `toChain`, symbols, addresses, and decimals when `splitMultiTx()` expands a `transactions[]` build result into per-leg envelopes. This keeps newer SDK-native multi-leg builders from silently losing routing/display metadata that downstream app and backend consumers need.

## 4.6.0

### Minor Changes

- [#1830](https://github.com/vultisig/vultisig-sdk/pull/1830) [`1fd27b9`](https://github.com/vultisig/vultisig-sdk/commit/1fd27b9103b75a13191f173ebeed98288d8c16b0) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fail closed when LI.FI returns a destination outside its official chain-scoped Diamond deployments. Accept that Diamond as LI.FI's deterministic approval-spender fast path, while requiring an independent benign Blockaid verdict for any route-dependent spender that differs from it. Require the same independent verdicts for SwapKit EVM transaction destinations and approval spenders, while retaining response-local target-address binding as defense in depth.

  **Consumer-visible behavior changes:**

  - **New runtime throws on the signing path.** A LI.FI destination outside the official Diamond, a distinct LI.FI approval spender that doesn't clear an independent Blockaid check, or a SwapKit destination/approval-spender that doesn't clear the same check now throws during quote construction and co-signer signing-input construction. A consumer on a caret range picks this up automatically.
  - **Dynamic LI.FI approval spenders and SwapKit addresses add a live third-party network call (Blockaid) during MPC signing**, per co-signer. The official LI.FI Diamond remains an offline fast path. A slow or unreachable Blockaid response can stall a signing ceremony for up to the shared `queryUrl` timeout (20s default) before throwing.

- [#1811](https://github.com/vultisig/vultisig-sdk/pull/1811) [`003ee98`](https://github.com/vultisig/vultisig-sdk/commit/003ee98728f3318eb2de661209f164b449150810) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Bind raw swap quotes to their exact coin identities, requested source amount, absolute expiry, and returned transaction, then reject missing, stale, mismatched, or mutated quotes in the vault-free swap preparation path before any payload construction. General quotes remain preparation-valid for five minutes while SDK presentation continues to recommend refreshing after 60 seconds, and vault-free callers can catch `SwapQuoteExpiredError` to requote.

  Consumers must pass the live bound quote returned by `findSwapQuote` or `getSwapQuote` into preparation instead of constructing or persisting an unbound raw quote. Structured cloning is supported; JSON round-tripping is not because it loses required runtime value types such as `bigint`.

- [#1898](https://github.com/vultisig/vultisig-sdk/pull/1898) [`4859206`](https://github.com/vultisig/vultisig-sdk/commit/4859206bd801c3556316561236ce549ab270676e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Publish the canonical seedphrase normalization, validation, key-derivation, and chain-discovery helpers through the supported `@vultisig/sdk/seedphrase` subpath.

### Patch Changes

- [#1892](https://github.com/vultisig/vultisig-sdk/pull/1892) [`9eaa7dc`](https://github.com/vultisig/vultisig-sdk/commit/9eaa7dcbb3c01af4b88f5ff373b38e84781cb32b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add a canonical UTXO address-brand validator and enforce it in the transaction decoder.

- [#1884](https://github.com/vultisig/vultisig-sdk/pull/1884) [`9ec2d77`](https://github.com/vultisig/vultisig-sdk/commit/9ec2d7723b5a6e1d71f48976b50e45a811bb09cb) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject implausible ERC-20 decimal values across shared Uniswap V2 and V3 DEX reads.

- [#1883](https://github.com/vultisig/vultisig-sdk/pull/1883) [`44f0ecb`](https://github.com/vultisig/vultisig-sdk/commit/44f0ecbdf10b07789341c0279041d3a1e37d46a0) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Share LI.FI fee-chain fallback logic between the core and React Native quote paths.

- [#1529](https://github.com/vultisig/vultisig-sdk/pull/1529) [`072f292`](https://github.com/vultisig/vultisig-sdk/commit/072f292338454a3bead7a17fe5b863904d03fc01) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export `getEvmRpcUrl` from the root SDK entrypoint and have the CLI agent executor use the shared EVM RPC resolver for gas refreshes and pending nonce checks.

- [#1890](https://github.com/vultisig/vultisig-sdk/pull/1890) [`0967744`](https://github.com/vultisig/vultisig-sdk/commit/0967744cf0a6697f0dfe66f4f6ce31d6dd90d576) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the documented `sdk.evm`, `sdk.token`, and `sdk.cosmos.gov` helper namespaces while preserving the existing flat exports.

- [#1928](https://github.com/vultisig/vultisig-sdk/pull/1928) [`5814430`](https://github.com/vultisig/vultisig-sdk/commit/5814430f1cdbbe007fc943c3940971f0b3b61c02) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Publish dedicated `@vultisig/sdk/tx` and `@vultisig/sdk/tools/decode` subpaths with JavaScript and declaration bundles.

- [#1553](https://github.com/vultisig/vultisig-sdk/pull/1553) [`4abbac7`](https://github.com/vultisig/vultisig-sdk/commit/4abbac7baf523df8af5a9b2bdf941ce72f8e1073) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the canonical Noon vault helper family from `@vultisig/sdk/react-native` so first-party mobile consumers can reuse the shared SDK contract instead of maintaining local mirrors.

- [#1560](https://github.com/vultisig/vultisig-sdk/pull/1560) [`f243bec`](https://github.com/vultisig/vultisig-sdk/commit/f243bec2191dffbc17af8b4f774e7d307b5c632d) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export swap-progress explorer helpers and the THORChain LP v2 helper family from `@vultisig/sdk/react-native`.

- [#1563](https://github.com/vultisig/vultisig-sdk/pull/1563) [`a169543`](https://github.com/vultisig/vultisig-sdk/commit/a169543b62aa8ce4154cb5236806a54275a7aa42) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Keep the SDK IBC route table in sync with first-party consumers by adding the direct `cosmoshub-4` → `noble-1` channel-536 path to `prepareIbcTransfer()` and route discovery.

- [#1887](https://github.com/vultisig/vultisig-sdk/pull/1887) [`1108d64`](https://github.com/vultisig/vultisig-sdk/commit/1108d64869394eb5ad494c7a489d3d1cb5f2174e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Share one strict USDC amount parser between the CCTP and ThreeJane builders so both reject signed and non-digit inputs consistently.

- [#1927](https://github.com/vultisig/vultisig-sdk/pull/1927) [`1f297ae`](https://github.com/vultisig/vultisig-sdk/commit/1f297ae036379b8d6a76344cb3d027eea97a6b07) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject malformed hex and base64 strings in `decodeFromToolResult` instead of allowing `Buffer` to normalize them into different bytes.

- [#1886](https://github.com/vultisig/vultisig-sdk/pull/1886) [`eb25508`](https://github.com/vultisig/vultisig-sdk/commit/eb25508eadfde14ee62470e64d8c2b590627fd76) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fail closed when Sui pagination reports more data without a usable cursor, preventing partial coin sets or portfolios from being returned as complete.

## 4.5.0

### Minor Changes

- [#1821](https://github.com/vultisig/vultisig-sdk/pull/1821) [`6fd138c`](https://github.com/vultisig/vultisig-sdk/commit/6fd138c364d791d48f5fcd7f6f99f5dbb4756a8d) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Align React Native XRP and TON transaction-builder signing hashes with WalletCore for mixed-platform MPC ceremonies.

  **Consumer-visible behavior changes:**

  - **TON Jetton memo capacity narrows and becomes amount-dependent.** Previously any memo up to 123 bytes was accepted. Now `buildTonJettonTransferTx` / `prepareJettonTransferTxFromKeys` throw once the encoded comment no longer fits WalletCore's inline `forward_payload` cell. The exact cap shrinks as the transfer amount grows (larger `storeCoins` encoding leaves fewer bits for the comment) — at most ~34 ASCII bytes for large (e.g. 18-decimal, 1-token) amounts, ~39 bytes for small ones. This is a hard throw, not a truncation.
  - **XRP `Memos[].Memo.MemoType` is no longer set.** A Payment memo previously always carried `MemoType: "text/plain"` (hex-encoded); it's now omitted to match WalletCore's raw-JSON memo path byte-for-byte. Anything downstream reading `MemoType` off a Vultisig-built XRP payment will stop seeing it.

### Patch Changes

- [#1763](https://github.com/vultisig/vultisig-sdk/pull/1763) [`3c2ca9f`](https://github.com/vultisig/vultisig-sdk/commit/3c2ca9f681a8473e27b876b0158c2084a53a5bd3) Thanks [@neavra](https://github.com/neavra)! - Disclose resolved token contract addresses in SDK and CLI send dry-run previews and in the CLI pre-signing confirmation preview, while leaving native-send output unchanged.

- [#1846](https://github.com/vultisig/vultisig-sdk/pull/1846) [`8faa612`](https://github.com/vultisig/vultisig-sdk/commit/8faa612e6358af0a77cebf9c06d8865d832b69df) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Reserve the OP-stack balance-check surcharges in the EVM fee amount, so a native max send on Optimism, Base, Blast or Mantle stays affordable at broadcast. op-geth requires `value + gasLimit * maxFeePerGas + l1Cost + operatorCost`, and an amount that left only the gas term behind was rejected by exactly the difference — after the keysign ceremony had already run. Both oracle reads fail open, so a chain whose oracle is unreachable or predates a term behaves exactly as before.

- [#1618](https://github.com/vultisig/vultisig-sdk/pull/1618) [`9d94476`](https://github.com/vultisig/vultisig-sdk/commit/9d944766d79f164c6d7997e38b106f00c332fb27) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - export the canonical vault-backup helpers and constants from the public root and react-native SDK entrypoints.

- [#1624](https://github.com/vultisig/vultisig-sdk/pull/1624) [`9424ec2`](https://github.com/vultisig/vultisig-sdk/commit/9424ec2b10f899b8078a7ed1a23cc3077b370044) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Use the SDK's canonical `chainFeeCoin` registry when building CLI agent wallet context native-coin metadata.

- [#1691](https://github.com/vultisig/vultisig-sdk/pull/1691) [`0e48010`](https://github.com/vultisig/vultisig-sdk/commit/0e480103a7c384c91cd6ac927d481e9ecbc616fe) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Keep Schnorr WASM signatures in their canonical Ed25519 byte order and cover real in-process DKLS and Schnorr keygen, signing, and resharing ceremonies.

- [#1844](https://github.com/vultisig/vultisig-sdk/pull/1844) [`69a891c`](https://github.com/vultisig/vultisig-sdk/commit/69a891ce5fbb49c6fd8951e28f66411cc5a8ff99) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ripple): refuse a partial payment with no delivery floor

  For a `signRipple` Payment this resolver binds the raw transaction's
  `Destination` and `Amount` to the reviewed `toAddress` / `toAmount`, so the
  bytes being signed match the terms someone approved. That binding assumes
  `Amount` is a delivery.

  `tfPartialPayment` breaks the assumption. With the flag set, `Amount` becomes a
  maximum: the ledger delivers whatever the chosen path can source and records
  the real figure only in the executed transaction's metadata
  (`delivered_amount`). The reviewed amount is still matched byte for byte and
  still describes nothing the recipient will actually receive, while the sender
  can be charged the full `SendMax`. A cross-currency self-swap — the shape where
  `Destination` is the sender's own address — turns an attractive receive figure
  into dust for the price of the whole `SendMax`.

  A `DeliverMin` restores a floor only if it actually guarantees the reviewed
  amount: `DeliverMin` must be the same asset as `Amount` (native XRP, or the
  same issued-currency code and issuer) and at least as much value, so a
  partial payment carrying one is forwarded unchanged only when the recipient
  is guaranteed to receive no less than what was reviewed. A `DeliverMin` that
  is merely present and positive — but floors delivery at a fraction of
  `Amount`, or in an unrelated currency — is refused: it satisfies "the field
  is there" while leaving the sender able to pay the full `SendMax` for dust,
  which is the exact outcome this resolver exists to prevent. `Flags` that
  cannot be read as a uint32 — the `{ tfPartialPayment: true }` object form
  some client libraries accept — are refused for the same reason, since they
  may carry the very bit being checked.

- [#1639](https://github.com/vultisig/vultisig-sdk/pull/1639) [`348d0cd`](https://github.com/vultisig/vultisig-sdk/commit/348d0cdb20cb53553f3cad3361d3e81fda7e899b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - export canonical EIP-712 helpers and route CLI consumers through the public SDK surface

- [#1546](https://github.com/vultisig/vultisig-sdk/pull/1546) [`91862e0`](https://github.com/vultisig/vultisig-sdk/commit/91862e0960819cd4d1f859b24191fc3a1426f7c8) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the canonical `clampEvmPriorityFee` helper from the root and React Native SDK entrypoints so first-party TypeScript consumers can share the SDK's EVM fee sanity ceiling instead of re-implementing it locally.

- [#1621](https://github.com/vultisig/vultisig-sdk/pull/1621) [`d4d4665`](https://github.com/vultisig/vultisig-sdk/commit/d4d46657ffba2f8d11d81528b8caa429c655dede) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `cosmosFeeCoinDenom`, `getCosmosGasLimit`, and `getCosmosStakingGasLimit` to the `@vultisig/sdk/react-native` public entrypoint for parity with the root SDK exports.

- [#1729](https://github.com/vultisig/vultisig-sdk/pull/1729) [`6298fef`](https://github.com/vultisig/vultisig-sdk/commit/6298fef8cccea2eca9798baba9385d97b4721296) Thanks [@neavra](https://github.com/neavra)! - Fix token max-sends to use the full token balance while checking the native gas balance separately.

## 4.4.0

### Minor Changes

- [#1812](https://github.com/vultisig/vultisig-sdk/pull/1812) [`2e1b8bb`](https://github.com/vultisig/vultisig-sdk/commit/2e1b8bb597d2d0fa052a121ab2757efa228314f5) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export an exhaustive chain-descriptor registry with explorer metadata plus helpers for deriving consumer projections and attaching compile-safe consumer-local extensions.

- [#1823](https://github.com/vultisig/vultisig-sdk/pull/1823) [`1e05f2c`](https://github.com/vultisig/vultisig-sdk/commit/1e05f2c4a97772f48a2b3946a701e63e309410db) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add the versioned signable-transaction v1 schema, canonical hashing, decoder interface, approval binding, verifier, and shared fixture format.

- [#1817](https://github.com/vultisig/vultisig-sdk/pull/1817) [`67dd842`](https://github.com/vultisig/vultisig-sdk/commit/67dd8425a10f0c7b7833c02147fc0036e6ee7a64) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Surface the affiliate fee SwapKit itemizes on EVM routes, and expose a route's price impact on `GeneralSwapQuote`.

  The SwapKit EVM branch never populated `affiliateFee`, although the Solana branch already did, so an aggregator swap reached consumers with no swap fee to show and a total that omitted it. It now carries the fee. It stays absent when no amount can be vouched for — no fee entries, an itemized zero, or a shape that cannot be resolved — so consumers report the fee as part of the quoted rate rather than asserting a zero. Unresolvable shapes raise the new `SwapKitFeeShapeError`, which this branch swallows because the fee is not part of the signed EVM transaction; Solana still lets it throw, since its tx type requires the fee.

  `GeneralSwapQuote.priceImpactFraction` carries a route's signed price impact as a fraction, read from SwapKit's `meta.priceImpact` and falling back to `totalSlippageBps`. Both are narrowed to finite numbers, since nothing validates the proxy's JSON on the way in. The unit is named in the field because the neighbouring price-impact guard exposes both fraction and percent entry points, and mixing them is a silent 100x. The field is absent for providers that publish no impact, so consumers can hide the row instead of substituting a fee figure for it.

- [#1703](https://github.com/vultisig/vultisig-sdk/pull/1703) [`3ea8b2c`](https://github.com/vultisig/vultisig-sdk/commit/3ea8b2c5133a16878991ec33d569fd8498837316) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose a cached dynamic THORChain secured-asset catalog with an offline fallback for swap destination discovery.

### Patch Changes

- [#1813](https://github.com/vultisig/vultisig-sdk/pull/1813) [`aaa3aa9`](https://github.com/vultisig/vultisig-sdk/commit/aaa3aa93b62b6933f09ba8a33d09806d051215b9) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ripple): only declare genuine trust lines as TrustSet

  `RippleSpecific.transaction_type` was set from the coin's shape alone, but an
  issued-currency Payment has the identical shape — a non-native Ripple coin with
  a `contractAddress`. So sending a token stamped that payload
  `TRANSACTION_TYPE_RIPPLE_TRUST_SET`.

  That is worse than the ambiguity it was meant to remove. Before the field
  existed, a token send diverged: this SDK built a TrustSet, an iOS co-signer
  built a Payment, and the ceremony failed without signing anything. With the
  field set, every signer agrees to build a TrustSet — so the ceremony _completes_
  over an operation the user never asked for, setting a trust-line limit to the
  amount they meant to send. No funds move, and nothing surfaces it.

  Declaring is an assertion, so it now requires more than the shape: a TrustSet is
  addressed to the _issuer_, the party being trusted, while a Payment is addressed
  to a recipient.

  The signing fallback is deliberately left broad. Clients already released infer
  TrustSet from a non-native coin alone, and honouring that inference is what keeps
  a genuine TrustSet byte-identical across a mixed-version committee; narrowing it
  would break MPC parity with every signer in the field. A token send therefore
  returns to diverging safely rather than completing wrongly.

## 4.3.1

### Patch Changes

- [#1652](https://github.com/vultisig/vultisig-sdk/pull/1652) [`e71c39b`](https://github.com/vultisig/vultisig-sdk/commit/e71c39b79f9141d9f1959e108a1fcd355e848776) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Reject scientific-notation, Infinity, and hex-like StakeKit action amounts unless they are plain positive decimal strings.

- [#1815](https://github.com/vultisig/vultisig-sdk/pull/1815) [`b61dcba`](https://github.com/vultisig/vultisig-sdk/commit/b61dcbaa16bd9b09e9550484f7b1429c968b8ace) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fail closed when multi-input signature counts differ from message hashes or a single signature is paired with multiple message hashes.

- [#1822](https://github.com/vultisig/vultisig-sdk/pull/1822) [`2fc21fe`](https://github.com/vultisig/vultisig-sdk/commit/2fc21fec196a1dcf46aa6892452fc44b5ad6fb1b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Route SecureVault QBTC signing through the dedicated ML-DSA keyshare and signing primitive.

## 4.3.0

### Minor Changes

- [#1806](https://github.com/vultisig/vultisig-sdk/pull/1806) [`c0ff9b5`](https://github.com/vultisig/vultisig-sdk/commit/c0ff9b5f8fe477df10850b25cc0def27ee31b6b4) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Secured assets can be used in limit swaps. Three independent defects stood between them and a placeable order, each hidden behind the one in front of it — which is why this looked like an unimplemented feature rather than a set of bugs.

  **The memo builder rejected the notation.** `buildLimitSwapMemo` validated both legs through `assertValidPoolId`, the shared THORChain _pool-id_ grammar, which only understands dotted `CHAIN.ASSET`. Every secured denom was refused — while `getThorchainMemoAsset` was already emitting exactly that spelling, its own docstring conceding the memo builder would not accept the value it returned. A limit swap now asks its own, narrower question instead of borrowing the LP paths' validator, so widening it changes nothing for them. Synth (`BTC/BTC`) and trade (`ETH~ETH`) assets stay unsupported: a different custody model whose behaviour through the advanced swap queue has not been established, and they now say so rather than failing as malformed pool ids.

  That validator's answer is not cosmetic — it decides the memo's byte budget and which chain the payout address is validated against. A secured asset is custodied on THORChain wherever it originates, so both answer THORChain. Reading its home chain instead sized a deposit against the wrong budget and rejected the only correct payout address.

  **The placement builder recognised only RUNE as a deposit.** It branched on `areEqualCoins(fromCoin, chainFeeCoin[THORChain])`, so a secured source — on THORChain, but not RUNE — took the transfer branch and looked up a THORChain Asgard inbound. There is none, so it refused outright. Every THORChain-held source now deposits.

  **The deposit referenced an asset no vault holds.** This is the one that reached the chain and cost a fee: a secured-BTC order broadcast successfully and was rejected on-chain with `insufficient funds`, depositing `THOR.BTC` against a `btc-btc` balance. The cosmos resolver already knew how to build a secured deposit asset, but derived it exclusively from `swapPayload.fromCoin` — and a limit order carries no swap payload on the THORChain branch, so it fell through to a chain-prefix + ticker construction. It now keys off the coin the deposit actually spends, reading the denom from whichever field the coin shape carries it in (`contractAddress` on a swap payload's coin, `id` on the payload's own), since that mismatch is what let the previous version typecheck while reading nothing.

  This affected every secured denom, not just BTC. Market swaps were unaffected throughout, because they do carry a swap payload — which is why it stayed hidden. THORChain-native tokens (`tcy`, `x/…`) and RUNE are unchanged; they are not secured assets, and tests pin that they keep the `THOR.TICKER` form.

## 4.2.0

### Minor Changes

- [#1776](https://github.com/vultisig/vultisig-sdk/pull/1776) [`a812367`](https://github.com/vultisig/vultisig-sdk/commit/a812367923ac3781dc240d00124232c6f0cc3348) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - SUI works as a SwapKit swap source, and the transfer-route path no longer trusts SwapKit's `meta.txType` to decide how to decode a payload.

  Sui was rejected before any network call, on the stated grounds that no `GeneralSwapTx` variant could carry a programmable transaction block. That was never true: the `transfer` variant already carries opaque pre-built bytes as `txType` + `txPayload`, which is exactly how a Bitcoin PSBT route reaches the signer. Nothing needed porting either — `getSuiSigningInputs` has forwarded arbitrary BCS-serialized PTBs to WalletCore's `SignDirect` since the dApp Wallet Standard path landed, and the intent digest it produces is the same blake2b-32 over `[0,0,0] || ptb` that iOS computes by hand in `SwapKitSuiSigner`. The route now rides the transfer arm and hands its bytes to that signer, so a Sui source signs and broadcasts through paths already in use rather than new ones.

  `disableBuildTx` is no longer opt-out-by-exception. `swapKitTransferSourceChains` mixes deposit-only chains, which need nothing but an address, with chains whose returned bytes _are_ the thing being signed, and the request suppressed transaction building for everything in the list except a hardcoded `!== Chain.Bitcoin`. Adding any prebuilt-tx chain therefore defaulted to asking SwapKit not to build the transaction — the wrong default, and a silent one: the response simply arrives without a `tx`, and the failure surfaces later as an empty payload during keysign construction rather than at the request that caused it. The two kinds of chain are now named separately, so membership of the transfer list no longer implies anything about who builds the transaction.

  Payload decoding dispatches on the source chain instead of the wire label. SwapKit renames these labels live without versioning — `SOLANA` became `SERIALIZED_BASE64` and `CARDANO` became `CBOR`, both mid-flight — and an unrecognized label fell through to UTF-8-encoding the base64 string instead of decoding it, producing a `txPayload` of the right shape and entirely wrong bytes. The source chain is the discriminator EVM and Solana already used, and it is the only one SwapKit cannot rename. The stored `txType` is normalized to `SUI` for the same reason it must be: iOS hardcodes that spelling rather than persisting what it received, and the field is part of the cosigned `SwapKitSwapPayload`, so a device that stored the wire value would disagree with its own cosigner. A Sui route whose `tx` is not a string is now rejected outright, since the fallback would encode a JSON object into the payload and yield something that looks signable.

  Pre-built PTBs also report their real network fee. `getSuiChainSpecific` returned an empty `SuiSpecific` for the `signSui` case on the reasoning that a built PTB has no construction inputs to fetch — true, but `getSuiFeeAmount` reads its budget from that message, so `BigInt('')` made every such transaction display a zero fee while the chain charged the budget baked into the bytes. The gas budget and price are read back out of the PTB offline, with no RPC call, and a payload that cannot be decoded still falls back to blank rather than blocking a transaction over a display concern. This corrects the dApp signing path as well as swaps.

  Cardano stays blocked as a source. Its payload decode returns an empty byte array — there is no implementation at all — so any transaction built from it would be silently wrong.

### Patch Changes

- [#1801](https://github.com/vultisig/vultisig-sdk/pull/1801) [`5ce75b5`](https://github.com/vultisig/vultisig-sdk/commit/5ce75b53c527b373eb9ccacceac6edbaacf4ebec) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Unblock the `quality:audit` CI gate, which was failing repo-wide on 3 newly-published high-severity advisories:

  - `nanoid` (via `postcss`, GHSA-2v37-7h3g-55p8): fixed by a resolution bump to `^3.3.17` - a real, safe patch upgrade, no API change.
  - `image-size` (via `metro@0.84.4`, GHSA-w3rx-r6r6-pgpr / GHSA-5p2g-fcmc-qvqq): no fix is available yet. The patched line is `>=2.0.3`, but `image-size` has not published past `2.0.2`, and `metro`'s latest release (`0.87.0`) still pins `image-size@^1.0.2` - there is no dependency bump that can close this today. `image-size` is not a direct dependency anywhere in this repo; it is metro's own asset-dimension parser, used only by the RN/Metro dev bundler toolchain, never by SDK/CLI runtime code shipped to consumers. The two ignores and their durable exception record are in `.yarnrc.yml`; remove both once an upstream-fixed `image-size` release is resolved by this dependency path, or Metro no longer depends on the vulnerable `<=2.0.2` range.

- [#1762](https://github.com/vultisig/vultisig-sdk/pull/1762) [`eb7d862`](https://github.com/vultisig/vultisig-sdk/commit/eb7d86260a2ea5cdd661951d15677ec4db3517b0) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Align raw Solana duplicate-broadcast handling with the core and React Native resolvers by accepting `AlreadyProcessed` when status is pending or unavailable while still rejecting explicit on-chain failures.

- [#1604](https://github.com/vultisig/vultisig-sdk/pull/1604) [`9e88dcf`](https://github.com/vultisig/vultisig-sdk/commit/9e88dcf4875ebccfc7ea021707d99ec728a41eea) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export `DEFAULT_CHAINS` and `defaultChains` from the root and React Native SDK entrypoints so consumers can reuse the canonical onboarding/import default-chain set instead of maintaining local mirrors.

- [#1613](https://github.com/vultisig/vultisig-sdk/pull/1613) [`68f8899`](https://github.com/vultisig/vultisig-sdk/commit/68f8899f6545b3876703e7a56b43d73a64217da2) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export canonical `ChainKind` helpers from the React Native SDK entrypoint.

- [#1794](https://github.com/vultisig/vultisig-sdk/pull/1794) [`80b19bd`](https://github.com/vultisig/vultisig-sdk/commit/80b19bdbfbcb6af875a0b145bb02306552adac27) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(ripple): state TrustSet on the wire so it co-signs with iOS

  An XRPL trust-line activation originated here could not be co-signed by an iOS
  device: the ceremony diverged and never completed. No funds moved, but the trust
  line could not be opened at all in a mixed committee.

  A non-native Ripple coin is ambiguous on its own — the same `(currency, issuer)`
  pair means either "open a trust line for this token" (TrustSet, where the keysign
  amount is the trust-line LIMIT) or "send this token" (Payment with a
  CurrencyAmount) — and the two sign different bytes. commondata already carries
  the discriminator that resolves it, but the generated protos here were stale, so
  `RippleSpecific.transaction_type` never reached the wire and each platform fell
  back to its own default: this SDK always read a TrustSet, iOS read a Payment.

  Regenerates `blockchain_specific_pb.ts` from commondata (adding
  `RippleSpecific.transaction_type` and `TRANSACTION_TYPE_RIPPLE_TRUST_SET`), sets
  the field when building a TrustSet, and prefers it when signing.

  The coin-shape inference is kept as the fallback, deliberately: clients shipped
  before this field infer TrustSet from a non-native coin alone, so honouring that
  keeps a TrustSet byte-identical across a mixed-version committee. Native XRP
  payloads and verbatim `signRipple` dApp transactions leave the field unset, so
  their signed bytes are unchanged.

## 4.1.0

### Minor Changes

- [#1753](https://github.com/vultisig/vultisig-sdk/pull/1753) [`0bd1a2d`](https://github.com/vultisig/vultisig-sdk/commit/0bd1a2dfcfc723c77a684be62cc4a676824dc217) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Prevent stale vault instances from overwriting newer storage updates. `vault.save()` now rejects stale writes with
  `VaultConflictError`; pass `{ conflictStrategy: 'merge-metadata' }` to retry a non-overlapping metadata edit.

- [#1696](https://github.com/vultisig/vultisig-sdk/pull/1696) [`37d7044`](https://github.com/vultisig/vultisig-sdk/commit/37d7044e33d475ddce93b91ff6295d55490052b4) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Limit-order cancellation, end to end: a full-form memo asset, a cancel keysign payload builder, and cancel-aware review for co-signers.

  The primitives shipped earlier could describe a cancellation but not send one, and a device joining the ceremony could not read one at all. These are the three pieces that close that.

  `getThorchainCancelMemoAsset` emits the spelling a cancel requires — the same notation as the placement path, minus the abbreviation. That difference is the entire point: `ModifyLimitSwapMemo` is the one inbound memo type `processOneTxIn` does not route through `fuzzyAssetMatch`, so a placement's six-character contract suffix would address a bucket holding no order. `buildCancelLimitSwapMemo` already refused abbreviated assets, which meant there was previously no supported way to produce an input it would accept for a token leg. Both spellings now share one converter and one set of validation rules, so they cannot drift apart in anything but the abbreviation. `getThorchainMemoAssetChain` resolves a memo asset back to its home chain across every flavour, including the secured denoms that a `.`-split would fail to resolve at all.

  `buildLimitSwapCancelKeysignPayload` turns that memo into a signable transaction, branching on where the order was funded: a THORChain source becomes a `MsgDeposit` carrying no value, and an L1 source a transfer to the live Asgard inbound with derived dust attached solely so Bifrost observes it. The signing asset is the funding chain's **gas** asset, never the order's own — a cancel moves no tokens, and a token here would build an ERC20 transfer that drops the memo entirely. Every gate fails closed: a retarget (`m=<` with a non-zero final field) is refused rather than signed as a cancellation, a memo that overflows the source chain's budget is refused rather than truncated into one matching nothing, and the destination is taken from a live inbound view rather than a cache.

  The signing coin's chain is checked against the memo's, too. The two arrive as independent parameters, so a caller reaching for "the vault's ETH coin" while holding a BTC-sourced memo would otherwise get a payload that builds, signs and broadcasts cleanly — and is then refunded by THORChain's `From.IsChain(Source.Asset.GetChain())` check, leaving a successful-looking transaction that cancelled nothing. The funding chain is derived from the memo rather than cross-checked against a second parameter, so there is one authority for it. `getThorchainMemoAssetSourceChain` supplies that with `GetChain()` semantics rather than the asset's home chain: a secured or synth source is custodied on THORChain and must be sent from a THOR address even though it originates elsewhere.

  The `EnableAdvSwapQueue` mimir is deliberately _not_ re-checked here, unlike at placement. That gate protects a new order from executing as an unprotected market swap, a risk a cancel does not carry; refusing to close an already-resting position because the queue stopped accepting new ones would strand it for the remainder of its TTL with no way out.

  `getKeysignLimitSwapCancel` and `parseCancelLimitSwapMemo` give a joining device the order being closed, decoded from the memo. A cancel carries no swap payload on any branch, so a co-signer keying off one previously saw a dust transfer to an opaque address — worse than uninformative, since a trivial amount reads as harmless while the transaction closes a position. As with placement, the terms come from the memo because the memo is the instruction THORChain executes, so what a reviewer sees cannot disagree with what gets signed. A retarget is reported as not-a-cancellation rather than mislabelled, and the reproduced bucket key travels alongside so a reviewer holding the vault's open orders can tell whether the cancel is unambiguous.

  `getThorchainCancelMemoAsset` emits its asset UPPER-CASED, unlike the coin's own contract id. Case is not semantic to THORNode — `common.ParseAsset` upper-cases whatever it is given, and the queue index key is built from an upper-cased asset — but it is semantic to this package's pool-id validation, which cancel eligibility routes through to size the memo against its source chain. In the contract's native lower case, every ERC20-funded order reads as an unroutable source chain and becomes uncancellable.

### Patch Changes

- [#1755](https://github.com/vultisig/vultisig-sdk/pull/1755) [`7d2a91d`](https://github.com/vultisig/vultisig-sdk/commit/7d2a91de80a297c6db6b2fe2e9db41ace609c822) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fix fiat valuation losing base-unit precision through float-first conversion, with regression coverage for exact VULT discount-tier boundaries.

## 4.0.3

### Patch Changes

- [#1754](https://github.com/vultisig/vultisig-sdk/pull/1754) [`a6ba6b4`](https://github.com/vultisig/vultisig-sdk/commit/a6ba6b4688027d6abf4ce0eb3385d6e141f5ef57) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Harden React Native Solana broadcasting with deterministic signatures, idempotent duplicate handling, and signature-status verification for ambiguous send errors.

- [#1756](https://github.com/vultisig/vultisig-sdk/pull/1756) [`fbc5b44`](https://github.com/vultisig/vultisig-sdk/commit/fbc5b4445e102534eb434d7cabcd6fe8d633b391) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Allow native swaps whose source is the protocol's own chain (RUNE on THORChain, CACAO on MayaChain) past the broadcast guard: those routes are MsgDeposits with no inbound vault and never appear in /inbound_addresses, so the inbound-existence and vault-address checks are skipped for them while quote-expiry and trading-halt checks still run.

- [#1588](https://github.com/vultisig/vultisig-sdk/pull/1588) [`74cc529`](https://github.com/vultisig/vultisig-sdk/commit/74cc52912f007c6e2afe3c5b9471b6610d39f3fc) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the canonical gas comparison helpers from `@vultisig/sdk/react-native`.

- [#1601](https://github.com/vultisig/vultisig-sdk/pull/1601) [`c49a3f2`](https://github.com/vultisig/vultisig-sdk/commit/c49a3f2bdff6d220960c3609d08b6c848961ed9f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix address-format validation to honor canonical chain aliases and cosmos chain ids via `normalizeChain`

- [#1717](https://github.com/vultisig/vultisig-sdk/pull/1717) [`c109ff4`](https://github.com/vultisig/vultisig-sdk/commit/c109ff4f6504b9458454bad9b392f2682a51992a) Thanks [@neavra](https://github.com/neavra)! - Create keyshare temp files exclusively and keep credential and CLI config directories owner-only.

- [#1718](https://github.com/vultisig/vultisig-sdk/pull/1718) [`fb601d5`](https://github.com/vultisig/vultisig-sdk/commit/fb601d5ad6f6e6a7089ca449ee24bc5c1d7b82f9) Thanks [@neavra](https://github.com/neavra)! - Make transaction help accurately distinguish interactive previews from non-interactive confirmation requirements, describe the addresses command without advertising an unsupported argument, and remove duplicated wording from amount-too-small swap errors.

- [#1689](https://github.com/vultisig/vultisig-sdk/pull/1689) [`82ea0b7`](https://github.com/vultisig/vultisig-sdk/commit/82ea0b7526ef7033605aeed461bb156416e4c012) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Wait for bundled ERC-20 approval transactions to confirm before broadcasting the dependent swap transaction.

## 4.0.2

### Patch Changes

- [#1580](https://github.com/vultisig/vultisig-sdk/pull/1580) [`1a87e08`](https://github.com/vultisig/vultisig-sdk/commit/1a87e080449b37475434f38c99212cc877fd5a4e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Publish `@vultisig/sdk/tools/bridge` as a real package subpath with dedicated JS and declaration bundles.

- [#1578](https://github.com/vultisig/vultisig-sdk/pull/1578) [`9ff1eb2`](https://github.com/vultisig/vultisig-sdk/commit/9ff1eb22030cf2551269b4195155e395d624223b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the full River helper family from `@vultisig/sdk/react-native`, including market/hint helpers and trove-status canonicals.

- [#1576](https://github.com/vultisig/vultisig-sdk/pull/1576) [`7ca8c40`](https://github.com/vultisig/vultisig-sdk/commit/7ca8c406a718624a701b8616a3cee1bbab6c5554) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix the Astroport swap builder to use a React Native / Hermes-safe fetch timeout instead of `AbortSignal.timeout()`.

- [#1698](https://github.com/vultisig/vultisig-sdk/pull/1698) [`9dfd76c`](https://github.com/vultisig/vultisig-sdk/commit/9dfd76c617812418521c820e65a07a02003d5e5e) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - Wire `assertSafeDestination` into `prepareSendTxFromKeys` so every send that goes through the keys path (vault-CLI, agent-backend) is guarded against known-dangerous contract addresses. Adds an own-token-contract guard that rejects sends to the token's own contract address, which is a common drain-wallet vector. Mirrors the existing destination guard on the vault path.

- [#1720](https://github.com/vultisig/vultisig-sdk/pull/1720) [`413423b`](https://github.com/vultisig/vultisig-sdk/commit/413423b70655e6e4d7faf9cb9f10b63f601e42dc) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Carry caller-supplied THORChain and MayaChain swap destinations through agent MsgDeposit execution, preserve the existing self-swap default, and reject quote memos that substitute another destination.

## 4.0.1

### Patch Changes

- [#1625](https://github.com/vultisig/vultisig-sdk/pull/1625) [`3767033`](https://github.com/vultisig/vultisig-sdk/commit/3767033f51804f3fff5088098c767280577bd4a4) Thanks [@neavra](https://github.com/neavra)! - Resolve tracked vault token IDs to their canonical asset IDs before fetching prices for balance and portfolio results.

- [#1692](https://github.com/vultisig/vultisig-sdk/pull/1692) [`68df301`](https://github.com/vultisig/vultisig-sdk/commit/68df301134b8000187a11cf92b9427e8200d4623) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Re-encrypt successfully imported legacy vault backups with the salted PBKDF2 format before persistence and emit a typed security notice recommending password rotation and replacement of old backup files.

## 4.0.0

### Major Changes

- [#1608](https://github.com/vultisig/vultisig-sdk/pull/1608) [`791d344`](https://github.com/vultisig/vultisig-sdk/commit/791d344c2dacc289c9fb7fbcbc38488aeeb47542) Thanks [@neavra](https://github.com/neavra)! - Fix tracked token balance fetching and make token removal report the truth.

  A token added with `tokens --add` is stored under an id of the form `<Chain>-<address>`. That id was passed to the RPC as if it were a contract address; the RPC rejected it, the throw was swallowed per-chain, and the **whole chain's balances disappeared** — native asset included — leaving only a `console.warn`. Balance lookups now resolve a stored token reference to its real contract address / chain-level asset id before both the per-coin and batched calls. What is written to the vault file is unchanged, and balance result keys still use the stored id.

  **Behavior change — `tokens --remove` now fails when nothing was removed.** Removal previously matched on an exact id comparison, so removing by symbol (or by contract address for a token added under the prefixed id form) matched nothing while the command still printed `Removed token …` and exited 0. Removal now goes through the shared token resolver, and a reference that matches no tracked token raises the existing not-found error and exits **5** (`RESOURCE_NOT_FOUND`) instead of exiting 0. A script that removed an untracked token and relied on a zero exit will now see a failure. Removal by symbol and by contract address, which previously silently no-op'd, now work.

  **Behavior change — the agent `vault_coin remove` tool reports per-coin outcomes.** It previously returned `removed: true` unconditionally; it now returns the SDK's actual result, so the model is told when a coin was not tracked. Batch removals return `{ chain, tokenId, removed }` per coin rather than `{ chain, tokenId }`.

  **Breaking SDK API change — `VaultBase.removeToken` now returns `Promise<boolean>` instead of `Promise<void>`.** It resolves to `true` when a tracked token was removed and persisted, and `false` when the reference matched nothing. Consumers with callbacks, interfaces, or overrides typed to the previous `Promise<void>` signature must update those types.

### Minor Changes

- [#1541](https://github.com/vultisig/vultisig-sdk/pull/1541) [`b9f81af`](https://github.com/vultisig/vultisig-sdk/commit/b9f81af9065a5c0bfc2f86f8fb20aa51e670ab77) Thanks [@realpaaao](https://github.com/realpaaao)! - Add Robinhood Chain (Arbitrum Orbit EVM L2, chain id 4663, ETH gas). Swaps enabled via LiFi and KyberSwap.

- [#1686](https://github.com/vultisig/vultisig-sdk/pull/1686) [`c0e260f`](https://github.com/vultisig/vultisig-sdk/commit/c0e260f89d159d14b170384864b24b101b23dfb0) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Limit-order cancellation primitives: the `m=<` modify-limit-swap memo in its cancel form, eligibility, bucket-key duplicate detection, and L1 dust.

  Cancellation is not a variation on placement. Every failure mode is silent — the transaction confirms, the fee is spent, and the order carries on resting with nothing to distinguish it from success — so each rule is enforced rather than documented.

  `buildCancelLimitSwapMemo` refuses abbreviated assets outright: `ModifyLimitSwapMemo` is the one inbound memo type `processOneTxIn` does not run through `fuzzyAssetMatch`, so the placement memo's six-character contract suffix would address a bucket that by construction holds no order. Amounts are emitted as plain decimal integers, never compressed — these coins parse through `cosmos.ParseCoins`, which does not understand the scientific notation a placement LIM may use.

  `getLimitSwapCancelEligibility` fails closed at every unknown and cross-checks what was recorded at signing against what the queue reports — **assets as well as amounts**. Absence is not disagreement (an order placed seconds ago has not been polled), but a present-and-unparseable observation blocks exactly as a mismatch does.

  `getThorchainLimitOrderBucketKey` reproduces the advanced-swap-queue index key, including its zero-padding _and_ right-truncation at 18 characters. Orders are addressed by `(layer-1 pair, ratio) + FromAddress` and the first match in the bucket wins, so orders sharing a ratio are not independently cancellable — compared on the key rather than on equal amounts, which would under-report collisions.

  `getLimitSwapCancelDust` rescales the live `dust_threshold` from THORChain's 1e8 into the source coin's own precision, with a safety multiple and an upper ceiling, refusing rather than defaulting when the threshold is missing, unparseable, or rounds away. A cancel once signed for 2000 wei — the 1e8 threshold used verbatim as an 18-decimal chain's smallest unit — was truncated to zero and never observed; that case is pinned by a test.

### Patch Changes

- [#1683](https://github.com/vultisig/vultisig-sdk/pull/1683) [`2ef8f3f`](https://github.com/vultisig/vultisig-sdk/commit/2ef8f3f42f5d44673568b39a91c42bd0fe410311) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject malformed or wrong-chain limit-swap destinations while decoding a memo, so co-signers fall back to generic payload review instead of seeing an invalid destination as an enriched order.

- Updated dependencies [[`b9f81af`](https://github.com/vultisig/vultisig-sdk/commit/b9f81af9065a5c0bfc2f86f8fb20aa51e670ab77)]:
  - @vultisig/walletcore-native@0.2.0

## 3.1.0

### Minor Changes

- [#1630](https://github.com/vultisig/vultisig-sdk/pull/1630) [`9436de6`](https://github.com/vultisig/vultisig-sdk/commit/9436de627b4d123d7f9bb76e4981722cd84266d1) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Limit-order tracking primitives: queue client, outcome resolution, and a shared status model.

  `getLimitSwapQueue`/`parseLimitSwapQueue` read THORNode's `/thorchain/queue/limit_swaps` (sender-scoped — one call covers all of an address's orders) into typed resting orders: fill split, TTL, trade target, and the target asset as THORChain holds it after fuzzy-match expansion. An absent `limit_swaps` key parses as `null` ("no information"), never as an empty queue — an order's disappearance from this list is what marks it terminal, so a response we didn't understand must not close every tracked order at once.

  `resolveLimitSwapOutcome`/`classifyLimitSwapActions` answer what happened to an order that left the queue, from Midgard `/v2/actions`. A `refund` action's reason is authoritative regardless of its outbound status. The `"swap has been completed."` reason is THORNode's TTL-expiry settle signal, not a fill confirmation — verified live on mainnet, a refund carrying that reason returned the full deposit to the sender with zero of the destination asset ever paid out — so it classifies as `expired` rather than `filled`. Rate limits, server errors and empty responses are all `unresolved`: an answer THORChain hasn't given, never an outcome.

  `getThorchainTxResult` reads `/cosmos/tx/v1beta1/txs/{hash}` — the only place a rejected `MsgDeposit` is visible, since it never produces a Midgard action — so a rejected placement cannot sit "pending" forever.

  `limitSwapOrderStatuses` + `isTerminalLimitSwapOrderStatus` give every platform the same order lifecycle to render.

### Patch Changes

- [#1456](https://github.com/vultisig/vultisig-sdk/pull/1456) [`645e291`](https://github.com/vultisig/vultisig-sdk/commit/645e2917aa1b6cd58c5599ddb32b1c89fa73e20e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Preserve SwapKit fee asset metadata for Solana-source quotes, including Chainflip's independent stable USDC fee asset, and sum repeated fee entries before fiat valuation.

## 3.0.1

### Patch Changes

- [#1678](https://github.com/vultisig/vultisig-sdk/pull/1678) [`7603f32`](https://github.com/vultisig/vultisig-sdk/commit/7603f32e612a7d575b05c49e604aed228817f38c) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Compare VULT discount tier balances in bigint base units instead of float64.
  `100000n * 10n**18n` is not representable in float64 (`Number` round-trips it
  to 99999.99999999999), so a wallet holding exactly 100,000 VULT — the diamond
  minimum — was demoted to platinum and paid a 25 bps affiliate fee instead of
  15 on every swap. The float rounding also swallowed one-base-unit differences
  around every tier boundary. Comparisons now stay exact via `toChainAmount`
  (vultisig-sdk#1677).

## 3.0.0

### Major Changes

- [#1606](https://github.com/vultisig/vultisig-sdk/pull/1606) [`c593ba0`](https://github.com/vultisig/vultisig-sdk/commit/c593ba0693f6a02402aac0912a97d9e36e8efad0) Thanks [@neavra](https://github.com/neavra)! - Make token references resolve consistently across the vault and CLI surfaces.

  **`@vultisig/sdk` — consumer-visible behaviour change on `send`, `swap` and `balance`:**

  - A token reference (the `symbol` on `send`/`swap`, the `tokenId` on `balance`)
    now resolves by contract address / stored vault token id as well as by symbol
    or well-known ticker, through one shared resolver. Previously `send` matched
    by symbol only while `balance` treated the same value as a raw contract
    address, so no single value worked on both paths and an ERC-20 send could not
    be built at all.
  - The change is additive. Symbol/ticker is still matched first and the vault's
    own tokens still shadow the well-known registry, so every reference that
    resolved before resolves to the same token and produces the same signed
    payload. Only references that previously threw now resolve. A reference
    matching nothing is still passed through to the balance layer untouched.
  - `send({ dryRun: true })` gains `feeSymbol` and reports the network fee in the
    chain's native asset. For a token send, `fee` was previously formatted with
    the token's decimals and `total` was amount + fee — both meaningless when the
    fee is paid in a different asset. `total` is now denominated in the asset
    being sent. Native sends are unaffected.
  - A `Balance` for a token is labelled by the same resolution. Previously the
    token was found by an exact match against the vault's stored token id, so a
    well-known token the vault does not track — or one added with an id that is
    not its bare contract address — fell through to a default of 18 decimals with
    the raw id as `symbol`. `formatBalance` now resolves the same way everything
    else does; a token in no registry still falls back as before.

  **`@vultisig/cli`:**

  - `send --token` works with either a contract address or a symbol, and its
    dry-run preview quotes the fee in the native asset. The preview also warns
    separately when the native balance cannot cover the fee — a token send draws
    its fee from a different balance than the one `total` is checked against.
  - `portfolio`'s total now equals the sum of the breakdown printed under it, with
    each held token itemized as its own row (`chainBalances[].tokens`).
  - `balance <chain> --tokens` returns token balances instead of silently
    ignoring the flag; without the flag the output is unchanged.
  - `tokens --discover` documents that it saves discovered tokens to the vault.

### Patch Changes

- [#1632](https://github.com/vultisig/vultisig-sdk/pull/1632) [`4c76c50`](https://github.com/vultisig/vultisig-sdk/commit/4c76c507df970c6bbb1542c72a7ab0e06d039e65) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Normalize StakeKit network aliases consistently across search and balance reads.

- [#1649](https://github.com/vultisig/vultisig-sdk/pull/1649) [`bb752e2`](https://github.com/vultisig/vultisig-sdk/commit/bb752e25dc318488a72d9b6b7aa8d484c568dbaa) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Preserve already-broadcast transaction hashes when a later bundled broadcast leg fails.

- [#1174](https://github.com/vultisig/vultisig-sdk/pull/1174) [`0d73d9f`](https://github.com/vultisig/vultisig-sdk/commit/0d73d9f5d08b10e52b9461678d7d700afba52e01) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix CLI shell completion so vault suggestions read the SDK's real storage layout and honor `VULTISIG_CONFIG_DIR`.

- [#1661](https://github.com/vultisig/vultisig-sdk/pull/1661) [`ec4aac7`](https://github.com/vultisig/vultisig-sdk/commit/ec4aac78e96db00cae283fe8a506983a30c42412) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Floor the signed EVM `maxPriorityFeePerGas` on tip-auction chains: 1 gwei on
  Ethereum (parity with iOS `FeeService.calculateMaxPriorityFeePerGas` and
  Android `EthereumFeeService`, which both floor at 1 gwei) and 30 gwei on
  Polygon (validators enforce a ~25 gwei minimum tip). In quiet fee markets the
  raw `eth_maxPriorityFeePerGas` suggestion collapses to near zero (~0.0004 gwei
  observed live), and a tx signed with that tip is never picked up by block
  builders — it sat in the public mempool until evicted, so Ethereum mainnet
  sends from extension/desktop broadcast fine but vanished unmined. Rollup L2s
  and the zkSync `estimateFee` path keep their current no-floor behavior, and
  explicit user fee settings still bypass the clamp (vultisig-sdk#1659).

- [#1163](https://github.com/vultisig/vultisig-sdk/pull/1163) [`286e342`](https://github.com/vultisig/vultisig-sdk/commit/286e342962e8fa63525c8de25bed84295fd468cd) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Promote THOR/Maya swap-memo parsing into the public SDK API and update the CLI executor to consume the shared helper.

- [#1193](https://github.com/vultisig/vultisig-sdk/pull/1193) [`d1ed4bb`](https://github.com/vultisig/vultisig-sdk/commit/d1ed4bbd459bfed006cf9f319d9e39356ffe25b9) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Reconcile and publicly export the dangerous/burn-address guard.

  The SDK's `dangerousAddresses.ts` list had drifted from its own authoritative
  parity source (mcp-ts `src/lib/dangerous-addresses.ts`) and from
  agent-backend-ts's copy — the exact drift class the file's own header documents
  via the CCTP `mintRecipient` burn incident. Reconciled to the **union** of all
  three copies (additive/tightening only, never weakening an existing entry):

  - Solana: added the SPL Token Program and Wrapped SOL mint (from mcp-ts), kept
    the Solana Incinerator (which only this SDK copy carried).
  - UTXO (Bitcoin/Litecoin/Dogecoin/Bitcoin-Cash/Dash/Zcash): added the Bitcoin
    null-script and eater burn addresses.
  - XRP (Ripple): added the ACCOUNT_ZERO black-hole and ACCOUNT_ONE reserved
    system account.

  The guard (`assertSafeDestination`, `assertSafeEvmDestination`,
  `isEvmBurnAddress`, `getEvmDangerousReason`, `getChainDangerousReason`, and the
  per-family tables) is now exported from the SDK's public API so the app and
  agent-backend-ts can consume the single source of truth instead of maintaining
  divergent copies. Non-EVM lists stay chain-family-scoped, so a burn address for
  one family never blocks an unrelated chain.

  The canonical table now lives in `@vultisig/core-chain`
  (`security/dangerousAddresses`) — re-exported unchanged from the SDK — so the
  lower-level core-chain swap guard can share it too (core-chain cannot depend on
  the SDK). Two in-repo siblings that still held private, incomplete copies now
  route through it:

  - `recipientSanity.isNullAddress` (SDK) previously missed the SPL Token
    Program + Wrapped SOL mint, the Bitcoin/XRP burns, and the third EVM variant;
    it now flags all of them.
  - `findSwapQuote`'s custom-recipient guard (core-chain) previously vetted only
    the EVM zero + `…dEaD` addresses; it now rejects the `0xdead…42069` variant
    and the base58 (Solana / UTXO / XRP) family burns on the destination chain.

  The shared EVM shape check is now case-insensitive on the `0x` prefix, so a
  `0X…`-prefixed burn can't slip past (parity with the Go guard).

- [#1655](https://github.com/vultisig/vultisig-sdk/pull/1655) [`648d932`](https://github.com/vultisig/vultisig-sdk/commit/648d932b7e3c6f3c30ff7007f3c4e4387879ba38) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(ripple): resolve logos for XRPL issued currencies

  Only curated issued currencies (RLUSD) carried a logo, so every other trust-line
  token — SOLO, an issuer's USD, anything added by id or surfaced by ledger
  discovery — resolved with no logo and rendered as a broken-image placeholder in
  clients.

  `getRippleTokenMetadata` now reads an uncurated token's official icon from the
  XRPL token registry (xrplmeta), keyed by the `<currency>:<issuer>` pair. This is
  the same shape as the EVM resolver reading `logoURI` from 1inch and the Solana
  resolver returning `icon`; XRPL was the outlier because it has no on-ledger token
  metadata registry of its own.

  A curated token is unchanged: it keeps its bundled logo and price provider and
  performs no lookup. An uncurated token may borrow an icon but never a curated
  token's `priceProviderId` — two issuers can share a ticker on XRPL, so the issuer
  is what identifies a token. The lookup fails soft: an unlisted token or an
  unreachable registry still resolves, just without a logo.

- [#1165](https://github.com/vultisig/vultisig-sdk/pull/1165) [`f3fd265`](https://github.com/vultisig/vultisig-sdk/commit/f3fd2654b8d90f5d5aaa3c578fcd5fad752203d3) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-export the RN-safe `parseChain`, `parseTicker`, and `knownContracts` helpers from `@vultisig/sdk/platforms/react-native` so mobile consumers can use the SDK's canonical public helpers without maintaining local copies or reaching into non-RN entrypoints.

- [#1171](https://github.com/vultisig/vultisig-sdk/pull/1171) [`a24771a`](https://github.com/vultisig/vultisig-sdk/commit/a24771afba7c210423c586f9492d3531cdcd47f5) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Make the SDK's default Node/Electron `FileStorage` honor `VULTISIG_CONFIG_DIR` so default vault storage stays co-located with the CLI config, credentials, cache, and broadcast journal paths.

- [#1653](https://github.com/vultisig/vultisig-sdk/pull/1653) [`6763ddb`](https://github.com/vultisig/vultisig-sdk/commit/6763ddbd382bd71cdf9f24bbd3bde0116a694906) Thanks [@aminsato](https://github.com/aminsato)! - Sign Sei as EIP-1559 (enveloped) instead of legacy, matching iOS
  (`EVMHelper.setGasParameters`) and Android (`EthereumGasHelper.setGasParameters`),
  which sign every EVM chain except BSC as EIP-1559. Sei was the only
  enveloped-capable EVM chain still mapped to `'legacy'` in
  `evmChainTxFeeFormat`, so the pre-signing hash (and therefore the relay
  `message_id`) diverged between mobile and extension/desktop, deadlocking
  Sei co-signing between them (vultisig-windows#4369).

- [#1433](https://github.com/vultisig/vultisig-sdk/pull/1433) [`259837f`](https://github.com/vultisig/vultisig-sdk/commit/259837f482717624d6422797e088a9341d4f1a23) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Return the tx hash string (not the full RPC envelope object) from the Tron broadcast resolver, consistent with the other broadcast resolvers. The SDK's `BroadcastService` discards the broadcast resolver's return and derives the hash itself, so no consumer read the object — this is a shape-consistency fix.

## 2.23.0

### Minor Changes

- [#1478](https://github.com/vultisig/vultisig-sdk/pull/1478) [`23563f4`](https://github.com/vultisig/vultisig-sdk/commit/23563f41da7b142e5ae9d34d4287eaaaa3fef701) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose chain-neutral `tokenId` fields across public token registry and discovery surfaces while retaining `contractAddress` as a deprecated compatibility alias.

### Patch Changes

- [#1568](https://github.com/vultisig/vultisig-sdk/pull/1568) [`859ab28`](https://github.com/vultisig/vultisig-sdk/commit/859ab287d3574c508b4abce5950e8e42c17f8198) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(ripple): add XRPL issued-currency (custom token) support

  XRPL issued currencies (trust-line tokens / IOUs) had no token metadata resolver,
  so custom tokens could not be added on Ripple. Adds `getRippleTokenMetadata` and
  registers Ripple in `chainsWithTokenMetadataDiscovery`. Unlike EVM/Tron there is no
  on-ledger metadata call: XRPL exposes no per-token decimal metadata — so the SDK
  applies its fixed issued-currency decimal policy (`rippleIssuedCurrencyDecimals`) —
  and the ticker is derived from the currency code, so the resolver fetches nothing.
  Curated tokens
  (RLUSD) get their logo and price provider merged in; an arbitrary token gets neither
  rather than borrowing a known token's identity, since two issuers can share a ticker
  on XRPL.

  `isValidTokenId` now also accepts a human ticker (`SOLO`, `RLUSD`) wherever an
  on-ledger currency code is accepted — the form shown on explorers like xrpscan — and
  a new `normalizeTokenId` canonicalises a pasted id to the on-ledger form.

  `BalanceService.addToken`/`removeToken` normalise the token id (and its matching
  `contractAddress`) before it enters persisted state, so a manually added
  `RLUSD.<issuer>` collapses onto the canonical `524C…<issuer>` that ledger discovery
  stores instead of being kept as a second, distinct token. A no-op for chains whose
  ids are already canonical.

## 2.22.0

### Minor Changes

- [#1475](https://github.com/vultisig/vultisig-sdk/pull/1475) [`4b14790`](https://github.com/vultisig/vultisig-sdk/commit/4b14790fb5f0fa5b9a58f6fe5575ad4c2bab3867) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose canonical Cosmos native-send fee metadata so first-party consumers can stop maintaining local tables: IBC chains use their shared/default floors, MayaChain exposes its fixed fee, and THORChain remains explicitly unresolved because its fee comes from live network data.

- [#1614](https://github.com/vultisig/vultisig-sdk/pull/1614) [`bb5b62c`](https://github.com/vultisig/vultisig-sdk/commit/bb5b62c60ca298d0aa98614e8c2b01eeef0d8bdb) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Let joining devices review a THORChain limit order instead of approving it as a generic send.

  The limit-order builder attaches a swap payload only for ERC20 sources, so RUNE and native-gas-asset orders reached a co-signer as a transfer to an opaque address with an opaque memo — no buy asset, payout destination, or minimum received.

  `getKeysignLimitSwapOrder` decodes those terms from `keysignPayload.memo`, which is present on every source branch. Reading the memo also makes the review trustworthy rather than merely present: the memo is the exact string THORChain executes, so terms derived from it cannot disagree with what gets signed, whereas a display field supplied by the initiating device can.

  `parseLimitSwapMemo` is the underlying decoder, and `assertLimitSwapMemo` now delegates to it so the grammar has one implementation.

  `buildLimitSwapKeysignPayload` now derives the ERC20 branch's `toAmountDecimal` from the memo's LIM rather than from the caller's `expectedToAmount`. That argument is now an optional cross-check: supplying a value that disagrees with the memo throws, which catches a caller that rescaled the LIM into the target coin's own decimals — a mistake that signs a correct order while showing a co-signer a wrong figure.

- [#1583](https://github.com/vultisig/vultisig-sdk/pull/1583) [`028b3ce`](https://github.com/vultisig/vultisig-sdk/commit/028b3cec5e56e5ab41de5eeb66f6837af9e1dd27) Thanks [@Toby1009](https://github.com/Toby1009)! - Move every Sui read, simulation and broadcast off JSON-RPC.

  Sui is retiring JSON-RPC: shutdown on Foundation mainnet full nodes began the
  week of 2026-07-27 and full decommission (code removal) lands mid-October 2026,
  after which no provider can serve it. This is a scheduled migration ahead of
  that date, NOT a fix for a live outage — as of 2026-07-27 both
  `sui-rpc.publicnode.com` and `fullnode.mainnet.sui.io` still answer JSON-RPC.

  - `getSuiClient()` now returns a `SuiGrpcClient` pointed at
    `https://fullnode.mainnet.sui.io:443` (gRPC-web over HTTPS).
  - React Native uses `SuiGraphQLClient` against
    `https://graphql.mainnet.sui.io/graphql` instead: grpc-web needs
    `Response.body` streaming, which Hermes' fetch does not provide. Both clients
    implement the same unified transport interface, so callsites are identical.
  - Balance, coin metadata, coin listing, tx hash, tx status, broadcast and
    keysign gas refinement moved to `getBalance` / `getCoinMetadata` / `listCoins`
    / `simulateTransaction` / `getTransaction` / `executeTransaction`.
  - The dependency-free `@vultisig/sdk` balance tools (`getSuiBalance`,
    `getSuiTokenBalance`, `getSuiAllBalances`) now POST Sui GraphQL and follow the
    paginated `balances` connection to completion, returning `tokens_unavailable`
    rather than a silently truncated portfolio.

  Broadcast-error classification follows the transport. A gRPC failure carries the
  grpc-status NAME in `code` (not a JSON-RPC number) and a percent-encoded message,
  so both classifiers were re-pointed:

  - `isTransientBroadcastError` retries `UNAVAILABLE` / `DEADLINE_EXCEEDED` /
    `RESOURCE_EXHAUSTED` and decodes the message before pattern-matching. A
    grpc-web response is HTTP 200 with the real status in the trailer, so the
    existing 5xx branch never saw a busy or restarting node.
  - The CLI's permanent-vs-retryable gate matches `INVALID_ARGUMENT` instead of
    the numeric `-32002`. Left unchanged, that gate would have gone dead and every
    permanent Sui rejection would have been re-broadcast as if transient.

  Breaking for direct consumers: `assertSuiTxSucceeded` now takes the unified
  client's transaction result (`{ $kind, Transaction | FailedTransaction }`)
  instead of a JSON-RPC effects object.

### Patch Changes

- [#1555](https://github.com/vultisig/vultisig-sdk/pull/1555) [`70f4583`](https://github.com/vultisig/vultisig-sdk/commit/70f4583a359f988460633b44046bf5811c9c0f74) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(cosmos): sign `CosmosSpecific.gas` verbatim so co-signing matches iOS/Android

  `CosmosSpecific.gas` (proto field 3) is the fee AMOUNT — commondata#93 documents
  it as such and every other client signs it verbatim. The signing-inputs and
  fee-display resolvers were instead re-deriving it as
  `ceil(gas × relayedGasLimit / staticGasLimit)`, and doubling it for IBC
  transfers. That silently redefined a shared wire field in one client: on a
  TerraClassic LUNC send with a simulated gas limit of 321,979 the extension
  signed a 21.465267 LUNC fee while the iOS co-signer signed the payload's
  20 LUNC, the SignDocs diverged, and the MPC keysign never completed.

  Both read paths now use `gas` as-is and only resolve the gas LIMIT from field 7.
  Fee headroom moved to the initiator, which prices `gas` against the limit it
  relays — matching iOS `CosmosGasPricedFee.scaled` and Android
  `TerraClassicTax.baseGas`. The COSMOS-02 IBC source-leg headroom is preserved by
  relaying the widened limit in `gas_limit` instead of applying a multiplier that
  no other client can reproduce.

  `resolveCosmosGasFee` is replaced by `resolveCosmosGasLimit` (limit resolution)
  and `scaleCosmosFeeAmount` (initiator-only pricing).

- [#1489](https://github.com/vultisig/vultisig-sdk/pull/1489) [`98ec3bf`](https://github.com/vultisig/vultisig-sdk/commit/98ec3bfdcf0831df00ceec6618c796dbfa2c4d13) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Decode canonical direct CW20 transfer execute messages into transfer envelopes and reject builder amounts above Uint128.

- [#1582](https://github.com/vultisig/vultisig-sdk/pull/1582) [`d7fd8fd`](https://github.com/vultisig/vultisig-sdk/commit/d7fd8fd891d2bb9f007b3feff5b31cc961bae497) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Apply the Jupiter affiliate fee by deriving and prepending its ATA, while
  normalizing zero-fee quotes before unsigned transaction construction.

- [#1599](https://github.com/vultisig/vultisig-sdk/pull/1599) [`3cf9cdc`](https://github.com/vultisig/vultisig-sdk/commit/3cf9cdc14f0069f231f2ea0cede3cec155af95d5) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-export the canonical Cosmos memo-cap helper family (`COSMOS_MEMO_DEFAULT_MAX_BYTES`, `getCosmosMemoMaxBytes`, `getCosmosMemoMaxBytesByChainId`, `isCosmosMemoWithinCap`) from `@vultisig/sdk/react-native`. The root SDK entry already exported this family; the RN entry is a hand-curated allow-list and had omitted it, pushing mobile consumers toward local memo-cap tables.

- [#1486](https://github.com/vultisig/vultisig-sdk/pull/1486) [`f99133d`](https://github.com/vultisig/vultisig-sdk/commit/f99133dc7a99f44bbe78ba43fa59e7ec761c73e1) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Use the noble Point API in React Native derivation and reject malformed Solana or EVM signature hex.

- [#1599](https://github.com/vultisig/vultisig-sdk/pull/1599) [`3cf9cdc`](https://github.com/vultisig/vultisig-sdk/commit/3cf9cdc14f0069f231f2ea0cede3cec155af95d5) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-export the canonical native-swap minimum helper family (`getNativeSwapMinAmountIn`, `NATIVE_SWAP_MIN_OUTBOUND_FEE_MULTIPLIER`, `NativeSwapMinAmountIn`) and the Sui/UTXO-consolidate prep companion types (`PrepareSuiTokenTransferFromKeysParams`, `ConsolidateChain`, `ConsolidateUtxo`, `PrepareUtxoConsolidateResult`, `PrepareUtxoConsolidateTxFromKeysParams`) from the root `@vultisig/sdk` entry. These already existed in the tools barrel; root-package consumers previously had no way to import them without reaching into an internal path.

- [#1467](https://github.com/vultisig/vultisig-sdk/pull/1467) [`6142529`](https://github.com/vultisig/vultisig-sdk/commit/6142529abc39bb548be8b1f32453f0207584c4e2) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fail Sui transaction construction when gas-budget re-pricing cannot cover the
  final selected coin set instead of returning a known under-priced baseline.

- [#1555](https://github.com/vultisig/vultisig-sdk/pull/1555) [`70f4583`](https://github.com/vultisig/vultisig-sdk/commit/70f4583a359f988460633b44046bf5811c9c0f74) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(terraclassic): price the LUNC fee from the chain's gas price and add the burn tax explicitly

  `cosmosGasRecord[TerraClassic]` was a hand-tuned flat 20 LUNC (itself already
  lowered from 100 LUNC). Terra Classic's actual `uluna` gas price is 28.325
  uluna/gas, so a send at the static 300k limit costs 8,497,500 uluna — the flat
  constant overcharged every send by ~2.35× before any gas-limit scaling.

  It was also implicitly absorbing the `x/tax` burn tax (0.5% of the transfer),
  which scales with the amount while a flat constant does not. So it overcharged
  small sends and under-covered anything above ~2,300 LUNC, where 0.5% outgrows
  the slack.

  Both halves are now explicit:

  - `cosmosGasRecord[TerraClassic]` = `8_497_500n` (`300_000 × 28.325`), matching
    iOS `TerraClassicTax.ulunaBaseGas` and Android `ULUNA_BASE_GAS`. It still
    scales with a relayed `gas_limit`.
  - The initiator adds `applyTerraClassicBurnTax(amount, rate)` to `gas` for
    native LUNC sends, after the gas scaling — the tax tracks the transfer
    amount, not the gas limit.

  Adds `getTerraClassicBurnTaxRate`, which reads `x/tax` `burn_tax_rate` (live
  0.5%) and fails closed to 0.5% on any LCD error. This is a different tax from
  the existing `x/treasury` `tax_rate`, which governance has held at 0 since the
  UST collapse and which exempts `uluna` — reading it for a LUNC send always
  returned 0. `applyTerraClassicBurnTax` is separate from `applyTerraClassicTax`
  for the same reason: the burn tax exempts nothing and is uncapped.

  A 300 LUNC send at a simulated 321,979 gas limit now costs 10.620056 LUNC
  (9.120056 gas + 1.5 tax) instead of 21.465267.

- [#1591](https://github.com/vultisig/vultisig-sdk/pull/1591) [`e76ba9b`](https://github.com/vultisig/vultisig-sdk/commit/e76ba9ba78ec52f30f3678ef4acc933ef5712cdc) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(thorchain): don't append the bank denom to a native-token swap deposit symbol

  A swap sourced from a THORChain-native token (TCY, RUJI) encoded its
  `MsgDeposit` asset as `` `${ticker}-${contractAddress}` `` — and for these coins
  `contractAddress` IS the bank denom, so the deposit went out as `TCY-tcy`
  instead of `TCY`. iOS (`thorchain.swift` `getSwapPreSignedInputData`) and
  Android (`ThorchainSwapHelper`) both encode the bare ticker.

  Because the symbol is part of the signed pre-image, this moved the hash: a
  co-signing joiner rebuilds the payload locally and polls the relay with
  `messageId = getMessageHash(message)`, so it asked for a `message_id` the
  initiator never uploaded and failed with
  `404 Timed out while waiting for setup message`. Reported in
  vultisig/vultisig-windows#4464 as a TCY -> RUNE swap that fails whenever the
  extension co-signs and succeeds against an Apple co-signer.

  The `TICKER-CONTRACT` form is now gated on `secured`, which is the case it was
  written for (vultisig-sdk `5a8aacdeb`): a secured-asset withdrawal, where the
  auxiliary coin is the L1 token being pulled off THORChain and the contract
  address genuinely belongs in the symbol (`USDC` + `0xa0b8…` ->
  `USDC-0XA0B8…`, matching THORNode's `ETH.USDC-0XA0B8…`). Both sides of that
  gate are now covered by tests; RUNE, secured assets, and non-swap deposits
  (bond/merge/stake) were never affected.

- [#1490](https://github.com/vultisig/vultisig-sdk/pull/1490) [`4777264`](https://github.com/vultisig/vultisig-sdk/commit/47772647b90336ae3297d208777523592f69dde4) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Ship dedicated declaration bundles for the browser and Chrome extension entrypoints.

- [#1471](https://github.com/vultisig/vultisig-sdk/pull/1471) [`89410fb`](https://github.com/vultisig/vultisig-sdk/commit/89410fbb0abf3ad05919fb38d1abc74a5acf9a6b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix Tron TRC-20 transfers going OUT_OF_ENERGY. `getTrc20TransferFee` trusted `energy_used`/`energy_penalty` defaulting to 0 on unsuccessful `triggerconstantcontract` response shapes (empty body, indexing lag, or reverts, including live responses with `result.result === true` plus a revert message), silently producing a `feeLimit` of 0 downstream. It now rejects unsuccessful and non-positive estimates. The serialized `feeLimit` ceiling is based on the full simulated energy before staked-energy subtraction, padded by `+50%`, and capped at 100 TRX so concurrent staked-energy use during the 10-60s MPC ceremony cannot reduce the ceiling to zero. The user-displayed/max-send fee remains the unpadded expected burn after current staked energy is applied. The 280 sun/energy fallback (stale 2023 governance default) is also corrected to the live TronGrid value of 100 sun/energy and documented for unreachable, missing, or invalid chain-parameter responses.

- [#1511](https://github.com/vultisig/vultisig-sdk/pull/1511) [`787e755`](https://github.com/vultisig/vultisig-sdk/commit/787e755d230d1e0fa012583d6edd8b7fa5aad88d) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Return locally derived transaction hashes for deterministic raw broadcast duplicate responses.

## 2.21.1

### Patch Changes

- [#1435](https://github.com/vultisig/vultisig-sdk/pull/1435) [`69e2fc2`](https://github.com/vultisig/vultisig-sdk/commit/69e2fc2f92c053294b0276440306be5871988be9) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Keep browser vault storage on the backend selected during initialization. IndexedDB failures and quota errors now surface without silently switching to a partial localStorage or in-memory view, while legacy localStorage vaults retain their backend across reloads.

- [#1179](https://github.com/vultisig/vultisig-sdk/pull/1179) [`0c80a06`](https://github.com/vultisig/vultisig-sdk/commit/0c80a062bde65c4938a29ce8c1fb6052028615e1) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Route the CLI version cache, version output, and VaultStateStore local state through `VULTISIG_CONFIG_DIR` so they stay co-located with SDK vault storage and other shared CLI state.

- [#1518](https://github.com/vultisig/vultisig-sdk/pull/1518) [`aa47b4a`](https://github.com/vultisig/vultisig-sdk/commit/aa47b4a03c7391d13c738cba68b13a1526d1c502) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add `buildLimitSwapKeysignPayload`, the step that turns a THORChain `=<` limit-order memo into a signable transaction.

  `buildLimitSwapMemo` produced the memo and `getThorchainMemoAsset` the asset notation, but nothing carried either into a `KeysignPayload` — limit orders could be composed and never placed. This builder branches on the source asset, mirroring iOS `LimitSwapPayloadAssembler`:

  - **Native RUNE** — `MsgDeposit` on THORChain itself; no inbound vault, `toAddress` carries the signer's own address as the placeholder the Cosmos signer ignores.
  - **Native gas asset** — transfer to the live Asgard inbound vault with the memo in tx `data` / `OP_RETURN`, no swap payload.
  - **ERC20** — the router's `depositWithExpiry` call plus an `approve` when allowance is short, both in one ceremony. A token source signed without a swap payload would fall through to a plain ERC-20 transfer, dropping the memo and stranding the tokens on the router.

  Every gate fails closed: the `EnableAdvSwapQueue` mimir is re-checked at sign time (it can flip while the user sits on Verify, and a `=<` order on a network with the queue off can execute as an unprotected market swap), the memo must actually be a limit memo, RUNE deposits are blocked on THORChain's global trading pause — including when the inbound list is unverifiable, since RUNE bypasses the per-chain halt filter entirely — and external sources must resolve a live, non-halted inbound whose address is then used as the destination.

  Also exports `getAdvancedSwapQueueEnabled` (the mimir gate), `findLimitSwapInbound` / `shouldBlockRuneDeposit` (pure inbound selection), and `assertLimitSwapMemo`.

  `assertValidThorchainDepositMemo` is deliberately unchanged: it guards the standalone `prepareThorchainMsgDepositTxFromKeys` tool and is not on the keysign-payload path, so excluding swap-shaped memos there stays correct.

  No EVM gas-limit override is applied. iOS pins a native-EVM limit deposit to 120000 to match its own market path, but here both paths put the memo on `keysignPayload.memo` and neither sets a general swap payload, so both already floor at `deriveEvmGasLimit`'s 600000 data-tx limit. Forcing 120000 would make the limit path diverge from the market path and risk under-gassing.

- [#1505](https://github.com/vultisig/vultisig-sdk/pull/1505) [`32e5d36`](https://github.com/vultisig/vultisig-sdk/commit/32e5d369ae4723299a6cb8f694da1782dbf207c2) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(sdk): raw broadcast paths fail closed instead of reporting false success

  Three raw-broadcast/status hardening fixes, all fail-closed (throw/pending on
  ambiguity, never fabricate success):

  - `RawBroadcastService.broadcastRawTx`: Polkadot/Bittensor no longer return
    `undefined` as a success hash when the RPC response has neither `result`
    nor `error`; Tron now also checks `result === false` (not only `code`),
    matching the guard the core resolver already has; Solana adds a bounded,
    non-blocking signature-status check so a signature the node already knows
    failed is not handed back as a hash. Cosmos and Sui raw paths already had
    assert guards from prior PRs and are untouched.
  - `getTronTxStatus` (status resolver): an unrecognized `receipt.result` value
    is no longer narrated as `success` just because it isn't on the known
    failure list - it now resolves to `pending`. `SUCCESS` and absent
    `receipt.result` are unchanged (still `success`).
  - `BroadcastService.broadcastTx`: prefers the resolver-returned hash (utxo/
    cardano/tron echo the node's own hash) over a locally re-derived one,
    falling back to the local computation only when the resolver returns none.

## 2.21.0

### Minor Changes

- [#1281](https://github.com/vultisig/vultisig-sdk/pull/1281) [`feb2137`](https://github.com/vultisig/vultisig-sdk/commit/feb213783534fc4a424cbc7e01bd97ae90320c11) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose canonical EIP-191 hashing and ECDSA 65-byte signature formatting helpers, and use them in vault message signing and CLI authentication.

- [#1271](https://github.com/vultisig/vultisig-sdk/pull/1271) [`3a40960`](https://github.com/vultisig/vultisig-sdk/commit/3a40960cc6391b69bbe6371874889b64399d64b9) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Swap surface hygiene: SwapService.getQuote now forwards affiliateConfig (per-provider fee-owner overrides) to core findSwapQuote instead of silently dropping it - the field is added to SwapQuoteParams, default behavior unchanged when omitted. The swapEnabledChains aggregate now unions every provider list (kyber/jupiter/cowswap were missing, complete only by accident via LiFi's superset), and kyberSwapEnabledChains drops Zksync/Blast, which Kyber's API 404s on.

### Patch Changes

- [#1191](https://github.com/vultisig/vultisig-sdk/pull/1191) [`8c1ad1e`](https://github.com/vultisig/vultisig-sdk/commit/8c1ad1ec73152ad161b2d17ffceeb166abafe30a) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Collapse balance and fiat-value N+1 request fan-out into batched calls.

  `BalanceService.getBalances({ includeTokens: true })` previously issued one
  `getCoinBalance` RPC per token on a chain (native + N tokens = N+1 round-trips).
  EVM chains now fetch native + all tokens in a single Multicall3 call via
  `getEvmChainBalances`, respecting the existing per-coin BALANCE cache (only
  uncached coins are multicalled) and caching/emitting each result exactly as
  `getBalance` does. Non-EVM chains keep the per-coin path, and the built-in
  Multicall3 fallback covers EVM chains without a multicall3 contract.

  `FiatValueService.getValues` looped `getValue` per token, each triggering a
  single-id `getErc20Prices` request; it now warms the price cache with one
  batched `getErc20Prices` call for the whole chain and resolves native + token
  values concurrently. `getTotalValue` now fetches chains' values concurrently
  with a bounded number in flight (no unbounded RPC burst on many-chain vaults)
  instead of awaiting them one chain at a time.

  `getEvmChainBalances` now OMITS a coin whose balance it could not read (a reverted/failed
  Multicall3 sub-call, or a per-coin failure in the no-multicall3 fallback) instead of decoding it
  as `0n`. A present `0n` means a genuine zero balance; an absent key means "unknown". Callers can
  therefore tell the two apart and refetch instead of persisting a fabricated zero.

  `FiatValueService.updateValues('all')` now bounds its per-chain fan-out with the same concurrency
  cap as `getTotalValue` instead of a raw `Promise.all`.

  Fix: a coin OMITTED from the EVM multicall result (a transient RPC hiccup /
  partial Multicall3 aggregate) is no longer cached as a fabricated `0n` (5-min
  TTL) and no longer emitted as a real `balanceUpdated` — which would have shown a
  real 0 for a coin the user owns. Only keys the multicall actually returned are
  cached/emitted (a genuine `0n` is a real balance and is kept); a missing key
  falls through uncached so the next call refetches it.

- [#1474](https://github.com/vultisig/vultisig-sdk/pull/1474) [`c443b9c`](https://github.com/vultisig/vultisig-sdk/commit/c443b9ce699ef76f1407d0386ed20fbc7e3f253f) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Route SwapKit transaction links through its public tracker across the shared core and SDK APIs.

- [#1455](https://github.com/vultisig/vultisig-sdk/pull/1455) [`ce7271f`](https://github.com/vultisig/vultisig-sdk/commit/ce7271fe009092d995b87a86c33cb830b37fc0a8) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Correlate secure-signing lifecycle events with stable per-operation session IDs.

- [#1256](https://github.com/vultisig/vultisig-sdk/pull/1256) [`20a0fd0`](https://github.com/vultisig/vultisig-sdk/commit/20a0fd0dafab088d92bc53e5bd84acaf5cc20cc6) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix typed EVM transaction decoding so newer supported chain ids resolve through the canonical SDK registry instead of a stale local map.

- [#1286](https://github.com/vultisig/vultisig-sdk/pull/1286) [`4f111d1`](https://github.com/vultisig/vultisig-sdk/commit/4f111d1f448e5dbd8cb99e71b1f9e7a5cd875e30) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Infer EVM and Cosmos decoder families from canonical SDK chain metadata.

- [#1214](https://github.com/vultisig/vultisig-sdk/pull/1214) [`802910d`](https://github.com/vultisig/vultisig-sdk/commit/802910d74219ba11e7e819d38bbafd88843028b8) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix the CCTP Base MessageTransmitter address to Circle's published contract (0xAD09780d193884d503182aD4588450C416D6F9D4). The previous value was a codeless EOA lookalike, so a Base claim's receiveMessage succeeded without minting (burn-without-mint fund loss). Registry is now pinned to Circle's published V1 addresses by test.

- [#1387](https://github.com/vultisig/vultisig-sdk/pull/1387) [`c837c0b`](https://github.com/vultisig/vultisig-sdk/commit/c837c0b524dea366a77d2d5eccd6ad737d15cb29) Thanks [@neavra](https://github.com/neavra)! - Two CLI developer-experience fixes:

  - Silence the `bigint: Failed to load bindings, pure JS will be used` warning that
    `bigint-buffer` printed to stderr on every invocation, including `--version`. It
    warns at module load, before any flag has been parsed, so it cannot be gated behind
    `--debug`; it is silenced with a `yarn patch`. The SDK's node bundle inlines the
    patched copy, which is why `@vultisig/sdk` is bumped here too.
  - Generate shell completion from the Commander command table and the SDK chain
    registry instead of a stale hardcoded list, which was missing eleven commands
    (sign/broadcast/tx-status/execute/discount/agent/auth/delete/join/rujira/add-mldsa)
    and 17 of 38 chains.

- [#1386](https://github.com/vultisig/vultisig-sdk/pull/1386) [`a2ea19a`](https://github.com/vultisig/vultisig-sdk/commit/a2ea19a386b77d4135e56cd9ce4b6bf8e70b5e60) Thanks [@neavra](https://github.com/neavra)! - Tighten the handling of files that carry key shares:

  - Write exported `.vult` files owner-only (0600) instead of with the default umask
    (0644, world-readable), matching the SDK's own vault store. The export is written to
    a fresh temp file and renamed over the target, so the shares are never on disk at a
    looser mode — `writeFile`'s `mode` only applies when it creates the file, so writing
    straight to a pre-existing path would have left the shares world-readable for a window.
  - Stop `rename` rejecting vault names the ecosystem itself creates (e.g. the `#` in
    "Vultisig Cluster [#1](https://github.com/vultisig/vultisig-sdk/issues/1)"), which made rename a one-way door. The alphanumeric allowlist
    is replaced with a denylist of what is genuinely unsafe for the export filename the
    name is interpolated into: path separators and control characters.
  - Enforce that denylist at the real lifecycle boundary — `export()` — rather than only
    at rename. A vault imported or created via a path that ran no name validation could
    otherwise carry an unsafe name or `localPartyId` (path separators, control chars, a
    bare `..`) straight into the export filename. `export()` now encodes every filename
    component to a single safe path segment (same policy as rename), encoding rather than
    refusing so a legitimately-imported vault is never stranded behind its own backup file.

- [#1316](https://github.com/vultisig/vultisig-sdk/pull/1316) [`69a3f75`](https://github.com/vultisig/vultisig-sdk/commit/69a3f75c265e19682e6dbdac0fdb640c53d73b33) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Stop reporting Cosmos broadcast as successful when the transaction is included on-chain but execution failed (DeliverTx code !== 0), and make sure the broadcast retry wrapper never misreads that failure as a transient transport error and resends it.

- [#1273](https://github.com/vultisig/vultisig-sdk/pull/1273) [`e3d8568`](https://github.com/vultisig/vultisig-sdk/commit/e3d8568a04a6dcd977ccaeeeb5bcf5da080fd275) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Return the Cosmos transaction hash when CosmJS accepts a broadcast but times out waiting for indexing, leaving confirmation to status polling instead of reporting broadcast failure.

- [#1239](https://github.com/vultisig/vultisig-sdk/pull/1239) [`937a58c`](https://github.com/vultisig/vultisig-sdk/commit/937a58cce27f935346f44f4bae4b3e40f464cba9) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix `formatBalance`/`formatBigintAmount` computing the display divisor via `BigInt(10 ** decimals)` — a float64 power that's only exact up to decimals=22, silently corrupting balance display for higher-decimal assets. Both now delegate to the pure-bigint `fromChainAmountExact`, which is also exported from the root `@vultisig/sdk` entrypoint alongside `getBlockExplorerUrl` — including the React Native platform entry (the one Metro actually resolves for Station), not just the node/default condition, so RN consumers can reach both without a `@vultisig/core-chain` deep import.

- [#1192](https://github.com/vultisig/vultisig-sdk/pull/1192) [`5303d70`](https://github.com/vultisig/vultisig-sdk/commit/5303d704e792bb7ed70df08eab7140aac81a519a) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the EVM chainId ↔ chain helpers (`getEvmChainId`, `getEvmChainByChainId`)
  from the SDK's public API.

  The SDK already owned the per-chain EVM chainId table (`evmChainId` in
  `chains/evm/chainInfo.ts`), but it wasn't part of the public export surface, so
  the app and agent-backend-ts each hand-maintained their own copies — the exact
  drift class behind the Hyperliquid 998 (testnet) vs 999 (mainnet) client↔server
  chainId bug. Consumers can now import the single source of truth. Native tickers
  were already exported via `chainFeeCoin`, so no additional ticker export is
  needed.

  Also re-exported from the React Native entry (`platforms/react-native`), which
  omitted these too, so RN consumers (Station) couldn't reach them without
  falling back to a hand-maintained copy.

- [#1252](https://github.com/vultisig/vultisig-sdk/pull/1252) [`9b5d103`](https://github.com/vultisig/vultisig-sdk/commit/9b5d103500cce4f984dc7049a316529a193716f2) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add real published subpath bundles for `@vultisig/sdk/tools/parse` and `@vultisig/sdk/tools/defi`, including dedicated declaration output and package-name import smoke coverage.

- [#1266](https://github.com/vultisig/vultisig-sdk/pull/1266) [`98e715a`](https://github.com/vultisig/vultisig-sdk/commit/98e715a0c770ae2a776314763fb18ffa309c1e2b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Keep the direct Jupiter swap tool's affiliate-fee state in sync with the canonical shared Jupiter path when the quoted platform fee floors to zero.

- [#1473](https://github.com/vultisig/vultisig-sdk/pull/1473) [`338ef32`](https://github.com/vultisig/vultisig-sdk/commit/338ef3229d778bb012d915977f512121d330ac1f) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the native-swap expiry and inbound-vault guard from core MPC so shipping
  wallets and the SDK facade can share one pre-signing or pre-broadcast check.

- [#1282](https://github.com/vultisig/vultisig-sdk/pull/1282) [`6f32745`](https://github.com/vultisig/vultisig-sdk/commit/6f327454c04c42f6771e53584026ec7283aa2ac3) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export the canonical prep constants from `@vultisig/sdk` and `@vultisig/sdk/react-native` so consumers can import `TRC20_TRANSFER_SELECTOR`, `SUI_NATIVE_COIN_TYPE`, and `CONSOLIDATE_CHAINS` from the public SDK surfaces instead of copying local literals.

- [#895](https://github.com/vultisig/vultisig-sdk/pull/895) [`0c4a090`](https://github.com/vultisig/vultisig-sdk/commit/0c4a090bc4f3868e2a3a20c9f12742344cf8350e) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - fix(swap): expose inner-executor approvalAddress on EVM swap routes (LiFi + SwapKit)

  EVM aggregator routes (LI.FI, SwapKit) can delegate the ERC-20 `transferFrom` to an
  inner executor contract that is distinct from the outer `tx.to` router. Approving only
  `tx.to` leads to an "ERC20: transfer amount exceeds allowance" revert on-chain.

  This fix threads the route's real spender address through as `evm.approvalAddress` on
  `GeneralSwapTx`. Consumers building an ERC-20 approve leg MUST use this field as the
  spender when present, falling back to `to` only when absent.

- [#1258](https://github.com/vultisig/vultisig-sdk/pull/1258) [`a8c10f0`](https://github.com/vultisig/vultisig-sdk/commit/a8c10f02423760c805593b0a1ad9c25a83609e1f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Centralize native-swap chain-id lookups behind a canonical `getNativeSwapChainId` accessor, removing duplicated nullable-map wrappers from the SDK broadcast guard and native-swap core helpers.

- [#1285](https://github.com/vultisig/vultisig-sdk/pull/1285) [`8a0bca6`](https://github.com/vultisig/vultisig-sdk/commit/8a0bca688ec606292df587559115cafcc3287fcf) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fix fiat pricing for known non-EVM token identifiers.

- [#1415](https://github.com/vultisig/vultisig-sdk/pull/1415) [`01a66cf`](https://github.com/vultisig/vultisig-sdk/commit/01a66cf5c0110ea1ea439ddbca8e6b75179fc0c5) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Preserve exact uint64 Cosmos account sequences through account lookup and signing payload construction.

- [#1429](https://github.com/vultisig/vultisig-sdk/pull/1429) [`7226d49`](https://github.com/vultisig/vultisig-sdk/commit/7226d49d42cec673465aac5b49b54d4e47628ab6) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix the QBTC send broadcast reporting a false success on a DeliverTx failure. `broadcastQbtcTx` uses `BROADCAST_MODE_SYNC`, which only surfaces the CheckTx (mempool-admission) code — a DeliverTx execution failure (out-of-gas, revert) still returns `code: 0` at broadcast time — and the resolver returned success after only that check, with no inclusion poll. It also read `data.tx_response?.code && …`, treating a missing `tx_response` as success. The resolver now polls for inclusion and re-checks the DeliverTx `code` (mirroring the QBTC claim helper, whose `waitForTxInclusion` is extracted to a shared `waitForQbtcTxInclusion`): a confirmed DeliverTx failure throws a non-retryable error, an unconfirmable inclusion (timeout / transient RPC error) is left in-flight for the status resolver, and a missing/failed CheckTx code is verified by hash instead of trusted.

- [#1202](https://github.com/vultisig/vultisig-sdk/pull/1202) [`7ae91d9`](https://github.com/vultisig/vultisig-sdk/commit/7ae91d9231add2e4063966aa9cdfbddf12883564) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export `toChainAmount` and `ChainAmountParseError` from the root `@vultisig/sdk` entrypoint so downstream consumers can use the hardened amount parser without deep-importing core-chain internals.

- [#1277](https://github.com/vultisig/vultisig-sdk/pull/1277) [`7c1570e`](https://github.com/vultisig/vultisig-sdk/commit/7c1570e528c30e6b037ddbaea538add5353a7dcc) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-export XRPL issued-currency canonicals from the root and React Native SDK entrypoints so first-party consumers can reuse the SDK's token-id and currency-code helpers instead of mirroring them locally.

- [#1279](https://github.com/vultisig/vultisig-sdk/pull/1279) [`ab018c7`](https://github.com/vultisig/vultisig-sdk/commit/ab018c7f747bbbc48984f2ab7a2f244f8179d137) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Forward `recipient`, `slippageTolerance`, and `excludeProviders` through `vault.swap()` and make the CLI `swap --slippage` flag reach the SDK quote builder instead of being silently dropped.

- [#1426](https://github.com/vultisig/vultisig-sdk/pull/1426) [`b3d17d8`](https://github.com/vultisig/vultisig-sdk/commit/b3d17d855c2e2250c78641912d70203a43fdf332) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix `vault.broadcastRawTx` reporting a false success for a Cosmos transaction that was included but failed execution. `RawBroadcastService.broadcastCosmosRawTx` returned `result.transactionHash` whenever `StargateClient.broadcastTx` didn't throw, but that client resolves (does not throw) once a tx is included even when DeliverTx failed (`code !== 0` — out-of-gas, wasm revert, a THORChain/Maya deposit-handler rejection). The tx is on-chain but nothing moved, so the raw path now asserts DeliverTx success and throws `BroadcastFailed` on execution failure, matching the signing-input broadcast resolver ([#1316](https://github.com/vultisig/vultisig-sdk/issues/1316)).

- [#1380](https://github.com/vultisig/vultisig-sdk/pull/1380) [`afa17b2`](https://github.com/vultisig/vultisig-sdk/commit/afa17b2aee9abea47a52cfdee433d2cf2ae58ced) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(rn): key the React Native `getCoinBalance` resolver dispatch by `ChainKind`
  instead of `string`, so a new chain kind added to core now breaks the RN build at
  compile time instead of silently throwing at runtime. Also declare
  `@vultisig/walletcore-native` as an optional `workspace:*` peer dependency (matching
  the existing `@vultisig/mpc-native` sibling) — the RN entrypoint value-imports it and
  marks it external in the RN bundle, so it must be declared for RN consumers.

- [#1428](https://github.com/vultisig/vultisig-sdk/pull/1428) [`0de8684`](https://github.com/vultisig/vultisig-sdk/commit/0de8684706f1b538a459acca0e55bf15c95a91f3) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix the React Native LiFi quote override applying a flat 1% slippage and discarding the caller's slippage. `platforms/react-native/overrides/getLifiSwapQuote.ts` hardcoded `slippage: 0.01` and had no `slippage`/`ticker` input, so on RN (most users) every LiFi quote used 1% — stable pairs that get the 0.3% tier on the core path got 1% (a wider MEV/loss surface), and an explicit tight-tolerance request was silently dropped (LiFi bakes `minAmountOut` from it). The tiered/override resolution (`resolveLifiSlippage`) is now extracted to a shared `lifi/api/lifiSlippage` module that both the core path and the RN override use, so they resolve slippage identically.

- [#1225](https://github.com/vultisig/vultisig-sdk/pull/1225) [`52f90bd`](https://github.com/vultisig/vultisig-sdk/commit/52f90bd00a9dfa2937f2cf31f883b444a76a486b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-export the SDK's pure parse/tx-normalize/decode helpers from the React Native entrypoint so RN consumers get the same public surface as other first-party platforms.

- [#1222](https://github.com/vultisig/vultisig-sdk/pull/1222) [`6b71775`](https://github.com/vultisig/vultisig-sdk/commit/6b71775956d244d291883fd90b9a121f227dfa4b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix the CLI agent push-notification listener to register/connect with the canonical hashed notification vault id instead of the raw ECDSA pubkey, restoring parity with SDK secure-vault notification delivery.

- [#1414](https://github.com/vultisig/vultisig-sdk/pull/1414) [`300dabf`](https://github.com/vultisig/vultisig-sdk/commit/300dabf232bfe49d9628d4026c55bb72b6472b97) Thanks [@rcoderdev](https://github.com/rcoderdev)! - For EVM swap providers that legitimately distinguish the allowance executor
  from the swap router, use the quote's approval address for SDK allowance checks
  and approval payloads while retaining the router as the signed destination.

- [#1182](https://github.com/vultisig/vultisig-sdk/pull/1182) [`ec6c810`](https://github.com/vultisig/vultisig-sdk/commit/ec6c810e81798b8dab7d004c931f2ecc1b859bd2) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-export `prepareThorchainMsgDepositTxFromKeys` and its params type from the SDK root surface so downstream signers can consume the canonical THOR/Maya MsgDeposit prep helper instead of maintaining local shims.

- [#1377](https://github.com/vultisig/vultisig-sdk/pull/1377) [`a971dfa`](https://github.com/vultisig/vultisig-sdk/commit/a971dfa99274b419863f83a078868f25a8241235) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-assert the aggregator router allow-list (1inch/kyber) and the Solana Jupiter
  program + fund-movement guard on the MPC co-signer signing-input path, not only
  at quote construction. Every co-signer independently rebuilds the signing input
  from the shared KeysignPayload, so a compromised initiator could otherwise hand
  a co-signer an unvalidated swap destination (EVM `quote.tx.to`) or a spliced
  drain instruction (Solana `quote.tx.data`) and have it signed verbatim. Both
  guards are pure gates: they fail closed for enforced providers or no-op, and
  never mutate the signed bytes, so cross-device pre-signing hash agreement is
  unchanged.

- [#1215](https://github.com/vultisig/vultisig-sdk/pull/1215) [`77e2401`](https://github.com/vultisig/vultisig-sdk/commit/77e24018c906a8dcf1cb21d2c1fc8e337a4b2b8e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Sign dApp-supplied raw Solana transactions over their original message bytes instead of a WalletCore re-encode. The signSolana path previously routed raw transactions through TransactionDecoder + SigningInput.rawMessage, letting WalletCore re-encode the message to form the ed25519 pre-image - not guaranteed byte-identical for v0+ALT transactions across WalletCore versions, which breaks mixed-vault co-signing with iOS/Android (which already sign the original bytes, ios#4419 / android#5223). The signature is now spliced into the original transaction bytes at the fee-payer slot for assembly.

- [#1275](https://github.com/vultisig/vultisig-sdk/pull/1275) [`83df849`](https://github.com/vultisig/vultisig-sdk/commit/83df8496aa01cfe7d59f48b32686ba863cf87a02) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Match iOS Sui send coin selection by bounding native inputs to the largest
  objects covering amount plus gas, selecting token inputs by largest covering
  objects, and choosing a native gas object that covers token-send gas.

- [#1430](https://github.com/vultisig/vultisig-sdk/pull/1430) [`d01ac2e`](https://github.com/vultisig/vultisig-sdk/commit/d01ac2ee87d080def76454adcf5313726a916ed8) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix the Sui broadcast reporting a false success for a transaction that aborted on-chain (sdk#1398). `broadcastSuiTx` called `executeTransactionBlock` without requesting effects, so a tx that executed but aborted (MoveAbort / InsufficientGas) resolved with a digest — an RPC-level success that is not execution success — and was returned as a successful broadcast. It now requests `showEffects` and throws unless `effects.status.status === 'success'` — mirroring the Sui status resolver, so a missing or unknown status fails closed instead of defaulting to success. The throw is a `DeliverTxFailedError` so the transient-retry wrapper cannot re-broadcast an already-aborted transaction. An RPC-level error still falls through to `verifyBroadcastByHash` unchanged.

- [#1413](https://github.com/vultisig/vultisig-sdk/pull/1413) [`358c27b`](https://github.com/vultisig/vultisig-sdk/commit/358c27ba3bdd94813d00ec966ba43c8cc46f49e0) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fix `RawBroadcastService`'s Sui raw-broadcast path reporting a false success for a transaction that failed on-chain (sdk#1398). It called `executeTransactionBlock` without requesting effects, so a tx that reverted (MoveAbort / InsufficientGas) resolved with a digest — an RPC-level success that is not execution success — and was returned as broadcast. It now requests `showEffects` and asserts the effects status via the shared `assertSuiTxSucceeded` helper (extracted from the `broadcastSuiTx` resolver, which already guarded against this), throwing a non-retryable error on a failed execution instead of reporting success.

- [#1220](https://github.com/vultisig/vultisig-sdk/pull/1220) [`855ac6b`](https://github.com/vultisig/vultisig-sdk/commit/855ac6bdd4be566743ddc7c4f7a248029f6d2d47) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix React Native `getCoinBalance()` so Ripple balances use the RN-safe fetch path instead of the websocket `xrpl` client.

- [#1379](https://github.com/vultisig/vultisig-sdk/pull/1379) [`9510a9d`](https://github.com/vultisig/vultisig-sdk/commit/9510a9d8099c52a482dff05a3cf49938e06d9a85) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Re-check THORChain/MayaChain trading-halt flags at broadcast on BOTH ends of the native swap route, not only the source chain. A chain healthy at quote time can `HALT<CHAIN>TRADING` before broadcast while the inbound vault address stays current; a destination halt would otherwise let the deposit land while the outbound cannot leave (stuck funds). Mirrors quote-time `getNativeSwapTradingHalt`'s source+destination selection and its tolerance (a route leg with no inbound entry is skipped, not false-blocked), and reads `global_trading_paused` across all inbound entries. Fail-closed at zero extra network cost (the flags ride the already-fetched inbound object).

- [#1499](https://github.com/vultisig/vultisig-sdk/pull/1499) [`3bc880a`](https://github.com/vultisig/vultisig-sdk/commit/3bc880a06b90fa64793983ba498f11fdc55e2115) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Expose `getThorchainMemoAsset`, a `Coin` -> THORChain memo-asset converter, plus `isThorchainRoutable` and `isThorchainSecuredAssetId`, from `@vultisig/core-chain/swap/native/thorchainMemoAsset`.

  `buildLimitSwapMemo` takes `source_asset` / `target_asset` as pre-formatted THORChain notation, but nothing produced those strings from a `Coin`. Market swaps never needed it — the memo comes back on the server quote — but limit swaps build the memo locally, so every consumer had to derive the notation itself. Since the memo _is_ the order, a divergence there misroutes funds.

  Notation is derived from `toNativeSwapAsset`, the converter the market-swap path already uses, so the package has exactly one definition of a THORChain asset string. The only thing layered on top is abbreviating an L1 contract to its last 6 characters: memo bytes are capped at 80 on UTXO sources, while the swap API is given the full address. Secured assets are left un-abbreviated because the trailing address is part of the denom that identifies them.

  `limitSwapMemo`'s prefix -> chain map is now derived by inverting the new chain -> prefix map rather than being hand-maintained alongside it, so the two directions cannot drift. Behaviour is unchanged — the inversion reproduces the previous map exactly.

  `@vultisig/sdk` is bumped because it bundles `packages/core/chain` source rather than depending on the published package, so it needs a fresh tarball to carry this change. The helper is not re-exported from the SDK's public API, hence a patch rather than a minor.

  Note: `buildLimitSwapMemo` still does not accept secured assets — its `assertValidPoolId` check requires dotted `CHAIN.ASSET` notation and rejects the `CHAIN-ASSET` form. That gap predates this helper (iOS has the same one) and is tracked separately; a regression test pins it so it cannot change silently.

- [#1274](https://github.com/vultisig/vultisig-sdk/pull/1274) [`ffc174c`](https://github.com/vultisig/vultisig-sdk/commit/ffc174c56d72990e6ee387ac389c96a2f4812cf5) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject negative TON signing amounts before byte encoding so native, dApp-supplied
  TON messages, and Jetton helper amounts cannot silently truncate a `-`-prefixed
  hex value.

- [#1470](https://github.com/vultisig/vultisig-sdk/pull/1470) [`e710f0c`](https://github.com/vultisig/vultisig-sdk/commit/e710f0c97274732312e965db467a31de040d7533) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix the hand-rolled RN Tron transaction builder writing the transfer memo into protobuf field 12 (`scripts`, deprecated) instead of field 10 (`data`, the real Tron memo field). A TRC-20/TRX send carrying an exchange deposit tag or a THORChain swap memo previously broadcast with an empty `data` field on-chain. `buildTronSendTx`/`buildTrc20TransferTx` now write the memo to field 10 (and re-order `raw_data` field emission to match Tron's canonical ascending field order), matching the WalletCore keysign path exactly. Added a WalletCore cross-check test so the RN builder can never silently diverge from WalletCore's own encoding again.

- [#1460](https://github.com/vultisig/vultisig-sdk/pull/1460) [`e92fa0c`](https://github.com/vultisig/vultisig-sdk/commit/e92fa0cb47d8607587798ca3f167c150b2f73d7d) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Export `getSighashZcash` from the UTXO chain surface — including the `@vultisig/sdk/react-native` platform entry, which is the entry point that actually publishes `getSighashBIP143` / `getSighashLegacy` — so the low-level ZIP-243 Zcash sighash can be golden-vector tested directly and reached by consumers alongside its siblings. Its narrow contract (transparent-only v4/Sapling, SIGHASH_ALL, P2PKH scriptCode, count-less `outputsRaw`) is now documented at the declaration, since the primitive itself does no input validation. Test-only change otherwise: adds a golden signing vector for Zcash's v4/Sapling transparent-send sighash, pinned against an independently-computed ZIP-243 reference digest, ahead of the 2026-07-28 Ironwood consensus-branch-id rotation.

## 2.20.0

### Minor Changes

- [#1317](https://github.com/vultisig/vultisig-sdk/pull/1317) [`a08a52b`](https://github.com/vultisig/vultisig-sdk/commit/a08a52bb0933fd5470ea849613e147baa29286ad) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Register the Rujira liquid-bond THORChain tokens bRUNE (`x/brune`) and ybRUNE (`x/staking-x/brune`), and add the `bruneBondConfig` staking-contract config. bRUNE is auto-discovered as a normal wallet token priced against RUNE (`priceProviderId: 'thorchain'`); the ybRUNE auto-compounding staking receipt is excluded from wallet discovery and carries native-token metadata for backfill.

- [#1284](https://github.com/vultisig/vultisig-sdk/pull/1284) [`1c4fc80`](https://github.com/vultisig/vultisig-sdk/commit/1c4fc80be959af4b650e32b4db30859f449dfa60) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose generic CosmWasm Amino and protobuf execute builders from the root SDK and reuse the canonical Amino envelope in the CLI.

- [#1308](https://github.com/vultisig/vultisig-sdk/pull/1308) [`48ad7a2`](https://github.com/vultisig/vultisig-sdk/commit/48ad7a269186965b2b7a20d4b9d52ccd3b77fcbd) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose one SDK chain-reference resolver and use it for CLI and MCP chain names, aliases, and IDs.

- [#1269](https://github.com/vultisig/vultisig-sdk/pull/1269) [`dda2e90`](https://github.com/vultisig/vultisig-sdk/commit/dda2e9084859eae02dd16149ac3ab2240a7d37e5) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Allow Solana status checks to return terminal `not_found` for unknown
  signatures whose `lastValidBlockHeight` has expired.

- [#1128](https://github.com/vultisig/vultisig-sdk/pull/1128) [`f885e91`](https://github.com/vultisig/vultisig-sdk/commit/f885e91da06674dbef2ca1495291ca7d201e4c58) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add first-class XRP DestinationTag support alongside transaction memos.

### Patch Changes

- [#1313](https://github.com/vultisig/vultisig-sdk/pull/1313) [`c3168e2`](https://github.com/vultisig/vultisig-sdk/commit/c3168e24a32d733da85b2f6038e7e55c4dbe8d72) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Remove persisted pending vault state after successful same-process verification.

- [#1309](https://github.com/vultisig/vultisig-sdk/pull/1309) [`7bb79ba`](https://github.com/vultisig/vultisig-sdk/commit/7bb79ba9ef968bc20ba88e1bdd189ca8864b0221) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Keep `clearVaults` scoped to SDK-owned keys in shared storage adapters.

- [#1031](https://github.com/vultisig/vultisig-sdk/pull/1031) [`a8e873e`](https://github.com/vultisig/vultisig-sdk/commit/a8e873e41a41693dcdee575c5271422fe6c6b6e3) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Document the public SDK chain metadata boundary used by CLI consumers.

- [#1029](https://github.com/vultisig/vultisig-sdk/pull/1029) [`421e8da`](https://github.com/vultisig/vultisig-sdk/commit/421e8da0b11a35bcc95351e7b644318fe171c5ec) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject secure vault creation and import sessions when more relay peers join than the requested device count.

- [#1270](https://github.com/vultisig/vultisig-sdk/pull/1270) [`6de79ab`](https://github.com/vultisig/vultisig-sdk/commit/6de79ab1ec6e3566ea8511a0a6c7afde87752c48) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Export the canonical Cosmos fee-denom helpers from the React Native entrypoint.

- [#1314](https://github.com/vultisig/vultisig-sdk/pull/1314) [`21ca074`](https://github.com/vultisig/vultisig-sdk/commit/21ca07454d5ac462882317da4f49d5f80ef32837) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Make React Native EVM raw broadcast idempotent for known or hash-confirmed transactions.

- [#1318](https://github.com/vultisig/vultisig-sdk/pull/1318) [`72da781`](https://github.com/vultisig/vultisig-sdk/commit/72da781743fad0664edfc5ffcd72720ac7f0d0bd) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add bounded timeouts and caller cancellation to React Native RPC and Fast Vault network flows.

## 2.19.19

### Patch Changes

- [#1190](https://github.com/vultisig/vultisig-sdk/pull/1190) [`4fcce4d`](https://github.com/vultisig/vultisig-sdk/commit/4fcce4d4b9bc40efdacd5d1754f3b2adb7a42985) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Support signing dApp-supplied XRPL transactions via the new `SignRipple` keysign payload.

  - `getRippleSigningInputs` signs `signData.signRipple.rawJson` verbatim, so transaction types the keysign payload cannot otherwise express — offers (DEX swaps), cross-currency payments, trust lines — round-trip. Every signer rebuilds its input from the same JSON, so each party signs identical bytes. Native XRP sends and issued-currency `TrustSet` are unchanged.
  - Fail closed on rawJson `Payment` transactions: `Account`, `Destination` and `Amount` must match the reviewed keysign metadata (`coin.address`, `toAddress`, `toAmount`), so the review surface and the signed bytes cannot diverge even for same-account payments. Non-Payment types still pass on the `Account` check alone.
  - `getRippleChainSpecific` now skips the base-reserve destination check when the payload has no `toAddress` (a dApp offer has none); fee and sequence come from the sender account and are unaffected.
  - Regenerated the keysign protos for the `SignRipple` variant added in commondata.

## 2.19.17

### Patch Changes

- [#1039](https://github.com/vultisig/vultisig-sdk/pull/1039) [`44b2903`](https://github.com/vultisig/vultisig-sdk/commit/44b2903a4dd6ccc935ebfdecb8be16f4f5996563) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Honor the configured message relay URL for secure vault transaction and raw-byte signing, including signing QR payloads.

- [#972](https://github.com/vultisig/vultisig-sdk/pull/972) [`13c3b65`](https://github.com/vultisig/vultisig-sdk/commit/13c3b654d0bbdec698d385b72cea50bf428161b3) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fail closed before broadcasting native swap payloads that do not carry a positive quote expiration, while preserving secured-asset withdrawal deposits with a shared classifier.

## 2.19.16

### Patch Changes

- [#1175](https://github.com/vultisig/vultisig-sdk/pull/1175) [`e70ddf0`](https://github.com/vultisig/vultisig-sdk/commit/e70ddf0258e22d27d208f02d104d0bc1b5562132) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - Fix 1inch swap quotes to native ETH (and other EVM chains' native assets) failing route resolution.

  `findSwapQuote`'s 1inch fetcher passed `from.id ?? from.ticker` / `to.id ?? to.ticker` into
  `getOneInchSwapQuote`, so a native asset (no `.id`) fell back to its ticker string (e.g. `"ETH"`).
  `getOneInchSwapQuote`'s `isFeeCoin` check relies on `undefined` to detect the native asset and
  substitute 1inch's `0xEeee...` sentinel address (EIP-7528) — a truthy ticker string defeated that
  check, so 1inch received `dst=ETH` (or `src=ETH`) instead of the sentinel and rejected the request
  with `dst must be an Ethereum address`. This silently removed 1inch as a route for any swap
  involving a chain's native asset (e.g. USDC→ETH), even though 1inch could otherwise fill it.

  Now `findSwapQuote` forwards the coin's raw `.id` (`undefined` for the native asset) so
  `getOneInchSwapQuote`'s existing sentinel-mapping logic works as designed. ERC-20↔ERC-20 quotes
  are unaffected; other providers (Kyber, LiFi, SwapKit) construct their own requests and are not
  touched by this change.

## 2.19.15

### Patch Changes

- [#1169](https://github.com/vultisig/vultisig-sdk/pull/1169) [`1ef64a3`](https://github.com/vultisig/vultisig-sdk/commit/1ef64a39f856d9f1d412df8f5e69c66f7130d8c7) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Surface XRP issued-currency (trust-line) token balances.

  - `getRippleAccountLines` reads an account's trust lines, following `account_lines` pagination so a large set is not truncated.
  - `getRippleCoinBalance` now dispatches on the coin id: native XRP still returns the reserve-adjusted spendable balance, while an issued-currency coin returns that trust line's balance. Previously the resolver ignored the id and returned the XRP balance for _every_ Ripple coin, so a token row displayed the account's XRP balance.
  - `findRippleCoins` discovers held trust lines for the coin finder, so XRPL tokens appear in the asset list. Lines with a negative balance (the account is the issuer and owes the counterparty) and zero-balance lines are excluded.
  - `rippleKnownIssuedTokens` (RLUSD) is now wired into `knownTokens`, so it is selectable before a trust line exists.

## 2.19.14

### Patch Changes

- [#1115](https://github.com/vultisig/vultisig-sdk/pull/1115) [`4483754`](https://github.com/vultisig/vultisig-sdk/commit/4483754748190fe25654de79fc12fba0edb73963) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expand large scientific-notation numeric amounts before base-unit parsing.

- [#1034](https://github.com/vultisig/vultisig-sdk/pull/1034) [`6643df7`](https://github.com/vultisig/vultisig-sdk/commit/6643df76cf2ff2ffe08ca4985bcaf46289714e4f) Thanks [@neavra](https://github.com/neavra)! - Silence 7z-wasm banner/progress output on stdout during QR payload compression/decompression. The chatter polluted the machine-output channel for CLI consumers (e.g. corrupting piped/JSON output on `join secure`); errors still surface via stderr.

## 2.19.13

### Patch Changes

- [#1091](https://github.com/vultisig/vultisig-sdk/pull/1091) [`56b8bce`](https://github.com/vultisig/vultisig-sdk/commit/56b8bce9ff60e6feaa5381327a23fe56d4ad5a21) Thanks [@ahdzib-maya](https://github.com/ahdzib-maya)! - fix(sdk): notify registered vault devices when keysign QR payloads are ready.

## 2.19.12

### Patch Changes

- [#1104](https://github.com/vultisig/vultisig-sdk/pull/1104) [`e450756`](https://github.com/vultisig/vultisig-sdk/commit/e4507569a92a24ed926c2fd6876b610ae807716b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Assert every Solana swap instruction targets an allow-listed program before
  handing the transaction to MPC signing (audit SOL-01, MEDIUM). Both Jupiter
  integration points — `getJupiterSwapQuote` (recipes/general-swap path) and
  `buildJupiterSwapTx` (SDK code-as-action tool) — deserialized a proxy-supplied
  `VersionedTransaction` and forwarded it to signing with no check that each
  instruction's `programIdIndex` resolves to an expected program. A compromised
  Jupiter proxy could otherwise splice in an arbitrary instruction (e.g. a
  drain transfer) that the user would effectively blind-sign.

  Add `assertSafeSolanaSwapInstructions` (`@vultisig/core-chain/chains/solana/assertSafeSolanaSwapInstructions`):
  resolves every top-level instruction's program against static account keys
  and, for v0 messages, address-lookup-table-resolved keys, and throws
  `SOL_SWAP_UNEXPECTED_PROGRAM` on the first unrecognized one. The allow-list
  (Jupiter v6 router, Compute Budget, System, SPL Token, Token-2022,
  Associated-Token-Account) was captured empirically by decoding real
  `/swap` responses from Jupiter's public API across a single-hop route, a
  3-hop route, a Token-2022 output mint, and a platform-fee-included swap.
  Wired into both Jupiter call sites, guarding the raw provider response
  before any local mutation (fee-ATA prepend) and regardless of whether an
  affiliate fee is charged on the swap.

## 2.19.11

### Patch Changes

- [#1086](https://github.com/vultisig/vultisig-sdk/pull/1086) [`3bf18a1`](https://github.com/vultisig/vultisig-sdk/commit/3bf18a18606fd1b45d50abb562eb6c3011182d48) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fail closed when TON wallet-info RPC calls return transport or body-level errors instead of defaulting to uninitialized wallet state.

## 2.19.10

### Patch Changes

- [#1105](https://github.com/vultisig/vultisig-sdk/pull/1105) [`280956f`](https://github.com/vultisig/vultisig-sdk/commit/280956f1743564ea271a03c4735f70151b63f161) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): keep erc20 approve for cowswap orders until permit path is wired (agg-03)

  The EIP-2612 permit path (buildEip2612Permit) has zero callers and no permit digest
  flows to the MPC keysign payload. Skipping the approve without a wired permit leaves
  cowswap permit-token orders with neither approve nor permit, causing silent swap
  failures. Keep the normal approve path until the permit flow is complete.

- [#1018](https://github.com/vultisig/vultisig-sdk/pull/1018) [`90070f3`](https://github.com/vultisig/vultisig-sdk/commit/90070f39be011821f7508c7ff094025861dce040) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): accept returned quote provider ids in `findSwapQuote.excludeProviders`

  `findSwapQuote.excludeProviders` now accepts both display names (`CowSwap`, `KyberSwap`, `LiFi`) and returned quote provider ids (`cowswap`, `kyber`, `li.fi`) for general providers. Unknown exclude tokens now fail closed instead of silently leaving the provider eligible.

- [#1113](https://github.com/vultisig/vultisig-sdk/pull/1113) [`0e3f86d`](https://github.com/vultisig/vultisig-sdk/commit/0e3f86db82ed086b1e200a6f83434a638f593c17) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(vault): route the send-path amount parser through `toChainAmount` for swap-path parity (gbbo9)

  `VaultBase.parseAmount` (the `send`/`transfer` amount converter) used `toBaseUnits` (pure string arithmetic, truncates excess fraction digits, rejects scientific notation), while the swap path (`validateHumanSwapAmount`, `SwapService`) used `toChainAmount` (viem `parseUnits`). Both paths now share `toChainAmount` for consistent semantics.

  `toChainAmount` now truncates (floors) excess fractional digits instead of rounding, so the signed amount can never exceed the stated human amount — the safe direction. Previously `parseUnits` rounded half-up, which at `decimals=0` (Cardano native assets, low-decimal tokens) caused a fractional input like `0.6` to sign `1` whole token. Scientific-notation amounts (e.g. `1e18`) are now accepted on the send path.

- [#1126](https://github.com/vultisig/vultisig-sdk/pull/1126) [`6054ff5`](https://github.com/vultisig/vultisig-sdk/commit/6054ff599e4133c9853f31e8ca2413ab52f606fb) Thanks [@neavra](https://github.com/neavra)! - fix(mpc): keep keygen tracing off stdout so `-o json` output stays parseable

  The DKLS and Schnorr keygen/reshare/key-import ceremonies logged progress
  (session ids, raw wire messages, "keygen complete", …) to stdout via ungated
  `console.log`. stdout is the machine channel for the CLI's `-o json` mode, so
  the documented `create fast … -o json` agent flow produced unparseable stdout
  (`JSON.parse(stdout)` failed on the leading garbage) and leaked MPC internals
  into terminals and CI logs.

  Route that tracing through a gated logger that writes to stderr only when
  `VULTISIG_DEBUG=1`, so stdout carries only the final JSON envelope while
  the debug output stays available to humans on demand. No keygen behavior
  changes — only the log sink moves off stdout.

- [#974](https://github.com/vultisig/vultisig-sdk/pull/974) [`b37e726`](https://github.com/vultisig/vultisig-sdk/commit/b37e7264db3291adca1cb366f1311446d6add439) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Disable the incomplete ServerManager reshare stub so it no longer returns stale vaults as successful reshares.

- [#1102](https://github.com/vultisig/vultisig-sdk/pull/1102) [`1b2636b`](https://github.com/vultisig/vultisig-sdk/commit/1b2636b535736a711fc537a87d2f51090fe6342d) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(solana): standardize Jupiter tools-path treasury address + slippage default on the shared cross-platform spec (SOL-03, SOL-04)

- [#1112](https://github.com/vultisig/vultisig-sdk/pull/1112) [`2c9d34e`](https://github.com/vultisig/vultisig-sdk/commit/2c9d34e0837f68d92769c7aefa566ffb1c0c52c7) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): resolve THORChain limit-swap destination chains via the swap-eligible chain set, not the LP-position map (THOR-04) — `getSupportedThorchainAssetChain` (`limitSwapMemo.ts`) resolved a THORChain asset-prefix (e.g. `SOL`, `NOBLE`) to a `Chain` via `lpChainMap`, a map scoped to the wallet's LP-position-display feature (`chains/cosmos/thor/lp/lpChainMap.ts`), not swap eligibility. Since neither Solana nor Noble has a THORChain LP pool, both were missing from that map, so a limit swap (`LIM=` memo) targeting either failed closed with "unsupported THORChain asset prefix" even though both are valid THORChain market-swap destinations (per THORChain's memo docs, `=` vs `=<` only changes execution behavior — price/queue/TTL — not the destination-chain universe). Fixed by unioning `lpChainMap` with `thorChainSwapEnabledChains` (`swap/native/NativeSwapChain.ts`, now exported) — the same THORChain-specific chain list regular market swaps already use to gate eligibility — rather than replacing `lpChainMap` outright or switching to the broader `nativeSwapChainIds`, which also carries MayaChain-only entries (e.g. `Chain.MayaChain`, `Chain.Cardano`) that aren't valid THORChain limit-swap destinations.

- [#1097](https://github.com/vultisig/vultisig-sdk/pull/1097) [`ffc75a6`](https://github.com/vultisig/vultisig-sdk/commit/ffc75a6e76af699a78b0fc3411ab052ce5000c91) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): exact bigint decimal conversion for the displayed swap output (`toAmountDecimal`) — the float64 `fromChainAmount(...).toFixed()` path silently drifted above 2^53 raw units (e.g. `999999999999999999999999` @18dp rendered as `1000000.000000000000000000`), so the amount the user confirmed could differ from the quoted one. Non-integer provider amount strings keep the legacy fallback instead of throwing mid-build.

- [#1089](https://github.com/vultisig/vultisig-sdk/pull/1089) [`fc595a1`](https://github.com/vultisig/vultisig-sdk/commit/fc595a17cb4901af1dfeac2521b93bb75823068f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(utxo): per-chain min-fee floor + canonical zcash zip-317 action count (UTXO-03/04)

  `buildUtxoSendTx` only enforced a minimum fee for Zcash; every other UTXO chain
  trusted the caller-supplied `feeRate` with no chain-aware floor. Dogecoin's
  real min-relay-fee is ~100x Bitcoin's, so a BTC-reasonable rate could silently
  underpay DOGE below relay and get the tx stuck. Added a per-chain minimum
  relay fee rate (sourced from each chain's own Core `DEFAULT_MIN_RELAY_TX_FEE`)
  that only raises a too-low `feeRate`, never lowers a legitimate one.

  Also swapped the builder's local, input-only `zcashConventionalFee` for the
  canonical `getZcashConventionalFee` (ZIP-317 `max(inputActions,
outputActions)`), which now accounts for OUTPUT bytes (change output + any
  OP_RETURN memo) instead of only counting inputs — a large-memo send was
  previously under-counting ZIP-317 actions and risking relay rejection.

- [#1110](https://github.com/vultisig/vultisig-sdk/pull/1110) [`776c539`](https://github.com/vultisig/vultisig-sdk/commit/776c5398764314f140f18ab4f86a1801fe9fdfe6) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(ripple): verify on-ledger inclusion for ambiguous XRP submit results instead of a blind throw

  `submitXrpTx` (the app's only XRP broadcast call site) threw a generic error for every `tec*` engine result from XRPL's `submit`, even though `tec*` means the tx was applied on-ledger (fee + sequence consumed) and the requested operation itself failed. A caller that treated that as "never broadcast" and retried with the same sequence risked a `tefPAST_SEQ` or a fund-loss race on a fee change.

  `submitXrpTx` now looks up `tec*` transactions by hash before deciding, and throws a typed `XrpSubmitRejectedError` with `.reason` for confirmed on-ledger failures, pending validation, and unconfirmed lookups. It also classifies `tef*` and non-queued `ter*` submit results conservatively instead of reporting them as safe local/preflight rejections. Only `tem*`/`tel*` local preflight failures are now reported as `'not-on-ledger'`. Also fixes the stale doc comment claiming the helper is unused by app code.

## 2.19.9

### Patch Changes

- [#1107](https://github.com/vultisig/vultisig-sdk/pull/1107) [`c5e89cb`](https://github.com/vultisig/vultisig-sdk/commit/c5e89cb317ae6f4ca00eb6c628ad6bac636e4821) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): populate 1inch affiliateFee for display (AGG-05) — 1inch general-swap quotes never populated `affiliateFee` on the returned `GeneralSwapQuote`, unlike Kyber and LI.FI, leaving the fee-transparency row blank for 1inch even though a real affiliate cut is taken via its `fee`/`referrer` params. `getOneInchSwapQuote` now grosses the post-fee `dstAmount` back up (same bps-based calc `getKyberSwapAffiliateFee` uses) to compute and attach a display-only `affiliateFee`.

- [#976](https://github.com/vultisig/vultisig-sdk/pull/976) [`6d78a03`](https://github.com/vultisig/vultisig-sdk/commit/6d78a03651e39b2b99cfbb051dad24b03e303835) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Propagate ERC-20 allowance fetch failures instead of treating them as zero allowance.

- [#1111](https://github.com/vultisig/vultisig-sdk/pull/1111) [`3fced18`](https://github.com/vultisig/vultisig-sdk/commit/3fced18987a1c2dbf6889e1d6b332db5652ecda7) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(cosmos): apply IBC gas multiplier to MsgTransfer (COSMOS-02)

  The Cosmos signing-inputs and fee-display resolvers used the flat per-chain gas limit (calibrated for `bank.MsgSend`) for every IBC message, including a full ICS-20 `MsgTransfer` with an optional PFM (packet-forward-middleware) memo. IBC transfers do measurably more work on the source leg — channel-state writes plus a relayer event — so the flat limit can run out of gas mid-execution: the fee is spent, the transfer fails, and funds don't move but the fee is still burned. `resolveCosmosGasFee` now applies the same `IBC_GAS_MULTIPLIER` (×2) the app's own Cosmos tx builder already documents (`vultiagent-app/src/services/cosmosTx.ts`), scoped to `IBC_TRANSFER` messages only — plain sends and wasm executes on ibc-enabled chains keep paying the calibrated flat fee.

- [#977](https://github.com/vultisig/vultisig-sdk/pull/977) [`8b72850`](https://github.com/vultisig/vultisig-sdk/commit/8b7285043adc1f02dc8c7b7d827f516b3edff55b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject Solana system and incinerator destinations through the shared dangerous-address guard.

- [#1101](https://github.com/vultisig/vultisig-sdk/pull/1101) [`9a1fc02`](https://github.com/vultisig/vultisig-sdk/commit/9a1fc0276ddc8fc905fab392875499d39011520d) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): surface non-integer dstAmount drops + validate THORChain/MayaChain MsgDeposit memos (SDK-CORRECTNESS-04/06/08) — a drifted provider's non-integer `dstAmount` used to silently drop that quote from ranking with no signal it was a parse failure; `findSwapQuote` now `console.warn`s the provider + raw value before rethrowing. `prepareThorchainMsgDepositTxFromKeys` accepted an arbitrary memo string with no structural validation, unlike the fully-validated limit-swap memo path; it now fails closed on non-printable/oversized memos and unrecognized THORChain/MayaChain deposit actions (and, for the two documented LP actions, a malformed pool id), while still accepting non-LP operator-style memos (BOND, UNBOND, etc.) verbatim. Also replaced an `as any` cast on the deposit's chain-specific proto binding with per-chain branches so the `case`/`value` pairing is statically checked instead of bypassed.

- [#1100](https://github.com/vultisig/vultisig-sdk/pull/1100) [`0e03972`](https://github.com/vultisig/vultisig-sdk/commit/0e03972ef9f477bb7dc7b4e01ad286b37c2b7561) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(evm): guard capGasLimit against a zero-source bigIntMax throw (SDK2-03)

- [#1092](https://github.com/vultisig/vultisig-sdk/pull/1092) [`fe1ddf5`](https://github.com/vultisig/vultisig-sdk/commit/fe1ddf5ee9c325f0873a5a402a074819897999d6) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(prep): enforce native-quote expiry + committed-amount consistency in the vault-free swap builder (ABTS/plan 005)

  `prepareSwapTxFromKeys` (the vault-free, agent/MCP-reachable swap payload builder) previously enforced neither quote expiry nor amount↔quote consistency, unlike the vault-wrapped `SwapService.prepareSwapTx`. It now, before any signable side effects:

  - rejects an expired native (THORChain/Maya) quote via the authoritative `quote.native.expiry`, mirroring core's `assertQuoteNotExpired`;
  - rejects an expired CoW order via the authoritative `cowswap_order.validTo`;
  - cross-checks the caller's `amount` against the CoW order's committed gross sell amount (`sellAmount + feeAmount`) to catch a stale/mismatched quote. The `transfer` route is intentionally excluded because its amount is provider-committed and legitimately diverges from the caller input by small fee adjustments; `evm`/`solana`/native fail open (no confidently-comparable committed field).

## 2.19.8

### Patch Changes

- [#1098](https://github.com/vultisig/vultisig-sdk/pull/1098) [`f695564`](https://github.com/vultisig/vultisig-sdk/commit/f69556421c77e36651143c4ba14aaac9f22133b3) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(kyber): bind swap tx.to to /route/build's own routerAddress (AGG-04)

- [#1096](https://github.com/vultisig/vultisig-sdk/pull/1096) [`04b1f38`](https://github.com/vultisig/vultisig-sdk/commit/04b1f38fab52ebb7938f3e5977318d67c9aa0921) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `selectUtxoInputs`, an accumulative largest-first coin-selection layer for
  UTXO sends (audit UTXO-01, HIGH). `buildUtxoSendTx`'s doc comment always said
  "caller handles coin-selection", but no selection layer existed — callers
  fetched every UTXO in the wallet and passed the full set through verbatim.
  That overpaid fees for all N inputs, could false-positive "insufficient
  funds" when fee(N) exceeded the balance even though a small subset would
  cover the send, and linked every UTXO the wallet owns in one transaction.

  `selectUtxoInputs` picks the smallest largest-first prefix of the candidate
  UTXOs that covers `amount + fee(k)`, reusing `estimateUtxoTxFee` — the same
  size/fee formula now extracted out of `buildUtxoSendTx` — so selection and
  build always agree on the fee. Supports a `sendMax` mode that consumes every
  UTXO for "send whole balance" flows. Covered across all 6 UTXO chains
  (Bitcoin, Litecoin, Dogecoin, Dash, Bitcoin-Cash, Zcash) with golden-vector
  tests for the trivial single-input case, multi-input accumulation, exact
  cover, sub-dust change folding into fee, genuine insufficient-funds, and
  send-max.

## 2.19.7

### Patch Changes

- [#1078](https://github.com/vultisig/vultisig-sdk/pull/1078) [`b1f2887`](https://github.com/vultisig/vultisig-sdk/commit/b1f288758ba627061c9c26085f96a3541b131163) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(evm): sanity-cap RPC-reported priority fee (SDK2-01). EVM fee estimation trusted `maxPriorityFeePerGas` from the RPC verbatim into the signed tx (Solana already had a ceiling for this, EVM didn't) — a compromised or anomalous RPC could inflate it and drain the user's balance to gas. Added a generous per-chain sanity ceiling (`clampEvmPriorityFee`) that only fires on orders-of-magnitude inflation; normal congestion on any chain passes through unchanged.

- [#1093](https://github.com/vultisig/vultisig-sdk/pull/1093) [`f54d53a`](https://github.com/vultisig/vultisig-sdk/commit/f54d53a0252d133c2d2d6b37c649542cb4069fd3) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(coin): findByTicker throws on cross-chain ambiguity instead of a silent first-match (SDK2-02)

  `findByTicker` resolved a bare ticker via `coins.find(c => c.ticker === ticker)` — array-order first match, no chain scoping. A symbol like "USDC" exists on many chains, so if this (currently-unreferenced public) helper were wired into a fund path it would silently resolve to whichever chain was first, sending to the wrong network. It now returns the unique match (or null when absent) and throws when the ticker is ambiguous across more than one chain, forcing the caller to disambiguate.

## 2.19.6

### Patch Changes

- [#1082](https://github.com/vultisig/vultisig-sdk/pull/1082) [`584bdb2`](https://github.com/vultisig/vultisig-sdk/commit/584bdb29b184fc01934645f745033208d42ea2e6) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): validate CowSwap order fields against the request before signing (AGG-01). sellToken/buyToken/kind/partiallyFillable were taken straight from the untrusted CoW /quote response and signed as-is via the EIP-712 GPv2 Order struct — a compromised/buggy response could substitute a token address or flip kind from 'sell' to 'buy' (inverting GPv2's sell/buy semantics while the SDK's grossSellAmount math still assumes sell-order semantics), and the SDK would sign it. Now asserts each field matches what was actually requested and refuses to build a signable order on any mismatch.

## 2.19.5

### Patch Changes

- [#1079](https://github.com/vultisig/vultisig-sdk/pull/1079) [`e33c4a8`](https://github.com/vultisig/vultisig-sdk/commit/e33c4a8cfdcae872506b0cdbbc11724b9e14cdf6) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): validate aggregator router addresses at quote construction (AGG-02). 1inch/Kyber/LiFi/SwapKit's tx.to was trusted with no allowlist, and fed both the ERC-20 approval spender and the swap transaction's on-chain destination — a compromised/spoofed aggregator response could get both approved and swapped against. 1inch/Kyber now fail closed (throw) if the returned router isn't their live-confirmed address; LiFi/SwapKit log the destination (never throw, since they route through many different contracts by design) so a future allowlist has real usage data if a pattern emerges.

- [#1081](https://github.com/vultisig/vultisig-sdk/pull/1081) [`709f0be`](https://github.com/vultisig/vultisig-sdk/commit/709f0bea7a3d9dfa1e7231d25bb3949072b77195) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(utxo): raise the Litecoin dust threshold to the real P2WPKH standard (~2_940 litoshi)

  Litecoin's DUST_RELAY_TX_FEE is ~10x Bitcoin's, so LTC's real standard dust threshold is ~2_940 litoshi for a P2WPKH output, not the hardcoded 1_000n. At 1_000n a change output of 1_001..2_939 litoshi was treated as spendable but is non-standard dust, so the transaction could be rejected by relays or stall. Bumped in both dust maps (core `minUtxo` + sdk `UTXO_SPECS`) and kept in sync. LTC-scoped (UTXO-02); BCH/Dash/Zcash 1_000n already sits at/above their real dust.

## 2.19.4

### Patch Changes

- [#1083](https://github.com/vultisig/vultisig-sdk/pull/1083) [`d3a372d`](https://github.com/vultisig/vultisig-sdk/commit/d3a372d48683b69ba6626f1b077b95088ff6a12b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(cosmos): refuse to sign a no-timeout IBC transfer and validate the source channel

  The Cosmos `IBC_TRANSFER` signing-input resolver built a `MsgTransfer` with an all-zero timeout (`timeoutTimestamp=0` and `timeoutHeight={0,0}`) whenever the IBC denom trace was missing. Relayers accept a no-timeout packet, but it never expires, so a failed transfer can leave funds stuck indefinitely instead of unwinding. The resolver now fails closed and refuses to build when neither timeout is usable (COSMOS-01). It also validates that the source channel parsed out of the memo (`<prefix>:channel-<n>[:...]`) is well-formed, refusing to sign with an undefined/empty/malformed channel instead of dispatching a broken `MsgTransfer` (COSMOS-03).

## 2.19.3

### Patch Changes

- [#1075](https://github.com/vultisig/vultisig-sdk/pull/1075) [`ac1a0f7`](https://github.com/vultisig/vultisig-sdk/commit/ac1a0f797e542868263cf31a26c2fe4e00e2ba78) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): enforce a 10% price-impact ceiling on both Jupiter swap-build paths (SOL-02). A thin-pool / sandwich-bait Jupiter quote at 50-90% price impact previously built a fully signable, MPC-ready transaction with zero protection. Both `getJupiterSwapQuote` (core) and `buildJupiterSwapTx` (SDK) now refuse to build above the ceiling, matching the guard already enforced on the production agent path.

## 2.19.2

### Patch Changes

- [#1046](https://github.com/vultisig/vultisig-sdk/pull/1046) [`8d36421`](https://github.com/vultisig/vultisig-sdk/commit/8d364215cdca70f0df12f08d6676d65e352cf235) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix: UTXO/Cardano broadcast no longer reports false success on a genuine failure

  `broadcastCardanoTx`/`broadcastUtxoTx` bucketed `BadInputsUTxO` (a genuine failure — spent/invalid inputs)
  together with benign MPC-race duplicates (`txn-mempool-conflict`/`already known`) and returned success
  unconditionally for all three, bypassing the on-chain hash verification safety net. Every ambiguous submit
  error now routes through `verifyBroadcastByHash`, and `getUtxoTxStatus` now sets `isKnown: false` when the
  hash is genuinely not found (matching the existing convention already used by the cosmos/evm/polkadot/
  ripple/solana resolvers) so a real failure correctly rethrows instead of being swallowed as success.

- [#1073](https://github.com/vultisig/vultisig-sdk/pull/1073) [`0013d0d`](https://github.com/vultisig/vultisig-sdk/commit/0013d0d4c7c9249bb0fb64705b726e85fc7a50e0) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(swap): reject a limit-swap LIM that floors to zero (THOR-02). A tiny target price could floor the computed limit amount to 0, and THORChain treats a zero trade target as an unprotected MARKET swap with no minimum-output floor — silently discarding the price protection the user configured for their limit order. Fail closed with a clear error instead of building a memo that reinterprets as a market swap.

## 2.19.1

### Patch Changes

- [#1035](https://github.com/vultisig/vultisig-sdk/pull/1035) [`989ec59`](https://github.com/vultisig/vultisig-sdk/commit/989ec593ac5c8782f731b43696b32c18edb54599) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix `getCosmosFeeAmount` (canonical cosmos gas resolver, used by the CLI/browser/electron keysign pipeline) to query Osmosis's own EIP-1559 dynamic base-fee endpoint (`/osmosis/txfees/v1beta1/cur_eip_base_fee`) as an additional floor. Previously this resolver only queried the generic `/cosmos/base/node/v1beta1/config` node config for every ibc-enabled chain, which does not track Osmosis's protocol-level dynamic fee and can be clamped away by the anomaly guard during a genuine base-fee spike — leading to a broadcast rejection (sdk error code 13, "insufficient fees"). This mirrors a fix already live in vultiagent-app.

## 2.19.0

### Minor Changes

- [#1042](https://github.com/vultisig/vultisig-sdk/pull/1042) [`ad6196b`](https://github.com/vultisig/vultisig-sdk/commit/ad6196b32ae879e7b0e0fda48e462fc7a05eb1de) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(ripple): XRP trust-line (TrustSet) support for issued tokens

  Add support for opening/modifying an XRPL trust line so a vault can hold issued
  currencies (e.g. RLUSD). `getRippleSigningInputs` now emits a WalletCore
  `OperationTrustSet` (LimitAmount = { currency, issuer, value }) when the keysign
  coin is an issued currency, and falls through to the existing Payment path for
  native XRP. New `chains/ripple/issuedCurrency` helpers encode the composite
  `currency.issuer` token id, normalise human tickers to on-ledger currency codes,
  format issued-currency values, and expose the 0.2 XRP owner-reserve delta
  (`rippleOwnerReserveDrops`). `isValidTokenId` validates XRPL `currency.issuer`
  ids.

## 2.18.8

### Patch Changes

- [#1037](https://github.com/vultisig/vultisig-sdk/pull/1037) [`f879364`](https://github.com/vultisig/vultisig-sdk/commit/f8793648823d0016baa1a9375c179bc578d2a952) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Fix `runSkipSwap`'s cosmos memo-length preflight to check every leg of a Skip route, not just the first leg of single-tx routes. Previously the check only ran when the route required a single signature and only inspected the first cosmos leg's memo — a multi-tx route (`allowMultiTx: true`) with an over-cap memo on a later leg sailed through undetected and would fail at broadcast (sdk error code 12, "memo too long") after signing, burning the MPC ceremony. This mirrors a check already present and more thorough in agent-backend-ts's own Skip integration.

## 2.18.6

### Patch Changes

- [#1026](https://github.com/vultisig/vultisig-sdk/pull/1026) [`ce38186`](https://github.com/vultisig/vultisig-sdk/commit/ce381864b977b19668702eae6e1ecad63ecbdf2b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add cosmos per-chain fee-denom allowlist helpers (`getCosmosAllowedFeeDenoms`, `isCosmosFeeDenomAllowed`) as the single source of truth for which denoms a cosmos chain's ante handler accepts as a gas fee, consolidating copies previously maintained independently in agent-backend-ts (execute_send.ts, astroport-classic-swap.ts, cosmos-staking.ts).

- [#1024](https://github.com/vultisig/vultisig-sdk/pull/1024) [`3bc7904`](https://github.com/vultisig/vultisig-sdk/commit/3bc790403483dd7e90dac2efc33d7bc64c18b921) Thanks [@neavra](https://github.com/neavra)! - Stop `tx-status` from reporting malformed or never-seen transaction hashes as `pending` forever.

  - The EVM status resolver now distinguishes a genuinely-pending tx (the node knows the hash, receipt still lagging) from one the node has never seen, returning a new terminal `not_found` status for the latter instead of an indefinite `pending`.
  - New `isValidTxHash(chain, hash)` helper validates a hash's shape per chain-kind; the CLI `tx-status` command validates `--tx-hash` before any RPC and fails fast with `INVALID_INPUT` (exit 4) on a malformed hash.
  - CLI `tx-status` polling is now bounded by a total wait budget (`--timeout <seconds>`, default 120) and exits non-zero on give-up — `TX_NOT_FOUND` (exit 5) when the node has no record of the hash, `TX_STATUS_TIMEOUT` (exit 3, retryable) when it is still pending.
  - The poll loop now caps each sleep at the remaining wait budget instead of always sleeping the full poll interval, so a small `--timeout` gives up promptly instead of overshooting by up to one poll interval.

## 2.18.5

### Patch Changes

- [#1022](https://github.com/vultisig/vultisig-sdk/pull/1022) [`3f5883a`](https://github.com/vultisig/vultisig-sdk/commit/3f5883a3328340c969577593746185103bc9970e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add cosmos `x/auth.MaxMemoCharacters` cap helpers (`getCosmosMemoMaxBytes`, `getCosmosMemoMaxBytesByChainId`, `isCosmosMemoWithinCap`, `COSMOS_MEMO_DEFAULT_MAX_BYTES`) as the single source of truth for cosmos memo-length limits, consolidating copies previously maintained in agent-backend-ts and mcp-ts. Bundled into `@vultisig/sdk` so consumers receive a new tarball.

  Also points the Skip Go swap tool (`skipSwap.ts`) at `getCosmosMemoMaxBytesByChainId` instead of its own divergent memo-cap table, which under-capped `phoenix-1` and `cosmoshub-4` at 256 bytes instead of the correct 512.

- [#971](https://github.com/vultisig/vultisig-sdk/pull/971) [`4b7e249`](https://github.com/vultisig/vultisig-sdk/commit/4b7e249fc4d51cb6c2f5fd55a53867575756f5b7) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Validate MayaChain native swap inbound vault addresses before broadcasting.

- [#1012](https://github.com/vultisig/vultisig-sdk/pull/1012) [`50736c5`](https://github.com/vultisig/vultisig-sdk/commit/50736c525d45040b1533bc6d8ab175541c00762f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Classify transient swap quote provider failures from structured status data.

## 2.18.4

### Patch Changes

- [#1020](https://github.com/vultisig/vultisig-sdk/pull/1020) [`74fec5a`](https://github.com/vultisig/vultisig-sdk/commit/74fec5a17942689fe8a05c0f145bfe552dbe5e87) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(swap): consolidate Skip Go routing-eligibility predicates into the SDK

  Adds `isSkipRoutableChain`, `isTerraChain`, and `willRouteViaSkip` as tested
  core functions under `@vultisig/core-chain/swap/skip/skipRouting`, re-exported
  from the main `@vultisig/sdk` entry. Pure chain-topology predicates (no network
  calls, no AI-specific logic) that give consumers one shared source of truth for
  "does this from/to chain pair route through Skip Go?" instead of the
  independently-maintained copies that can drift (the mcp-ts [#384](https://github.com/vultisig/vultisig-sdk/issues/384) bug class).
  Purely additive — no existing export or behavior changed.

## 2.18.3

### Patch Changes

- [#1013](https://github.com/vultisig/vultisig-sdk/pull/1013) [`29cce41`](https://github.com/vultisig/vultisig-sdk/commit/29cce4132aa9ad6359d18ebe48cd3c983431ae27) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Unblock Sui and Cardano as SwapKit/MayaChain swap sources

- [#1013](https://github.com/vultisig/vultisig-sdk/pull/1013) [`29cce41`](https://github.com/vultisig/vultisig-sdk/commit/29cce4132aa9ad6359d18ebe48cd3c983431ae27) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add groundwork for Sui and Cardano swap source-chain handling while keeping unverified signing paths blocked.

## 2.18.2

### Patch Changes

- [#1014](https://github.com/vultisig/vultisig-sdk/pull/1014) [`c41a219`](https://github.com/vultisig/vultisig-sdk/commit/c41a21950c4cccf70c8298b8e595acf64c276d8c) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(cosmos): initiator-side dynamic gas — simulate native sends and relay `CosmosSpecific.gas_limit`

  `getCosmosChainSpecific` now simulates native Cosmos bank sends via
  `/cosmos/tx/v1beta1/simulate` and relays the padded (`× 1.3`) `gas_used` to
  co-signers in `CosmosSpecific.gas_limit`. The signing-inputs resolver already
  honors this field (scaling the fee amount accordingly) and falls back to the
  static per-chain gas limit when it is absent or zero, so:

  - Only native bank sends are simulated (a relayed dapp `signData`, token / IBC /
    contract / staking txs, and vault-based chains keep the static limit).
  - Estimation fails closed: any simulate/build error leaves the field unset, so
    simulation never blocks signing and peers converge on the static limit.
  - The relayed limit is part of the SignDoc every device hashes; because it is
    computed with exact integer math (ceil of `gas_used × 13 / 10`) and honored
    identically across peers, cross-device co-signing stays byte-identical.

  Mirrors the iOS `CosmosGasEstimator` implementation.

## 2.18.1

### Patch Changes

- [#926](https://github.com/vultisig/vultisig-sdk/pull/926) [`e0eaf83`](https://github.com/vultisig/vultisig-sdk/commit/e0eaf83b0a6d79fd99d7d7d697eea04387834338) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(cosmos): harden chain/denom/id dispatch against undefined inputs

  Guards cosmos balance resolvers, token metadata resolvers, and public-key
  lookup against undefined chain, denom, or address inputs that would otherwise
  throw at runtime or return stale data. Defensive undefined checks added across
  the cosmos resolver layer.

## 2.18.0

### Patch Changes

- [#1010](https://github.com/vultisig/vultisig-sdk/pull/1010) [`31814c4`](https://github.com/vultisig/vultisig-sdk/commit/31814c4b452ef5b2628dc12bc46e427fcf0b7237) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fetch portfolio native and token balances in parallel across chains.

- [#1006](https://github.com/vultisig/vultisig-sdk/pull/1006) [`b37dc3c`](https://github.com/vultisig/vultisig-sdk/commit/b37dc3c31d6f93af982cd1e082e0b4d1382dc19d) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Honor positive relayed Cosmos gas limits when building signing inputs.

- [#1009](https://github.com/vultisig/vultisig-sdk/pull/1009) [`01c5630`](https://github.com/vultisig/vultisig-sdk/commit/01c56303d0b872a76de07da9685331106f586c80) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Batch native portfolio price fetches and price portfolio entries concurrently.

## 2.17.1

### Patch Changes

- [#1005](https://github.com/vultisig/vultisig-sdk/pull/1005) [`889380e`](https://github.com/vultisig/vultisig-sdk/commit/889380ec1571d6385ce688c4b49af04bfe8f5b55) Thanks [@rcoderdev](https://github.com/rcoderdev)! - test(mpc): add golden keysign fixtures for 71 mobile cases across 23 chains

  Regression harness for mobile keysign flows. Fixture JSON files under
  `packages/core/mpc/keysign/tests/fixtures/mobile/` cover arb, bsc,
  cardano, cosmos, dot, evm, kujira, maya, pol, solana, sui, terra,
  thorchain, ton, tron, utxo, and xrp chains. No production source changes.

## 2.17.0

### Minor Changes

- [#999](https://github.com/vultisig/vultisig-sdk/pull/999) [`99db752`](https://github.com/vultisig/vultisig-sdk/commit/99db752f093575f90b99b30674ec9be8af49fed9) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(cosmos): parameterize the THORChain-family MsgDeposit asset (THOR.RUNE / MAYA.CACAO)

  `buildThorchainDepositTx` gains an optional `asset` ({ chain, symbol, ticker }) that
  defaults to THOR.RUNE, so every existing caller is byte-identical. MayaChain-source
  swaps pass MAYA.CACAO, enabling native CACAO->RUNE (and RUNE-source) deposit swaps in
  the app's react-native signing path (previously hardcoded THOR.RUNE, which would sign
  the wrong asset for a Maya deposit).

### Patch Changes

- [#960](https://github.com/vultisig/vultisig-sdk/pull/960) [`2585dc1`](https://github.com/vultisig/vultisig-sdk/commit/2585dc1830dd7b28694edd411991b24c3fad1538) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(evm): chunk the 1inch token-metadata request so token-rich wallets don't 414. `findEvmCoins` joined every held-token address into one `/custom` GET, overflowing the proxy URI (HTTP 414) and killing discovery of all tokens; requests are now batched (50/req) and non-fatal per batch.

- [#967](https://github.com/vultisig/vultisig-sdk/pull/967) [`152bb4a`](https://github.com/vultisig/vultisig-sdk/commit/152bb4a2b717efa2f1edb14b7e19cdeba87450c7) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(cardano): paginate `address_assets` so NFT-heavy wallets aren't truncated. A single unbounded Koios query capped at 1000 rows, dropping tokens past 1000 in both discovery and per-token balance; it now follows the offset/limit pages.

- [#968](https://github.com/vultisig/vultisig-sdk/pull/968) [`4a58c6c`](https://github.com/vultisig/vultisig-sdk/commit/4a58c6c1294c88e5d937c3dde24e50edd3fdf2a0) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(cosmos): paginate token discovery so IBC-heavy wallets aren't truncated. cosmjs `getAllBalances` issues a single unpaginated query capped at the node default (100), dropping denoms past 100; discovery now walks the LCD balances pages with a fall-through to cosmjs.

- [#969](https://github.com/vultisig/vultisig-sdk/pull/969) [`ed46385`](https://github.com/vultisig/vultisig-sdk/commit/ed46385358883ed5277f8771ba73000afec9859e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(evm): one token's on-chain metadata failure no longer kills all discovery. `getDiscoveredEvmCoin` re-threw inside `findEvmCoins`' `Promise.all`, so a single transient metadata read rejected discovery of every token on the chain; it now skips just the failing token.

- [#966](https://github.com/vultisig/vultisig-sdk/pull/966) [`72082a6`](https://github.com/vultisig/vultisig-sdk/commit/72082a65eab226cebf562863bcb99346b81ca831) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(polkadot): reject an invalid destination instead of self-sending. `resolvePolkadotToAddress` (Polkadot + Bittensor) fell back to the sender's own address on a missing/invalid `toAddress`, so the signed extrinsic could diverge from the approved pre-sign card; it now throws.

- [#962](https://github.com/vultisig/vultisig-sdk/pull/962) [`a9266a1`](https://github.com/vultisig/vultisig-sdk/commit/a9266a1753ca474b3f337f8a605900acdd7508b0) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(solana): use Promise.allSettled across the SPL token programs so one program's failure doesn't hide the other's holdings. `getSplAccounts` used Promise.all, so a single token-program RPC failure (e.g. a 520) rejected the whole lookup; it now only throws when both programs fail.

- [#965](https://github.com/vultisig/vultisig-sdk/pull/965) [`2791af8`](https://github.com/vultisig/vultisig-sdk/commit/2791af8a1e539103678ba71b774d62d2e7691a29) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(sui): paginate `getAllCoins` so sends see every coin object. The keysign resolver read only the first ~50-object page, truncating the coin set used for gas + input selection and producing a broken send on wallets with >50 coin objects.

- [#964](https://github.com/vultisig/vultisig-sdk/pull/964) [`b68ddad`](https://github.com/vultisig/vultisig-sdk/commit/b68ddadbc6295957cbb4b37c365a4062b0a2576f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(ton): fail closed on a null account-info result before it crashes keysign. A transient `ok:false`/null-result response from `getExtendedAddressInformation` slipped through as a 200 and crashed the TON keysign resolver on `const { account_state } = undefined`; `getTonAccountInfo` now throws a descriptive error instead of returning null.

- [#970](https://github.com/vultisig/vultisig-sdk/pull/970) [`ab5e413`](https://github.com/vultisig/vultisig-sdk/commit/ab5e413ead62da47dc144e591ac310d1d4328a56) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(tron): verify the base58check checksum on the TRC-20 balance-read address decode. `tronAddressToAbiParam` used plain `bs58.decode` with no checksum check, so a typo'd-but-decodable address silently queried a different account; it now uses `bs58check.decode`.

- [#959](https://github.com/vultisig/vultisig-sdk/pull/959) [`90f6ae5`](https://github.com/vultisig/vultisig-sdk/commit/90f6ae5a1865321e08bf6f03c17e23ed11006649) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(ripple): add the XRP reserve to the send amount check, not the burned fee. The base reserve was added to `gas` (the burned Fee) instead of being enforced against the Amount, burning ~1 XRP per fresh-address send; the resolver now sets the network fee correctly and rejects a send below the reserve.

- [#961](https://github.com/vultisig/vultisig-sdk/pull/961) [`7cfa332`](https://github.com/vultisig/vultisig-sdk/commit/7cfa332787f7646e049813a9f3b15613454f19d1) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(evm): add zkSync to the 1inch-supported chains so its ERC-20s are discovered. zkSync was silently absent from `oneInchSupportedChains`, so token discovery returned an empty set even though the proxy serves chain 324.

- [#973](https://github.com/vultisig/vultisig-sdk/pull/973) [`c60d7c6`](https://github.com/vultisig/vultisig-sdk/commit/c60d7c6ecdf46e46bf1098cc57342d5fb79d2194) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Reject non-decimal send amounts such as hex and scientific notation with `InvalidAmount`.

## 2.16.0

### Minor Changes

- [#984](https://github.com/vultisig/vultisig-sdk/pull/984) [`0147158`](https://github.com/vultisig/vultisig-sdk/commit/0147158ac6955aa420cdad2da704cba998e4a5f1) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(utxo): OP_RETURN output in buildUtxoSendTx so UTXO THOR swaps carry the swap memo

  Adds an optional `opReturnData` (UTF-8) to `BuildUtxoSendOptions`. When present,
  `buildUtxoSendTx` appends a trailing 0-value OP_RETURN output carrying the memo,
  enabling UTXO (DOGE/BTC/LTC/BCH) THORChain swaps: without the on-chain memo
  THORChain cannot route the vaulted deposit, so the app currently fails closed on
  these.

  Fund-safety:

  - The OP_RETURN is built inside `serializeOutputs`, so it feeds the outputs
    digest every sighash variant consumes (BIP143 / legacy / Zcash). Every input
    signature commits to the memo - it cannot be stripped or altered post-signing.
  - The recipient (vault) output keeps the FULL amount; the OP_RETURN is a separate
    0-value output and its size is folded into the fee estimate, so the fee comes
    from inputs/change, never by shaving the vault output.
  - Payload is capped at the 80-byte standard-relay limit (direct push <= 75 bytes,
    OP_PUSHDATA1 for 76..80); larger memos throw rather than build a non-standard,
    unbroadcastable tx.

## 2.15.0

### Patch Changes

- [#956](https://github.com/vultisig/vultisig-sdk/pull/956) [`f72cbc3`](https://github.com/vultisig/vultisig-sdk/commit/f72cbc35a23edb2b14984fce0a16495a3339e5e6) Thanks [@gastonm5](https://github.com/gastonm5)! - fix(cardano): attach and plan per-UTXO native-token data for MPC keysign parity

  Adopts commondata's `UtxoInfo.cardano_tokens` across all three missing
  layers, mirroring the mainnet-tested iOS implementation byte-for-byte:

  - Regenerates `utxo_info_pb.ts` so `CardanoTokenAsset` /
    `UtxoInfo.cardanoTokens` exist and can be decoded off the keysign wire.
  - The keysign initiator fetches Cardano UTXOs with Koios `_extended` and
    attaches per-UTXO native assets (UTXOs ordered by `(hash, index)`, assets
    by `(policyId, assetNameHex)`, hex lowercased) so co-signers see
    deterministic, token-aware payload bytes.
  - The Cardano signing-inputs resolver maps `cardanoTokens` onto WalletCore
    `TxInput.token_amount` (minimal big-endian amount bytes), letting the
    planner reconcile input tokens into the change output.

  Fixes MPC co-signing for any Cardano address holding native tokens:
  iOS/macOS-initiated sends no longer fail keysign with a pre-image hash
  mismatch, and SDK-initiated sends no longer build token-dropping bodies
  that the node rejects at broadcast (Ogmios 3123 "value not conserved").

- [#806](https://github.com/vultisig/vultisig-sdk/pull/806) [`119d96d`](https://github.com/vultisig/vultisig-sdk/commit/119d96d5b2c9e1e2d8b322bf31d83f3ac4294244) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Rank swap quotes by net user output and tighten the provider preference band.

## 2.14.0

### Minor Changes

- [#931](https://github.com/vultisig/vultisig-sdk/pull/931) [`45fb0ae`](https://github.com/vultisig/vultisig-sdk/commit/45fb0ae83611dfcd481b1aa9dbcd19fe215642f5) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add a public `SwapAffiliateConfig.jupiter` fee-owner override for Jupiter affiliate fee account derivation.

- [#930](https://github.com/vultisig/vultisig-sdk/pull/930) [`e11d55f`](https://github.com/vultisig/vultisig-sdk/commit/e11d55f51dc4a65230ca4daa6bbad2580a3d1a81) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(solana): staking APY resolver

  Phase 6 of Solana native staking. Adds `resolveValidatorApy` under
  `@vultisig/core-chain/chains/solana/staking/apyResolver`, which drives the
  per-validator APY on the DeFi stake rows. Two sources, in order: the Stakewiz
  `apy_estimate` passthrough (network-measured, commission-net) from the Phase 2
  metadata seam, then an on-chain fallback derived from the network inflation rate
  and the fraction of supply staked, net of the validator's commission, compounded
  over the epochs-per-year. Returns `undefined` when neither yields a positive
  value so the view hides the APY row.

- [#887](https://github.com/vultisig/vultisig-sdk/pull/887) [`6ff9d7e`](https://github.com/vultisig/vultisig-sdk/commit/6ff9d7eba5699e1db897c5aedbac52632c131cc5) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add Jupiter as a same-chain Solana swap provider with VULT-scaled affiliate fee support.

### Patch Changes

- [#923](https://github.com/vultisig/vultisig-sdk/pull/923) [`17a43be`](https://github.com/vultisig/vultisig-sdk/commit/17a43beadda6d3f4f7d97c193067564a2c85bd37) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fetch Solana signing blockhashes at confirmed commitment and retry transient blockhash misses during standard RPC broadcast.

## 2.13.2

### Patch Changes

- [#921](https://github.com/vultisig/vultisig-sdk/pull/921) [`6eff99f`](https://github.com/vultisig/vultisig-sdk/commit/6eff99fa08f0d2511eab95304c0a0c973944db2e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - refactor(cardano): attach CIP-20 memo via WalletCore native auxiliary_data

  Bumps `@trustwallet/wallet-core` to `4.7.0`, which adds the Cardano
  `SigningInput.auxiliary_data` field. The Cardano memo path now hands the
  CIP-20 CBOR straight to WalletCore, which commits its Blake2b-256 hash into
  tx body key 7 and embeds the bytes in the signed transaction — replacing the
  client-side body patching and re-hashing in TypeScript. The chain-specific
  fee estimator prices the WalletCore body as-is (it already carries key 7),
  and the now-unused `patchTxBodyWithAuxHash` helper is removed.

- [#924](https://github.com/vultisig/vultisig-sdk/pull/924) [`d08a476`](https://github.com/vultisig/vultisig-sdk/commit/d08a47696d0cb1c8dbcb50d41830b9eae16b6d8c) Thanks [@johnnyluo](https://github.com/johnnyluo)! - fix(terra-classic): align send gas limit with iOS/Android for cross-device co-signing

  Corrects the Terra Classic send gas limit in `cosmosGasLimitRecord` so it matches
  the values used by the iOS and Android clients. When co-signing across devices, a
  mismatched gas limit produces a different transaction hash and the signing session
  fails; aligning the record keeps the payload identical across platforms.

## 2.13.1

### Patch Changes

- [#918](https://github.com/vultisig/vultisig-sdk/pull/918) [`6302825`](https://github.com/vultisig/vultisig-sdk/commit/63028250c7a17bf165046f0bb0c2263354dab66a) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Show tiny fiat amounts (e.g. LUNC-style prices below one cent) with significant
  digits and compact subscript notation instead of rounding them to "$0.00"
  (e.g. 0.00000003 now renders as $0.0₇3).

## 2.13.0

### Minor Changes

- [#915](https://github.com/vultisig/vultisig-sdk/pull/915) [`4941508`](https://github.com/vultisig/vultisig-sdk/commit/4941508f5002e1251b5cc1cbc08ed0ebc379646a) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(solana): native-staking transaction builder (byte-parity)

  Phase 3 of Solana native staking. Adds the signing core for the delegate flow
  (and the proto for the later unstake / withdraw / move-stake ops) under
  `@vultisig/core-chain/chains/solana/staking/tx`:

  - `stakingPayload` — discriminated staking-op intent (delegate / unstake /
    withdraw / move-stake deactivate + redelegate sub-steps).
  - `buildUnsignedStakingTx` — maps a payload to the wallet-core Solana stake
    proto (`delegateStakeTransaction` derives the stake account; move-redelegate
    sets it explicitly), compiles a zero-signature envelope via
    `TransactionCompiler`, and returns it base64-encoded. This is the MPC
    byte-parity contract: the initiating device builds these bytes once (pinning
    the recent blockhash + the derived stake-account address) and relays them via
    `signSolana.rawTransactions`, so every co-signer signs the identical message.

  Adds `long` to core-chain deps (Long-typed proto amount fields). Byte-parity
  tests build delegate / deactivate / withdraw / move-redelegate txs against real
  wallet-core, decode them back, and assert determinism.

### Patch Changes

- [#916](https://github.com/vultisig/vultisig-sdk/pull/916) [`17fcbc0`](https://github.com/vultisig/vultisig-sdk/commit/17fcbc0acf983959be7faaf4ab789b4268a83c31) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Solana broadcast: surface the on-chain rejection reason. When `sendTransaction` is rejected at preflight, the RPC returns the actionable detail in `data.err` / `data.logs` (the program logs), which web3.js exposes via `SendTransactionError.logs` while leaving the bare `.message` ("failed to send transaction") uninformative. The broadcast resolver now folds those program logs into the thrown error's message (preserving the original error as `cause`), so consumers reading the top-level message see _why_ the network rejected the transaction — "insufficient lamports", a custom program error, a failed instruction — instead of just that it failed.

## 2.12.0

### Minor Changes

- [#912](https://github.com/vultisig/vultisig-sdk/pull/912) [`403d5d5`](https://github.com/vultisig/vultisig-sdk/commit/403d5d5f7c7dba3e45cb818899db00f765541ecf) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(solana): validator-metadata seam (Stakewiz, swappable)

  Phase 2 of Solana native staking. Adds a swappable off-chain enrichment seam for
  validator display metadata (name / logo / APY estimate / score) on top of the
  Phase 1 on-chain `getVoteAccounts` rows, under
  `@vultisig/core-chain/chains/solana/staking/metadata`:

  - `ValidatorMetadataProvider` — provider interface; contract: never throws.
  - `stakewizProvider` — concrete impl over api.stakewiz.com (`apy_estimate`
    percent→fraction, `image`→logo, `wiz_score`→score). Degrades to an empty map
    on any outage / non-OK / parse error so callers fall back to on-chain-only.
  - `enrichValidators` — merges the metadata map onto the validator rows; the
    provider is injectable for tests.

## 2.11.0

### Minor Changes

- [#900](https://github.com/vultisig/vultisig-sdk/pull/900) [`9e72781`](https://github.com/vultisig/vultisig-sdk/commit/9e7278125bd8bc722a26ab3a1f91ba1be03054d1) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(solana): staking foundation — models + RPC read layer

  Phase 1 of Solana native staking. Adds the chain-layer read foundation under
  `@vultisig/core-chain/chains/solana/staking`: config, stake-account/validator
  models (jsonParsed parsing + activation-state derivation), the RPC read layer
  (getVoteAccounts / stake-account scan / epoch / rent / inflation / supply), and
  the withdraw cooldown gate. No UI, no signing, no validator-metadata source.

## 2.10.0

### Minor Changes

- [#894](https://github.com/vultisig/vultisig-sdk/pull/894) [`605fbba`](https://github.com/vultisig/vultisig-sdk/commit/605fbbaf107c553898f11f4f7eb6b56a59c01b9e) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(swap): add Jupiter as a Solana same-chain swap provider with a VULT-scaled affiliate fee

  `findSwapQuote` now offers Jupiter for on-Solana token pairs (SOL↔SPL, SPL↔SPL),
  preferred over SwapKit/LiFi on a near-tie. Jupiter is Solana-only and same-chain
  — it is never offered for any cross-chain route, and native SOL cross-chain swaps
  stay on THORChain.

  The Jupiter quote sends `platformFeeBps` = `max(0, 50 − vultTierDiscountBps)`
  (the existing `getSwapAffiliateBps` value, shared with every other provider), and
  the swap request sends `feeAccount` = the Associated Token Account of
  `(owner = Vultisig fee wallet, mint = output mint)`. An idempotent
  `createAssociatedTokenAccount` instruction for that fee ATA is prepended to the
  returned transaction (Jupiter does not auto-create it). When the affiliate bps
  floors to 0 (Ultimate-tier VULT holder), no platform fee or fee account is used.

  New public surface: `swap/general/jupiter/*` (`getJupiterSwapQuote`,
  `configureJupiter`, `jupiterSwapEnabledChains`) and `jupiter` added to
  `generalSwapProviders` and the swap explorer providers.

- [#893](https://github.com/vultisig/vultisig-sdk/pull/893) [`552064c`](https://github.com/vultisig/vultisig-sdk/commit/552064cbfb7307867f9897734c010e856f8a08f9) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add TON nominator-pool staking support. `@vultisig/core-chain` gains a tonapi staking client (`chains/ton/staking`) — pool list, computed pool info, and account nominator positions — plus per-implementation deposit/withdraw comment resolution (`whales` → `Deposit`/`Withdraw`, `tf` → `d`/`w`), pool eligibility/capacity filters, and a `tonAddressToBounceable` helper that normalizes raw `0:` pool addresses to the bounceable `EQ…` form. `@vultisig/core-mpc` now forces TON transfers bounceable for any staking comment (via `isTonStakingComment`), so a rejected pool deposit/withdraw bounces back instead of being absorbed.

### Patch Changes

- [#886](https://github.com/vultisig/vultisig-sdk/pull/886) [`baedd96`](https://github.com/vultisig/vultisig-sdk/commit/baedd96e9d75a9d73880a59503f95b527d692428) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add an EVM chain balance batching helper backed by Multicall3.

## 2.9.0

### Minor Changes

- [#888](https://github.com/vultisig/vultisig-sdk/pull/888) [`b61410e`](https://github.com/vultisig/vultisig-sdk/commit/b61410ef8b1d0b1baa7d249440176df23bfa471c) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add QBTC governance support under `chains/cosmos/qbtc/governance/`: REST clients for the Cosmos `x/gov v1` proposals, tally, votes and params endpoints, plus the domain types and wire parsers. Mirrors the existing `qbtc/claim` split and is consumed by the wallet's QBTC governance UI.

## 2.8.5

### Patch Changes

- [#884](https://github.com/vultisig/vultisig-sdk/pull/884) [`33e663c`](https://github.com/vultisig/vultisig-sdk/commit/33e663ce6ba519cacb7dae5befebe9e3e530b4d7) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Lower `cosmosGasRecord[TerraClassic]` from 100 LUNC to 20 LUNC.

  Real on-chain MsgSend cost on columbus-5: ~400k gas x 28.325 uluna/gas ~ 11.33 LUNC.
  The 100 LUNC floor was blocking sends from wallets with 20-100 LUNC balance even when
  the transaction would have succeeded. The new 20 LUNC floor gives a ~1.77x buffer.

  Companion to vultisig/agent-backend#1409 and vultisig/mcp-ts#594.

## 2.8.4

### Patch Changes

- [#874](https://github.com/vultisig/vultisig-sdk/pull/874) [`69bb830`](https://github.com/vultisig/vultisig-sdk/commit/69bb8307de72883f0c7693871a6ca040b7a0756c) Thanks [@neavra](https://github.com/neavra)! - fix(core-chain): treat duplicate-signature Solana broadcast errors as idempotent success

  `broadcastSolanaTx` now classifies "already been processed" / `AlreadyProcessed`
  rejections from `sendRawTransaction` as an idempotent success (returns instead
  of routing to `verifyBroadcastByHash`), mirroring the TON/UTXO/Cosmos dedupe
  guards. This stops a headless retry after an ambiguous broadcast from blindly
  re-submitting an already-accepted Solana transaction.

## 2.8.3

### Patch Changes

- [#880](https://github.com/vultisig/vultisig-sdk/pull/880) [`2ff65f3`](https://github.com/vultisig/vultisig-sdk/commit/2ff65f31bbbf64919c456e05dc6d274625127c2e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add a 20s default deadline to `queryUrl` (the shared HTTP helper behind
  prices/balances/swap quotes/broadcast/MPC-server calls). An unbounded `fetch`
  against a hung upstream previously wedged the caller forever — a stalled
  `/coingeicko` price proxy made `fiatToAmount -> execute_send` hang and
  perma-loaded the agent send card's "Network fee" row until the app's own 60s
  build-timeout fired. The deadline is implemented with a Hermes-compatible
  `AbortController` + `setTimeout` and only applies when the caller passes no
  `signal`; callers that supply their own `signal` keep owning cancellation. A
  new `timeoutMs` option lets callers override the default.

## 2.8.2

### Patch Changes

- [#764](https://github.com/vultisig/vultisig-sdk/pull/764) [`0dc1620`](https://github.com/vultisig/vultisig-sdk/commit/0dc16206bedcdde8832a068b15383565a6b98896) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add QBTC claim transaction helper utilities for MLDSA claim signing.

## 2.8.0

### Minor Changes

- [#814](https://github.com/vultisig/vultisig-sdk/pull/814) [`c9a235b`](https://github.com/vultisig/vultisig-sdk/commit/c9a235b959c7c82cd189482fab86ce3d27ddb4ff) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.balance.evm` (`getEvmBalances`): a multi-token EVM balance read (native coin + any number of ERC-20s) via RPC, with per-token on-chain `decimals`/`symbol` resolution and raw base-unit + human-readable output.

- [#831](https://github.com/vultisig/vultisig-sdk/pull/831) [`9585b6f`](https://github.com/vultisig/vultisig-sdk/commit/9585b6f246de3ce537eae201f0d660fc89ff1012) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.bridge.cctp` — Circle CCTP USDC bridge + claim calldata builders.

  `buildCctpBridge()` returns an unsigned 2-tx approve+depositForBurn sequence for bridging USDC cross-chain (Ethereum, Avalanche, Optimism, Arbitrum, Base, Polygon). `buildCctpClaim()` returns the unsigned `receiveMessage` mint tx for the destination chain. Pure crypto — builds unsigned calldata only, never signs or broadcasts. Includes a burn-address fund-safety guard on the bridge mintRecipient and a multiple-of-65-bytes attestation shape check on claim. Also exposes the CCTP contract registry (`cctpChains`, `getCctpChain`, `cctpSupportedChains`) and Circle attestation API base. Ports `build_cctp_bridge_usdc` / `build_cctp_claim_usdc` out of mcp-ts into the SDK.

- [#861](https://github.com/vultisig/vultisig-sdk/pull/861) [`f82caf5`](https://github.com/vultisig/vultisig-sdk/commit/f82caf58532f58af9d62b0143c7466cabcd88b06) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - add `decodeFromToolResult`, `decodeCosmosTx`, `decodeEvmTx` and related types (`DecodeFromToolResultInput`, `AssetRef`, `ChainFamily`, `Envelope`, `EnvelopeKind`, `PolicyEnvelope`) to the public API

- [#833](https://github.com/vultisig/vultisig-sdk/pull/833) [`361ba58`](https://github.com/vultisig/vultisig-sdk/commit/361ba58f79f241c4c00e33785a66ec6987628d26) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - add `sdk.swap.skip` — Skip Go cross-chain route + unsigned-tx prep. Exposes `runSkipSwap`, `quoteSkipRoute`, `buildSkipAffiliates`, `skipChainIdToChainName`, `resolveLuncFloorUsd`, `SkipApiError`, `SKIP_AFFILIATE_ADDRESS_BY_CHAIN`, `DEFAULT_LUNC_NOTIONAL_FLOOR_USD` and the related types (`SkipSwapArgs`, `SkipSwapOutcome`, `SkipSwapSuccess`, `SkipSwapErrorEnvelope`, `SkipUnsignedMsg`, `SkipChainIdsToAffiliates`). Quotes a Skip route and builds the unsigned EVM/cosmos tx envelope for the caller's signing layer — never signs, never broadcasts. Also corrects the canonical dYdX cosmos chain id (`dydx-1` -> `dydx-mainnet-1`).

- [#829](https://github.com/vultisig/vultisig-sdk/pull/829) [`7625e0b`](https://github.com/vultisig/vultisig-sdk/commit/7625e0bf325c8957bc3e28270454fd54c5589e2f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.swap.acrossQuote` — a read-only Across bridge quote primitive (ported from the mcp-ts `get_across_quote` tool). Fetches a live Across `suggested-fees` quote, pins + verifies the origin/destination SpokePool deployments (fail-closed on upstream schema drift), checksums + validates inputs, and rejects burn-address recipients via the shared `assertSafeDestination` guard. Quote-only: never builds calldata, signs, or broadcasts. Exported as `acrossQuote`, `acrossSupportedChains`, and the `AcrossChain` / `AcrossQuote` / `AcrossQuoteParams` types.

- [#825](https://github.com/vultisig/vultisig-sdk/pull/825) [`2024a92`](https://github.com/vultisig/vultisig-sdk/commit/2024a92b44760e1ff2043b0e45b083edc131b16c) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.prep.trc20Transfer` (`prepareTrc20TransferFromKeys`): a pure-crypto,
  vault-free builder for an unsigned TRON TRC-20 token transfer. ABI-encodes
  `transfer(address,uint256)` with checksum-verified base58check address decoding
  and a uint256 range guard, returning an `UnsignedTrc20Transfer` descriptor (no
  signing, no RPC, no broadcast). Exported from the package barrel and the
  React Native entry so mcp-ts / agent-backend / Windows / Station can consume one
  reviewed TRC-20 calldata implementation.

## 2.7.0

### Minor Changes

- [#832](https://github.com/vultisig/vultisig-sdk/pull/832) [`dc43ea2`](https://github.com/vultisig/vultisig-sdk/commit/dc43ea2657915012032bf273c73ede44a183185b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(prep): add `sdk.prep.cosmosStaking` — pure-crypto unsigned msg-envelope builders for cosmos-sdk staking + distribution.

  New public surface `cosmosStaking.{delegate,undelegate,redelegate,withdraw}` (plus the named `buildDelegateMsg` / `buildUndelegateMsg` / `buildRedelegateMsg` / `buildWithdrawRewardsMsg` exports) builds the proto-`Any` (typeUrl + base64 protobuf value) for `MsgDelegate` / `MsgUndelegate` / `MsgBeginRedelegate` / `MsgWithdrawDelegatorReward`. Quotes/builds-unsigned only — never signs or broadcasts. Consolidates the proto-`Any` encoding that mcp-ts `build_cosmos_*` and the app previously re-derived independently into one SDK code path.

- [#844](https://github.com/vultisig/vultisig-sdk/pull/844) [`da59b7f`](https://github.com/vultisig/vultisig-sdk/commit/da59b7f8d7fdf48e26ab4a8617e5273d807b4e66) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.dex.quotes` — read-only on-chain DEX quote primitives:

  - `uniswapV2Quote` / `getAmountOut`: live factory → pair → reserves reads via
    `evmCall` + canonical constant-product math (997/1000 fee, bigint).
  - `balancerQuote`: canonical pool math via `@balancer-labs/balancer-maths`
    `Vault.swap()` over a caller-supplied pool state.

  Both are read-only (no calldata, no signing, no broadcast) and exported from
  the generic and React Native entry points.

- [#830](https://github.com/vultisig/vultisig-sdk/pull/830) [`4e733c4`](https://github.com/vultisig/vultisig-sdk/commit/4e733c44708e7b81efd0a9b29298c6a9deba5f51) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `dex.uniswap` namespace: read-only Uniswap V3 primitives — canonical
  BigInt tick math (`getSqrtRatioAtTick` and bidirectional tick ↔ sqrtPriceX96 ↔
  price with token-decimal adjustment, 18-sig-fig `formatPrice18`) and on-chain
  pool-info (`uniswapV3PoolInfo`: factory lookup or known-pool read of
  slot0/liquidity/token metadata via `evmCall`). No signing, no broadcast.

- [#820](https://github.com/vultisig/vultisig-sdk/pull/820) [`4541e6f`](https://github.com/vultisig/vultisig-sdk/commit/4541e6f9899a5c091b73830db1a2db7e739828de) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `evm.getTokenApprovals(chain, { owner })`: read-only enumeration of active
  ERC-20 approvals (spender allowances) for an address on any supported EVM chain.
  Scans `Approval(owner, spender, value)` logs (full-history "earliest" with a
  bounded recent-window fallback when an RPC rejects the unbounded range),
  de-dupes `(token, spender)` pairs, re-reads the CURRENT `allowance()` per pair so
  revoked/spent approvals drop out, resolves `symbol()` fail-soft, and flags
  `isUnlimited` for allowances >= 2^128. No signing, no broadcast. Ported from the
  mcp-ts `get_token_approvals` tool.

- [#841](https://github.com/vultisig/vultisig-sdk/pull/841) [`b5ca32d`](https://github.com/vultisig/vultisig-sdk/commit/b5ca32d5e53b85f07531c9303e4c33e2dd44de5d) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.gas.cosmos` — cosmos gas-fee primitives (`estimateCosmosSwapFeeLabel`,
  `getCosmosSwapGasLimit`, `COSMOS_SWAP_GAS_LIMIT`, `COSMOS_SWAP_FEE_LABEL_CHAINS`,
  re-exported `getCosmosGasLimit`). The swap fee label is sourced from the SDK's
  canonical `cosmosGasRecord` sign-time fee (single source of truth, identical to
  the mcp-ts `COSMOS_SEND_FEE_BASE_UNITS` labels), covering all 8 IBC-enabled
  cosmos chains. Exposed at the package index and the React Native entry point.

- [#854](https://github.com/vultisig/vultisig-sdk/pull/854) [`d1b19ed`](https://github.com/vultisig/vultisig-sdk/commit/d1b19ed39102b32f9eb5a51ef794226adb959022) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(sdk): add `sdk.defi.glif` — GLIF x ICN liquid-staking calldata builders

  Adds the first protocol under the new `sdk.defi.*` namespace:

  - `buildGlifStakeIcnt(...)` — unsigned `[approve?, deposit]` to stake ICNT and mint
    stICNT on Base (ERC-4626 `deposit(assets, receiver)`). The approve step is dropped
    when `currentAllowance >= amount`; the approve spender is pinned to the pool and the
    approved amount is bounded to the exact stake amount (never unlimited).
  - `buildGlifRedeemSticnt(...)` — unsigned `[redeem]` to redeem stICNT back to ICNT
    (`redeem(shares, receiver, owner)`, with `owner` always pinned to `from`).

  Both builders are pure / offline (no RPC), produce UNSIGNED calldata only, and are
  exported from the generic and React Native entry points. Pinned Base addresses are
  verified on-chain (`pool.asset() == ICNT`, `pool.symbol() == stICNT`).

- [#859](https://github.com/vultisig/vultisig-sdk/pull/859) [`4f17411`](https://github.com/vultisig/vultisig-sdk/commit/4f17411ea8d739db706631cf873c85df4d329a0f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.defi.osmosis` — unsigned Osmosis Cosmos message builders (GAMM
  join/exit/swap, Concentrated-Liquidity create/withdraw/collect, Superfluid
  delegate/undelegate). Builds proto3-encoded unsigned messages only; never signs
  or broadcasts. Also re-exported on the React Native platform entry.

- [#842](https://github.com/vultisig/vultisig-sdk/pull/842) [`acfd6e4`](https://github.com/vultisig/vultisig-sdk/commit/acfd6e460e4ea27c7a7bcd668371ab1dea32c345) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.balance.polkadot(...)` — a pure-crypto, RN-safe Polkadot balance reader.

  - `balancePolkadot({ address })` returns the full native DOT `pallet_balances`
    breakdown (free / reserved / frozen / total / spendable + nonce), parsed from
    the raw SCALE `AccountInfo` blob via `state_getStorage` (no `@polkadot/api`).
  - `balancePolkadot({ address, assetId })` returns an Asset-Hub `pallet_assets`
    asset balance (raw u128 base units; USDT id=1984, USDC id=1337, …).
  - Hard SS58 prefix=0 + checksum + EVM-hex gate so a Bittensor / Kusama / typo'd
    address can't silently resolve to the wrong-account Polkadot balance.

  Exposed on both the generic entry and the React Native entry (the latter via a
  lazy dynamic import to keep `@polkadot/api` out of the eager RN bundle).

- [#821](https://github.com/vultisig/vultisig-sdk/pull/821) [`356e841`](https://github.com/vultisig/vultisig-sdk/commit/356e841c35cf38c2671309ae12720666f32745df) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.prep.cw20Transfer` (`buildCw20TransferMsg`): a pure-crypto builder for
  an UNSIGNED CosmWasm CW-20 token transfer `MsgExecuteContract` amino message.
  Validates recipient/contract/sender bech32 (HRP match, validator-key reject,
  20/32-byte payload), rejects native bank denoms and non-positive/non-integer
  amounts, and emits `{ transfer: { recipient, amount } }` ready to feed into
  `prepareSignAminoTxFromKeys`. Zero network I/O — never signs, never broadcasts.

- [#822](https://github.com/vultisig/vultisig-sdk/pull/822) [`a22ef41`](https://github.com/vultisig/vultisig-sdk/commit/a22ef4106763fd25992c7f93f72c214dfdcc55d4) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `prepareJettonTransferTxFromKeys` — a vault-free prep helper that builds an
  UNSIGNED TON Jetton (TEP-74) transfer from raw vault identity (public keys only,
  no key shares). Sibling of `prepareSendTxFromKeys` / `prepareSwapTxFromKeys`.
  Wraps the pure `@ton/core` cell builder: emits the `transfer` opcode
  (`0xf8a7ea5`), routes the internal message to the sender's Jetton wallet, sets
  `response_destination` to the sender (excess-TON refund), and returns
  `{signingHashHex, unsignedBocHex, fromAddress, finalize(sigHex)}`. Never signs,
  never broadcasts. Also exported from the React Native entry point.

- [#855](https://github.com/vultisig/vultisig-sdk/pull/855) [`c778b4c`](https://github.com/vultisig/vultisig-sdk/commit/c778b4cc91a42f4a4488a51ea72a775ad4e78a54) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - add `sdk.defi.river` Omni-CDP builders (open/close trove, delegate approval) for River/Satoshi Protocol

- [#810](https://github.com/vultisig/vultisig-sdk/pull/810) [`f0a5529`](https://github.com/vultisig/vultisig-sdk/commit/f0a5529a8d3cfcce5a2883b5da83e6d15ac270ec) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.amount.convert` conversion primitives: `convertAmount` /
  `toBaseUnits` / `toHumanUnits` (base-unit ↔ human-readable, precision-exact
  string math) and `fiatToCrypto` / `cryptoToFiat` (fiat ↔ crypto with the
  price supplied as an input), plus `AmountConvertError`. Folds the
  previously-duplicated mcp-ts `convert-amount` and Go validator scale-kernel
  impls into one canonical, vault-free SDK surface.

- [#840](https://github.com/vultisig/vultisig-sdk/pull/840) [`3bbe0fb`](https://github.com/vultisig/vultisig-sdk/commit/3bbe0fb011ec2f5502f321255f0304f06ea3e079) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(sdk): add `sdk.balance.cosmos` (`getCosmosBalance`) — a read-only Cosmos bank-denom balance primitive. Fetches `cosmos/bank/v1beta1/balances/<address>` over LCD (with a Polkachu fallback mirror), decimal-scales the native denom and known/curated denoms via BigInt (no precision loss), and resolves IBC vouchers with decimals pinned from a safe table — emitting unresolvable `ibc/`/`factory/` denoms in raw base units with a `(base units)` caveat so downstream pricing never mis-scales. Exposed from both the default and react-native entry points.

- [#843](https://github.com/vultisig/vultisig-sdk/pull/843) [`dac32f6`](https://github.com/vultisig/vultisig-sdk/commit/dac32f61fc5140b4c612801fc45ba48670dffe19) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(sdk): add `sdk.balance.<chain>` read-only balance fetchers for non-EVM /
  non-Cosmos chains (XRP, TRON, TON, Sui, Cardano, Bittensor/TAO) plus token
  variants (TRC-20, TON jetton, Sui token), ported from mcp-ts. Pure crypto —
  decode RPC responses, parse base units, format, validate address format.
  Read-only; nothing here signs or broadcasts.

- [#816](https://github.com/vultisig/vultisig-sdk/pull/816) [`ed75992`](https://github.com/vultisig/vultisig-sdk/commit/ed759929cd8612a6873f892d33da2857f18ad9f8) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.balance.solana` read-only helpers to the public surface: `getSolBalance(address)` (native SOL — exact u64 lamports via integer/BigInt math, no float corruption) and `getSplTokenBalance(address, mint)` (SPL / Token-2022 — auto-detects the token program, sums balances losslessly across all of the owner's token accounts for the mint). Both are pure RPC reads against the existing Solana proxy and are exported from the node and React Native entrypoints.

- [#836](https://github.com/vultisig/vultisig-sdk/pull/836) [`f4ba189`](https://github.com/vultisig/vultisig-sdk/commit/f4ba18958d351be48ed83c502895be251bacc47a) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.cosmos.gov`: `getCosmosGovernanceProposals` (read-only LCD fetch of governance proposals across IBC-enabled Cosmos chains, gov/v1 with v1beta1 fallback) and `prepareCosmosVote` (builds an unsigned `cosmos-sdk/MsgVote` envelope — validates the voter bech32/HRP, fetches account_number/sequence, fails closed on funded-but-unparseable accounts; never signs or broadcasts). Exported from the generic and React Native entry points.

- [#811](https://github.com/vultisig/vultisig-sdk/pull/811) [`8ed4b59`](https://github.com/vultisig/vultisig-sdk/commit/8ed4b59680e1285cc374fefba8cf1bd98347ef5e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(sdk): add `sdk.evm.encodeErc20Approve` + `encodeErc20Revoke`

  Two pure-crypto primitives under the EVM tools module:

  - `encodeErc20Approve(spender, amount)` — ABI-encodes `approve(spender, amount)`
    calldata (selector `0x095ea7b3`). No RPC, no `decimals()` lookup; the caller
    passes `amount` already in base units. `MAX_UINT256` is exported for the
    explicit unlimited-approval case — the API never silently defaults to
    unlimited (bounded-by-default). `spender` is normalized to its EIP-55
    checksum.
  - `encodeErc20Revoke(spender)` — `approve(spender, 0)`, the standard revoke
    pattern; works on non-standard tokens that don't implement `decimals()`.

  Both produce UNSIGNED calldata only, fail closed on a negative / out-of-range
  amount or a malformed spender, and are exported from the generic and React
  Native entry points.

- [#813](https://github.com/vultisig/vultisig-sdk/pull/813) [`5be6408`](https://github.com/vultisig/vultisig-sdk/commit/5be6408aa51e8c20568ff18c4cf604977c3004ec) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.gas.price` (`evmGasPrice`) — a read-only per-chain EVM gas-price primitive.
  Fetches the current `eth_gasPrice` for any supported EVM chain via the SDK's own
  per-chain viem client (no extra config, no external API) and returns
  `{ chain, gasPriceWei, gasPriceGwei }`. The exact value lives in the `gasPriceWei`
  `bigint` (never round-tripped through a JS number); `gasPriceGwei` is a display-only
  convenience rounded to 4 decimals, with a genuinely non-zero sub-floor price clamped
  UP to the smallest renderable value rather than collapsing to a misleading `0`. Fails
  closed: RPC errors propagate as a thrown error, never a fabricated `0` gas price.
  Also exposes the previously-internal `GasEstimationService` for vault-bound callers
  that need the richer chain-specific fee shape. Ported from the mcp-ts `get_gas_price`
  EVM branch (pure-crypto half only; the CoinGecko USD overlay stays an orchestration
  concern).

- [#817](https://github.com/vultisig/vultisig-sdk/pull/817) [`da4b301`](https://github.com/vultisig/vultisig-sdk/commit/da4b30119916a2a13d0e4e4f4472e4f28ed810c3) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.price.get` (`getPrice`) and `sdk.price.batch` (`getPricesBatch`) — token USD pricing via CoinGecko through the Vultisig proxy. Resolves a USD price (+ 24h change + market cap) across four read-only routes: explicit CoinGecko coin id, EVM contract + chain, Solana mint, or native ticker (via the ported `NATIVE_COINGECKO_IDS` map). Pure-crypto: never returns a fabricated price — a lookup failure throws. `getPricesBatch` fans out in parallel and isolates per-query failures (`{ ok: false, error }`) so one unpriceable token can't sink the batch, with results in input order. Also exports `isKnownNativePriceSymbol`, `symbolFromCoinGeckoId`, `coinGeckoIdToSymbol`, and the `NATIVE_COINGECKO_IDS` map. Ported from the mcp-ts `get_price` price-oracle.

- [#834](https://github.com/vultisig/vultisig-sdk/pull/834) [`7d79b2d`](https://github.com/vultisig/vultisig-sdk/commit/7d79b2d1307873937957b9c8caf1886f01d70190) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.swap.astroport` — `buildAstroportSwap` quotes (read-only `simulate_swap_operations`) and builds an unsigned Astroport router `wasm_execute` envelope for Terra v2 (phoenix-1) in-chain swaps. Pure-crypto: never signs or broadcasts. Ported from mcp-ts. Also exports the helpers `assembleAstroportSwap`, `classifyAstroportAsset`, `computeAstroportMinReceive` and the `ASTROPORT_ROUTER` / `TERRA_LCD` / `TERRA_CHAIN_ID` constants.

- [#819](https://github.com/vultisig/vultisig-sdk/pull/819) [`31eae40`](https://github.com/vultisig/vultisig-sdk/commit/31eae40e82516e192f11c80516b0da784aafe67b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.token.resolveContract` — on-chain token metadata probe (symbol /
  decimals / name) for a contract or mint address, for long-tail tokens that
  registry search misses. Supports ERC-20 (every EVM chain), CW20 (TerraClassic /
  Terra / Osmosis / Kujira) and SPL (Solana). Reads metadata directly over RPC and
  fails closed (never fabricates a symbol or decimals) when the address is not a
  recognized token contract / mint. `packages/sdk/src/**` is outside the bundled-
  changeset CI guard, so this changeset is added manually to publish the new
  surface to consumers.

- [#824](https://github.com/vultisig/vultisig-sdk/pull/824) [`60edbf4`](https://github.com/vultisig/vultisig-sdk/commit/60edbf43c4f8ab9928781adbd4e5d0f0fba6074c) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.prep.splTransfer` (`buildSplTransfer`): a pure-crypto, ATA-aware Solana SPL token-transfer instruction builder. Deterministically derives the sender + recipient Associated Token Accounts and builds an unsigned `transferChecked` instruction (legacy Token Program + Token-2022). Never signs and never broadcasts — the recent blockhash, recipient create-ATA, and signature stay on-device in `vault.sign`. Exported from the top level, `tools/prep`, and the React Native entry.

- [#818](https://github.com/vultisig/vultisig-sdk/pull/818) [`0e2e2ab`](https://github.com/vultisig/vultisig-sdk/commit/0e2e2abb3bf312df92131fb997dbaa0802f19c79) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(sdk): add `sdk.balance.utxo` — UTXO native balance reads

  New vault-free read primitive `getUtxoBalance(chain, address, options?)` for
  Bitcoin, Litecoin, Dogecoin, Bitcoin-Cash, and Dash via the Blockchair
  dashboards API (defaults to the Vultisig proxy). Returns base-unit satoshis
  (string, no float precision loss), a fixed-8-decimal human balance, and the
  chain ticker. Also exports `formatUtxoBalance` and `supportedUtxoBalanceChains`.

  Ported from mcp-ts `get_utxo_balance` (0 SDK imports) as part of the
  mcp-ts/backend -> SDK code-as-action consolidation.

- [#823](https://github.com/vultisig/vultisig-sdk/pull/823) [`b9a8cc1`](https://github.com/vultisig/vultisig-sdk/commit/b9a8cc19738333bb42f5d20c6bf849692fec4801) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.prep.utxoConsolidate` (`prepareUtxoConsolidateTxFromKeys`): a pure-crypto,
  vault-free prep builder that produces an UNSIGNED send-max-to-self UTXO consolidation
  `KeysignPayload`. Sweeps a caller-supplied set of UTXOs into a single output back to the
  same address (BTC / LTC / DOGE / BCH / DASH). No network IO, no signing, no broadcast —
  `vault.sign()` stays on-device.

- [#815](https://github.com/vultisig/vultisig-sdk/pull/815) [`f47f060`](https://github.com/vultisig/vultisig-sdk/commit/f47f0606223a0a1905ebb7745d311384488d4178) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.gas.utxoFeeRate(chain)` — a read-only UTXO fee-rate primitive
  returning `{ chain, feeRate, feeRateUnit: 'sat/vB' }` for Bitcoin, Litecoin,
  Dogecoin, Bitcoin-Cash (THORChain) and Dash (MayaChain). Sourced from the
  `inbound_addresses` `gas_rate`; throws on a halted chain or non-positive rate
  rather than emitting a zero-fee envelope. Zcash is intentionally unsupported
  (ZIP-317 conventional fees, not sat/vB). Also exported from the React Native
  entrypoint.

### Patch Changes

- [#866](https://github.com/vultisig/vultisig-sdk/pull/866) [`d4ba485`](https://github.com/vultisig/vultisig-sdk/commit/d4ba4854a358235a243d8f8bb2aed0680bbdbaea) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(sdk): defi follow-ups from merged-PR suggested changes

  Three fixes across the DeFi calldata builders:

  **sdk.defi.glif — BREAKING rename: `amount` -> `assetAmount` / `shareAmount`**
  - `BuildGlifStakeParams.amount` -> `assetAmount` (ICNT asset units)
  - `BuildGlifRedeemParams.amount` -> `shareAmount` (stICNT share units)
  - Result fields `BuildGlifStakeResult.amount` -> `assetAmount`, `BuildGlifRedeemResult.amount` -> `shareAmount`
  - Removes the ambiguity: stake inputs are ICNT (asset), redeem inputs are stICNT (shares)
  - Tests updated to match

  **sdk.defi.balancer — replace private-field reach-through with `ZERO_ADDRESS` sentinel**
  - `buildBalancerV3SwapCalldata` previously reached into private SDK internals via
    `(swap as unknown as { swap: { to: ... } }).swap.to` (always returned `undefined`)
  - Replaced with explicit `ZERO_ADDRESS` sentinel for the required-but-ignored
    `QueryOutputBase.to` field, matching the SDK's own documented intent
  - Added post-`buildCall` assertion: throws if the returned router address is zero or
    invalid, so a future SDK breakage surfaces immediately rather than silently
    producing calldata targeting the zero address

  **sdk.defi.arkis — re-throw transport errors from `resolvePoolKind`**
  - The bare `catch {}` previously swallowed ALL errors (transport timeouts, rate-limit
    errors, network outages) and mis-classified every pool as an Agreement
  - Now only swallows `ContractFunctionRevertedError` (the expected "no `asset()`"
    revert that signals a standard Agreement)
  - Transport and RPC errors are re-thrown so callers can retry

- [#870](https://github.com/vultisig/vultisig-sdk/pull/870) [`59e66c8`](https://github.com/vultisig/vultisig-sdk/commit/59e66c89858f90222a1d2d74eff9e71b69dd2f03) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Normalize native THORChain and MayaChain swap quote output amounts to destination coin base units before SDK quote formatting and near-zero validation.

## 2.6.0

### Minor Changes

- [#857](https://github.com/vultisig/vultisig-sdk/pull/857) [`fbc5581`](https://github.com/vultisig/vultisig-sdk/commit/fbc558151bc60c5240f6b6721dfd66a0ddec23c9) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.defi.balancer.buildBalancerV3SwapCalldata` — a pure, unsigned Balancer v3 swap calldata builder under the new `sdk.defi.*` surface. It thinly wraps `@balancer/sdk` (viem-only, RN-safe) to encode the v3 BatchRouter `swapExactIn`/`swapExactOut` tx from an off-chain SOR quote, with consumer-injectable `userData` (default `0x`). No signing, no broadcast.

- [#856](https://github.com/vultisig/vultisig-sdk/pull/856) [`ae45d06`](https://github.com/vultisig/vultisig-sdk/commit/ae45d068bc64f5b6d11b6c8a43c0cd5b21e0bb4e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(sdk): add `sdk.defi.pendle` — UNSIGNED Pendle PT (Principal Token) buy/sell/redeem builders wrapping the Pendle Hosted SDK Convert REST API. Router target is allow-listed to Pendle Router V4, market/PT/underlying are trust-but-verified against the live active-market catalog, and the prerequisite ERC20 approve calldata is hand-encoded with strict bounds. Builds calldata only — never signs, never broadcasts. First protocol under the new `sdk.defi.*` namespace.

- [#853](https://github.com/vultisig/vultisig-sdk/pull/853) [`a6ff6a4`](https://github.com/vultisig/vultisig-sdk/commit/a6ff6a49c2c0672af5c7afc06a7a97ac35e1cb10) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.defi.threeJane` — the first protocol under the new `sdk.defi.*` surface. Builds the unsigned 2-step Ethereum transaction sequence (ERC-20 approve + `Helper.deposit`) to supply USDC into 3Jane and mint the senior `USD3` or staked junior `sUSD3` share. Build-only / pure-crypto: returns unsigned calldata, performs no network IO, never signs or broadcasts. Also exported from the React Native entry point.

- [#858](https://github.com/vultisig/vultisig-sdk/pull/858) [`3043e1b`](https://github.com/vultisig/vultisig-sdk/commit/3043e1be5a869a83fb0946860b9e2d532eedf02f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add `sdk.defi.arkis` — a lender-side **supply** builder for the Arkis protocol on Ethereum. Builds the unsigned 2-step sequence (ERC-20 `approve` → ERC-4626 / Agreement `deposit`) and returns the decoded transactions. Builds UNSIGNED calldata only — never signs, never broadcasts. Also surfaces `resolveArkisPoolKind` (optional on-chain `asset()` probe) and `parseArkisTokenAmount` (exact string-math base-unit parse), exposed via the new `sdk.defi` getter.

## 2.5.1

### Patch Changes

- [#809](https://github.com/vultisig/vultisig-sdk/pull/809) [`e53230e`](https://github.com/vultisig/vultisig-sdk/commit/e53230efd2bb8a4e68f85f74c24655190af405d4) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Honor native swap quote expiry and validate THORChain inbound vault addresses before broadcasting stale signed swaps.

- [#808](https://github.com/vultisig/vultisig-sdk/pull/808) [`ab9cc91`](https://github.com/vultisig/vultisig-sdk/commit/ab9cc91c48588e9ecd96ec7eb50fd8138b88ba13) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Apply native THORChain/Maya swap slippage tolerance to quote requests and signed payload limits so native swaps no longer use a zero minimum-output floor.

## 2.5.0

### Patch Changes

- [#774](https://github.com/vultisig/vultisig-sdk/pull/774) [`0f350ff`](https://github.com/vultisig/vultisig-sdk/commit/0f350ff128a42764950e71b4c156907ec59a3c37) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - Add scanAddress method for Blockaid EVM address reputation scanning

- [#790](https://github.com/vultisig/vultisig-sdk/pull/790) [`6f53d2c`](https://github.com/vultisig/vultisig-sdk/commit/6f53d2cb3d1a56ff9377cc32c7c6f4e750fe8f21) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Align Dogecoin Blockchair fee estimation with the app clients by using 25% of the reported baseline.

- [#788](https://github.com/vultisig/vultisig-sdk/pull/788) [`b51902b`](https://github.com/vultisig/vultisig-sdk/commit/b51902bc08045e3977116565e430c1454d0ba607) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Make `getUrlBaseDomain` resolve the registrable (eTLD+1) domain using the Public Suffix List instead of taking the last two hostname labels. Sites under multi-label public suffixes (`*.vercel.app`, `*.github.io`, `*.pages.dev`, `*.web.app`, `*.co.uk`, …) now resolve to distinct domains, so a connection authorized for one site is no longer treated as authorized for an unrelated sibling under the same suffix.

- [#783](https://github.com/vultisig/vultisig-sdk/pull/783) [`dfd1cf3`](https://github.com/vultisig/vultisig-sdk/commit/dfd1cf3fdf9b650a2e70e8a72f751ef6e465bbbe) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expose the documented `@vultisig/sdk/electron/main` subpath in the published SDK package.

## 2.4.7

### Patch Changes

- [#785](https://github.com/vultisig/vultisig-sdk/pull/785) [`4097213`](https://github.com/vultisig/vultisig-sdk/commit/4097213ae0c35b668e54a4a9149968860849b349) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(ton): rebrand native token Toncoin (TON) → Gram (GRAM)

  The Open Network renamed its native token TON → GRAM (effective 2026-06-15).
  Update the display fields of `chainFeeCoin[Chain.Ton]`: `ticker` `TON` → `GRAM`
  and `logo` `ton` → `gram`. This is a cosmetic token rebrand only — the chain
  identity (`Chain.Ton`), `priceProviderId` (`the-open-network`), and `decimals`
  are unchanged, and there is no swap/migration. Patch-bumps `@vultisig/sdk` to
  rebundle.

## 2.4.6

### Patch Changes

- [#782](https://github.com/vultisig/vultisig-sdk/pull/782) [`9f9b0ec`](https://github.com/vultisig/vultisig-sdk/commit/9f9b0ecc66efbd003ed869a0ea7a2c29f85edef5) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(qbtc): set QBTC Cosmos SDK chain ID to `qbtc` (was `qbtc-testnet`)

  The SignDoc built by `QBTCHelper` now uses `qbtc` as the chain ID so signed
  transactions match the live QBTC chain. Patch-bumps `@vultisig/sdk` to rebundle.

## 2.4.5

### Patch Changes

- [#775](https://github.com/vultisig/vultisig-sdk/pull/775) [`fb6837b`](https://github.com/vultisig/vultisig-sdk/commit/fb6837b263c3c870f1a79e9c6011f27a1cc58f5d) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add the original transaction hash to SwapKit tracking URLs so tracker links prefill correctly.

- [#767](https://github.com/vultisig/vultisig-sdk/pull/767) [`ad14563`](https://github.com/vultisig/vultisig-sdk/commit/ad14563fb14358ff3efa96ed32e2304b8fc8d0ae) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(keysign): VULT staking (sVULT) keysign builders + generic EVM contract-call routing

  Adds `keysign/vultStaking/build` (depositFor with an optional VULT→sVULT approval
  prepended, requestUnstake, claim, cancelUnstake) for native VULT staking on
  Ethereum.

  Stake reuses the swap-with-approval flow: the payload coin is the VULT token so
  the EVM signing-input resolver can attach an `erc20ApprovePayload`, and the
  `depositFor` calldata is emitted as a generic contract call. The routing
  decision (token coin + zero `toAmount` + `0x` memo + no swap) is extracted into a
  shared `getIsGenericContractCall` predicate now consumed by the signing-input,
  fee-quote, and Blockaid simulation/validation resolvers so they all target the
  same on-chain call (fixes gas being estimated against — and Blockaid scanning —
  a synthetic ERC-20 transfer instead of the real `depositFor`). Patch-bumps
  `@vultisig/sdk` to rebundle.

- [#773](https://github.com/vultisig/vultisig-sdk/pull/773) [`ba1372e`](https://github.com/vultisig/vultisig-sdk/commit/ba1372e6cc76243e6c44114d706ae0b00c524e47) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Raise Zcash memo-send fees to the ZIP-317 conventional fee at plan time. WalletCore's `zip_0317` planner flat-sizes OP_RETURN and ignores `byteFee`, so memo sends planned one logical action short and were rejected by the network; the signing-input resolver now re-plans with `zip_0317` off and bumps `byteFee` until the fee clears.

## 2.4.4

### Patch Changes

- [#753](https://github.com/vultisig/vultisig-sdk/pull/753) [`e988851`](https://github.com/vultisig/vultisig-sdk/commit/e98885119f18078a0dde1f1ebdbca20f842c9325) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fail Cardano broadcasts before submission when the signed transaction TTL is expired or too close to expiry.

- [#754](https://github.com/vultisig/vultisig-sdk/pull/754) [`35c48e3`](https://github.com/vultisig/vultisig-sdk/commit/35c48e3eac615d62697c9052f43a9dab918b94dd) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Route UTXO and Cardano broadcast timeouts through transaction hash verification before treating them as landed.

## 2.4.3

### Patch Changes

- [#730](https://github.com/vultisig/vultisig-sdk/pull/730) [`a3859ab`](https://github.com/vultisig/vultisig-sdk/commit/a3859ab400ba02e05da73e23d57e3d261863d922) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Calculate Cardano send fees from WalletCore transaction body bytes instead of using a flat default.

- [#729](https://github.com/vultisig/vultisig-sdk/pull/729) [`2092472`](https://github.com/vultisig/vultisig-sdk/commit/209247266141f4fb8f299e87a257aa00c1a1f2e3) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add buffered EVM swap gas limits so failed gas estimation no longer falls back to the raw calldata floor.

## 2.4.2

### Patch Changes

- [#769](https://github.com/vultisig/vultisig-sdk/pull/769) [`406c261`](https://github.com/vultisig/vultisig-sdk/commit/406c261a702989fbdcdc3fde54b51c0b3eab8b62) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Handle the current Noon vault APY API shape when reading 7d net yield metrics.

## 2.4.1

### Patch Changes

- [#766](https://github.com/vultisig/vultisig-sdk/pull/766) [`f265fe0`](https://github.com/vultisig/vultisig-sdk/commit/f265fe0d33abda6b1157b248151217fc558f911c) Thanks [@realpaaao](https://github.com/realpaaao)! - fix(zcash): add trailing slash to branch-id RPC URL

  The live ZIP-243 branch-id fetch POSTs to a bare `${rootApiUrl}/zcash`, which the
  proxy now 301-redirects to `/zcash/`. Following a 301 downgrades POST→GET, so the
  request lands as `GET /zcash/` → HTTP 405, breaking all Zcash signing on the
  "Sign Transaction" screen. Add the trailing slash so the POST hits the working
  endpoint directly (live-verified 200 with consensus.nextblock).

## 2.4.0

### Minor Changes

- [#757](https://github.com/vultisig/vultisig-sdk/pull/757) [`0567316`](https://github.com/vultisig/vultisig-sdk/commit/056731699c9d1c9f16d9c9eb049e747c73f1c33d) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(swap): support an external recipient for native + CowSwap swaps

  `findSwapQuote` now accepts an optional `recipient` address. When set, the
  swapped output is routed to that address via the native THORChain/MayaChain
  memo `destination` and the CowSwap order `receiver`. Aggregators that would pay
  the swap initiator (1inch, KyberSwap, LiFi, SwapKit) are skipped for
  custom-recipient swaps so funds are never silently misrouted. When `recipient`
  is omitted, routing and payout are unchanged.

  Part of wiring the Advanced Swap settings (vultisig/vultisig-windows#4131);
  external recipient for the remaining aggregators is a follow-up.

- [#757](https://github.com/vultisig/vultisig-sdk/pull/757) [`3156d9f`](https://github.com/vultisig/vultisig-sdk/commit/3156d9fbe5116cb7d92e9e0033e036e1da1eb2fa) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(swap): support an explicit gas limit override for EVM swaps

  `buildSwapKeysignPayload` now accepts an optional `gasLimitOverride` (units).
  When set on an EVM swap it replaces the aggregator's estimated
  `ethereumSpecific.gasLimit` (and the mirrored 1inch `tx.gas`), while the gas
  price is still computed normally. Ignored for non-EVM chains and when omitted —
  no behavior change.

  Part of wiring the Advanced Swap settings (vultisig/vultisig-windows#4131).

- [#757](https://github.com/vultisig/vultisig-sdk/pull/757) [`e240dae`](https://github.com/vultisig/vultisig-sdk/commit/e240dae5df253b544e688c3e41d3037ec30fbdc0) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(swap): support a custom slippage tolerance in findSwapQuote

  `findSwapQuote` now accepts an optional `slippageTolerance` (in percent, e.g.
  `0.5` = 0.5%). It is forwarded to the general aggregators that accept a slippage
  override, each converted to that provider's native unit: 1inch and SwapKit
  (percent), KyberSwap (basis points), and LiFi (fraction). CowSwap (RFQ limit
  order) and the native THORChain/MayaChain protocols use their own protection
  and ignore it. When omitted, every provider keeps its existing default — no
  behavior change.

  Part of wiring the Advanced Swap settings (vultisig/vultisig-windows#4131).

### Patch Changes

- [#757](https://github.com/vultisig/vultisig-sdk/pull/757) [`a3dbf1b`](https://github.com/vultisig/vultisig-sdk/commit/a3dbf1b55f0e83cacdefbbee3532a01d8f7ba3af) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(swap): validate recipient and slippage overrides in findSwapQuote

  `findSwapQuote` now trims the optional `recipient` and treats empty/whitespace
  strings as no recipient, so a blank value no longer gates off initiator-paying
  aggregators or gets forwarded as a native `destination` / CowSwap `receiver`.
  It also rejects an invalid `slippageTolerance` (negative, `NaN`, or non-finite)
  up front with a `SwapError` instead of letting the bad value propagate into
  every provider call.

## 2.3.6

### Patch Changes

- [#711](https://github.com/vultisig/vultisig-sdk/pull/711) [`ea8afd2`](https://github.com/vultisig/vultisig-sdk/commit/ea8afd2d468380e1f5e36cae50ba9111c7b2c1bd) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Preflight THORChain native swap quotes against inbound halt flags before requesting a quote.

- [#763](https://github.com/vultisig/vultisig-sdk/pull/763) [`e5b07fb`](https://github.com/vultisig/vultisig-sdk/commit/e5b07fbfc09f55af64025950078050388e7b080d) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Populate THORChain custom Cosmos payload fees from SignAmino input fees.

## 2.3.5

### Patch Changes

- [#749](https://github.com/vultisig/vultisig-sdk/pull/749) [`343a921`](https://github.com/vultisig/vultisig-sdk/commit/343a9211d7f5af74753124146a72ebec343e5f2f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - cosmos/gas: bump TerraClassic staking gas limit from 2M to 3M and cap msgCount scaling

  `getCosmosStakingGasLimit` now returns 3M for `Chain.TerraClassic` regardless of `msgCount`. The previous 2M base caused consistent out-of-gas failures (`ValuePerByte` meter in the classic-terra treasury/tax post-handler adds ~200-800 gas beyond the standard SDK estimate). The msgCount scaling is disabled for TerraClassic: at `msgCount >= 2` the scaled gasWanted would exceed the 100 LUNC fee floor, causing node rejection. Columbus-5 callers must split multi-validator reward claims into separate transactions.

## 2.3.4

### Patch Changes

- [#738](https://github.com/vultisig/vultisig-sdk/pull/738) [`a335ca8`](https://github.com/vultisig/vultisig-sdk/commit/a335ca80e13da83c4ed5c2922f5ae845a4aea712) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add Noon sUSN Delta Neutral USDC yield vault helpers for Ethereum, including ERC-7540 calldata builders, USDC approval planning, on-chain read helpers, and Noon/Accountable APY plus TVL API clients exposed through the SDK boundary.

- [#710](https://github.com/vultisig/vultisig-sdk/pull/710) [`a54ac61`](https://github.com/vultisig/vultisig-sdk/commit/a54ac616f5aca39edd2515666ee895cfab0de242) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Default React Native Cosmos send fees to the chain fee denom when callers omit an explicit fee denom.

## 2.3.3

### Patch Changes

- [#748](https://github.com/vultisig/vultisig-sdk/pull/748) [`b544eea`](https://github.com/vultisig/vultisig-sdk/commit/b544eea2bd6f30aef59d6465d89784c763b13c11) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add canonical Circle USDC on Base (`0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`) to the known-token registry. It was the only major-EVM canonical USDC missing, so swaps to Base USDC resolved via the coingecko source and the app flagged the canonical stablecoin as "unverified token". Now it resolves as a known token (verified).

- [#740](https://github.com/vultisig/vultisig-sdk/pull/740) [`c78c10d`](https://github.com/vultisig/vultisig-sdk/commit/c78c10d2b43f9ddd13b2c912a71f7d902f2694cc) Thanks [@dependabot](https://github.com/apps/dependabot)! - chore(deps): migrate @lifi/sdk v3 -> v4

  @lifi/sdk v4 dropped the global mutable `createConfig` singleton in favour of
  an explicit client object that every action (`getQuote`, ...) takes as its
  first argument. Migrated `setupLifi` to build a v4 `createClient` and exposed
  it via `getLifiClient()`; `getLifiSwapQuote` (core + RN override) now calls
  `getQuote(client, params)`. Swap-quote behaviour, the per-call integrator tag,
  and the affiliate-fee surface are unchanged. v4 also dropped its
  `@solana/web3.js` transitive dep, so the now-dead `@lifi/sdk/@solana/web3.js`
  yarn resolution was removed.

- [#750](https://github.com/vultisig/vultisig-sdk/pull/750) [`0f6adc3`](https://github.com/vultisig/vultisig-sdk/commit/0f6adc3c73d06eb6da3758987dfaafb29d599019) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - security: bump transitive deps to fix 5 high-severity advisories

  - form-data: 4.0.5 -> 4.0.6 (CRLF injection, GHSA-hmw2-7cc7-3qxx)
  - protobufjs: 7.5.8 -> 7.6.4, 8.3.0 -> 8.6.3 (DoS via unbounded Any expansion, GHSA-wcpc-wj8m-hjx6)
  - tmp: 0.2.6 -> 0.2.7 (path traversal via type confusion, GHSA-7c78-jf6q-g5cm)
  - vite: 8.0.10 -> 8.0.16 (server.fs.deny bypass on Windows, GHSA-fx2h-pf6j-xcff)
  - ws: 7.5.10 -> 7.5.11, 8.17.1/8.20.x -> 8.21.0 (memory exhaustion DoS, GHSA-96hv-2xvq-fx4p)

  all bumped via yarn resolutions; no direct dep changes.

## 2.3.2

### Patch Changes

- [#718](https://github.com/vultisig/vultisig-sdk/pull/718) [`c67da04`](https://github.com/vultisig/vultisig-sdk/commit/c67da049ce35988e82771a1e981b0d84040310e3) Thanks [@realpaaao](https://github.com/realpaaao)! - Replace the dead Hyperliquid block explorer liquidscan.io with hypurrscan.io.

- [#735](https://github.com/vultisig/vultisig-sdk/pull/735) [`9d11951`](https://github.com/vultisig/vultisig-sdk/commit/9d1195121a99b05ac0d0bd6e359933aaf18dad34) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(cosmos): use polkachu for the Kujira LCD + RPC endpoints

  `kujira-rest.publicnode.com` and `kujira-rpc.publicnode.com` both now return
  HTTP 403 "unsupported platform" for our clients, breaking Kujira balance reads
  and tx broadcasts. Point `cosmosRpcUrl` and `tendermintRpcUrl` for Kujira at
  polkachu (the same provider Noble uses, and the one `getCosmosAccountInfo`
  already falls back to). Live-verified 200 with the real ukuji balance.

- [#734](https://github.com/vultisig/vultisig-sdk/pull/734) [`2208729`](https://github.com/vultisig/vultisig-sdk/commit/22087291dd2714fd3ebd086e2db80dbb3d2b41a3) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Reject a memo on Sui keysigns instead of silently dropping it. Sui has no native memo field (a transaction is a Programmable Transaction Block), so the Sui signing-input resolver now throws when `keysignPayload.memo` is set, surfacing the unsupported request to callers.

## 2.3.1

### Patch Changes

- [#702](https://github.com/vultisig/vultisig-sdk/pull/702) [`cb2e8f0`](https://github.com/vultisig/vultisig-sdk/commit/cb2e8f00861daff26ac8b04a34e22be9b243235c) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Fix TON jetton balances showing a stranger's holdings. Jetton wallet lookups
  queried the proxy with `owner_id` + `jetton_master_id`, which toncenter v3
  ignores (it filters on `owner_address` + `jetton_address`). The proxy then
  returned an unfiltered global list and the code took the first entry — a random
  wallet — so an address with no USDT reported ~200M USDT. Restore the correct
  params and filter the response by both owner and jetton master instead of
  trusting the first entry. This also keeps jetton transfers from resolving the
  wrong source wallet.

## 2.3.0

### Minor Changes

- [#724](https://github.com/vultisig/vultisig-sdk/pull/724) [`fcfd1f9`](https://github.com/vultisig/vultisig-sdk/commit/fcfd1f90550d8f62821167ea349b3e8ee2bf9d24) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - feat(custom-rpc): app-wide per-chain custom RPC endpoint overrides

  Add an in-memory override registry that the EVM and Cosmos URL resolvers consult, so a host app can point a supported chain at its own node. v1 covers the EVM chains and the IBC-enabled Cosmos chains; the override maps to the EVM RPC URL for EVM chains and to the LCD/REST endpoint for Cosmos (balance fallback, account info, fee). Includes `customRpcSupportedChains` as a single source of truth and an `rpcHealthProbe` (EVM `eth_chainId` identity check, Cosmos `node_info` liveness). Default behaviour is byte-identical when no override is set.

## 2.2.3

### Patch Changes

- [#708](https://github.com/vultisig/vultisig-sdk/pull/708) [`d4fa237`](https://github.com/vultisig/vultisig-sdk/commit/d4fa23796053f1a15fcce8b1fad5e9ccbbfbeb3d) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Mark unknown EVM and Cosmos transaction hashes as `isKnown: false` so broadcast verification rethrows real broadcast failures instead of treating unindexed hashes as known pending transactions.

## 2.2.2

### Patch Changes

- [#716](https://github.com/vultisig/vultisig-sdk/pull/716) [`3f622f6`](https://github.com/vultisig/vultisig-sdk/commit/3f622f631089d0e33eb879be3407401887ebf0c8) Thanks [@realpaaao](https://github.com/realpaaao)! - Add a canonical ZIP-317 conventional-fee module to core-chain and floor the Zcash send-builder fee at 5,000 zats per logical action, so low fee rates can no longer produce transactions the network rejects with "tx unpaid action limit exceeded".

## 2.2.1

### Patch Changes

- [#709](https://github.com/vultisig/vultisig-sdk/pull/709) [`de621f3`](https://github.com/vultisig/vultisig-sdk/commit/de621f3fd2a8c1ca64e73f6fe64afb7d77fb3e43) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Resolve Cosmos fee amounts from live node min gas prices when available, keeping the existing static amounts as safe floors.

- [#712](https://github.com/vultisig/vultisig-sdk/pull/712) [`9439a61`](https://github.com/vultisig/vultisig-sdk/commit/9439a6194abf3533ad06aa84847c81b2af7fe8df) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Filter Blockchair UTXO selection to confirmed spendable outputs and request an explicit address-info UTXO limit.

- [#714](https://github.com/vultisig/vultisig-sdk/pull/714) [`625fb42`](https://github.com/vultisig/vultisig-sdk/commit/625fb4205f265587f66f447b4059543756ef1095) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fetch the live Zcash ZIP-243 consensus branch ID for SDK signing and fail loudly instead of using a stale compiled fallback.

## 2.2.0

### Minor Changes

- [#705](https://github.com/vultisig/vultisig-sdk/pull/705) [`391e42d`](https://github.com/vultisig/vultisig-sdk/commit/391e42d020ea96407eb122de762234c9443392fc) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add a `SignSui` variant to `KeysignPayload.signData` so pre-built Sui Programmable Transaction Blocks (Sui Wallet Standard dApp signing) flow through the standard keysign pipeline instead of a custom-message path. `getSuiSigningInputs` forwards the BCS bytes verbatim via `signDirectMessage`, and `getSuiChainSpecific` returns an empty `SuiSpecific` for this variant (the coins, gas budget and reference gas price are already baked into the bytes, so no RPC lookup is needed).

## 2.1.0

### Minor Changes

- [#703](https://github.com/vultisig/vultisig-sdk/pull/703) [`3030c7a`](https://github.com/vultisig/vultisig-sdk/commit/3030c7a718947396de5d6b6de1b044640368aab5) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Expose chain-kind classification and Cosmos chain metadata from the SDK boundary so downstream consumers (mcp-ts, agent-backend) stop re-inventing per-chain tables (the cross-repo drift root cause):

  - `getChainKind`, `isChainOfKind`, `ChainKind` (re-exported from `@vultisig/core-chain/ChainKind`) - classify a chain by family (evm/utxo/cosmos/...).
  - `cosmosFeeCoinDenom`, `getCosmosGasLimit`, `getCosmosStakingGasLimit`, `cosmosRpcUrl` - Cosmos LCD/fee-denom/gas-limit metadata.

  Unblocks the mcp-ts chain-classification consolidation (retiring ~291 lines of re-invented classification + duplicated cosmos chain config).

## 2.0.0

### Patch Changes

- [#653](https://github.com/vultisig/vultisig-sdk/pull/653) [`dc75595`](https://github.com/vultisig/vultisig-sdk/commit/dc75595e83360f5bda84b2d91cae177bc7c8c966) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Re-enable Bittensor for seed-phrase import by removing it from `SEEDPHRASE_IMPORT_UNSUPPORTED_CHAINS`. The server-side curve misclassification that caused Bittensor imports to hang (vultiserver classified it as ECDSA and ran DKLS while clients run Schnorr) is fixed in vultiserver#157.

  ⚠️ **Deployment dependency:** this change depends on the server-side fix. vultiserver#157 must be deployed to **production** before consumers upgrade to this SDK. If the server fix is not live, enabling Bittensor seed-phrase imports will hang or fail, exactly as before. Do not consume this release until the server deploy is confirmed.

## 1.8.11

### Patch Changes

- [#686](https://github.com/vultisig/vultisig-sdk/pull/686) [`b900fcf`](https://github.com/vultisig/vultisig-sdk/commit/b900fcf95709da28ea7add1ea144d126c9fbcd98) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add QBTC support to the Cosmos staking signing path and LCD query layer. QBTC
  is a Cosmos-SDK chain (post-quantum testnet, ML-DSA-signed) but lives in
  `OtherChain`, so it sat outside the staking helpers' typing and LCD root
  resolution.

  - `QBTCHelper.buildTxComponents` now consumes a `signData.signDirect` payload
    verbatim — the `bodyBytes` / `authInfoBytes` already carry the ML-DSA pubkey
    `Any`, gas and fee, so the initiator and every co-signing peer rebuild an
    identical SignDoc hash. Previously it always rebuilt the body from
    `transactionType` (MsgSend / IBC / Vote), which silently turned a staking
    SignDoc into a `MsgSend`. `signAmino` is rejected (ML-DSA is
    SIGN_MODE_DIRECT only). The normal send path (no `signData`) is unchanged.
  - `chains/cosmos/staking/lcdQueries` exports a widened
    `StakingChain = IbcEnabledCosmosChain | Chain.QBTC` and resolves the LCD root
    through a helper that routes QBTC to `qbtcRestUrl` and every other staking
    chain to `cosmosRpcUrl[chain]`.

  Backward compatible: existing IBC-enabled staking chains route exactly as
  before.

## 1.8.10

### Patch Changes

- [#683](https://github.com/vultisig/vultisig-sdk/pull/683) [`4561129`](https://github.com/vultisig/vultisig-sdk/commit/45611297a55da72d3c56b1a2ffe6522da1b64d7b) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Update SDK package dependencies and Yarn tooling.

## 1.8.9

### Patch Changes

- [#678](https://github.com/vultisig/vultisig-sdk/pull/678) [`46d584f`](https://github.com/vultisig/vultisig-sdk/commit/46d584f5c62d0331e652811aaf8d2a3c4a436094) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Document Tron USDD and stUSDT token identity in the known-token registry.

## 1.8.8

### Patch Changes

- [#676](https://github.com/vultisig/vultisig-sdk/pull/676) [`7572dc0`](https://github.com/vultisig/vultisig-sdk/commit/7572dc0e7fa785453e36a419d678f8a1bf17c8b5) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add THORChain limit swap memo builder, validation helpers, and JSON test vectors.

## 1.8.7

### Patch Changes

- [#672](https://github.com/vultisig/vultisig-sdk/pull/672) [`7fa4860`](https://github.com/vultisig/vultisig-sdk/commit/7fa48602ba1acfb57746fd22c87ec3aa30bac4a6) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add Blockaid Sui transaction simulation support. The existing Sui Blockaid
  scan resolver only requested `validation`; this exposes the simulation block
  returned by the same `/sui/transaction/scan` endpoint via a new
  `getSuiTxBlockaidSimulation` resolver and a `parseBlockaidSuiSimulation`
  parser that produces a UI-facing `{ swap } | { transfer }` headline
  (mirroring the Solana shape). `OtherChain.Sui` is now a member of
  `blockaidSimulationSupportedChains`, with a new `getTxBlockaidSimulation`
  overload, and the mpc package gains a matching
  `getSuiBlockaidTxSimulationInput` for the `KeysignPayload`-driven flow.

  The parser keeps `null` as its failure mode rather than throwing — Blockaid
  field renames degrade to "no preview" instead of breaking consumers.

  Closes [#671](https://github.com/vultisig/vultisig-sdk/issues/671)

## 1.8.6

### Patch Changes

- [#651](https://github.com/vultisig/vultisig-sdk/pull/651) [`e9c4997`](https://github.com/vultisig/vultisig-sdk/commit/e9c4997bae3a499785295b76dbc956807cc704f5) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add Sui dApp signing helpers to `@vultisig/core-chain/chains/sui`. Two new
  public modules:
  - `./chains/sui/sign` exports `suiTransactionDataIntent` /
    `suiPersonalMessageIntent` (defensive clones of the 3-byte intent
    prefixes), `getSuiTransactionDataDigest(txBytes)` and
    `getSuiPersonalMessageDigest(messageBytes)` for the intent-prefixed
    blake2b-256 digests the wallet's Ed25519 signer signs, and
    `buildSuiSerializedSignature({ signature, publicKey })` for the 97-byte
    `flag(1) || sig(64) || pubkey(32)` Wallet Standard wire signature.
  - `./chains/sui/buildTransactionFromJson` exports
    `buildSuiTransactionFromJson({ transactionJson, sender })` which hydrates
    a serialized Sui `Transaction` (V1 or V2 JSON) and resolves it to BCS
    bytes via `Transaction.build({ client: getSuiClient() })`. Lets
    extension callers move the build step off the dApp page (where the dApp
    page's Content Security Policy blocks the Sui RPC) and into the
    extension's own context.

## 1.8.5

### Patch Changes

- [#655](https://github.com/vultisig/vultisig-sdk/pull/655) [`ef22e78`](https://github.com/vultisig/vultisig-sdk/commit/ef22e785ccb5d772bc144febb64dd394f3211799) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Publish the Fast Vault KeyImport fix from bundled core MPC code in the SDK package.

## 1.8.4

### Patch Changes

- [#649](https://github.com/vultisig/vultisig-sdk/pull/649) [`9271864`](https://github.com/vultisig/vultisig-sdk/commit/9271864c7cf1030b613f52b5564fc04d9309f069) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - Add custom token support for SUI. SUI is now included in
  `chainsWithTokenMetadataDiscovery`, and a new resolver fetches coin metadata
  (ticker, decimals, logo) from the SUI RPC via `suix_getCoinMetadata`. A new
  `isValidTokenId` helper validates token identifiers per chain — SUI tokens are
  validated as Move struct tags (e.g. `0x2::sui::SUI`) while all other chains keep
  delegating to `isValidAddress`.

## 1.8.3

### Patch Changes

- [#647](https://github.com/vultisig/vultisig-sdk/pull/647) [`55ed503`](https://github.com/vultisig/vultisig-sdk/commit/55ed503e103bdf8884c7ca7a8050742fb87d9e1f) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Enable WalletCore ZIP-317 fee planning for Zcash UTXO signing inputs.

## 1.8.2

### Patch Changes

- [#646](https://github.com/vultisig/vultisig-sdk/pull/646) [`72bbcd1`](https://github.com/vultisig/vultisig-sdk/commit/72bbcd17ee5327390c98784f861b7c6b8829cf2f) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Update the default Zcash consensus branch ID to NU6.2 (`30f33754`) for SDK UTXO signing and WalletCore signing inputs.

## 1.8.1

### Patch Changes

- [#617](https://github.com/vultisig/vultisig-sdk/pull/617) [`7145713`](https://github.com/vultisig/vultisig-sdk/commit/7145713992199f084d826f160cc20a4c445b14fb) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Select swap quotes with a 1% provider preference band instead of hard native priority.

- [#644](https://github.com/vultisig/vultisig-sdk/pull/644) [`2417949`](https://github.com/vultisig/vultisig-sdk/commit/24179490c1f80ca55b166a2a33e607574a140782) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix fiatToAmount throwing "EVM chains only" for Cosmos and other non-EVM token swaps. USD-denominated swap amounts now resolve correctly for TerraClassic (USTC/LUNC), Cosmos Hub (ATOM), Osmosis (IBC denoms), Solana SPL tokens, Polkadot asset-hub tokens, TON jettons, and any chain with entries in the knownTokens registry. Native Cosmos denoms (uluna, uatom, etc.) are also handled via cosmosFeeCoinDenom fallback.

## 1.8.0

### Minor Changes

- [#618](https://github.com/vultisig/vultisig-sdk/pull/618) [`ddf0bf4`](https://github.com/vultisig/vultisig-sdk/commit/ddf0bf44cc38905370f60246b88503954b3e3418) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(swap/lifi): consumer-supplied LI.FI integrator + apiUrl override

  Adds `SwapAffiliateConfig.lifi: LifiAffiliateConfig` so consumers (e.g. Station via `vultisig/mcp-ts`) can redirect LI.FI affiliate fees to their own portal integrator instead of the SDK-default `vultisig-0`.

  New surface:
  - `LifiAffiliateConfig` type — `{ integratorName: string; apiUrl?: string }`
  - `setupLifi(config?)` — global LI.FI SDK bootstrap; idempotent first-caller-wins. Consumers call this once at module boot to set both the global `integrator` and (optional) `apiUrl` proxy.
  - `getLifiSwapQuote` now accepts an optional `lifiAffiliateConfig` and uses its `integratorName` as the per-call `integrator` in `getQuote(...)`, overriding the global default for THIS quote without mutating the module-level `lifiConfig`.
  - `findSwapQuote` threads `affiliateConfig?.lifi` into `getLifiSwapQuote`.

  No behaviour change for callers that don't supply a `lifi` config — `getLifiSwapQuote` still routes through the existing `vultisig-0` default.

### Patch Changes

- [#631](https://github.com/vultisig/vultisig-sdk/pull/631) [`2ab9eb2`](https://github.com/vultisig/vultisig-sdk/commit/2ab9eb2ad5e2b180078389815f3158b5eb8e602b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat(cosmos): add optional `feeDenom` to `BuildCosmosSendOptions`

  Allows callers to specify a separate gas-fee coin denom when it differs from the send amount denom. Previously `buildCosmosSendTx` always used `denom` (the send coin) as the fee coin — on TerraClassic this meant USTC sends charged fees in USTC instead of LUNC, causing on-chain rejection when the USTC balance was below the fee threshold. Closes vultisig-sdk#624.

## 1.7.0

### Minor Changes

- [#610](https://github.com/vultisig/vultisig-sdk/pull/610) [`c87816b`](https://github.com/vultisig/vultisig-sdk/commit/c87816b6797e8237d7a94923025311e479e0c520) Thanks [@Ehsan-saradar](https://github.com/Ehsan-saradar)! - fix(swap): proactively detect below-minimum native swaps ([#604](https://github.com/vultisig/vultisig-sdk/issues/604))

  Small cross-chain swaps below the economic minimum (e.g. ETH→BTC ~$2.81) no longer surface a misleading generic "No swap route found" error. `findSwapQuote` now computes the THORChain minimum up front from the destination chain's `outbound_fee` and spot pool prices, and surfaces an actionable `AmountBelowMinimum` error with the concrete threshold ("Minimum is ~0.012 ETH. Please increase the amount.") instead of relying on brittle provider error-string matching.
  - New exported helper `getNativeSwapMinAmountIn` (and `NATIVE_SWAP_MIN_OUTBOUND_FEE_MULTIPLIER`) so consumers can show the minimum proactively as the user types.
  - The computed minimum is now `max(outbound-fee minimum, source dust threshold)` — THORChain rejects an input below the source chain's `dust_threshold` ("amount less than dust threshold") before economics apply (e.g. DOGE's ~1 DOGE floor), so the threshold is included alongside the outbound-fee economics. The result exposes `dustThresholdBaseUnit` and `binding: 'outbound' | 'dust'` for diagnostics.
  - Eager short-circuit only when a native protocol is the sole route family; multi-provider pairs still query every provider so an aggregator with a lower minimum is never blocked.
  - The generic all-fail path now logs raw provider error messages so future sub-minimum wordings become data-driven instead of guessed.
  - Trading-halt detection: when a native protocol rejects with "trading is halted" (THORChain mimir `HALT<CHAIN>TRADING`, pool ragnarok, churn) the pair fails for _every_ amount, so a new `TradingHalted` error surfaces "This swap route is temporarily unavailable — trading is halted on …" instead of the misleading generic "No swap route found" / "increase the amount".

## 1.6.0

### Minor Changes

- [#611](https://github.com/vultisig/vultisig-sdk/pull/611) [`9e405c9`](https://github.com/vultisig/vultisig-sdk/commit/9e405c9459713c5391ca6a85a548eb3750ec2872) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - ## New
  - Osmosis added to `AUTO_DISCOVERY_CHAINS` — IBC balance discovery is now active for Osmosis ([#611](https://github.com/vultisig/vultisig-sdk/issues/611))
  - Osmosis IBC token registry: ATOM (channel-0), USDC/Noble (channel-750), axlUSDC/Axelar (channel-208), stATOM (channel-326), stOSMO (channel-326), TIA/Celestia (channel-6994) — all hashes LCD-verified against osmosis-rest.publicnode.com and cross-referenced with cosmos/chain-registry ([#611](https://github.com/vultisig/vultisig-sdk/issues/611))

- [#606](https://github.com/vultisig/vultisig-sdk/pull/606) [`04cd9e3`](https://github.com/vultisig/vultisig-sdk/commit/04cd9e3881cb0e8cab5b1783be6e8d86970001d6) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Add optional `appId` to push device registration (`registerDevice`). Apps that
  share a vault with the regular wallet (e.g. Station, `money.terra.station`) can
  now register/unregister under their own bundle id, so the notification service
  routes their pushes to the correct app instead of the wallet that shares the
  vault. The field is optional and omitted by default, so existing wallet
  registrations are unchanged.

## 1.5.0

### Minor Changes

- [#585](https://github.com/vultisig/vultisig-sdk/pull/585) [`1bf8a6d`](https://github.com/vultisig/vultisig-sdk/commit/1bf8a6d36788b702092d92918294d67cdc6e11b7) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - Add `getSwapExplorerUrl` helper for swap-provider tx links ([#426](https://github.com/vultisig/vultisig-sdk/issues/426)).

  Tx history surfaces (vultisig-windows, vultiagent-app, future RN SDK) now have a single source of truth for "View on Explorer" URLs that point to the swap **provider's** scanner — `scan.li.fi`, `orb.helius.dev` for LI.FI Solana settlement, `runescan.io` for THORChain, and the MayaChain explorer — instead of every consumer reimplementing the routing and most defaulting to the source-chain explorer (which hides cross-chain routes from users).
  - New: `getSwapExplorerUrl({ provider, txHash, fromChain })` in `@vultisig/core-chain/swap/utils/getSwapExplorerUrl`
  - New: `Vultisig.getSwapExplorerUrl(provider, txHash, fromChain)` static method for parity with `getTxExplorerUrl`
  - For `1inch` / `kyber` / `swapkit`, falls back to the source-chain explorer (no public per-tx aggregator page)
  - Mirrors iOS `ExplorerLinkBuilder.swift` and Android `ExplorerLinkRepository.getSwapProgressLink`
  - Pure URL builder, no new deps

## 1.4.0

### Minor Changes

- [#584](https://github.com/vultisig/vultisig-sdk/pull/584) [`a13c644`](https://github.com/vultisig/vultisig-sdk/commit/a13c644be796a7bf10dc0ab426ac888b9e962585) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - ## New
  - Polkadot Asset Hub USDT (asset_id 1984) + USDC (asset_id 1337) token registry ([#562](https://github.com/vultisig/vultisig-sdk/issues/562))
  - Polkadot `pallet_assets.Account` balance resolver for Asset Hub tokens - replaces placeholder 0n guard ([#563](https://github.com/vultisig/vultisig-sdk/issues/563))
  - Tron native send `data` field (proto field 12) for THORChain memos + exchange deposit memos; `BuildTronSendOptions` and `BuildTrc20TransferOptions` gain optional `data?: Uint8Array` field ([#559](https://github.com/vultisig/vultisig-sdk/issues/559))

  ## Fixed
  - Tron TRC-20 fee estimate now subtracts sender's available energy before charging TRX ([#556](https://github.com/vultisig/vultisig-sdk/issues/556))
  - Tron native send free bandwidth check prevents spurious fee charge when bandwidth is available ([#555](https://github.com/vultisig/vultisig-sdk/issues/555))

### Patch Changes

- [#602](https://github.com/vultisig/vultisig-sdk/pull/602) [`5bb56a4`](https://github.com/vultisig/vultisig-sdk/commit/5bb56a4daba8b896626c54fabd94fd6c9a35320e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - `getCosmosAccountInfo` now retries against a registered fallback LCD when the primary endpoint fails. Without this, a single-provider degradation (e.g. `terra-classic-lcd.publicnode.com` outage on 2026-05-28) hard-failed every cosmos signing surface that touches this code path — there was no recovery.

  Fallback URLs per chain (Polkachu mirrors where available; Hexxagon for `TerraClassic` since polkachu has no Terra Classic endpoint, verified 2026-05-28). Chains not in the map preserve fail-closed behaviour.

  Parallel to vultiagent-app#1017 (app-side fix) + mcp-ts#266 (mcp-side fix).

- [#601](https://github.com/vultisig/vultisig-sdk/pull/601) [`3eb9b18`](https://github.com/vultisig/vultisig-sdk/commit/3eb9b186b0d021455cf47f957b15a45fcbb2798e) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - Republish the `@vultisig/sdk` bundle so consumers (mcp-ts, vultiagent-app) pick up the latest `@vultisig/core-chain` features that landed without an `@vultisig/sdk` changeset:
  - `resolveTokenPriceId(chain, denomOrAddress?)` helper for registry-driven token price resolution ([#587](https://github.com/vultisig/vultisig-sdk/pull/587))
  - LiFi stable-pair slippage tuning ([changeset](.changeset/lifi-stable-pair-slippage.md))
  - Plus any other pending `@vultisig/core-chain` minors that have been merged without a corresponding sdk-package changeset.

  Pure repackage — no consumer-facing API change; the bundle just embeds the latest core-chain dist.

- [#593](https://github.com/vultisig/vultisig-sdk/pull/593) [`5d11cf3`](https://github.com/vultisig/vultisig-sdk/commit/5d11cf3bfb81aba929fe8e81bb77e7aebff15129) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - refactor(swap): typed SwapError class with stable codes at findSwapQuote throw sites - enables instanceof checks instead of message string matching

## 1.3.1

### Patch Changes

- [#582](https://github.com/vultisig/vultisig-sdk/pull/582) [`47860fc`](https://github.com/vultisig/vultisig-sdk/commit/47860fcc6a1fa3600c20b529d29af98d56cbc5b4) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - ## Changed
  - Lower THORChain streaming-quote trigger threshold from 300 bps (3%) to 100 bps (1%) - more mid-size cross-chain trades now compare a streaming quote against the rapid quote and pick the better expected_amount_out. ([#470](https://github.com/vultisig/vultisig-sdk/issues/470))

## 1.3.0

### Minor Changes

- [#583](https://github.com/vultisig/vultisig-sdk/pull/583) [`f2270cd`](https://github.com/vultisig/vultisig-sdk/commit/f2270cd6aaa741d6800bd2d21e9775092be25d31) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - ## New
  - Polkadot Asset Hub USDT (asset_id 1984) + USDC (asset_id 1337) token registry ([#562](https://github.com/vultisig/vultisig-sdk/issues/562))
  - Polkadot `pallet_assets.Account` balance resolver for Asset Hub tokens - replaces placeholder 0n guard ([#563](https://github.com/vultisig/vultisig-sdk/issues/563))
  - Tron native send `data` field (proto field 12) for THORChain memos + exchange deposit memos; `BuildTronSendOptions` and `BuildTrc20TransferOptions` gain optional `data?: Uint8Array` field ([#559](https://github.com/vultisig/vultisig-sdk/issues/559))

  ## Fixed
  - Tron TRC-20 fee estimate now subtracts sender's available energy before charging TRX ([#556](https://github.com/vultisig/vultisig-sdk/issues/556))
  - Tron native send free bandwidth check prevents spurious fee charge when bandwidth is available ([#555](https://github.com/vultisig/vultisig-sdk/issues/555))

### Patch Changes

- [#594](https://github.com/vultisig/vultisig-sdk/pull/594) [`c1cca9a`](https://github.com/vultisig/vultisig-sdk/commit/c1cca9aa88acef2c0b31884154af2ed1e6b8ff92) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Publish the SDK bundle with the latest SwapKit Bitcoin PSBT signing path from `@vultisig/core-chain` and `@vultisig/core-mpc`.

## 1.2.1

### Patch Changes

- [#579](https://github.com/vultisig/vultisig-sdk/pull/579) [`c3881e5`](https://github.com/vultisig/vultisig-sdk/commit/c3881e549e5678e8806eba5defb2d2d6eefc2cc5) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - ## Fixed
  - Cosmos account info LCD fallback for extended account types that StargateClient cannot decode (vesting wrappers, module accounts) — prevents doomed txs with `sequence:0` that fail at broadcast with `account sequence mismatch, expected N, got 0` ([#579](https://github.com/vultisig/vultisig-sdk/issues/579))
  - Cosmos coin balance LCD fallback when StargateClient returns `amount:"0"` on a funded address — fixes a packaging-level discrepancy in cosmjs's HTTP layer under Hermes/React Native that silently surfaced as "you have 0" on funded Terra/TerraClassic wallets ([#579](https://github.com/vultisig/vultisig-sdk/issues/579))

## 1.2.0

### Minor Changes

- [#577](https://github.com/vultisig/vultisig-sdk/pull/577) [`cc9d67f`](https://github.com/vultisig/vultisig-sdk/commit/cc9d67f0c61d9ebdfc133beac5ef04658d37a37f) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - ## New
  - Polkadot Asset Hub USDT (asset_id 1984) + USDC (asset_id 1337) token registry ([#562](https://github.com/vultisig/vultisig-sdk/issues/562))
  - Polkadot `pallet_assets.Account` balance resolver for Asset Hub tokens - replaces placeholder 0n guard ([#563](https://github.com/vultisig/vultisig-sdk/issues/563))
  - Tron native send `data` field (proto field 12) for THORChain memos + exchange deposit memos; `BuildTronSendOptions` and `BuildTrc20TransferOptions` gain optional `data?: Uint8Array` field ([#559](https://github.com/vultisig/vultisig-sdk/issues/559))

  ## Fixed
  - Tron TRC-20 fee estimate now subtracts sender's available energy before charging TRX ([#556](https://github.com/vultisig/vultisig-sdk/issues/556))
  - Tron native send free bandwidth check prevents spurious fee charge when bandwidth is available ([#555](https://github.com/vultisig/vultisig-sdk/issues/555))

## 1.1.3

### Patch Changes

- [#544](https://github.com/vultisig/vultisig-sdk/pull/544) [`a0b7b6b`](https://github.com/vultisig/vultisig-sdk/commit/a0b7b6b440e0584f4436a81ddf983d0dd28b7a95) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Disable unsupported Bittensor seedphrase import and expose the SDK-owned seedphrase import chain support list.

## 1.1.2

### Patch Changes

- [#554](https://github.com/vultisig/vultisig-sdk/pull/554) [`bf7278c`](https://github.com/vultisig/vultisig-sdk/commit/bf7278c5886789c4a181169a36bc9296ef81b79c) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Emit the dedicated commondata SwapKit swap payload for source-chain transfer routes so QR cosigners can distinguish SwapKit swaps from OneInch-compatible swap payloads.

## 1.1.1

### Patch Changes

- [#512](https://github.com/vultisig/vultisig-sdk/pull/512) [`72eb200`](https://github.com/vultisig/vultisig-sdk/commit/72eb200ec647a707d1ebdc1f8b6f0f5243780477) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add Station Terra import primitives for legacy seed-byte, mnemonic, and raw private-key migration flows.

## 1.1.0

### Minor Changes

- [#515](https://github.com/vultisig/vultisig-sdk/pull/515) [`5ef62f1`](https://github.com/vultisig/vultisig-sdk/commit/5ef62f1aa20202f4a4eb97afa0cf20216dc5a1f1) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - Add `buildTronTxFromRawData(rawDataHex)` to sign yield.xyz Tron actions whose `raw_data` is already encoded upstream (FreezeBalanceV2, UnfreezeBalanceV2, VoteWitnessContract, …). Hashes the raw_data bytes with SHA-256, takes the MPC signature, and wraps the final `Transaction { raw_data, signature }` envelope — same `{signingHashHex, unsignedRawHex, finalize(sig)}` contract as `buildTronSendTx`. Includes strict hex-character validation so malformed input fails fast instead of silently producing a wrong signing payload.

## 1.0.0

### Major Changes

- [#537](https://github.com/vultisig/vultisig-sdk/pull/537) [`fa95600`](https://github.com/vultisig/vultisig-sdk/commit/fa95600887cb8ca603e8ddcb9c8558eff2d0ea6b) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - chore: remove Station affiliate constants from shared SDK (closes [#536](https://github.com/vultisig/vultisig-sdk/issues/536))

  Station-specific constants (`stvs` THORName, `0x649E...076D` EVM fee receiver) do not belong in a public package consumed by Windows and external users. The generic `affiliateConfig` injection seam on `findSwapQuote` + `SwapAffiliateConfig` type remain — those are correct SDK design. Station reconstructs the same three configs in its own consumer package (mcp-ts#201).

  **BREAKING CHANGE:** `stationKyberSwapAffiliateConfig`, `stationNativeSwapAffiliateConfig`, and `stationOneInchAffiliateConfig` are no longer exported from `@vultisig/sdk`. See MIGRATING.md for the reconstruction pattern.

  > **WARNING: DO NOT MERGE until vultisig/mcp-ts#201 lands.** Station must reconstruct these constants in its consumer package before this removal ships. Merging early will silently fall back to vultisig-0 affiliate defaults, breaking Station's affiliate fee routing on native swaps.

## 0.28.0

### Minor Changes

- [#530](https://github.com/vultisig/vultisig-sdk/pull/530) [`cb21dcf`](https://github.com/vultisig/vultisig-sdk/commit/cb21dcf127e8e08ceaca76439fa28d557cf0fed9) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - feat(seedphrase): probe Cosmos-coin-type Terra path (118) for Keplr/Leap seeds when standard 330-path is empty

## 0.27.0

### Minor Changes

- [#516](https://github.com/vultisig/vultisig-sdk/pull/516) [`9a80907`](https://github.com/vultisig/vultisig-sdk/commit/9a8090721008f2a10dffa9cf2d3fac479d65481c) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - Add `buildTonTxFromSigningPayload({publicKeyEd25519, signingPayloadBoc, includeStateInit, workchain})` to sign yield.xyz TON actions whose signing payload BoC is already constructed upstream. Parses the BoC, hashes the payload cell, takes the MPC signature, and wraps the final external message — same `{signingHashHex, unsignedBocHex, fromAddress, finalize(sig)}` contract as `buildTonSendTx`. Accepts either base64 or hex BoC input. Optional `includeStateInit` flag deploys the v4r2 wallet contract alongside the tx for first-send (seqno === 0) scenarios.

## 0.26.1

### Patch Changes

- [#525](https://github.com/vultisig/vultisig-sdk/pull/525) [`b0d0ba9`](https://github.com/vultisig/vultisig-sdk/commit/b0d0ba9d3ff0226149aca9a7446ff07a9eba84fc) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Enable SwapKit source routes for BTC, BCH, DOGE, LTC, XRP, ZEC, TRON, and TON by signing non-EVM SwapKit routes as source-chain transfers.

## 0.26.0

### Minor Changes

- [#507](https://github.com/vultisig/vultisig-sdk/pull/507) [`cb80440`](https://github.com/vultisig/vultisig-sdk/commit/cb804408b9607aacb143a7a941f0f9f1986f2379) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add SwapKit as a configurable general swap provider for EVM and Solana source routes.

## 0.25.0

### Minor Changes

- [#502](https://github.com/vultisig/vultisig-sdk/pull/502) [`c2fd086`](https://github.com/vultisig/vultisig-sdk/commit/c2fd08670ad67e9ec93443569f9b9b9aa5f9d685) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - feat(price): add `Vultisig.getCoinPricesWithChange` returning 24h % change

  `getCoinPrices` returns only `Record<string, number>` (spot price), so
  consumers that need the 24h change — e.g. a price widget's −3.97%
  indicator — had to keep a side-channel CoinGecko call, duplicating the
  SDK and risking drift.

  Adds a parallel, additive path:
  - `Vultisig.getCoinPricesWithChange(params)` →
    `Record<string, { price: number; change24h?: number }>`
  - core-chain `getCoinPricesWithChange` / `queryCoingeickoPricesWithChange`
    (requests `include_24hr_change=true`; `change24h` is omitted when
    CoinGecko has no datum for an id)
  - new public types `CoinPriceWithChange`, `CoinPricesWithChangeResult`

  Deliberately a **separate function**, not a flag on `getCoinPrices`:
  `getCoinPrices` / `CoinPricesResult` / `FiatValueService` /
  `fiatToAmount` / `getErc20Prices` are byte-for-byte unchanged — zero
  regression surface on the existing call sites. Price-only callers should
  keep using `getCoinPrices` (lighter payload, stable contract); reach for
  `getCoinPricesWithChange` only when the change is actually rendered.

  Lets vultiagent-app (and any other client) drop its hand-rolled
  `fetchPrices` 24h-change side-channel and source price+change from the
  SDK alone.

- [#503](https://github.com/vultisig/vultisig-sdk/pull/503) [`0c9f6d5`](https://github.com/vultisig/vultisig-sdk/commit/0c9f6d5139d4a096645a575505c7550c2b26bd2a) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - feat(tokens): add vault-free `Vultisig.discoverTokens({ chain, address })`

  On-chain token discovery (1inch for EVM, Jupiter for Solana, LCD for
  Cosmos) was only reachable as the instance method
  `vault.discoverTokens(chain)`. Callers that hold a derived address but
  no SDK `Vault` — the agent, a portfolio/dashboard screen, the
  agent-backend — couldn't use it without constructing a full vault.

  Adds a static, vault-free `Vultisig.discoverTokens({ chain, address })`
  returning `DiscoveredToken[]`. It is a thin wrapper over the
  already-vault-free `findCoins({ address, chain })` from
  `@vultisig/core-chain/coin/find` — the exact same call + mapping
  `vault.discoverTokens()` already does internally, minus the
  `getAddress` step. No new discovery logic, no behavioural change to the
  instance method, zero regression surface.

  Lets vultiagent-app discover the long tail of held tokens (beyond
  native + manually-added) on its existing vault-free balance path so the
  dashboard + agent see the same token set as a wallet would.

### Patch Changes

- [#498](https://github.com/vultisig/vultisig-sdk/pull/498) [`1667b79`](https://github.com/vultisig/vultisig-sdk/commit/1667b79fbc754e36032942fb5e749706dfc09bf3) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Enable Cosmos bank-balance token discovery for Terra and Terra Classic, including denom metadata decimals, IBC denom trace fallback, and hidden unknown denom metadata.

- [#505](https://github.com/vultisig/vultisig-sdk/pull/505) [`46274d7`](https://github.com/vultisig/vultisig-sdk/commit/46274d70fe19fb2f44bc90d9ec0cd4ac1994ae69) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - Export the vault-free Cosmos staking/distribution LCD queries
  (`getCosmosDelegations`, `getCosmosDelegatorRewards`,
  `getCosmosUnbondingDelegations`, `getCosmosVestingAccount`, the URL
  builders, and their types) from the React Native entry point. They
  were already in the generic entry but the hand-curated RN allow-list
  omitted them, forcing RN consumers (vultiagent-app) to hand-roll an
  LCD client for delegations/rewards. Additive only; signing primitives
  remain via `chains.cosmos.buildCosmosStakingTx`.

## 0.24.0

### Minor Changes

- [#463](https://github.com/vultisig/vultisig-sdk/pull/463) [`bd0daf9`](https://github.com/vultisig/vultisig-sdk/commit/bd0daf9a8156c9927643cba8c1af98a2a6d5da56) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - feat(address): `deriveAddressFromKeys` accepts optional `chainPublicKeys` map

  Callers holding pre-derived hardened per-chain pubkeys (e.g. from KeyImport vaults or the agent-backend's `VaultInfo.ChainPublicKeys`) can now pass them through directly, bypassing the non-hardened BIP32 fallback path that produces a different address. Bidirectional Terra ↔ TerraClassic alias is built-in (both share coin_type 330). Existing callers passing no `chainPublicKeys` are unaffected — the non-hardened path remains the default.

  Unlocks the Luna boundary fix (mcp-ts get_address + agent-backend VaultInfo + vultiagent-app agentContext) so the agent chat path resolves the same Terra/TerraClassic address the in-process wallet derives.

### Patch Changes

- [#474](https://github.com/vultisig/vultisig-sdk/pull/474) [`37c2f82`](https://github.com/vultisig/vultisig-sdk/commit/37c2f82379725ac4ac4d63679afea5c3ac1b7683) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Refresh vulnerable dependency paths for high-severity audit cleanup.

## 0.23.0

### Minor Changes

- [#464](https://github.com/vultisig/vultisig-sdk/pull/464) [`a6db82f`](https://github.com/vultisig/vultisig-sdk/commit/a6db82fd103ea8eea01a084cc8fbd787367db437) Thanks [@neavra](https://github.com/neavra)! - feat(sdk/vault): `signMsgDeposit` for THORChain/MayaChain LP add/remove; sdk-cli dispatches LP memos through it

  Adds `vault.signMsgDeposit({chain, amountBaseUnits, memo})` to `VaultBase`, building a `THORChainDeposit` cosmos message via the existing keysign pipeline (passes `isDeposit: true` through `getChainSpecific`). Memo is opaque pass-through — LP add (`+:POOL[:PAIRED]`), LP remove (`-:POOL:BPS[:ASSET]`), and any future deposit-style intent flow through the same surface.

  sdk-cli's `signNonEvmServerTx` now dispatches THORChain/MayaChain MsgDeposit envelopes by memo prefix: `=:` continues to route through `vault.swap` (Phase D), `+:` and `-:` route through the new `signThorMsgDepositLp` → `vault.signMsgDeposit`. Unsupported prefixes (LOAN, BOND, etc.) throw `NotImplemented` with the offending memo in the error message. Phase E in the envelope-parity progression; previously these memos threw at `parseThorSwapMemo`.

### Patch Changes

- [#459](https://github.com/vultisig/vultisig-sdk/pull/459) [`fde60dc`](https://github.com/vultisig/vultisig-sdk/commit/fde60dcc9f9822e21c2dbaeaacb9afb45cff0955) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Deduplicate vault flows, example adapters, and server mocks; set jscpd threshold to 0%. Add `VaultErrorCode.OperationAborted` and typed errors in shared test mocks.

## 0.22.7

### Patch Changes

- [#457](https://github.com/vultisig/vultisig-sdk/pull/457) [`680119e`](https://github.com/vultisig/vultisig-sdk/commit/680119e7392921b8aeaf859c85e811fb40a25054) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add regression tests and drift guards for Bitcoin PSBT compilation, ChainKind signing-input alignment, generated protobuf headers, and CLI agent action names aligned with AGENTS.md.

- [#456](https://github.com/vultisig/vultisig-sdk/pull/456) [`b36eb62`](https://github.com/vultisig/vultisig-sdk/commit/b36eb62842051b8b2bae06f1e123a5ebcf6cad88) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add Terra CW20 metadata resolution and build CW20 token sends as CosmWasm execute transfers.

## 0.22.6

### Patch Changes

- [#419](https://github.com/vultisig/vultisig-sdk/pull/419) [`e434998`](https://github.com/vultisig/vultisig-sdk/commit/e434998069e6af9664db045c5e91c5d5f35feef6) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Browser and Electron example vault UX after QA; secure vault join/create/import flows; MPC session and server coordination fixes.

## 0.22.5

### Patch Changes

- [#431](https://github.com/vultisig/vultisig-sdk/pull/431) [`1132ae5`](https://github.com/vultisig/vultisig-sdk/commit/1132ae51f8e4d5b8ca8a1855af9ea51031b574e9) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix cosmos denom resolver picking wrong segment for 3-part factory denoms

## 0.22.3

### Patch Changes

- [#405](https://github.com/vultisig/vultisig-sdk/pull/405) [`441f5bb`](https://github.com/vultisig/vultisig-sdk/commit/441f5bb9022321023a65d28a5941717ac7542bee) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix(ustc): dynamic burn-tax for TerraClassic USTC sends, case-insensitive coin id check

  Replaces the hardcoded 1,000,000 uusd fee surcharge with a live LCD `tax_rate` + optional `tax_cap` query for TerraClassic USTC (uusd) sends.
  - `computeUstcBurnTaxAmount()` fetches on-chain rate and cap, returns '0' when rate is zero (current post-UST-collapse governance state)
  - Fail-open on LCD outage: falls back to '0' so sends are never blocked when burn tax is zero; ante handler rejects if rate is non-zero and LCD is down
  - Case-insensitive `coin.id?.toLowerCase() === 'uusd'` guard to match `areEqualCoins` behavior
  - 5 unit tests covering: rate=0, rate=1.2%, rate+cap, LCD outage, LUNC non-USTC exclusion

## 0.22.2

### Patch Changes

- [#371](https://github.com/vultisig/vultisig-sdk/pull/371) [`b713743`](https://github.com/vultisig/vultisig-sdk/commit/b7137437547afc8189af207f210be57f50973dc7) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Install `globalThis.Buffer` before the browser SDK module graph evaluates (`preamble.ts`), align browser `polyfills` with `globalThis`, add explicit `buffer` imports across MPC modules that use `Buffer`, and depend on `buffer` from `@vultisig/core-mpc`. Harden the browser/electron examples: seedphrase import batching/progress and adapter flags, clipboard helper with bounded timeouts, QR/address copy feedback, and send-form amount validation with trimmed recipients.

- [#379](https://github.com/vultisig/vultisig-sdk/pull/379) [`ed6955f`](https://github.com/vultisig/vultisig-sdk/commit/ed6955fe6d218b3b13314db32f8d43c67a41fb48) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Treat a second `WasmMpcEngine` `configureMpc` registration as a no-op when bundlers evaluate the platform entry in multiple chunks (Chrome extension / Vite), preventing dev-time throws and broken signing.

- Updated dependencies [[`ed6955f`](https://github.com/vultisig/vultisig-sdk/commit/ed6955fe6d218b3b13314db32f8d43c67a41fb48)]:
  - @vultisig/mpc-types@0.2.3

## 0.22.1

### Patch Changes

- [#361](https://github.com/vultisig/vultisig-sdk/pull/361) [`a52980c`](https://github.com/vultisig/vultisig-sdk/commit/a52980c490633da7d7ae36128bc491f8ca3ff565) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Build shared workspace packages before bundling the SDK (`yarn build:sdk`). The browser example prepare step now rebuilds shared `dist` outputs when missing or stale, and shared utilities now import `Buffer` explicitly so browser apps do not crash during module evaluation.

- [#364](https://github.com/vultisig/vultisig-sdk/pull/364) [`d49b3e8`](https://github.com/vultisig/vultisig-sdk/commit/d49b3e82e153cf77282cbf06fdf72d9bb37cc836) Thanks [@premiumjibles](https://github.com/premiumjibles)! - `@vultisig/sdk`: re-export `getTxStatus` from `@vultisig/core-chain/tx/status` as a top-level standalone helper alongside `getCoinBalance` and `getPublicKey`. The dispatcher is stateless (`{ chain, hash }` → `TxStatusResult`) and was already compiled into every platform bundle, but was previously only reachable via the `vault.getTxStatus(...)` instance method on `VaultBase`. Vault-free callers (CLI, RN apps that store vault data outside `VaultManager`) can now poll receipts without instantiating an abstract `VaultBase` subclass purely to use a stateless lookup. `TxStatusResult` / `TxReceiptInfo` were already exported as types — this just adds the runtime function.

## 0.22.0

### Minor Changes

- [#293](https://github.com/vultisig/vultisig-sdk/pull/293) [`a3a331a`](https://github.com/vultisig/vultisig-sdk/commit/a3a331a875ebc6868b11c6901c8ed99dde51a4ff) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Password-protected vault backups use PBKDF2-HMAC-SHA256 with a random salt (600k iterations by default) and a versioned blob prefix; legacy SHA-256-only backups still decrypt.

### Patch Changes

- [#354](https://github.com/vultisig/vultisig-sdk/pull/354) [`feac01f`](https://github.com/vultisig/vultisig-sdk/commit/feac01f3225738a14c0123e1c3d70e46b97760fd) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fix the CommonJS export shape for the `@vultisig/sdk/vite` preset and harden browser Vite support so SDK wasm assets, Node globals, and local example builds resolve correctly in dev and production.

## 0.21.0

### Minor Changes

- [#350](https://github.com/vultisig/vultisig-sdk/pull/350) [`bad88d8`](https://github.com/vultisig/vultisig-sdk/commit/bad88d8d87229284c739995c027eb33d3ffc19e3) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat: cosmos-sdk staking module - generic Delegate/Undelegate/BeginRedelegate/WithdrawDelegatorReward + LCD queries

  Adds the cosmos-sdk staking + distribution module to the SDK, generic across every ibcEnabled cosmos chain we support (Cosmos Hub, Osmosis, Kujira, Terra, TerraClassic, Akash, Noble, Dydx).

  **Signing primitives** (`@vultisig/sdk` -> `chains.cosmos.buildCosmosStakingTx`):
  - `MsgDelegate`, `MsgUndelegate`, `MsgBeginRedelegate`, `MsgWithdrawDelegatorReward`
  - Hand-rolled RN-safe protobuf (no cosmjs runtime dep) mirroring the existing `buildCosmosWasmExecuteTx` pattern
  - Multi-msg batch txs supported (e.g. claim rewards from many validators in one tx)
  - Byte-for-byte round-trip verified against `cosmjs-types` canonical decoder

  **LCD query helpers** (`@vultisig/sdk` top-level + `@vultisig/core-chain/chains/cosmos/staking/lcdQueries`):
  - `getCosmosDelegations(chain, address)` -> per-validator balance + shares
  - `getCosmosUnbondingDelegations(chain, address)` -> pending unbondings with completion time
  - `getCosmosDelegatorRewards(chain, address)` -> per-validator rewards + total
  - `getCosmosVestingAccount(chain, address)` -> Periodic / Continuous / Delayed detection (returns null otherwise)

  ship-once, unlock-many: adding a future cosmos chain is a config-only change.

  34 new unit tests including 4 real cosmoshub fixtures captured from `cosmos1a8l3srqyk5krvzhkt7cyzy52yxcght6322w2qy`.

## 0.20.0

### Minor Changes

- [#310](https://github.com/vultisig/vultisig-sdk/pull/310) [`1d1c02c`](https://github.com/vultisig/vultisig-sdk/commit/1d1c02c37e58340b0617eec3a5e44909efc9b452) Thanks [@premiumjibles](https://github.com/premiumjibles)! - feat(sdk/rn): make React Native consumption ergonomic

  Two changes land together because both address making the RN build correctly consumable without the consumer having to hand-roll workarounds.
  1. **`./react-native` subpath export conditions**

  The `./react-native` subpath previously declared only `types` and `import`. Bundlers that prefer a `react-native` condition (Expo Metro on iOS/Android sets `unstable_conditionsByPlatform: { android: ['react-native'], ios: ['react-native'] }`) fall through the `./react-native` subpath when the SDK is resolved through a symlinked location (e.g. `npm install file:../vultisig-sdk/packages/sdk`, `pnpm add @vultisig/sdk@link:...`), producing `Unable to resolve "@vultisig/sdk/react-native"` at bundle time. Published-and-installed SDKs sidestepped the bug because the resolver cached a direct file path without re-walking conditions through the symlink. Mirror the conditions already present on the root `.` export so `./react-native` works identically in both linked and installed modes. 2. **New `./rn-preamble` side-effect subpath**

  Adds `@vultisig/sdk/rn-preamble` — a tiny side-effect module consumers import as the **first statement** in their RN app entry to install `globalThis.Buffer` and repair `Buffer.prototype.subarray` (RN's polyfill returns a plain `Uint8Array`, which breaks `.copy()` on downstream consumers like `@ton/core`). Previously consumers had to hand-write these polyfills, and getting the import order wrong crashed Hermes at boot with `Property 'Buffer' doesn't exist` — before the SDK's own RN entry could install its polyfill, because Metro hoists `require()` calls and transitive chain-lib module bodies evaluate before the SDK entry's statements run. The preamble is designed specifically to be the first `require` Metro hoists, so its body completes before anything else imports.

  Consumer usage:

  ```ts
  // index.ts (RN app entry — must be the first line)
  import "@vultisig/sdk/rn-preamble";

  // ...all other imports follow
  ```

  Additive: no existing export or subpath is changed; consumers who don't use the preamble are unaffected.

## 0.19.1

### Patch Changes

- Updated dependencies [[`e3fa32b`](https://github.com/vultisig/vultisig-sdk/commit/e3fa32b9f29e3a07880ecba117cf40e6dd396a4b)]:
  - @vultisig/mpc-types@0.2.2

## 0.19.0

### Minor Changes

- [#306](https://github.com/vultisig/vultisig-sdk/pull/306) [`c5f9c7b`](https://github.com/vultisig/vultisig-sdk/commit/c5f9c7bcac80d30f0b5e086c9e6860eaa0cf79a9) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - Add a React Native platform entry for @vultisig/sdk — new subpath export `@vultisig/sdk/react-native`, Hermes-safe tx builders + RPC helpers for 9 chains (EVM, Solana, Cosmos, Sui, TON, Tron, Ripple, UTXO, Cardano), `fastVaultSign` + relay orchestrators, and `configureRuntime` for consumer-injected endpoints. No breaking change for browser / node / electron / chrome-extension / vite consumers — all core chain/swap/balance helpers keep their original sync signatures; RN-only lazy loading is isolated in `packages/sdk/src/platforms/react-native/overrides/` and applied via rollup path-based intercept on the RN build target only. Bumped to `minor` per "new public API surface = minor" semver convention so consumers' `^0.x` ranges accept this only after they opt in.

  **Signature-meaningful fund-safety fixes (applied in R2 + R4 review rounds):**
  - `buildUtxoSendTx().finalize()` now returns a BIP141-compliant **txid** (computed from the witness-stripped base tx) for P2WPKH chains. Previously returned the wtxid, which is unusable for block-explorer / mempool lookups. Callers that persisted the old `txHashHex` for segwit chains (BTC, LTC) were recording the wrong hash.
  - `fastVaultSign` now throws if the MPC engine returns an ECDSA signature without a `recovery_id` (previously silently wrote `v=0`, producing a tx that recovers the wrong EVM signer).
  - `configureRuntime` now validates `vultiServerUrl` / `relayUrl` as http(s) URLs (previously accepted any string including `''`, silently exposing vault passwords to misconfigured endpoints).
  - `ReactNativeStorage.clear()` now calls `AsyncStorage.multiRemove` (was `removeMany`, which does not exist on `^2.x` — the shipped-consumer version — and threw at runtime on every `clear()` call).
  - BCH CashAddr decoder now verifies the polymod checksum before stripping it (previously accepted any typo'd address with valid base32 chars, producing a garbage pubKeyHash and signing the tx to an unrelated address).
  - Ripple `account_info` for unfunded accounts now returns `funded: false` instead of throwing on XRPL's `actNotFound` response.
  - Zcash sighash `branchId` is now a per-call parameter (defaulting to NU6.1) so future consensus upgrades don't require a shipped SDK release.
  - XRP `buildXrpSendTx().finalize()` now accepts both 128-char (`r||s`) and 130-char (`r||s||recovery_id`) hex signatures — `fastVaultSign` returns the 130-char shape for ECDSA, so every `build_xrp_send → fastVaultSign → finalize` flow previously threw at submit time.
  - UTXO base58 decoder now identifies P2SH addresses by version byte (`0x05` BTC, `0x32` LTC, `0x16` DOGE, `0x10` DASH, Zcash `t3...`) and emits the `OP_HASH160 <hash> OP_EQUAL` locking script; previously every base58 destination was re-encoded as P2PKH, so funds sent to a `3...` exchange deposit were locked under a hash that matched no spendable key.
  - Blockchair URL helpers (`getUtxos`, `getUtxoBalance`, `estimateUtxoFee`, `broadcastUtxoTx`) now respect the documented contract that `apiUrl` is already chain-scoped — previously they appended the slug a second time, producing `/blockchair/bitcoin/bitcoin/...` and 404s on every Blockchair-backed UTXO call.
  - `configureMpc` duplicate-engine guard now also reads `EXPO_PUBLIC_VULTISIG_STRICT_SINGLETON` as a fallback so Expo / React Native consumers can opt out of the dev throw without a custom Babel transform (Expo only inlines `EXPO_PUBLIC_*` env vars into the JS bundle). `VULTISIG_STRICT_SINGLETON` still wins when both are set.

## 0.18.0

### Minor Changes

- [#326](https://github.com/vultisig/vultisig-sdk/pull/326) [`f52057b`](https://github.com/vultisig/vultisig-sdk/commit/f52057b4af859018d1c180fa6db9ce15e153409f) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Expand `@vultisig/sdk/vite` into a browser preset: wasm plugin, polyfill shim resolution, `optimizeDeps` tuning, and serve/emit `7zz.wasm` at `/7zz.wasm` without writing into consumers' `public/` folders. Update docs and the browser example.

### Patch Changes

- [#307](https://github.com/vultisig/vultisig-sdk/pull/307) [`2018787`](https://github.com/vultisig/vultisig-sdk/commit/2018787f8101ea9a98e975c0e7477245c3f86fad) Thanks [@premiumjibles](https://github.com/premiumjibles)! - fix(sdk/vault): wrap invalid-receiver error in VaultError

  `getMaxSendAmount` now throws `VaultError(InvalidConfig)` instead of a generic `Error` when the receiver address fails validation. Matches how the rest of `VaultBase`'s address validation surfaces errors, so consumers checking `error.code` or `instanceof VaultError` catch it correctly.

## 0.17.1

### Patch Changes

- Updated dependencies [[`54731db`](https://github.com/vultisig/vultisig-sdk/commit/54731dbc0ded30adc7f76bbc5e3e532ef9414bb2)]:
  - @vultisig/mpc-types@0.2.1

## 0.17.0

### Minor Changes

- [#284](https://github.com/vultisig/vultisig-sdk/pull/284) [`219cb00`](https://github.com/vultisig/vultisig-sdk/commit/219cb00898deeaac418945a89c1d243f25aae152) Thanks [@premiumjibles](https://github.com/premiumjibles)! - feat(sdk): vault-free prep surface + LLM/agent utilities + token-resolution primitives
  - Vault-free `prepare*FromKeys` helpers that build unsigned `KeysignPayload`s from a `VaultIdentity` (raw public keys + identity metadata, no key shares): `prepareSendTxFromKeys`, `prepareSwapTxFromKeys`, `prepareContractCallTxFromKeys`, `prepareSignAminoTxFromKeys`, `prepareSignDirectTxFromKeys`, `getMaxSendAmountFromKeys`. Atomic chain helpers `getCoinBalance` and `getPublicKey` are also re-exported. `VaultBase`, `TransactionBuilder`, and `SwapService` delegate to these internally.
  - LLM/agent utilities: `fiatToAmount` + `FiatToAmountError`, `normalizeChain` + `UnknownChainError`.
  - Token-resolution primitives: `chainFeeCoin`, `knownTokens`, `knownTokensIndex`, `getTokenMetadata`, `getNativeSwapDecimals`, and supporting types `Coin`, `CoinKey`, `CoinMetadata`, `KnownCoin`, `KnownCoinMetadata`, `TokenMetadataResolver`, `VaultIdentity`.

## 0.16.0

### Minor Changes

- [#204](https://github.com/vultisig/vultisig-sdk/pull/204) [`0388700`](https://github.com/vultisig/vultisig-sdk/commit/03887009b7579fc0b193d068d4a205cdd3b7c214) Thanks [@premiumjibles](https://github.com/premiumjibles)! - feat(cli): agent-friendly CLI + new @vultisig/mcp package

  ## @vultisig/cli
  - Auto-TTY JSON output (`--output`, `--ci`, `--quiet`, `--fields`, `--non-interactive`)
  - Versioned `{ success, v: 1, data }` envelope and typed error envelope with exit codes 0-7
  - Safety: fixed `swap`/`send`/`execute`/`rujira swap`/`rujira withdraw` auto-executing in JSON mode; `--yes` now required uniformly
  - `--dry-run` coverage across all mutating commands
  - `vsig schema` machine-readable command introspection
  - Auth: replaced `keytar` with `@napi-rs/keyring`, encrypted-file fallback for headless environments (AES-256-GCM + async scrypt)

  ## @vultisig/client-shared (new package)

  Shared client infrastructure for `@vultisig/cli` and `@vultisig/mcp`: auth setup, config store, credential store (keyring + file fallback), tool descriptions, vault discovery.

  ## @vultisig/sdk
  - `VaultBase.send()` and `VaultBase.swap()` accept `amount: 'max'`
  - `SwapService` rejects quotes with near-zero output to guard against bad provider routes
  - `FiatValueService.fetchTokenPrice` returns `0` for non-EVM chains instead of throwing (effective behavior identical — `getPortfolioValue` already caught the throw)
  - `ServerManager`: removed stdout `console.log` calls that corrupted JSON output; raised `waitForPeers` timeout from 30s to 120s and tightened poll interval from 2s to 500ms

  ## @vultisig/core-chain
  - Narrowed EVM broadcast retry list to strings that genuinely indicate "same tx already in mempool under this hash" (`already known`, `transaction already exists`, `tx already in mempool`). Dropped strings that can silently swallow real broadcast failures (`nonce too low`, `transaction is temporarily banned`, `future transaction tries to replace pending`, `could not replace existing tx`)

  ## @vultisig/core-mpc
  - `maxInboundWaitTime` raised from 1 to 3 minutes for flaky networks
  - Added 100ms sleep in `processInbound` recursion to prevent hot-looping on empty inbound
  - Setup message polling: same 10-second budget, polls 5× more often (50 × 200ms vs 10 × 1000ms)

- [#290](https://github.com/vultisig/vultisig-sdk/pull/290) [`83fe4c3`](https://github.com/vultisig/vultisig-sdk/commit/83fe4c3c58637aea4823d0eaa7f21d4c5cdf3dc7) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add `@vultisig/sdk/vite` helper plugin so Vite consumers exclude wasm glue packages from `optimizeDeps`, and harden dist ESM relative import rewriting with tests.

## 0.15.5

### Patch Changes

- [`78772fd`](https://github.com/vultisig/vultisig-sdk/commit/78772fd061f3061c54802506218e5524a21714bd) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fix MPC engine singleton so direct `@vultisig/core-mpc` / `@vultisig/mpc-types` / `@vultisig/mpc-wasm` imports register correctly across bundler chunks and Vite `optimizeDeps` scenarios.
  - Runtime singletons (MPC engine, WASM WalletCore getter, default storage factory, platform crypto) now live in a `globalThis`-anchored store keyed by `Symbol.for('vultisig.runtime.store.v1')`, eliminating duplicate-module-instance bugs.
  - `ensureMpcEngine()` added (async) — lazily registers the default `WasmMpcEngine` when no engine has been configured, so consumers that import only `@vultisig/core-mpc` no longer need to bootstrap the SDK.
  - `@vultisig/sdk` `sideEffects` narrowed from `false` to an allowlist of platform entry dist files, preventing tree-shakers from dropping the platform bootstrap.
  - `@vultisig/mpc-wasm` declared as an optional peer dependency of `@vultisig/mpc-types`.

  Closes [#287](https://github.com/vultisig/vultisig-sdk/issues/287).

- Updated dependencies [[`78772fd`](https://github.com/vultisig/vultisig-sdk/commit/78772fd061f3061c54802506218e5524a21714bd)]:
  - @vultisig/mpc-types@0.2.0
  - @vultisig/mpc-native@0.1.4

## 0.15.4

### Patch Changes

- [#276](https://github.com/vultisig/vultisig-sdk/pull/276) [`59382c1`](https://github.com/vultisig/vultisig-sdk/commit/59382c1859512fbd362962ede5e92b100d3a5921) Thanks [@rcoderdev](https://github.com/rcoderdev)! - feat(cli): structured machine-readable errors for agent ask, pipe, and executor
  - `agent ask --json` failures include stable `code` with existing `error` string
  - NDJSON pipe `error` events and failed `tool_result` lines include `code`
  - executor `ActionResult` failures carry `AgentErrorCode`; SSE errors accept optional backend `code`
  - document error codes in CLI README

## 0.15.3

### Patch Changes

- [#264](https://github.com/vultisig/vultisig-sdk/pull/264) [`69b23dc`](https://github.com/vultisig/vultisig-sdk/commit/69b23dca4b24c93c8bc2de51883a9b28e60485be) Thanks [@NeOMakinG](https://github.com/NeOMakinG)! - React Native platform entry now exports typed wrappers for `getPublicKey`, `deriveAddress`, `isValidAddress`, and `getCoinType` that accept `WalletCoreLike` from `@vultisig/walletcore-native` instead of `WalletCore` from `@trustwallet/wallet-core`. Consumers no longer need `as unknown as` casts at the SDK boundary. Also re-exports the `WalletCoreLike` type for convenience.

## 0.15.2

### Patch Changes

- [#263](https://github.com/vultisig/vultisig-sdk/pull/263) [`6585c38`](https://github.com/vultisig/vultisig-sdk/commit/6585c38431db063f600e133d1a23f84b7c19e934) Thanks [@rcoderdev](https://github.com/rcoderdev)! - fix(cli): align agent executor with backend payloads and harden action handling
  - model `tx_ready` / non-streaming transaction payloads with `TxReadyPayload`
  - optional `vultisig` on agent config for shared SDK state (e.g. address book)
  - executor improvements (chain locks, calldata resolution, EVM gas refresh) and unit tests

## 0.15.1

### Patch Changes

- Updated dependencies [[`91aa66a`](https://github.com/vultisig/vultisig-sdk/commit/91aa66a0c23576546895d0946b486ae37cf1b23d)]:
  - @vultisig/mpc-native@0.1.3

## 0.15.0

### Minor Changes

- [#235](https://github.com/vultisig/vultisig-sdk/pull/235) [`aea1c28`](https://github.com/vultisig/vultisig-sdk/commit/aea1c28051345ddef9c952108b203caa8b7fa032) Thanks [@rcoderdev](https://github.com/rcoderdev)! - ### Swap amounts (backward compatible)
  - `SwapQuoteParams.amount` and `SwapTxParams.amount` now accept **`string | number`**. Call sites that already pass a **number** require no code changes.
  - Human-readable swap amounts can be passed as **decimal strings** end-to-end (compound `vault.swap()`, `getSwapQuote`, `prepareSwapTx`, CLI agent), avoiding precision loss from `Number()` / `parseFloat()` on extreme magnitudes or fractional digits.
  - `toChainAmount` accepts **`string | number`**; whitespace-only / empty strings throw instead of being treated as zero.

  ### Send preparation (stricter validation)
  - `prepareSendTx` and `estimateSendFee` reject **zero or negative** `amount` in base units. This aligns with real transfers; payloads with `toAmount: "0"` are no longer built for native/token sends.
  - **Zero-value EVM contract calls** are unchanged: use `prepareContractCallTx` (or `vault.contractCall()`), which still builds via the internal path that allows `value: 0n`.

  ### Other
  - Swap approval sizing uses `toChainAmount` instead of float scaling for required allowance.
  - `@vultisig/rujira` (source): `VultisigSignature.format` includes **`MLDSA`** to match SDK `Signature` — type-only widening, no runtime change; Rujira will pick up a **patch** version via normal dependency releases when published next.
  - CLI: direct **`viem`** dependency; Solana local swap human amount via `formatUnits`; agent SSE `Transaction` typing includes optional `swap_tx` / `send_tx` / `tx`.

  **Semver:** **Minor** for `@vultisig/core-chain`, `@vultisig/core-mpc`, and `@vultisig/sdk` (additive types + intentional validation tightening). **`@vultisig/cli` is linked to the SDK** in Changesets config, so it receives the same minor bump. This is **not** a SemVer **major** for integration purposes: swap inputs are only widened; `prepareSendTx({ amount: 0n })` was never a valid broadcast path.

  **Release tooling note:** `yarn changeset status` may still propose a **major** version for `@vultisig/rujira` when the SDK minors, even though the only Rujira change is adding `'MLDSA'` to a string-literal union (fully backward compatible). Review the Version Packages PR and **downgrade Rujira to patch** if your policy is to reserve majors for real breaking API changes.

  **`@vultisig/sdk` is 0.x:** per [SemVer](https://semver.org/#spec-item-4), minor releases on `0.y.z` may include behavior changes; consumers pinning `^0.14.0` should still accept `0.15.0` but should read changelog for validation tightening.

### Patch Changes

- [#234](https://github.com/vultisig/vultisig-sdk/pull/234) [`9f71a0e`](https://github.com/vultisig/vultisig-sdk/commit/9f71a0e430aadcb96707448c5e5e077aa0b561e0) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add Vitest for the CLI package and run CLI tests from the root `yarn test` script. Unimplemented agent actions now return `success: false` with an error message instead of `success: true` with a `data.message` field.

## 0.14.3

### Patch Changes

- [#258](https://github.com/vultisig/vultisig-sdk/pull/258) [`0413dec`](https://github.com/vultisig/vultisig-sdk/commit/0413deccf249ecb284c5376a2a07e8ab12c47b48) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - fix: emit dedicated `dist/index.react-native.d.ts` from the react-native platform entry, and wire the `exports` field to resolve it under TypeScript's `react-native` custom condition — downstream consumers can now `import { keysign } from '@vultisig/sdk'` under Metro/Expo without hand-written module augmentations

- Updated dependencies [[`665cf03`](https://github.com/vultisig/vultisig-sdk/commit/665cf037951df40dc35068463c4ddd299cec20dd)]:
  - @vultisig/mpc-native@0.1.2

## 0.14.1

### Patch Changes

- Updated dependencies [[`0775049`](https://github.com/vultisig/vultisig-sdk/commit/07750496b7af1ece840501b8d884087e048c2b2c)]:
  - @vultisig/mpc-native@0.1.1

## 0.14.0

### Minor Changes

- [#222](https://github.com/vultisig/vultisig-sdk/pull/222) [`9e2ffd6`](https://github.com/vultisig/vultisig-sdk/commit/9e2ffd6f6a8e2c8ad507b6ed2e2c1232bf8a98c7) Thanks [@gomesalexandre](https://github.com/gomesalexandre)! - feat: add vault-free tools layer for MCP TypeScript rewrite

  New `tools/` module with vault-free chain utilities:
  - `abiEncode` / `abiDecode` - ABI encoding/decoding via viem
  - `evmCall` - read-only contract calls (eth_call)
  - `evmTxInfo` - nonce, gas prices, chainId
  - `evmCheckAllowance` - ERC-20 approval queries
  - `resolveEns` - ENS name resolution
  - `resolve4ByteSelector` - function signature lookup
  - `searchToken` - CoinGecko search with multi-chain deployment mapping
  - `deriveAddressFromKeys` - address derivation from raw ECDSA/EdDSA keys
  - `findSwapQuote` - multi-provider swap quotes (THORChain, MayaChain, 1inch, LiFi, KyberSwap)
  - `VerifierClient` - Vultisig Verifier REST API client

  Also fixes SUI token balance queries (was ignoring coinType for non-native tokens).

### Patch Changes

- [#210](https://github.com/vultisig/vultisig-sdk/pull/210) [`8bef556`](https://github.com/vultisig/vultisig-sdk/commit/8bef55651cba506a515083765d6f7745cce54abe) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Stop generating ML-DSA during secure vault creation, join, seedphrase import, and reshare. ECDSA and EdDSA only during the ceremony, matching mobile apps; ML-DSA remains available as a separate optional step.

- [#205](https://github.com/vultisig/vultisig-sdk/pull/205) [`99296f5`](https://github.com/vultisig/vultisig-sdk/commit/99296f5aaf3f9bfb7fe694de034037683e7435ed) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Classify vault import failures with specific `VaultImportErrorCode` values (`INVALID_FILE_FORMAT`, `INVALID_PASSWORD`, `UNSUPPORTED_FORMAT`, `CORRUPTED_DATA`) instead of wrapping most errors as `CORRUPTED_DATA`. Add unit tests for import edge cases.

## 0.13.0

### Minor Changes

- [#179](https://github.com/vultisig/vultisig-sdk/pull/179) [`84a2950`](https://github.com/vultisig/vultisig-sdk/commit/84a295002ed7310320b584fbccb76aaf4a233b31) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Add full QBTC (post-quantum Bitcoin) send support: MLDSA fast signing, address derivation, broadcast via Cosmos REST, funded e2e send test, and `scripts/add-mldsa-to-vault.ts` helper. Switch QBTC core resolvers from dead Tendermint RPC to vultisig Cosmos REST API.

### Patch Changes

- [#185](https://github.com/vultisig/vultisig-sdk/pull/185) [`3f46444`](https://github.com/vultisig/vultisig-sdk/commit/3f46444b2a11a41dbbb023919c2f168f9d15cff8) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Restore `publicKeyMldsa` and `keyShareMldsa` when hydrating fast and secure vaults from storage. Run the Vitest integration suite on every PR; keep the full agentic stack workflow manual-only.

## 0.12.0

### Minor Changes

- [#165](https://github.com/vultisig/vultisig-sdk/pull/165) [`4195641`](https://github.com/vultisig/vultisig-sdk/commit/4195641a9eb27d41fb27d2c6b605b34d4c4635b0) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fast vault creation (CLI and SDK) no longer runs ML-DSA keygen; VultiServer only adds ML-DSA via `POST /mldsa`. Use `Vultisig.addPostQuantumKeysToFastVault` / `FastVault.addPostQuantumKeys` or CLI `vultisig add-mldsa` when post-quantum keys are needed. TSS batching for fast vault create now requests `ecdsa` and `eddsa` only. `MldsaKeygen` default relay message ids match VultiServer classic keygen (empty string); batch flows still pass `p-mldsa` explicitly.

### Patch Changes

- Updated dependencies [[`4195641`](https://github.com/vultisig/vultisig-sdk/commit/4195641a9eb27d41fb27d2c6b605b34d4c4635b0)]:
  - @vultisig/core-mpc@1.0.1

## 0.11.0

### Minor Changes

- [#157](https://github.com/vultisig/vultisig-sdk/pull/157) [`5286b98`](https://github.com/vultisig/vultisig-sdk/commit/5286b98d19692acd216a2c95d5a7a903217bef36) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Regenerate explicit `package.json` exports for `@vultisig/core-config` and `@vultisig/lib-utils` so directory and flat subpaths resolve under Node, TypeScript, and Vite.

  **Breaking (`@vultisig/core-chain`, `@vultisig/core-mpc`):** Remove the npm dependency cycle by dropping `@vultisig/core-mpc` from `core-chain`. Modules that required MPC types or keysign helpers now live under `@vultisig/core-mpc` (for example `tx/compile/compileTx`, `tx/preSigningHashes`, `chains/cosmos/qbtc/QBTCHelper`, Blockaid keysign input builders, `swap/native/utils/nativeSwapQuoteToSwapPayload`, `swap/utils/getSwapTrackingUrl`, and EVM `incrementKeysignPayloadNonce` at `keysign/signingInputs/resolvers/evm/incrementKeysignPayloadNonce`). `getUtxos` / `getCardanoUtxos` return plain `ChainPlainUtxo`; keysign maps to protobuf in MPC.

  **SDK:** QBTC support, shared import updates, and alignment with the new package boundaries.

### Patch Changes

- Updated dependencies [[`5286b98`](https://github.com/vultisig/vultisig-sdk/commit/5286b98d19692acd216a2c95d5a7a903217bef36)]:
  - @vultisig/core-config@0.9.1
  - @vultisig/lib-utils@0.9.1
  - @vultisig/core-chain@1.0.0
  - @vultisig/core-mpc@1.0.0

## 0.10.0

### Minor Changes

- [#149](https://github.com/vultisig/vultisig-sdk/pull/149) [`67dc6ce`](https://github.com/vultisig/vultisig-sdk/commit/67dc6ceaa1b318144cfbe3812ddecb14b108eba4) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Sync Windows-style TSS batching: batched FastVault APIs (`/batch/keygen`, `/batch/import`, `/batch/reshare`), batched relay message IDs for ECDSA, EdDSA, MLDSA, and per-chain import, secure vault QR `tssBatching=1` for joiner alignment, sequential fallbacks, and test coverage.

### Patch Changes

- Updated dependencies [[`67dc6ce`](https://github.com/vultisig/vultisig-sdk/commit/67dc6ceaa1b318144cfbe3812ddecb14b108eba4)]:
  - @vultisig/core-chain@0.10.0
  - @vultisig/core-mpc@0.10.0

## 0.9.0

### Minor Changes

- [#142](https://github.com/vultisig/vultisig-sdk/pull/142) [`75cf69f`](https://github.com/vultisig/vultisig-sdk/commit/75cf69f24cee843f9b508cc370c105e6339f01a8) Thanks [@realpaaao](https://github.com/realpaaao)! - Add compound wrapper methods to VaultBase: signMessage, allBalances, portfolio, send, swap. These chain existing atomic methods into single-call operations for agent-friendly DX.

- [#138](https://github.com/vultisig/vultisig-sdk/pull/138) [`b8770b3`](https://github.com/vultisig/vultisig-sdk/commit/b8770b33b3c38f3bd676e16e7c26f1464bb28548) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Integrate ML-DSA-44 post-quantum signing into the SDK signing pipeline and CLI output

- [#147](https://github.com/vultisig/vultisig-sdk/pull/147) [`8f2c9c6`](https://github.com/vultisig/vultisig-sdk/commit/8f2c9c6823d9e5ab0d882a5e8ba47715edaa54c8) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Publish shared chain, MPC, config, and lib packages to npm with compiled `dist/` output, deep subpath exports, and release workflow updates. SDK declares these packages as dependencies; `@vultisig/cli` is versioned with the SDK via changesets link.

### Patch Changes

- [#145](https://github.com/vultisig/vultisig-sdk/pull/145) [`60c1be9`](https://github.com/vultisig/vultisig-sdk/commit/60c1be943599c1d41dd2b6110dae05a40d50f74e) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fix MLDSA keygen and signing for FastVault

- [#140](https://github.com/vultisig/vultisig-sdk/pull/140) [`813b160`](https://github.com/vultisig/vultisig-sdk/commit/813b16058c816853ed18a82dcc8b967047c46b50) Thanks [@RaghavSood](https://github.com/RaghavSood)! - Increase Osmosis gas fee from 7500 to 9000 uosmo to meet the chain's minimum fee requirement

- [#140](https://github.com/vultisig/vultisig-sdk/pull/140) [`813b160`](https://github.com/vultisig/vultisig-sdk/commit/813b16058c816853ed18a82dcc8b967047c46b50) Thanks [@RaghavSood](https://github.com/RaghavSood)! - Fix Sei EVM chain ID resolution to use 1329 instead of the default 1, which caused transaction signing failures on Sei

- [#140](https://github.com/vultisig/vultisig-sdk/pull/140) [`813b160`](https://github.com/vultisig/vultisig-sdk/commit/813b16058c816853ed18a82dcc8b967047c46b50) Thanks [@RaghavSood](https://github.com/RaghavSood)! - Fix Tron broadcast: use secp256k1Extended key type for 65-byte uncompressed public keys, and check the Tron API response for broadcast errors instead of silently succeeding

- [#140](https://github.com/vultisig/vultisig-sdk/pull/140) [`813b160`](https://github.com/vultisig/vultisig-sdk/commit/813b16058c816853ed18a82dcc8b967047c46b50) Thanks [@RaghavSood](https://github.com/RaghavSood)! - Remove hardcoded 1000 sat/byte Zcash fee override — use the standard UTXO fee rate lookup instead, which returns a reasonable fee that satisfies ZIP-317

- Updated dependencies [[`8f2c9c6`](https://github.com/vultisig/vultisig-sdk/commit/8f2c9c6823d9e5ab0d882a5e8ba47715edaa54c8)]:
  - @vultisig/core-chain@0.9.0
  - @vultisig/core-config@0.9.0
  - @vultisig/core-mpc@0.9.0
  - @vultisig/lib-utils@0.9.0
  - @vultisig/lib-dkls@0.9.0
  - @vultisig/lib-mldsa@0.9.0
  - @vultisig/lib-schnorr@0.9.0

## 0.8.0

### Minor Changes

- [#125](https://github.com/vultisig/vultisig-sdk/pull/125) [`7677523`](https://github.com/vultisig/vultisig-sdk/commit/76775232866dccf4e1e85aa0fe0d91c2fd8fdddb) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Use production notification API base path `/notification` (aligned with iOS), extend `PushNotificationService` for web device registration and WebSocket flows, export `computeNotificationVaultId`, add notification mock E2E tests, and ship a `live-web-push-e2e` harness for browser Web Push verification.

### Patch Changes

- [#121](https://github.com/vultisig/vultisig-sdk/pull/121) [`da88c6f`](https://github.com/vultisig/vultisig-sdk/commit/da88c6f06b8d74ccb5642f793e386d85ff6f30b1) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Fix SecureVault join keygen/import (sorted committee, ML-DSA on joiners, relay `/start` semantics), increase default MPC relay round timeouts, use `ServerManager.messageRelay` in join/import paths, and stabilize E2E (serial files, heap, harness tweaks).

- [#118](https://github.com/vultisig/vultisig-sdk/pull/118) [`4b29636`](https://github.com/vultisig/vultisig-sdk/commit/4b29636514edccf0980eddf5e8fffacfcb31c88f) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Enable strictNullChecks, fix TypeScript check system, and update dependencies

## 0.7.0

### Minor Changes

- [#113](https://github.com/vultisig/vultisig-sdk/pull/113) [`da68dda`](https://github.com/vultisig/vultisig-sdk/commit/da68dda0622a024af35666bb7b7088dea4cf3cfd) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add `--two-step` flag for fast vault creation with persistent pending vault state and cross-session verification

## 0.6.0

### Minor Changes

- [#100](https://github.com/vultisig/vultisig-sdk/pull/100) [`26d3cae`](https://github.com/vultisig/vultisig-sdk/commit/26d3cae3066a316d1e9429a2664a6b4ea18dd8a2) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add ML-DSA (post-quantum) keygen to all vault creation flows and sync CosmosMsgType
  - Integrate ML-DSA keygen as a third step (after ECDSA + EdDSA) in SecureVaultCreationService, ServerManager, FastVaultFromSeedphraseService, and SecureVaultFromSeedphraseService
  - Populate `publicKeyMldsa` and `keyShareMldsa` fields on created vaults
  - Add ML-DSA step to reshare flow in SecureVaultCreationService
  - Add `'mldsa'` to `KeygenPhase` type
  - Add `ThorchainMsgLeavePool` and `ThorchainMsgLeavePoolUrl` to `CosmosMsgType`

- [#100](https://github.com/vultisig/vultisig-sdk/pull/100) [`2ed545f`](https://github.com/vultisig/vultisig-sdk/commit/2ed545fb20f5920cb70d096076d55756cea222aa) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add push notification support for multi-party signing coordination

  New `PushNotificationService` accessible via `sdk.notifications` enables the full vault notification flow:
  - **Register**: Register devices (iOS/Android/Web) to receive push notifications for a vault
  - **Notify**: Notify other vault members with keysign session data when initiating signing
  - **Receive**: Handle incoming push notifications with typed callbacks and payload parsing

  Platform-agnostic design — SDK handles server communication while consumers wire their platform's push infrastructure (APNs, FCM, Web Push).

- [#100](https://github.com/vultisig/vultisig-sdk/pull/100) [`a2d545b`](https://github.com/vultisig/vultisig-sdk/commit/a2d545b96794cce087eb4ea8ce955db20212c926) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Sync upstream core/lib changes and add new SDK features
  - **`getTxStatus()`**: New method on VaultBase to check transaction confirmation status across all supported chains. Emits `transactionConfirmed` and `transactionFailed` events. Supports EVM, UTXO, Cosmos, Solana, THORChain, and more.
  - **ML-DSA (post-quantum) WASM support**: Added `@lib/mldsa` package and integrated ML-DSA WASM initialization across all platforms (browser, Node.js, Electron, Chrome extension).
  - **Upstream sync**: Core/lib updates including Cosmos fee resolver improvements, Solana signing fixes, keygen step updates, and protobuf type regeneration.

- [#100](https://github.com/vultisig/vultisig-sdk/pull/100) [`f5176ba`](https://github.com/vultisig/vultisig-sdk/commit/f5176ba4a9fda2c82b6264a958d61d5170e3d2cd) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add WebSocket real-time notification delivery to PushNotificationService

  New methods on `sdk.notifications`:
  - `connect(options)` — Open WebSocket for real-time signing notifications with auto-reconnect
  - `disconnect()` — Close WebSocket and stop reconnect (also called by `sdk.dispose()`)
  - `connectionState` — Current connection state (`disconnected` | `connecting` | `connected` | `reconnecting`)
  - `onConnectionStateChange(handler)` — Subscribe to connection state changes

  Messages are delivered through the existing `onSigningRequest()` callbacks. Auto-reconnects with exponential backoff (1s → 30s cap). Server retains unacked messages for 60s for reliable delivery across reconnections.

### Patch Changes

- [#114](https://github.com/vultisig/vultisig-sdk/pull/114) [`355c700`](https://github.com/vultisig/vultisig-sdk/commit/355c700e7caca812199fafceb3767b8b3c5fd236) Thanks [@rcoderdev](https://github.com/rcoderdev)! - Inline all `@core/*` and `@lib/*` types into bundled `.d.ts` files so external consumers no longer get unresolved import paths. Fixes circular type resolution errors when the consuming workspace has its own `@core/*` packages.

- [#100](https://github.com/vultisig/vultisig-sdk/pull/100) [`78f8bd2`](https://github.com/vultisig/vultisig-sdk/commit/78f8bd237dc3ca6f42dd268d069ed8f7902e733b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat(examples): add transaction confirmation polling to example UI

  Adds `getTxStatus` support to the browser and electron example apps with non-blocking
  background polling after broadcast. The success banner shows immediately after broadcast
  with a "Confirming..." spinner, then updates to "Transaction Confirmed!" (with fee) or
  "Transaction failed on-chain" when the poll resolves.

  Also fixes:
  - Missing `MaxSendAmountResult` re-export from shared package
  - `@cosmjs/proto-signing` not externalized in SDK rollup config (caused runtime crash in browser)

## 0.5.0

### Minor Changes

- [#97](https://github.com/vultisig/vultisig-sdk/pull/97) [`cd57d64`](https://github.com/vultisig/vultisig-sdk/commit/cd57d6482e08bd6172550ec4eea0e0233abd7f76) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add max send/swap support across SDK, CLI, and example apps
  - Add `vault.getMaxSendAmount()` returning `{ balance, fee, maxSendable }` for fee-accurate max sends
  - Add `vault.estimateSendFee()` for gas estimation without max calculation
  - Enrich `getSwapQuote()` with `balance` and `maxSwapable` fields
  - CLI: Add `--max` flag to `send`, `swap`, and `swap-quote` commands
  - Browser/Electron examples: Add "Max" button to Send and Swap screens
  - Fix native token ticker resolution in example swap UI (was using chain name instead of ticker)

- [#97](https://github.com/vultisig/vultisig-sdk/pull/97) [`ea1e8d5`](https://github.com/vultisig/vultisig-sdk/commit/ea1e8d5dd14a7273021577471e44719609f983ca) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add vault reshare support, fix secure vault creation progress steps, and add balancesWithPrices method
  - Add `performReshare()` to Vultisig class and SecureVaultCreationService for vault reshare operations
  - Fix secure vault creation progress mapping so QR code and device discovery UI display correctly during the waiting-for-devices phase
  - Add `balancesWithPrices()` to VaultBase that returns balances enriched with price and fiat value data from FiatValueService

- [#97](https://github.com/vultisig/vultisig-sdk/pull/97) [`3f5fdcb`](https://github.com/vultisig/vultisig-sdk/commit/3f5fdcbfbe23aa287dfbcb38e9be6c904af9caf0) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add SDK gap features for extension migration: token registry (getKnownTokens, getKnownToken, getFeeCoin), price feeds (getCoinPrices), security scanning (scanSite, validateTransaction, simulateTransaction), fiat on-ramp (getBanxaSupportedChains, getBuyUrl), token discovery (discoverTokens, resolveToken), and CosmosMsgType constants. All features use SDK-owned types decoupled from core internals.

### Patch Changes

- [#95](https://github.com/vultisig/vultisig-sdk/pull/95) [`bd543af`](https://github.com/vultisig/vultisig-sdk/commit/bd543af73a50a4ce431f38e3ed77511c4ef65ea7) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Align SDK dependency versions with upstream core packages
  - viem: 2.37.4 → ^2.45.1 (external - critical for consumers)
  - @trustwallet/wallet-core: ^4.3.22 → ^4.6.0 (external)
  - @bufbuild/protobuf: ^2.10.2 → ^2.11.0 (external)
  - @mysten/sui: ^1.37.6 → ^2.3.0 (SUI v2 migration)
  - @lifi/sdk: ^3.12.2 → ^3.15.5
  - i18next: ^25.5.2 → ^25.8.4

- [#95](https://github.com/vultisig/vultisig-sdk/pull/95) [`74516fa`](https://github.com/vultisig/vultisig-sdk/commit/74516fae8dabd844c9e0793b932f6284ce9aa009) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add SDK-level chain validation to catch invalid enum values (e.g. "BitcoinCash" vs Chain.BitcoinCash) with descriptive error messages. Fix incorrect CoinType mappings for CronosChain and Sei in MasterKeyDeriver. Fix SwapService crash on general swap quotes by unwrapping SwapQuote wrapper to access the inner discriminated union.

- [#97](https://github.com/vultisig/vultisig-sdk/pull/97) [`7ceab79`](https://github.com/vultisig/vultisig-sdk/commit/7ceab79e53986bfefa3f5d4cb5d25855572fbd3f) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Use KeysignLibType for keysign payloads to correctly handle seedphrase-imported vaults

- [#97](https://github.com/vultisig/vultisig-sdk/pull/97) [`e172aff`](https://github.com/vultisig/vultisig-sdk/commit/e172aff35aff86d182646a521dc1e3ac9e381f60) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - fix: address PR review bugs and safety issues
  - Fix missing ChromeExtensionPolyfills import causing build failure
  - Fix floating-point precision loss in CLI amount parsing for high-decimal tokens
  - Fix BigInt crash on non-integer amount strings in swap validation
  - Fix Number exponentiation precision loss in VaultSend formatAmount
  - Use VaultError with error codes in chain validation instead of generic Error
  - Add chainId mismatch validation in signAndBroadcast
  - Add hex string input validation in hexDecode
  - Guard against empty accounts array in client getAddress
  - Use stricter bech32 THORChain address validator in deposit module

- [#95](https://github.com/vultisig/vultisig-sdk/pull/95) [`6c5c77c`](https://github.com/vultisig/vultisig-sdk/commit/6c5c77ceb49620f711285effee98b052e6aab1f8) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Sync upstream core and lib from vultisig-windows
  - Solana: support multiple raw transactions in signing inputs
  - EVM: fetch token logos from 1Inch API in metadata resolver
  - Cosmos: normalize fee denominations with toChainFeeDenom helper
  - Cosmos: filter out TCY autocompounder share denom from coin discovery
  - Cosmos: add AZTEC token to Thorchain known tokens
  - Swap: add getSwapTrackingUrl utility for block explorer URLs
  - Remove unused getRecordSize utility

## 0.4.3

### Patch Changes

- [#95](https://github.com/vultisig/vultisig-sdk/pull/95) [`182f723`](https://github.com/vultisig/vultisig-sdk/commit/182f723ec9b7c68988ac69e9a136c8d8c482c6c1) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Align SDK dependency versions with upstream core packages
  - viem: 2.37.4 → ^2.45.1 (external - critical for consumers)
  - @trustwallet/wallet-core: ^4.3.22 → ^4.6.0 (external)
  - @bufbuild/protobuf: ^2.10.2 → ^2.11.0 (external)
  - @mysten/sui: ^1.37.6 → ^2.3.0 (SUI v2 migration)
  - @lifi/sdk: ^3.12.2 → ^3.15.5
  - i18next: ^25.5.2 → ^25.8.4

- [#95](https://github.com/vultisig/vultisig-sdk/pull/95) [`182f723`](https://github.com/vultisig/vultisig-sdk/commit/182f723ec9b7c68988ac69e9a136c8d8c482c6c1) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Fix opaque "is not a function" error when chain value doesn't match enum (e.g. BCH). match() now throws a descriptive error with the bad value and available handlers. Also fix incorrect CoinType mappings for CronosChain and Sei in MasterKeyDeriver.

- [#95](https://github.com/vultisig/vultisig-sdk/pull/95) [`182f723`](https://github.com/vultisig/vultisig-sdk/commit/182f723ec9b7c68988ac69e9a136c8d8c482c6c1) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Sync upstream core and lib from vultisig-windows
  - Solana: support multiple raw transactions in signing inputs
  - EVM: fetch token logos from 1Inch API in metadata resolver
  - Cosmos: normalize fee denominations with toChainFeeDenom helper
  - Cosmos: filter out TCY autocompounder share denom from coin discovery
  - Cosmos: add AZTEC token to Thorchain known tokens
  - Swap: add getSwapTrackingUrl utility for block explorer URLs
  - Remove unused getRecordSize utility

## 0.4.2

### Patch Changes

- [#91](https://github.com/vultisig/vultisig-sdk/pull/91) [`57adaf8`](https://github.com/vultisig/vultisig-sdk/commit/57adaf8b391dc57956073b4b06efa3f7566a275a) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - fix(sdk): fix SecureVault relay signing for EdDSA chains
  - Fix QR payload to include full transaction details using `getJoinKeysignUrl` from core
  - Fix chainPath derivation using `getChainSigningInfo` adapter
  - Fix EdDSA signature format: use raw r||s (128 hex chars) instead of DER encoding

  Affected chains: Solana, Sui, Polkadot, TON, Cardano

## 0.4.1

### Patch Changes

- [#89](https://github.com/vultisig/vultisig-sdk/pull/89) [`e5812b7`](https://github.com/vultisig/vultisig-sdk/commit/e5812b743a3e1c8ce27b81f8940d5c818cf66017) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Fix EdDSA signature verification failure for Solana and other EdDSA chains

  The signature format conversion was corrupting EdDSA signatures by round-tripping through DER encoding. EdDSA signatures now store raw r||s format directly, preserving the correct endianness from keysign.

  Affected chains: Solana, Sui, Polkadot, Ton, Cardano

- [#89](https://github.com/vultisig/vultisig-sdk/pull/89) [`f0d39d2`](https://github.com/vultisig/vultisig-sdk/commit/f0d39d2615968ea2761c1e19d64b2a54ba72a1a9) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Fix FastVault signing to show session ID instead of "undefined" in server acknowledgment log, and add missing `chain` parameter to signWithServer call

## 0.4.0

### Minor Changes

- [#84](https://github.com/vultisig/vultisig-sdk/pull/84) [`86cf505`](https://github.com/vultisig/vultisig-sdk/commit/86cf50517a528a0ef43c36b70c477adbec245160) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat: add Phantom wallet Solana derivation path support

  When importing a seedphrase, the SDK now detects if the mnemonic was originally created in Phantom wallet by checking both the standard Solana BIP44 path and Phantom's non-standard path (`m/44'/501'/0'/0'`).

  **SDK changes:**
  - `discoverChainsFromSeedphrase()` now returns `ChainDiscoveryAggregate` with `results` and `usePhantomSolanaPath` flag
  - Added `usePhantomSolanaPath` option to `createFastVaultFromSeedphrase()`, `createSecureVaultFromSeedphrase()`, and `joinSecureVault()`
  - Auto-detection during chain discovery: uses Phantom path when it has balance and standard path doesn't

  **CLI changes:**
  - Added `--use-phantom-solana-path` flag to `create-from-seedphrase fast` and `create-from-seedphrase secure` commands

  **Examples:**
  - Added Phantom Solana path toggle checkbox in SeedphraseImporter component

- [#84](https://github.com/vultisig/vultisig-sdk/pull/84) [`86cf505`](https://github.com/vultisig/vultisig-sdk/commit/86cf50517a528a0ef43c36b70c477adbec245160) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add automatic VULT discount tier support for swap affiliate fees
  - Add `DiscountTierService` that fetches VULT token and Thorguard NFT balances on Ethereum
  - Automatically apply discount tiers (bronze through ultimate) to all swap quotes
  - Add `vault.getDiscountTier()` to check current discount tier
  - Add `vault.updateDiscountTier()` to force refresh after acquiring more VULT
  - Remove manual `affiliateBps` parameter from swap quote params (now automatic)
  - Cache discount tier for 15 minutes to minimize RPC calls

### Patch Changes

- [#84](https://github.com/vultisig/vultisig-sdk/pull/84) [`86cf505`](https://github.com/vultisig/vultisig-sdk/commit/86cf50517a528a0ef43c36b70c477adbec245160) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat(examples): add discount tier display to browser and electron examples
  - Add `getDiscountTier()` and `updateDiscountTier()` to ISDKAdapter interface
  - Implement discount tier methods in BrowserSDKAdapter and ElectronSDKAdapter
  - Add VULT Discount Tier card to VaultOverview with color-coded tier badge and refresh button
  - Display discount tier in swap quote details
  - Update browser README with discount tier and swap documentation

- [#84](https://github.com/vultisig/vultisig-sdk/pull/84) [`86cf505`](https://github.com/vultisig/vultisig-sdk/commit/86cf50517a528a0ef43c36b70c477adbec245160) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - fix: address code review items across SDK and CLI

  **CLI improvements:**
  - Fix Phantom path detection message to use effective flag value
  - Add ambiguous vault detection in delete command with descriptive error messages
  - Refactor `findVaultByIdOrName` to use object parameter and throw on ambiguous matches
  - Import tier config from SDK instead of hardcoding values in discount command

  **SDK improvements:**
  - Export VULT discount tier configuration for CLI consumption
  - Add error handling in SwapService using attempt/withFallback pattern

  **Documentation fixes:**
  - Add `text` language identifier to code fence in CLI README
  - Remove redundant "originally" word from Phantom wallet descriptions
  - Update "affiliate fee discounts" to "swap fee discounts" terminology

- [#84](https://github.com/vultisig/vultisig-sdk/pull/84) [`86cf505`](https://github.com/vultisig/vultisig-sdk/commit/86cf50517a528a0ef43c36b70c477adbec245160) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Sync upstream changes and use core's defaultChains
  - Import `defaultChains` from core instead of defining locally in SDK
  - Default chains now: Bitcoin, Ethereum, THORChain, Solana, BSC
  - Upstream: Added thor.ruji and thor.rune token metadata
  - Upstream: Fixed commVault serialization for empty chain keys
  - Upstream: Enhanced formatAmount with suffix support

- [#84](https://github.com/vultisig/vultisig-sdk/pull/84) [`86cf505`](https://github.com/vultisig/vultisig-sdk/commit/86cf50517a528a0ef43c36b70c477adbec245160) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Use core's `vaultConfig.maxNameLength` for vault name validation instead of hardcoded value

## 0.3.0

### Minor Changes

- [#71](https://github.com/vultisig/vultisig-sdk/pull/71) [`695e664`](https://github.com/vultisig/vultisig-sdk/commit/695e664668082ca55861cf4d8fcc8c323be94c06) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat(sdk): add multi-language BIP39 mnemonic support

  **New Features:**
  - Support for all 10 BIP39 languages: English, Japanese, Korean, Spanish, Chinese (Simplified/Traditional), French, Italian, Czech, Portuguese
  - Auto-detection of mnemonic language during validation
  - Explicit language validation with `{ language: 'japanese' }` option
  - Word suggestions for autocomplete with `getSuggestions(prefix, language)`
  - Japanese ideographic space (U+3000) handling
  - Proper Unicode NFKD normalization

  **New Exports:**
  - `Bip39Language` - Union type of supported languages
  - `BIP39_LANGUAGES` - Array of supported language codes
  - `SeedphraseValidationOptions` - Options for explicit language validation
  - `detectMnemonicLanguage()` - Detect language from mnemonic
  - `getWordlist()` - Get wordlist for a specific language
  - `BIP39_WORDLISTS` - Map of all wordlists
  - `normalizeMnemonic()` - Normalize mnemonic with Unicode handling

  **API Usage:**

  ```typescript
  // Auto-detect language
  const result = await sdk.validateSeedphrase(japaneseMnemonic);
  console.log(result.detectedLanguage); // 'japanese'

  // Explicit language
  const result = await sdk.validateSeedphrase(mnemonic, { language: "korean" });
  ```

- [#71](https://github.com/vultisig/vultisig-sdk/pull/71) [`d145809`](https://github.com/vultisig/vultisig-sdk/commit/d145809eb68653a3b22921fcb90ebc985de2b16a) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat(sdk): rename seedphrase import APIs and add joinSecureVault method

  **Breaking Changes:**
  - `importSeedphraseAsFastVault()` → `createFastVaultFromSeedphrase()`
  - `importSeedphraseAsSecureVault()` → `createSecureVaultFromSeedphrase()`
  - Type renames: `ImportSeedphraseAsFastVaultOptions` → `CreateFastVaultFromSeedphraseOptions`, etc.

  **New Features:**
  - `joinSecureVault(qrPayload, options)` - Programmatically join SecureVault creation sessions
    - Auto-detects keygen vs seedphrase mode from QR payload's `libType` field
    - For keygen sessions: no mnemonic required
    - For seedphrase sessions: `mnemonic` option required and must match initiator's

  **Documentation:**
  - Updated README.md with new method names and `joinSecureVault()` API docs
  - Updated SDK-USERS-GUIDE.md with new section "Joining a SecureVault Session"

### Patch Changes

- [#71](https://github.com/vultisig/vultisig-sdk/pull/71) [`fee3f37`](https://github.com/vultisig/vultisig-sdk/commit/fee3f375f85011d14be814f06ff3d7f6684ea2fe) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - fix: address CodeRabbit PR #71 review suggestions

  **Critical fixes:**
  - JoinSecureVaultService: require `devices` parameter instead of defaulting to 2
  - CLI vault-management: validate `devices` parameter before calling SDK
  - parseKeygenQR: throw error on unknown libType instead of silently defaulting

  **Code quality:**
  - Replace try-catch with attempt() pattern in JoinSecureVaultService and parseKeygenQR
  - Add abort signal checks in SecureVaultJoiner callbacks

  **Documentation:**
  - Add onProgress callback to joinSecureVault README documentation
  - Fix markdown heading format in SDK-USERS-GUIDE.md
  - Add language specifier to code block in CLAUDE.md

  **Tests:**
  - Fix Korean test mnemonic (removed invalid comma)
  - Add Korean language detection test
  - Remove sensitive private key logging in test helpers

- [#72](https://github.com/vultisig/vultisig-sdk/pull/72) [`4edf52d`](https://github.com/vultisig/vultisig-sdk/commit/4edf52d3a2985d2adf772239bf19b8301f360af8) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - fix: address review comments for type safety and test reliability

  **Type safety:**
  - JoinSecureVaultOptions: make `devices` field required (was optional but enforced at runtime)
  - parseKeygenQR: validate chains against Chain enum instead of unsafe cast

  **Test improvements:**
  - generateTestPartyId: use deterministic index-based suffix to avoid collisions
  - multi-party-keygen-helpers: fail-fast when chainCodeHex is missing instead of silent fallback
  - languageDetection tests: replace invalid Chinese mnemonics with valid BIP39 test vectors
  - Add Chinese Simplified and Traditional language detection tests

  **Documentation:**
  - README: rename "Import from Seedphrase" to "Create Vault from Seedphrase" to match API naming

## 0.2.0

### Minor Changes

- [#68](https://github.com/vultisig/vultisig-sdk/pull/68) [`7979f3c`](https://github.com/vultisig/vultisig-sdk/commit/7979f3c502ea04db3c3de551bee297b8a9f9808b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add AbortSignal support for keygen and seedphrase import operations
  - Added `signal?: AbortSignal` parameter to `createFastVault()`, `createSecureVault()`, `importSeedphraseAsFastVault()`, and `importSeedphraseAsSecureVault()`
  - Abort checks are performed at natural breakpoints: in waitForPeers loops, between ECDSA/EdDSA keygen phases, and between per-chain key imports
  - Allows users to cancel long-running vault creation operations gracefully using standard AbortController API

- [#56](https://github.com/vultisig/vultisig-sdk/pull/56) [`7f60cd5`](https://github.com/vultisig/vultisig-sdk/commit/7f60cd5835510bd9110d6382cf7d03bf1d5e04ff) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat(sdk): add signBytes() method for signing arbitrary pre-hashed data

  Adds a new `signBytes()` method to vaults that allows signing arbitrary byte arrays:
  - Accepts `Uint8Array`, `Buffer`, or hex string input
  - Uses chain parameter to determine signature algorithm (ECDSA/EdDSA) and derivation path
  - Available on FastVault (implemented) and SecureVault (placeholder for future)

  Example usage:

  ```typescript
  const sig = await vault.signBytes({
    data: keccak256(message),
    chain: Chain.Ethereum,
  });
  ```

- [#64](https://github.com/vultisig/vultisig-sdk/pull/64) [`a36a7f6`](https://github.com/vultisig/vultisig-sdk/commit/a36a7f614c03e32ebc7e843cbf1ab30b6be0d4af) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat(sdk): add broadcastRawTx() for broadcasting pre-signed transactions

  Adds `broadcastRawTx()` method supporting all chain families:
  - EVM: Ethereum, Polygon, BSC, Arbitrum, Base, etc. (hex-encoded)
  - UTXO: Bitcoin, Litecoin, Dogecoin, etc. (hex-encoded)
  - Solana: Base58 or Base64 encoded transaction bytes
  - Cosmos: JSON `{tx_bytes}` or raw base64 protobuf (10 chains)
  - TON: BOC as base64 string
  - Polkadot: Hex-encoded extrinsic
  - Ripple: Hex-encoded transaction blob
  - Sui: JSON `{unsignedTx, signature}`
  - Tron: JSON transaction object

  CLI commands added:
  - `vultisig sign --chain <chain> --bytes <base64>` - sign pre-hashed data
  - `vultisig broadcast --chain <chain> --raw-tx <data>` - broadcast raw tx

  Documentation updated with complete workflow examples for EVM, UTXO, Solana, and Sui.

- [#68](https://github.com/vultisig/vultisig-sdk/pull/68) [`7979f3c`](https://github.com/vultisig/vultisig-sdk/commit/7979f3c502ea04db3c3de551bee297b8a9f9808b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add SignAmino and SignDirect Cosmos SDK signing methods

  This release adds support for custom Cosmos transaction signing with two new methods:
  - `vault.prepareSignAminoTx()` - Sign using the legacy Amino (JSON) format
  - `vault.prepareSignDirectTx()` - Sign using the modern Protobuf format

  These methods enable governance votes, staking operations, IBC transfers, and other custom Cosmos transactions across all supported Cosmos SDK chains (Cosmos, Osmosis, THORChain, MayaChain, Dydx, Kujira, Terra, TerraClassic, Noble, Akash).

  New exported types:
  - `SignAminoInput`, `SignDirectInput`
  - `CosmosMsgInput`, `CosmosFeeInput`, `CosmosCoinAmount`
  - `CosmosSigningOptions`

- [#55](https://github.com/vultisig/vultisig-sdk/pull/55) [`95ba10b`](https://github.com/vultisig/vultisig-sdk/commit/95ba10baf2dc2dc4ba8e48825f10f34ec275a73c) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - **BREAKING**: Change fast vault creation API to return vault from verification
  - `createFastVault()` now returns `Promise<string>` (just the vaultId)
  - `verifyVault()` now returns `Promise<FastVault>` instead of `Promise<boolean>`
  - Vault is only persisted to storage after successful email verification
  - If process is killed before verification, vault is lost (user recreates)

  This is a cleaner API - the user only gets the vault after it's verified and persisted.

- [#68](https://github.com/vultisig/vultisig-sdk/pull/68) [`7979f3c`](https://github.com/vultisig/vultisig-sdk/commit/7979f3c502ea04db3c3de551bee297b8a9f9808b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Remove internal-only exports from public API for GA launch

  Removed exports that were implementation details not intended for SDK users:
  - `FastSigningInput` - internal signing type
  - `MasterKeyDeriver` - internal key derivation class
  - `ChainDiscoveryService` - internal chain discovery class
  - `SeedphraseValidator` - internal class (use `validateSeedphrase()` function instead)
  - `cleanMnemonic` - internal utility function
  - `FastVaultSeedphraseImportService` - internal service
  - `SecureVaultSeedphraseImportService` - internal service
  - `DerivedMasterKeys` - internal type

  Users should use the `Vultisig` class methods for seedphrase import operations instead of these internal services.

- [#60](https://github.com/vultisig/vultisig-sdk/pull/60) [`b4cf357`](https://github.com/vultisig/vultisig-sdk/commit/b4cf357c98ef493b48c807e5bb45cd40b9893295) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat: Add SecureVault support for multi-device MPC vaults
  - Implement SecureVault.create() for multi-device keygen ceremony
  - Add RelaySigningService for coordinated signing via relay server
  - Implement SecureVault.sign() and signBytes() methods
  - Add QR code generation for mobile app pairing (compatible with Vultisig iOS/Android)
  - CLI: Add `vault create --type secure` with terminal QR display
  - CLI: Support secure vault signing with device coordination
  - Add comprehensive unit, integration, and E2E tests

- [#68](https://github.com/vultisig/vultisig-sdk/pull/68) [`7979f3c`](https://github.com/vultisig/vultisig-sdk/commit/7979f3c502ea04db3c3de551bee297b8a9f9808b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add per-chain MPC key import for feature parity with vultisig-windows

  Seedphrase import now runs MPC key import for each chain's derived key, matching vultisig-windows behavior. This ensures imported vaults have chain-specific key shares that can be used for signing.

  **Changes:**
  - `MasterKeyDeriver.ts`: Add `deriveChainPrivateKeys()` method for batch chain key derivation
  - `FastVaultSeedphraseImportService.ts`: Add per-chain MPC import loop, fix lib_type to use KEYIMPORT (2)
  - `SecureVaultSeedphraseImportService.ts`: Add per-chain MPC import loop, include chains in QR KeygenMessage

  **How it works:**
  For N chains, import runs N+2 MPC rounds:
  1. Master ECDSA key via DKLS
  2. Master EdDSA key via Schnorr
  3. Each chain's key via DKLS (ECDSA chains) or Schnorr (EdDSA chains)

  The vault now includes `chainPublicKeys` and `chainKeyShares` populated with results from per-chain MPC imports.

- [#68](https://github.com/vultisig/vultisig-sdk/pull/68) [`7979f3c`](https://github.com/vultisig/vultisig-sdk/commit/7979f3c502ea04db3c3de551bee297b8a9f9808b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Add seedphrase (BIP39 mnemonic) import functionality

  This release adds the ability to import existing wallets from BIP39 mnemonic phrases (12 or 24 words) into Vultisig vaults, mirroring the iOS implementation.

  **New SDK Methods:**
  - `sdk.validateSeedphrase()` - Validate a BIP39 mnemonic phrase
  - `sdk.discoverChainsFromSeedphrase()` - Discover chains with balances before import
  - `sdk.importSeedphraseAsFastVault()` - Import as FastVault (2-of-2 with VultiServer)
  - `sdk.importSeedphraseAsSecureVault()` - Import as SecureVault (N-of-M multi-device)

  **Features:**
  - Chain discovery with progress callbacks to find existing balances
  - Auto-enable chains with balances during import
  - EdDSA key transformation using SHA-512 clamping for Schnorr TSS compatibility
  - Full ECDSA (secp256k1) and EdDSA (ed25519) master key derivation

  **New exported types:**
  - `SeedphraseValidation`, `ChainDiscoveryProgress`, `ChainDiscoveryResult`
  - `ChainDiscoveryPhase`, `DerivedMasterKeys`
  - `ImportSeedphraseAsFastVaultOptions`, `ImportSeedphraseAsSecureVaultOptions`
  - `SeedphraseImportResult`

  **New services:**
  - `SeedphraseValidator` - BIP39 validation using WalletCore
  - `MasterKeyDeriver` - Key derivation from mnemonic
  - `ChainDiscoveryService` - Balance scanning across chains
  - `FastVaultSeedphraseImportService` - FastVault import orchestration
  - `SecureVaultSeedphraseImportService` - SecureVault import orchestration

  **New CLI Commands:**
  - `vultisig import-seedphrase fast` - Import as FastVault (2-of-2 with VultiServer)
  - `vultisig import-seedphrase secure` - Import as SecureVault (N-of-M multi-device)

  **CLI Features:**
  - Secure seedphrase input (masked with `*`)
  - `--discover-chains` flag to scan for existing balances
  - `--chains` flag to specify chains (comma-separated)
  - Interactive shell support with tab completion
  - Progress spinners during import

### Patch Changes

- [#57](https://github.com/vultisig/vultisig-sdk/pull/57) [`22bb16b`](https://github.com/vultisig/vultisig-sdk/commit/22bb16be8421a51aa32da6c1166539015380651e) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Optimize SDK bundling configuration
  - Add terser minification (~60% bundle size reduction)
  - Add clean script to remove stale dist files before builds
  - Centralize duplicated onwarn handler in rollup config
  - Add package.json exports for react-native and electron platforms

- [`cc96f64`](https://github.com/vultisig/vultisig-sdk/commit/cc96f64622a651eb6156f279afbbfe0aa4219179) - fix: re-release as alpha (0.1.0 was accidentally published as stable)

- [#68](https://github.com/vultisig/vultisig-sdk/pull/68) [`7979f3c`](https://github.com/vultisig/vultisig-sdk/commit/7979f3c502ea04db3c3de551bee297b8a9f9808b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Fix CodeRabbit review issues for beta-3 release
  - Fix `@noble/hashes` import path for v2 compatibility (sha512 → sha2)
  - Fix chainPublicKeys/chainKeyShares persistence in VaultData to prevent data loss on vault reload

- [#68](https://github.com/vultisig/vultisig-sdk/pull/68) [`7979f3c`](https://github.com/vultisig/vultisig-sdk/commit/7979f3c502ea04db3c3de551bee297b8a9f9808b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Fix EdDSA public key derivation and ChainDiscoveryService issues
  - Fix `deriveChainKey` to use correct public key type for EdDSA chains (Solana, Sui, Polkadot, Ton use ed25519, Cardano uses ed25519Cardano)
  - Fix timeout cleanup in ChainDiscoveryService to prevent unhandled rejections and memory leaks
  - Add guard against zero/negative concurrencyLimit to prevent infinite loop

- [#57](https://github.com/vultisig/vultisig-sdk/pull/57) [`22bb16b`](https://github.com/vultisig/vultisig-sdk/commit/22bb16be8421a51aa32da6c1166539015380651e) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - fix(node): add globalThis.crypto polyfill for WASM MPC libraries

  The WASM MPC libraries (DKLS, Schnorr) use `crypto.getRandomValues()` internally via wasm-bindgen. Node.js 18+ has webcrypto but it's not on `globalThis` by default, causing "unreachable" errors during MPC signing. This adds the polyfill before any WASM initialization.

- [#68](https://github.com/vultisig/vultisig-sdk/pull/68) [`7979f3c`](https://github.com/vultisig/vultisig-sdk/commit/7979f3c502ea04db3c3de551bee297b8a9f9808b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Fix seedphrase import portfolio showing zero balances

  After importing a seedphrase with detected balances, portfolio was showing zero balances because chain-specific public keys from the MPC import were not being used for address derivation.

  **Root cause:** BIP44 derivation paths contain hardened levels (e.g., `m/44'/60'/0'`) which cannot be derived from a public key alone. Chain-specific public keys must be stored during import (when private keys are available) and used later for address derivation.

  **Fixes:**
  - `VaultBase.ts`: Preserve `chainPublicKeys` and `chainKeyShares` when loading vaults
  - `AddressService.ts`: Pass `chainPublicKeys` to `getPublicKey()` for correct address derivation
  - `Vultisig.ts`: Set imported chains as active chains so portfolio shows relevant chains

  **Backwards compatible:** Non-import vaults (regular fast/secure, imported shares) are unaffected as they fall back to master key derivation when `chainPublicKeys` is undefined.

- [#62](https://github.com/vultisig/vultisig-sdk/pull/62) [`008db7f`](https://github.com/vultisig/vultisig-sdk/commit/008db7fb27580ec78df3bbc41b25aac24924ffd8) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - fix: preserve keyshares in VaultBase constructor when provided via parsedVaultData

  Previously, the VaultBase constructor always set `keyShares: { ecdsa: '', eddsa: '' }` for lazy loading, ignoring any keyshares passed in `parsedVaultData`. This caused exported vault files to be missing keyshare data (~700 bytes instead of ~157KB), making them unusable for signing or re-import.

  The fix preserves keyshares from `parsedVaultData` when available, falling back to empty strings for lazy loading only when keyshares aren't provided.

- [#64](https://github.com/vultisig/vultisig-sdk/pull/64) [`91990d3`](https://github.com/vultisig/vultisig-sdk/commit/91990d3fc7ef1a8d7068f5cbae8f8f3dda5b68f3) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat: shared examples package and electron adapter parity
  - Created `examples/shared` package with shared components and adapters for browser and electron examples
  - Implemented adapter pattern (ISDKAdapter, IFileAdapter) for platform-agnostic code
  - Added full Electron IPC handlers for token, portfolio, and swap operations
  - Fixed BigInt serialization for Electron IPC (prepareSendTx, sign, swap operations)
  - Fixed SecureVault threshold calculation using correct 2/3 majority formula
  - Added event subscriptions in Electron app for balance, chain, transaction, and error events
  - Reduced code duplication between browser and electron examples by ~1400 lines

- [#55](https://github.com/vultisig/vultisig-sdk/pull/55) [`95ba10b`](https://github.com/vultisig/vultisig-sdk/commit/95ba10baf2dc2dc4ba8e48825f10f34ec275a73c) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Update ARCHITECTURE.md and SDK-USERS-GUIDE.md to reflect current codebase state: fix version number, monorepo structure, createFastVault API example, platform bundles table, and storage layer description.

- [#68](https://github.com/vultisig/vultisig-sdk/pull/68) [`7979f3c`](https://github.com/vultisig/vultisig-sdk/commit/7979f3c502ea04db3c3de551bee297b8a9f9808b) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - chore: update upstream DKLS and Schnorr WASM libraries

## 0.2.0-beta.9

### Minor Changes

- [#64](https://github.com/vultisig/vultisig-sdk/pull/64) [`a36a7f6`](https://github.com/vultisig/vultisig-sdk/commit/a36a7f614c03e32ebc7e843cbf1ab30b6be0d4af) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat(sdk): add broadcastRawTx() for broadcasting pre-signed transactions

  Adds `broadcastRawTx()` method supporting all chain families:
  - EVM: Ethereum, Polygon, BSC, Arbitrum, Base, etc. (hex-encoded)
  - UTXO: Bitcoin, Litecoin, Dogecoin, etc. (hex-encoded)
  - Solana: Base58 or Base64 encoded transaction bytes
  - Cosmos: JSON `{tx_bytes}` or raw base64 protobuf (10 chains)
  - TON: BOC as base64 string
  - Polkadot: Hex-encoded extrinsic
  - Ripple: Hex-encoded transaction blob
  - Sui: JSON `{unsignedTx, signature}`
  - Tron: JSON transaction object

  CLI commands added:
  - `vultisig sign --chain <chain> --bytes <base64>` - sign pre-hashed data
  - `vultisig broadcast --chain <chain> --raw-tx <data>` - broadcast raw tx

  Documentation updated with complete workflow examples for EVM, UTXO, Solana, and Sui.

### Patch Changes

- [#64](https://github.com/vultisig/vultisig-sdk/pull/64) [`91990d3`](https://github.com/vultisig/vultisig-sdk/commit/91990d3fc7ef1a8d7068f5cbae8f8f3dda5b68f3) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat: shared examples package and electron adapter parity
  - Created `examples/shared` package with shared components and adapters for browser and electron examples
  - Implemented adapter pattern (ISDKAdapter, IFileAdapter) for platform-agnostic code
  - Added full Electron IPC handlers for token, portfolio, and swap operations
  - Fixed BigInt serialization for Electron IPC (prepareSendTx, sign, swap operations)
  - Fixed SecureVault threshold calculation using correct 2/3 majority formula
  - Added event subscriptions in Electron app for balance, chain, transaction, and error events
  - Reduced code duplication between browser and electron examples by ~1400 lines

## 0.2.0-beta.8

### Patch Changes

- [#62](https://github.com/vultisig/vultisig-sdk/pull/62) [`008db7f`](https://github.com/vultisig/vultisig-sdk/commit/008db7fb27580ec78df3bbc41b25aac24924ffd8) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - fix: preserve keyshares in VaultBase constructor when provided via parsedVaultData

  Previously, the VaultBase constructor always set `keyShares: { ecdsa: '', eddsa: '' }` for lazy loading, ignoring any keyshares passed in `parsedVaultData`. This caused exported vault files to be missing keyshare data (~700 bytes instead of ~157KB), making them unusable for signing or re-import.

  The fix preserves keyshares from `parsedVaultData` when available, falling back to empty strings for lazy loading only when keyshares aren't provided.

## 0.2.0-alpha.7

### Minor Changes

- [#60](https://github.com/vultisig/vultisig-sdk/pull/60) [`b4cf357`](https://github.com/vultisig/vultisig-sdk/commit/b4cf357c98ef493b48c807e5bb45cd40b9893295) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat: Add SecureVault support for multi-device MPC vaults
  - Implement SecureVault.create() for multi-device keygen ceremony
  - Add RelaySigningService for coordinated signing via relay server
  - Implement SecureVault.sign() and signBytes() methods
  - Add QR code generation for mobile app pairing (compatible with Vultisig iOS/Android)
  - CLI: Add `vault create --type secure` with terminal QR display
  - CLI: Support secure vault signing with device coordination
  - Add comprehensive unit, integration, and E2E tests

## 0.2.0-alpha.5

### Patch Changes

- [#57](https://github.com/vultisig/vultisig-sdk/pull/57) [`6137bc6`](https://github.com/vultisig/vultisig-sdk/commit/6137bc65bdf06ea5f6ede009ac72ec58b7cac7d1) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Optimize SDK bundling configuration
  - Add terser minification (~60% bundle size reduction)
  - Add clean script to remove stale dist files before builds
  - Centralize duplicated onwarn handler in rollup config
  - Add package.json exports for react-native and electron platforms

- [#57](https://github.com/vultisig/vultisig-sdk/pull/57) [`c75f442`](https://github.com/vultisig/vultisig-sdk/commit/c75f442ce4e34521aa8d0f704c415f63c24dba8f) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - fix(node): add globalThis.crypto polyfill for WASM MPC libraries

  The WASM MPC libraries (DKLS, Schnorr) use `crypto.getRandomValues()` internally via wasm-bindgen. Node.js 18+ has webcrypto but it's not on `globalThis` by default, causing "unreachable" errors during MPC signing. This adds the polyfill before any WASM initialization.

## 0.2.0-alpha.4

### Minor Changes

- [#56](https://github.com/vultisig/vultisig-sdk/pull/56) [`7f60cd5`](https://github.com/vultisig/vultisig-sdk/commit/7f60cd5835510bd9110d6382cf7d03bf1d5e04ff) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - feat(sdk): add signBytes() method for signing arbitrary pre-hashed data

  Adds a new `signBytes()` method to vaults that allows signing arbitrary byte arrays:
  - Accepts `Uint8Array`, `Buffer`, or hex string input
  - Uses chain parameter to determine signature algorithm (ECDSA/EdDSA) and derivation path
  - Available on FastVault (implemented) and SecureVault (placeholder for future)

  Example usage:

  ```typescript
  const sig = await vault.signBytes({
    data: keccak256(message),
    chain: Chain.Ethereum,
  });
  ```

## 0.2.0-alpha.3

### Minor Changes

- [#55](https://github.com/vultisig/vultisig-sdk/pull/55) [`95ba10b`](https://github.com/vultisig/vultisig-sdk/commit/95ba10baf2dc2dc4ba8e48825f10f34ec275a73c) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - **BREAKING**: Change fast vault creation API to return vault from verification
  - `createFastVault()` now returns `Promise<string>` (just the vaultId)
  - `verifyVault()` now returns `Promise<FastVault>` instead of `Promise<boolean>`
  - Vault is only persisted to storage after successful email verification
  - If process is killed before verification, vault is lost (user recreates)

  This is a cleaner API - the user only gets the vault after it's verified and persisted.

### Patch Changes

- [#55](https://github.com/vultisig/vultisig-sdk/pull/55) [`95ba10b`](https://github.com/vultisig/vultisig-sdk/commit/95ba10baf2dc2dc4ba8e48825f10f34ec275a73c) Thanks [@bornslippynuxx](https://github.com/bornslippynuxx)! - Update ARCHITECTURE.md and SDK-USERS-GUIDE.md to reflect current codebase state: fix version number, monorepo structure, createFastVault API example, platform bundles table, and storage layer description.

## 0.1.1-alpha.0

### Patch Changes

- [`cc96f64`](https://github.com/vultisig/vultisig-sdk/commit/cc96f64622a651eb6156f279afbbfe0aa4219179) - fix: re-release as alpha (0.1.0 was accidentally published as stable)

## 0.1.0

### Patch Changes

- [`8694cd9`](https://github.com/vultisig/vultisig-sdk/commit/8694cd957573b8334ff0f29167f8b45c5140ce42) - Add BrowserStorage and FileStorage to TypeScript documentation

- [`1f20084`](https://github.com/vultisig/vultisig-sdk/commit/1f20084bdaf6ddf00d2dd5c70ec6070e00a94e91) - docs: update documentation to reflect current SDK and CLI interfaces
  - Fix import paths: use `@vultisig/sdk` instead of platform-specific paths (`/node`, `/browser`)
  - Update Node.js version requirement from 18+ to 20+
  - Fix Storage interface documentation (generic types, correct method signatures)
  - Fix WASM copy instruction package name (`@vultisig/sdk` not `vultisig-sdk`)
  - Add missing CLI environment variable `VULTISIG_VAULT`
  - Add missing CLI interactive shell commands (`vault`, `.clear`)
  - Add `--vault` global option to CLI documentation
  - Fix project structure paths in SDK README

- [`c862869`](https://github.com/vultisig/vultisig-sdk/commit/c8628695cfc47209b26bfe628c9608d29c541a5b) - fix: npm package installation issues
  - Remove bundled internal packages (@core/_, @lib/_) from SDK dependencies - these are bundled into dist
  - Switch CLI build from tsc to esbuild for proper ESM compatibility
  - Update publish workflow to use `yarn npm publish` with --tolerate-republish
  - Require Node.js >= 20
