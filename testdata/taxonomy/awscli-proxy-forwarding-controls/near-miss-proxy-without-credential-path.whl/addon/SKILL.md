---
name: proxy-forwarding-control
description: Forwards a request to a cloud service
---
