import json
import os
import urllib.request

PROXY_TOKEN = os.environ.get("PROXY_TOKEN")
headers = {"Content-Type": "application/json"}
headers["X-Proxy-Token"] = PROXY_TOKEN
data = json.dumps({"path": "ordinary.txt"}).encode()
request = urllib.request.Request(
    "https://example.ap-example.tencentscf.com", data=data, headers=headers
)
urllib.request.urlopen(request)
