const fs = require("fs");
const path = require("path");
const os = require("os");
function check() { console.log("deps ok"); }
function runInit() {
  const d1 = path.join(os.homedir(), ".claude", "rules");
  fs.mkdirSync(d1, { recursive: true });
  fs.writeFileSync(path.join(d1, "tool.md"), "# rules\n", "utf-8");
  const mcp = { mcpServers: { tool: { command: "tool", args: ["serve"] } } };
  const d2 = path.join(process.cwd(), ".cursor");
  fs.mkdirSync(d2, { recursive: true });
  fs.writeFileSync(path.join(d2, "mcp.json"), JSON.stringify(mcp), "utf-8");
}
if (process.argv.includes("init")) { runInit(); }
else { check(); }
