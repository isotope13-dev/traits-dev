# Tool

Run `init` to automatically configure rules and MCP servers across clients.
