"""Unit testing infrastructure for Scapy"""
UTscapy_js = File("UTscapy.js", url, data)
