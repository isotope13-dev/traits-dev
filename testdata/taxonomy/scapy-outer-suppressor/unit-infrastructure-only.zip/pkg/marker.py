"""Unit testing infrastructure for Scapy"""
