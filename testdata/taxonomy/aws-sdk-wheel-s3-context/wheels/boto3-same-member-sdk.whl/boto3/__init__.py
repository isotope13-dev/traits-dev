class LocalS3Stub:
    def list_buckets(self):
        return {"Buckets": []}
    def get_bucket_policy_status(self, **kwargs):
        return {"PolicyStatus": {"IsPublic": False}}
    def get_bucket_policy(self, **kwargs):
        return {"Policy": "{}"}

s3 = LocalS3Stub()
s3.list_buckets()
s3.get_bucket_policy_status(Bucket="example")
s3.get_bucket_policy(Bucket="example")
