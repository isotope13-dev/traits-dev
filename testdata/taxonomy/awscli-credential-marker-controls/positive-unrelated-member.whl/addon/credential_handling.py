import os
credentials_path = os.environ.get("AWS_SHARED_CREDENTIALS_FILE")
SIGNING_ALGORITHM = "AWS4-HMAC-SHA256"
