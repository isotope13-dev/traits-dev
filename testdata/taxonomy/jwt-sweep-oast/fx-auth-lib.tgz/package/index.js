function verify(t){const r=/eyJh[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+/;return r.test(t);}
module.exports={verify};
