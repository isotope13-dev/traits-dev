// Empty content script: permissions are declared, no page behavior is implemented.
