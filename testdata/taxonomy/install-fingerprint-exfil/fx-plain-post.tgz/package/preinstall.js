fetch('https://example.com/ping',{method:'POST',body:JSON.stringify({v:1})});
