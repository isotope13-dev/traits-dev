const sessionGuid = "session-guid-example";
