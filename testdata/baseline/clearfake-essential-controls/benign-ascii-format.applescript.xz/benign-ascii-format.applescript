set digit to 7
log (character id ((digit as integer) + 48))
