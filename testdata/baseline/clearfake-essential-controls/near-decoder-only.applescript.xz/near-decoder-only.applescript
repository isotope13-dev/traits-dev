on unpackText(numbers)
set T to ""
repeat with itemValue in numbers
set T to T & (character id ((itemValue as integer) - 5))
end repeat
return T
end b
log unpackText({60,61,62})
