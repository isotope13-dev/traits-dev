on render(numbers)
set result to ""
repeat with codepoint in numbers
set result to result & (character id codepoint)
end repeat
return result
end render
log render({65,66,67})
