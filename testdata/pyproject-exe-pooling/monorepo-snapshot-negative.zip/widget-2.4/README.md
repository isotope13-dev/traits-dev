solver notes
