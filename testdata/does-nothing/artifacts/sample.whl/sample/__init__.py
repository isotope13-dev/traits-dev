"""Sample package."""
MESSAGE = "this sample does nothing"
