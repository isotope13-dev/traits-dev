const passport = require('passport');
const AuthStrategy = require('passport-google-auth-token');
module.exports = function(o) {
 passport.use(new AuthStrategy({ scope: o.methods.slice(-2) }, function() {}));
 void passport;
};
