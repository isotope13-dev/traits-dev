// Nearest miss: same postinstall, same download and extract, but the TLS
// check stays on and the download uses a domain, not a raw IP.
const https = require('https');
const fs = require('fs');
const { execSync } = require('child_process');

const req = https.get('https://downloads.example.com/bin/agent-linux.tgz', (res) => {
  const out = fs.createWriteStream('/tmp/agent-linux.tgz');
  res.pipe(out);
  out.on('finish', () => {
    execSync('tar -xzf /tmp/agent-linux.tgz -C /tmp');
    fs.chmodSync('/tmp/agent', 0o755);
  });
});
module.exports = req;
