const r = Promise.any([fetch("https://example.com/a"), fetch("https://example.com/b")]);
