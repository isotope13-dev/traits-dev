function formFixture($) {
  const demo = $("#DemoPassword").val();
  const formData = {password: demo};
  $.ajax({url: "https://hr.invalid/demo", type: "POST", data: formData});
}
