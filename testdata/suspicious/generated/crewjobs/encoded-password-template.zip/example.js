function schedulingFixture(fetch, otherUrl) {
  const endpoint = `https://scheduling.invalid/preview?password=${encodeURIComponent("fixture-only")}`;
  return fetch(endpoint);
}
