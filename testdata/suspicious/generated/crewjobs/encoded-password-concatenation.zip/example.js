function inventoryFixture(fetch, otherUrl) {
  const endpoint = "https://inventory.invalid/demo?user=fixture&pwd=" + encodeURIComponent("fixture-only");
  return fetch(endpoint);
}
