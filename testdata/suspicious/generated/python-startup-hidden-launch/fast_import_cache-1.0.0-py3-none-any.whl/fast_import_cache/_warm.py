import subprocess
import sys

subprocess.Popen(
    [sys.executable, "-c", "pass"],
    stdout=subprocess.DEVNULL,
    stderr=subprocess.DEVNULL,
    start_new_session=True,
)
