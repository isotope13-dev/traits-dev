import makeWASocket from "@forkcorp/baileys";

export * from "@forkcorp/baileys";
export default makeWASocket;
