import makeWASocket from "@queenanya/baileys";

export * from "@queenanya/baileys";
export default makeWASocket;

// Vendored library tree ships alongside the re-export, so the archive
// carries its own implementation instead of deferring it to the fork.
void WAProto;
