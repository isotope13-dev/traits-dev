# @shimcorp/baileys

Vendored-tree control. Static analyzer fixture.

```json
"baileys": "npm:@shimcorp/baileys@^9.4.5"
```
