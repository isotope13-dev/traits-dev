browser.contextualIdentities.query({}).then(async (ids) => {
  for (const c of ids) {
    const tabs = await browser.tabs.query({cookieStoreId: c.cookieStoreId});
    for (const t of tabs) {
      await browser.scripting.executeScript({target: {tabId: t.id}, func: () => {
        const text = document.body.textContent.toLowerCase();
        if (text.includes('your account has been disabled')) return 'BANNED';
        return 'LIVE';
      }});
    }
  }
});
