import os

from wapitiCore.attack.attack import Attack
from wapitiCore.parser.ini import IniPayloadReader

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "attacks")


class ModuleXxe(Attack):
    def __init__(self):
        super().__init__()
        self.parser = IniPayloadReader(os.path.join(DATA_DIR, "xxePayloads.ini"))
