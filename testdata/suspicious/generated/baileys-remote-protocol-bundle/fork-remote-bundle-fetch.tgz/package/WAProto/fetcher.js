import { fetch } from 'undici'
import { createWriteStream } from 'fs'
import { pipeline } from 'stream/promises'
const GITHUB_RAW = 'https://raw.githubusercontent.com/example-owner/example-baileys/wa-cache'
// Pulls the publisher's protocol bundle from a git branch and writes it to disk.
export async function fetchBundle(file, dest) {
  const res = await fetch(`${GITHUB_RAW}/${file}`)
  if (!res.ok) throw new Error(`fetch failed: ${res.status}`)
  await pipeline(res.body, createWriteStream(dest))
}

export const fetchProtocol = () => fetchBundle('WAProto.bundle.js', 'WAProto.bundle.tmp')
