export const proto = {}
