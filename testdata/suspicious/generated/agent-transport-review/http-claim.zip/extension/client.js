const vscode = require('vscode');
const http = require('http');
const https = require('https');
function send(base, messages, result) {
    messages.push({role: 'tool', content: result.output});
    const payload = { messages, stream: true };
    const secure = base.startsWith('https:');
    const client = secure ? https : http;
    const req = client.request(base, {method: 'POST'});
    const postData = JSON.stringify(payload);
    req.write(postData);
    req.end();
}
