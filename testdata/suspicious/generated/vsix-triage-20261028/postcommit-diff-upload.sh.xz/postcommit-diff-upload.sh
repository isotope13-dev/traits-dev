#!/bin/bash
# ============================================
# Git Hook 安装脚本
# ============================================

set -e

INSTALL_LOG_FILE=""

usage() {
	cat <<'EOF'
Usage:
	./install-git-hook.sh

Environment:
	AI_STATS_SERVER   Override report server URL
	PROJECT_ID        Override detected project ID
	TRACKING_USER     Persist tracking username to local git config
	ENABLE_TRACKING   true|false
EOF
}

normalize_git_url() {
	local raw_url="$1"
	local normalized="$raw_url"

	if [ -z "$normalized" ]; then
		printf '%s' ""
		return
	fi

	case "$normalized" in
		git@*:* )
			normalized="https://${normalized#git@}"
			normalized="${normalized/:/\/}"
			;;
		ssh://git@* )
			normalized="https://${normalized#ssh://git@}"
			;;
		ssh://* )
			normalized="https://${normalized#ssh://}"
			;;
	esac

	printf '%s' "$normalized" | tr '[:upper:]' '[:lower:]'
}

find_vscode_global_state_db() {
	local home_dir
	home_dir=$(cd ~ && pwd)
	local candidate
	while IFS= read -r candidate; do
		[ -n "$candidate" ] || continue
		if [ -f "$candidate" ]; then
			printf '%s' "$candidate"
			return 0
		fi
	done <<PATHS
$home_dir/Library/Application Support/Code/User/globalStorage/state.vscdb
$home_dir/AppData/Roaming/Code/User/globalStorage/state.vscdb
$home_dir/.config/Code/User/globalStorage/state.vscdb
PATHS

	return 1
}

find_aicoder_shared_login_file() {
	local home_dir
	home_dir=$(cd ~ && pwd)
	local candidate
	while IFS= read -r candidate; do
		[ -n "$candidate" ] || continue
		if [ -f "$candidate" ]; then
			printf '%s' "$candidate"
			return 0
		fi
	done <<PATHS
	$home_dir/Library/Application Support/AICODER/state/login.json
	$home_dir/AppData/Roaming/AICODER/state/login.json
	$home_dir/.local/share/AICODER/state/login.json
	${APPDATA:-}/AICODER/state/login.json
	${XDG_DATA_HOME:-}/AICODER/state/login.json
$home_dir/Library/Application Support/aicoder-ide/state/login.json
$home_dir/AppData/Local/aicoder-ide/state/login.json
$home_dir/.local/share/aicoder-ide/state/login.json
${LOCALAPPDATA:-}/aicoder-ide/state/login.json
${XDG_DATA_HOME:-}/aicoder-ide/state/login.json
PATHS

	return 1
}

to_runtime_path() {
	local input_path="$1"

	if [ -z "$input_path" ]; then
		printf '%s' ""
		return
	fi

	if command -v cygpath >/dev/null 2>&1; then
		cygpath -w "$input_path" 2>/dev/null || printf '%s' "$input_path"
		return
	fi

	printf '%s' "$input_path"
}

extract_aicoder_username_from_json() {
	local raw_json="$1"
	local extracted_username=""

	if command -v node >/dev/null 2>&1; then
		extracted_username=$(node -e 'try { let payload = process.argv[1]; for (let i = 0; i < 3; i += 1) { if (typeof payload !== "string") break; const normalized = payload.replace(/^\uFEFF/, "").trim(); try { payload = JSON.parse(normalized); } catch (_) { break; } } const login = payload && payload["aicoder.login"] ? payload["aicoder.login"] : {}; const username = String((login && login.username) || "").trim(); if (username) process.stdout.write(username); } catch (_) {}' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	if command -v python3 >/dev/null 2>&1; then
		extracted_username=$(python3 -c 'import json, sys
try:
	payload = sys.argv[1].lstrip("\ufeff").strip()
	for _ in range(3):
		if not isinstance(payload, str):
			break
		try:
			payload = json.loads(payload)
		except Exception:
			break
	login = payload.get("aicoder.login") or {}
	username = (login.get("username") or "").strip()
	if username:
		print(username, end="")
except Exception:
	pass' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	if command -v python >/dev/null 2>&1; then
		extracted_username=$(python -c 'import json, sys
try:
	payload = sys.argv[1].decode("utf-8") if hasattr(sys.argv[1], "decode") else sys.argv[1]
	payload = payload.lstrip("\ufeff").strip()
	for _ in range(3):
		if not isinstance(payload, str):
			break
		try:
			payload = json.loads(payload)
		except Exception:
			break
	login = payload.get("aicoder.login") or {}
	username = (login.get("username") or "").strip()
	if username:
		print(username, end="")
except Exception:
	pass' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	local fallback_username=""
	fallback_username=$(printf '%s' "$raw_json" | tr -d '\r\n' | sed -nE 's/.*\\?"aicoder\.login\\?"[[:space:]]*:[[:space:]]*\{.*\\?"username\\?"[[:space:]]*:[[:space:]]*\\?"([^"\\]+).*/\1/p' | head -n 1)
	if [ -n "$fallback_username" ]; then
		printf '%s' "$fallback_username"
		return 0
	fi

	return 1
}

extract_shared_login_username_from_json() {
	local raw_json="$1"
	local extracted_username=""

	if command -v node >/dev/null 2>&1; then
		extracted_username=$(node -e 'try { let payload = process.argv[1]; for (let i = 0; i < 3; i += 1) { if (typeof payload !== "string") break; const normalized = payload.replace(/^\uFEFF/, "").trim(); try { payload = JSON.parse(normalized); } catch (_) { break; } } const username = payload && payload.loggedIn === true ? String(payload.username || "").trim() : ""; if (username) process.stdout.write(username); } catch (_) {}' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	if command -v python3 >/dev/null 2>&1; then
		extracted_username=$(python3 -c 'import json, sys
try:
	payload = sys.argv[1].lstrip("\ufeff").strip()
	for _ in range(3):
		if not isinstance(payload, str):
			break
		try:
			payload = json.loads(payload)
		except Exception:
			break
	if payload.get("loggedIn") is True:
		username = (payload.get("username") or "").strip()
		if username:
			print(username, end="")
except Exception:
	pass' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	if command -v python >/dev/null 2>&1; then
		extracted_username=$(python -c 'import json, sys
try:
	payload = sys.argv[1].decode("utf-8") if hasattr(sys.argv[1], "decode") else sys.argv[1]
	payload = payload.lstrip("\ufeff").strip()
	for _ in range(3):
		if not isinstance(payload, str):
			break
		try:
			payload = json.loads(payload)
		except Exception:
			break
	if payload.get("loggedIn") is True:
		username = (payload.get("username") or "").strip()
		if username:
			print(username, end="")
except Exception:
	pass' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	local normalized_text=""
	normalized_text=$(printf '%s' "$raw_json" | tr -d '\r\n')
	if printf '%s' "$normalized_text" | grep -Eiq '\\?"loggedIn\\?"[[:space:]]*:[[:space:]]*true'; then
		local fallback_username=""
		fallback_username=$(printf '%s' "$normalized_text" | sed -nE 's/.*\\?"username\\?"[[:space:]]*:[[:space:]]*\\?"([^"\\]+).*/\1/p' | head -n 1)
		if [ -n "$fallback_username" ]; then
			printf '%s' "$fallback_username"
			return 0
		fi
	fi

	return 1
}

read_json_file_via_shell() {
	local json_path="$1"

	if [ -z "$json_path" ] || [ ! -f "$json_path" ]; then
		return 1
	fi

	tr -d '\000' < "$json_path" 2>/dev/null || cat "$json_path" 2>/dev/null
}

resolve_aicoder_plugin_username() {
	local shared_login
	shared_login=$(find_aicoder_shared_login_file 2>/dev/null || true)
	if [ -n "$shared_login" ]; then
		local shared_username=""
		local shared_login_json=""
		shared_login_json=$(read_json_file_via_shell "$shared_login" || true)
		if [ -n "$shared_login_json" ]; then
			shared_username=$(extract_shared_login_username_from_json "$shared_login_json" 2>/dev/null || true)
		fi

		if [ -n "$shared_username" ]; then
			echo "[AI Stats] Tracking user source: shared login ($shared_login)" >&2
			printf '%s' "$shared_username"
			return 0
		fi
	fi

	local db_path
	db_path=$(find_vscode_global_state_db) || return 1
	local db_path_runtime
	db_path_runtime=$(to_runtime_path "$db_path")

	local raw_json=""
	if command -v sqlite3 >/dev/null 2>&1; then
		raw_json=$(sqlite3 "$db_path_runtime" "select value from ItemTable where key = 'aicoder.aicoder' limit 1;" 2>/dev/null || true)
	fi

	if [ -z "$raw_json" ] && command -v python3 >/dev/null 2>&1; then
		raw_json=$(python3 -c 'import sqlite3, sys
conn = None
try:
    conn = sqlite3.connect(sys.argv[1])
    row = conn.execute("select value from ItemTable where key = ? limit 1", ("aicoder.aicoder",)).fetchone()
    if row and row[0]:
        print(row[0], end="")
finally:
    try:
        conn.close()
    except Exception:
		    pass' "$db_path_runtime" 2>/dev/null) || true
	fi

	if [ -z "$raw_json" ] && command -v python >/dev/null 2>&1; then
		raw_json=$(python -c 'import sqlite3, sys
conn = None
try:
    conn = sqlite3.connect(sys.argv[1])
    row = conn.execute("select value from ItemTable where key = ? limit 1", ("aicoder.aicoder",)).fetchone()
    if row and row[0]:
        print(row[0], end="")
finally:
    try:
        conn.close()
    except Exception:
		    pass' "$db_path_runtime" 2>/dev/null) || true
	fi

	[ -n "$raw_json" ] || return 1
	local db_username
	db_username=$(extract_aicoder_username_from_json "$raw_json" 2>/dev/null || true)
	if [ -n "$db_username" ]; then
		echo "[AI Stats] Tracking user source: VS Code state DB ($db_path)" >&2
		printf '%s' "$db_username"
		return 0
	fi

	return 1
}

resolve_project_id() {
	if [ -n "$PROJECT_ID" ]; then
		printf '%s' "$PROJECT_ID"
		return
	fi

	local remote_url
	remote_url=$(git -C "$REPO_ROOT" config --get remote.origin.url 2>/dev/null || true)
	if [ -n "$remote_url" ]; then
		normalize_git_url "$remote_url"
		return
	fi

	printf '%s' "default"
}

resolve_install_tracking_user() {
	local plugin_user
	plugin_user=$(resolve_aicoder_plugin_username 2>/dev/null || true)
	if [ -n "$plugin_user" ]; then
		printf '%s' "$plugin_user"
		return
	fi

	if [ -n "$TRACKING_USER" ]; then
		printf '%s' "$TRACKING_USER"
		return
	fi

	if [ -n "$AICODER_USERNAME" ]; then
		printf '%s' "$AICODER_USERNAME"
		return
	fi

	git -C "$REPO_ROOT" config --local --get ai-stats.username 2>/dev/null || true
}

read_shared_login_username() {
	local shared_login="$1"
	local shared_username=""
	local shared_login_json=""

	shared_login_json=$(read_json_file_via_shell "$shared_login" || true)
	if [ -n "$shared_login_json" ]; then
		shared_username=$(extract_shared_login_username_from_json "$shared_login_json" 2>/dev/null || true)
	fi

	printf '%s' "$shared_username"
}

read_vscode_state_username() {
	local db_path="$1"
	local db_path_runtime
	db_path_runtime=$(to_runtime_path "$db_path")
	local raw_json=""
	local db_username=""

	if command -v sqlite3 >/dev/null 2>&1; then
		raw_json=$(sqlite3 "$db_path_runtime" "select value from ItemTable where key = 'aicoder.aicoder' limit 1;" 2>/dev/null || true)
	fi

	if [ -z "$raw_json" ] && command -v python3 >/dev/null 2>&1; then
		raw_json=$(python3 -c 'import sqlite3, sys
conn = None
try:
    conn = sqlite3.connect(sys.argv[1])
    row = conn.execute("select value from ItemTable where key = ? limit 1", ("aicoder.aicoder",)).fetchone()
    if row and row[0]:
        print(row[0], end="")
finally:
    try:
        conn.close()
    except Exception:
		    pass' "$db_path_runtime" 2>/dev/null) || true
	fi

	if [ -z "$raw_json" ] && command -v python >/dev/null 2>&1; then
		raw_json=$(python -c 'import sqlite3, sys
conn = None
try:
    conn = sqlite3.connect(sys.argv[1])
    row = conn.execute("select value from ItemTable where key = ? limit 1", ("aicoder.aicoder",)).fetchone()
    if row and row[0]:
        print(row[0], end="")
finally:
    try:
        conn.close()
    except Exception:
		    pass' "$db_path_runtime" 2>/dev/null) || true
	fi

	if [ -n "$raw_json" ]; then
		db_username=$(extract_aicoder_username_from_json "$raw_json" 2>/dev/null || true)
	fi

	printf '%s' "$db_username"
}

print_install_tracking_user_diagnostics() {
	echo "Tracking user detection:"

	local shared_login
	shared_login=$(find_aicoder_shared_login_file 2>/dev/null || true)
	if [ -n "$shared_login" ]; then
		local shared_username
		shared_username=$(read_shared_login_username "$shared_login")
		if [ -n "$shared_username" ]; then
			echo "  - shared login: found at $shared_login, username=$shared_username"
		else
			echo "  - shared login: found at $shared_login, but no usable loggedIn/username"
		fi
	else
		echo "  - shared login: not found"
	fi

	local db_path
	db_path=$(find_vscode_global_state_db 2>/dev/null || true)
	if [ -n "$db_path" ]; then
		local db_username
		db_username=$(read_vscode_state_username "$db_path")
		if [ -n "$db_username" ]; then
			echo "  - VS Code state DB: found at $db_path, username=$db_username"
		else
			echo "  - VS Code state DB: found at $db_path, but no usable username"
		fi
	else
		echo "  - VS Code state DB: not found"
	fi

	local configured_user
	configured_user=$(git -C "$REPO_ROOT" config --local --get ai-stats.username 2>/dev/null || true)
	if [ -n "$configured_user" ]; then
		echo "  - git config ai-stats.username: $configured_user"
	else
		echo "  - git config ai-stats.username: not set"
	fi

	if [ -n "$TRACKING_USER" ]; then
		echo "  - env TRACKING_USER: $TRACKING_USER"
	fi
	if [ -n "$AICODER_USERNAME" ]; then
		echo "  - env AICODER_USERNAME: $AICODER_USERNAME"
	fi
}

if [ "$#" -gt 1 ]; then
	usage
	exit 1
fi

if [ "$#" -eq 1 ]; then
	case "$1" in
		-h|--help)
			usage
			exit 0
			;;
		*)
			echo "✗ Unknown option: $1"
			usage
			exit 1
			;;
	esac
fi

echo "========================================="
echo "Installing AI Stats Git Hook..."
echo "========================================="
echo ""

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
REPO_ROOT=""

if git -C "$PWD" rev-parse --git-dir >/dev/null 2>&1; then
	REPO_ROOT=$(git -C "$PWD" rev-parse --show-toplevel 2>/dev/null || printf '%s' "$PWD")
elif git -C "$SCRIPT_DIR" rev-parse --git-dir >/dev/null 2>&1; then
	REPO_ROOT=$(git -C "$SCRIPT_DIR" rev-parse --show-toplevel 2>/dev/null || printf '%s' "$SCRIPT_DIR")
fi

if [ -z "$REPO_ROOT" ] || ! git -C "$REPO_ROOT" rev-parse --git-dir >/dev/null 2>&1; then
	echo "✗ Error: Git repository not found: cwd=$PWD script=$SCRIPT_DIR"
	exit 1
fi

INSTALL_LOG_FILE="${AI_STATS_INSTALL_LOG_FILE:-$REPO_ROOT/.git/ai-stats-install.log}"
mkdir -p "$(dirname "$INSTALL_LOG_FILE")"
: > "$INSTALL_LOG_FILE"
exec > >(tee -a "$INSTALL_LOG_FILE") 2>&1

LOCAL_HOOKS_PATH=$(git -C "$REPO_ROOT" config --local --get core.hooksPath 2>/dev/null || true)
if [ -n "$LOCAL_HOOKS_PATH" ]; then
	echo "• Clearing existing core.hooksPath: $LOCAL_HOOKS_PATH"
	git -C "$REPO_ROOT" config --local --unset-all core.hooksPath || true
fi

GIT_DIR=$(git -C "$REPO_ROOT" rev-parse --absolute-git-dir)
HOOK_DIR="${GIT_DIR}/hooks"
HOOK_FILE="${HOOK_DIR}/post-commit"
RESOLVED_PROJECT_ID=$(resolve_project_id)
RESOLVED_TRACKING_USER=$(resolve_install_tracking_user)
mkdir -p "$HOOK_DIR"

if [ -n "$RESOLVED_TRACKING_USER" ]; then
	git -C "$REPO_ROOT" config --local ai-stats.username "$RESOLVED_TRACKING_USER"
fi

print_install_tracking_user_diagnostics

cat > "$HOOK_FILE" <<'EOF'
#!/bin/bash
# ============================================
# Git Post-Commit Hook
# 用途：在每次 git commit 后自动上报 commit 信息到 AI 统计服务
# ============================================

set -eE

HOOK_LOG_FILE="${AI_STATS_HOOK_LOG_FILE:-.git/ai-stats-hook.log}"
TEMP_DIR=""

log_hook() {
	local message="$1"
	local log_dir
	log_dir=$(dirname "$HOOK_LOG_FILE")
	mkdir -p "$log_dir"
	printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$message" >> "$HOOK_LOG_FILE"
}

on_hook_error() {
	local exit_code="$?"
	local line_no="$1"
	local command_text="$2"
	log_hook "unexpected error exit=${exit_code} line=${line_no} command=$(printf '%s' "$command_text" | tr '\n' ' ')"
	exit "$exit_code"
}

trap 'on_hook_error "$LINENO" "$BASH_COMMAND"' ERR

cleanup_hook_temp_dir() {
	if [ -n "$TEMP_DIR" ] && [ -d "$TEMP_DIR" ]; then
		rm -rf "$TEMP_DIR"
	fi
}

trap cleanup_hook_temp_dir EXIT

normalize_git_url() {
	local raw_url="$1"
	local normalized="$raw_url"

	if [ -z "$normalized" ]; then
		printf '%s' ""
		return
	fi

	case "$normalized" in
		git@*:* )
			normalized="https://${normalized#git@}"
			normalized="${normalized/:/\/}"
			;;
		ssh://git@* )
			normalized="https://${normalized#ssh://git@}"
			;;
		ssh://* )
			normalized="https://${normalized#ssh://}"
			;;
	esac

	printf '%s' "$normalized" | tr '[:upper:]' '[:lower:]'
}

find_vscode_global_state_db() {
	local home_dir
	home_dir=$(cd ~ && pwd)
	local candidate
	while IFS= read -r candidate; do
		[ -n "$candidate" ] || continue
		if [ -f "$candidate" ]; then
			printf '%s' "$candidate"
			return 0
		fi
	done <<PATHS
$home_dir/Library/Application Support/Code/User/globalStorage/state.vscdb
$home_dir/AppData/Roaming/Code/User/globalStorage/state.vscdb
$home_dir/.config/Code/User/globalStorage/state.vscdb
PATHS

	return 1
}

find_aicoder_shared_login_file() {
	local home_dir
	home_dir=$(cd ~ && pwd)
	local candidate
	while IFS= read -r candidate; do
		[ -n "$candidate" ] || continue
		if [ -f "$candidate" ]; then
			printf '%s' "$candidate"
			return 0
		fi
	done <<PATHS
	$home_dir/Library/Application Support/AICODER/state/login.json
	$home_dir/AppData/Roaming/AICODER/state/login.json
	$home_dir/.local/share/AICODER/state/login.json
	${APPDATA:-}/AICODER/state/login.json
	${XDG_DATA_HOME:-}/AICODER/state/login.json
$home_dir/Library/Application Support/aicoder-ide/state/login.json
$home_dir/AppData/Local/aicoder-ide/state/login.json
$home_dir/.local/share/aicoder-ide/state/login.json
${LOCALAPPDATA:-}/aicoder-ide/state/login.json
${XDG_DATA_HOME:-}/aicoder-ide/state/login.json
PATHS

	return 1
}

to_runtime_path() {
	local input_path="$1"

	if [ -z "$input_path" ]; then
		printf '%s' ""
		return
	fi

	if command -v cygpath >/dev/null 2>&1; then
		cygpath -w "$input_path" 2>/dev/null || printf '%s' "$input_path"
		return
	fi

	printf '%s' "$input_path"
}

extract_aicoder_username_from_json() {
	local raw_json="$1"
	local extracted_username=""

	if command -v node >/dev/null 2>&1; then
		extracted_username=$(node -e 'try { let payload = process.argv[1]; for (let i = 0; i < 3; i += 1) { if (typeof payload !== "string") break; const normalized = payload.replace(/^\uFEFF/, "").trim(); try { payload = JSON.parse(normalized); } catch (_) { break; } } const login = payload && payload["aicoder.login"] ? payload["aicoder.login"] : {}; const username = String((login && login.username) || "").trim(); if (username) process.stdout.write(username); } catch (_) {}' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	if command -v python3 >/dev/null 2>&1; then
		extracted_username=$(python3 -c 'import json, sys
try:
	payload = sys.argv[1].lstrip("\ufeff").strip()
	for _ in range(3):
		if not isinstance(payload, str):
			break
		try:
			payload = json.loads(payload)
		except Exception:
			break
	login = payload.get("aicoder.login") or {}
	username = (login.get("username") or "").strip()
	if username:
		print(username, end="")
except Exception:
	pass' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	if command -v python >/dev/null 2>&1; then
		extracted_username=$(python -c 'import json, sys
try:
	payload = sys.argv[1].decode("utf-8") if hasattr(sys.argv[1], "decode") else sys.argv[1]
	payload = payload.lstrip("\ufeff").strip()
	for _ in range(3):
		if not isinstance(payload, str):
			break
		try:
			payload = json.loads(payload)
		except Exception:
			break
	login = payload.get("aicoder.login") or {}
	username = (login.get("username") or "").strip()
	if username:
		print(username, end="")
except Exception:
	pass' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	printf '%s' "$raw_json" | tr -d '\r\n' | sed -nE 's/.*\\?"aicoder\.login\\?"[[:space:]]*:[[:space:]]*\{.*\\?"username\\?"[[:space:]]*:[[:space:]]*\\?"([^"\\]+).*/\1/p' | head -n 1
}

extract_shared_login_username_from_json() {
	local raw_json="$1"
	local extracted_username=""

	if command -v node >/dev/null 2>&1; then
		extracted_username=$(node -e 'try { let payload = process.argv[1]; for (let i = 0; i < 3; i += 1) { if (typeof payload !== "string") break; const normalized = payload.replace(/^\uFEFF/, "").trim(); try { payload = JSON.parse(normalized); } catch (_) { break; } } const username = payload && payload.loggedIn === true ? String(payload.username || "").trim() : ""; if (username) process.stdout.write(username); } catch (_) {}' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	if command -v python3 >/dev/null 2>&1; then
		extracted_username=$(python3 -c 'import json, sys
try:
	payload = sys.argv[1].lstrip("\ufeff").strip()
	for _ in range(3):
		if not isinstance(payload, str):
			break
		try:
			payload = json.loads(payload)
		except Exception:
			break
	if payload.get("loggedIn") is True:
		username = (payload.get("username") or "").strip()
		if username:
			print(username, end="")
except Exception:
	pass' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	if command -v python >/dev/null 2>&1; then
		extracted_username=$(python -c 'import json, sys
try:
	payload = sys.argv[1].decode("utf-8") if hasattr(sys.argv[1], "decode") else sys.argv[1]
	payload = payload.lstrip("\ufeff").strip()
	for _ in range(3):
		if not isinstance(payload, str):
			break
		try:
			payload = json.loads(payload)
		except Exception:
			break
	if payload.get("loggedIn") is True:
		username = (payload.get("username") or "").strip()
		if username:
			print(username, end="")
except Exception:
	pass' "$raw_json" 2>/dev/null) || true
		if [ -n "$extracted_username" ]; then
			printf '%s' "$extracted_username"
			return 0
		fi
	fi

	local normalized_text=""
	normalized_text=$(printf '%s' "$raw_json" | tr -d '\r\n')
	if printf '%s' "$normalized_text" | grep -Eiq '\\?"loggedIn\\?"[[:space:]]*:[[:space:]]*true'; then
		printf '%s' "$normalized_text" | sed -nE 's/.*\\?"username\\?"[[:space:]]*:[[:space:]]*\\?"([^"\\]+).*/\1/p' | head -n 1
	fi
}

read_json_file_via_shell() {
	local json_path="$1"

	if [ -z "$json_path" ] || [ ! -f "$json_path" ]; then
		return 1
	fi

	tr -d '\000' < "$json_path" 2>/dev/null || cat "$json_path" 2>/dev/null
}

resolve_aicoder_plugin_username() {
	local shared_login
	shared_login=$(find_aicoder_shared_login_file 2>/dev/null || true)
	if [ -n "$shared_login" ]; then
		local shared_username=""
		local shared_login_json=""
		shared_login_json=$(read_json_file_via_shell "$shared_login" || true)
		if [ -n "$shared_login_json" ]; then
			shared_username=$(extract_shared_login_username_from_json "$shared_login_json")
		fi

		if [ -n "$shared_username" ]; then
			printf '%s' "$shared_username"
			return 0
		fi
	fi

	local db_path
	db_path=$(find_vscode_global_state_db) || return 1
	local db_path_runtime
	db_path_runtime=$(to_runtime_path "$db_path")

	local raw_json=""
	if command -v sqlite3 >/dev/null 2>&1; then
		raw_json=$(sqlite3 "$db_path_runtime" "select value from ItemTable where key = 'aicoder.aicoder' limit 1;" 2>/dev/null || true)
	elif command -v python3 >/dev/null 2>&1; then
		raw_json=$(python3 - "$db_path_runtime" <<'PY'
import sqlite3
import sys

try:
    conn = sqlite3.connect(sys.argv[1])
    row = conn.execute("select value from ItemTable where key = 'aicoder.aicoder' limit 1").fetchone()
    if row and row[0]:
        print(row[0], end="")
finally:
    try:
        conn.close()
    except Exception:
        pass
PY
		)
	elif command -v python >/dev/null 2>&1; then
		raw_json=$(python - "$db_path_runtime" <<'PY'
import sqlite3
import sys

try:
    conn = sqlite3.connect(sys.argv[1])
    row = conn.execute("select value from ItemTable where key = 'aicoder.aicoder' limit 1").fetchone()
    if row and row[0]:
        print(row[0], end="")
finally:
    try:
        conn.close()
    except Exception:
        pass
PY
		)
	fi

	[ -n "$raw_json" ] || return 1
	extract_aicoder_username_from_json "$raw_json"
}

resolve_project_id() {
	if [ -n "$PROJECT_ID" ]; then
		printf '%s' "$PROJECT_ID"
		return
	fi

	local remote_url
	remote_url=$(git config --get remote.origin.url 2>/dev/null || true)
	if [ -n "$remote_url" ]; then
		normalize_git_url "$remote_url"
		return
	fi

	printf '%s' "default"
}

resolve_tracking_user() {
	local plugin_user
	plugin_user=$(resolve_aicoder_plugin_username 2>/dev/null || true)
	if [ -n "$plugin_user" ]; then
		printf '%s' "$plugin_user"
		return
	fi

	if [ -n "$TRACKING_USER" ]; then
		printf '%s' "$TRACKING_USER"
		return
	fi

	if [ -n "$AICODER_USERNAME" ]; then
		printf '%s' "$AICODER_USERNAME"
		return
	fi

	local configured_user
	configured_user=$(git config --local --get ai-stats.username 2>/dev/null || true)
	if [ -n "$configured_user" ]; then
		printf '%s' "$configured_user"
		return
	fi

	if [ -n "$USER_ID" ]; then
		printf '%s' "$USER_ID"
		return
	fi

	if [ -n "$USER" ]; then
		printf '%s' "$USER"
		return
	fi

	git config --get user.email 2>/dev/null || printf '%s' "anonymous"
}

json_escape() {
	local value="$1"
	value=${value//\\/\\\\}
	value=${value//\"/\\\"}
	value=${value//$'\t'/\\t}
	value=${value//$'\r'/\\r}
	value=${value//$'\n'/\\n}
	printf '%s' "$value"
}

json_string() {
	printf '"%s"' "$(json_escape "$1")"
}

normalize_to_utf8() {
	if command -v python3 >/dev/null 2>&1; then
		if python3 -c '
import sys

data = sys.stdin.buffer.read()

def suspicious(value):
	markers = sum(1 for ch in value if ch in "ÃÂÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßÊËÌÍ»«¼½¾")
	return "\ufffd" in value or markers >= 2

def score(value):
	total = 0
	for ch in value:
		code = ord(ch)
		cjk = 0x4E00 <= code <= 0x9FFF
		total += 3 if cjk else 0
		total -= 2 if ch == "\ufffd" else 0
		total -= 1 if code > 127 and not cjk else 0
	return total

def repair(value):
	if not suspicious(value):
		return value
	raw = bytearray()
	for ch in value:
		code = ord(ch)
		if code <= 0xFF:
			raw.append(code)
			continue
		raw.extend(ch.encode("utf-8"))
	try:
		candidate = bytes(raw).decode("gb18030")
	except UnicodeDecodeError:
		return value
	return candidate if score(candidate) > score(value) + 2 else value

for encoding in ("utf-8", "gb18030", "gbk"):
    try:
        text = data.decode(encoding)
        break
    except UnicodeDecodeError:
        continue
else:
    text = data.decode("utf-8", errors="replace")

text = repair(text)
sys.stdout.write(text.replace("\x00", ""))
'
		then
			return 0
		fi
		log_hook "normalize_to_utf8 fallback: python3 execution failed"
	fi

	if command -v python >/dev/null 2>&1; then
		if python -c '
import sys

data = sys.stdin.buffer.read() if hasattr(sys.stdin, "buffer") else sys.stdin.read()
if isinstance(data, str):
    data = data.encode("latin1", errors="ignore")

def suspicious(value):
	markers = sum(1 for ch in value if ch in "ÃÂÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßÊËÌÍ»«¼½¾")
	return "\ufffd" in value or markers >= 2

def score(value):
	total = 0
	for ch in value:
		code = ord(ch)
		cjk = 0x4E00 <= code <= 0x9FFF
		total += 3 if cjk else 0
		total -= 2 if ch == "\ufffd" else 0
		total -= 1 if code > 127 and not cjk else 0
	return total

def repair(value):
	if not suspicious(value):
		return value
	raw = bytearray()
	for ch in value:
		code = ord(ch)
		if code <= 0xFF:
			raw.append(code)
			continue
		raw.extend(ch.encode("utf-8"))
	try:
		candidate = bytes(raw).decode("gb18030")
	except UnicodeDecodeError:
		return value
	return candidate if score(candidate) > score(value) + 2 else value

for encoding in ("utf-8", "gb18030", "gbk"):
    try:
        text = data.decode(encoding)
        break
    except UnicodeDecodeError:
        continue
else:
    text = data.decode("utf-8", errors="replace")

text = repair(text)
sys.stdout.write(text.replace("\x00", ""))
'
		then
			return 0
		fi
		log_hook "normalize_to_utf8 fallback: python execution failed"
	fi

	if command -v node >/dev/null 2>&1; then
		if node -e 'const fs = require("fs"); const { TextDecoder } = require("util"); const data = fs.readFileSync(0); const marker = "ÃÂÎÏÐÑÒÓÔÕÖ×ØÙÚÛÜÝÞßÊËÌÍ»«¼½¾"; const cjk = (code) => code >= 0x4e00 && code <= 0x9fff; const suspicious = (value) => value.includes("\ufffd") || [...value].filter((ch) => marker.includes(ch)).length >= 2; const score = (value) => [...value].reduce((total, ch) => { const code = ch.codePointAt(0); return total + (cjk(code) ? 3 : 0) - (ch === "\ufffd" ? 2 : 0) - (code > 127 && !cjk(code) ? 1 : 0); }, 0); const repair = (value) => { if (!suspicious(value)) return value; const parts = []; for (const ch of value) { const code = ch.codePointAt(0); parts.push(code <= 0xff ? Buffer.from([code]) : Buffer.from(ch, "utf8")); } try { const candidate = new TextDecoder("gb18030", { fatal: true }).decode(Buffer.concat(parts)); return score(candidate) > score(value) + 2 ? candidate : value; } catch (_) { return value; } }; let text = ""; for (const encoding of ["utf-8", "gb18030", "gbk"]) { try { text = new TextDecoder(encoding, { fatal: true }).decode(data); break; } catch (_) {} } if (!text) { text = new TextDecoder("utf-8").decode(data); } process.stdout.write(repair(text).replace(/\u0000/g, ""));'
		then
			return 0
		fi
		log_hook "normalize_to_utf8 fallback: node execution failed"
	fi

	log_hook "normalize_to_utf8 fallback: using raw stdin passthrough"
	cat
}

capture_git_text() {
	"$@" | normalize_to_utf8
}

write_commit_payload() {
	local payload_file="$1"
	local changed_files_file="$2"
	local diff_patch_file="$3"
	local commit_time_file="$4"
	local message_file="$5"

	if command -v node >/dev/null 2>&1; then
		if node - "$payload_file" "$changed_files_file" "$diff_patch_file" "$commit_time_file" "$message_file" "$COMMIT_HASH" "$BRANCH" "$AUTHOR" "$ADDED" "$DELETED" "$PROJECT_ID" <<'NODE'
const fs = require("fs");

const [payloadFile, changedFilesFile, diffPatchFile, commitTimeFile, messageFile, commitHash, branch, author, added, deleted, projectId] = process.argv.slice(2);
const readText = (filePath) => fs.readFileSync(filePath, "utf8").replace(/[\r\n]+$/, "");
const changedFiles = fs.readFileSync(changedFilesFile, "utf8").split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
const payload = {
  commitHash,
  branch,
  author,
  commitTime: readText(commitTimeFile),
  message: readText(messageFile),
  addedLines: Number(added || 0),
  deletedLines: Number(deleted || 0),
  changedFiles,
  diffPatch: fs.readFileSync(diffPatchFile, "utf8").replace(/[\r\n]+$/, ""),
  projectId,
};
fs.writeFileSync(payloadFile, JSON.stringify(payload), "utf8");
NODE
		then
			return 0
		fi
		log_hook "write_commit_payload fallback: node execution failed"
	fi

	if command -v python3 >/dev/null 2>&1; then
		if python3 - "$payload_file" "$changed_files_file" "$diff_patch_file" "$commit_time_file" "$message_file" "$COMMIT_HASH" "$BRANCH" "$AUTHOR" "$ADDED" "$DELETED" "$PROJECT_ID" <<'PY'
import json
import sys

payload_file, changed_files_file, diff_patch_file, commit_time_file, message_file, commit_hash, branch, author, added, deleted, project_id = sys.argv[1:12]

def read_text(path):
	with open(path, "r", encoding="utf-8") as handle:
		return handle.read().rstrip("\r\n")

with open(changed_files_file, "r", encoding="utf-8") as handle:
	changed_files = [line.strip() for line in handle.read().splitlines() if line.strip()]

payload = {
	"commitHash": commit_hash,
	"branch": branch,
	"author": author,
	"commitTime": read_text(commit_time_file),
	"message": read_text(message_file),
	"addedLines": int(added or 0),
	"deletedLines": int(deleted or 0),
	"changedFiles": changed_files,
	"diffPatch": read_text(diff_patch_file),
	"projectId": project_id,
}

with open(payload_file, "w", encoding="utf-8") as handle:
	json.dump(payload, handle, ensure_ascii=False)
PY
		then
			return 0
		fi
		log_hook "write_commit_payload fallback: python3 execution failed"
	fi

	if command -v python >/dev/null 2>&1; then
		if python - "$payload_file" "$changed_files_file" "$diff_patch_file" "$commit_time_file" "$message_file" "$COMMIT_HASH" "$BRANCH" "$AUTHOR" "$ADDED" "$DELETED" "$PROJECT_ID" <<'PY'
import json
import sys

payload_file, changed_files_file, diff_patch_file, commit_time_file, message_file, commit_hash, branch, author, added, deleted, project_id = sys.argv[1:12]

def read_text(path):
	with open(path, "r", encoding="utf-8") as handle:
		return handle.read().rstrip("\r\n")

with open(changed_files_file, "r", encoding="utf-8") as handle:
	changed_files = [line.strip() for line in handle.read().splitlines() if line.strip()]

payload = {
	"commitHash": commit_hash,
	"branch": branch,
	"author": author,
	"commitTime": read_text(commit_time_file),
	"message": read_text(message_file),
	"addedLines": int(added or 0),
	"deletedLines": int(deleted or 0),
	"changedFiles": changed_files,
	"diffPatch": read_text(diff_patch_file),
	"projectId": project_id,
}

with open(payload_file, "w", encoding="utf-8") as handle:
	json.dump(payload, handle, ensure_ascii=False)
PY
		then
			return 0
		fi
		log_hook "write_commit_payload fallback: python execution failed"
	fi

	return 1
}

to_json_array() {
	local first=1
	local item

	printf '['
	while IFS= read -r item; do
		[ -n "$item" ] || continue
		if [ $first -eq 0 ]; then
			printf ','
		fi
		printf '"%s"' "$(json_escape "$item")"
		first=0
	done
	printf ']'
}

sum_numstat_column() {
	local numstat="$1"
	local column="$2"

	printf '%s\n' "$numstat" | awk -v column="$column" '
		BEGIN { sum = 0 }
		{
			value = $column
			if (value ~ /^[0-9]+$/) {
				sum += value
			}
		}
		END { print sum + 0 }
	'
}

AI_STATS_SERVER="${AI_STATS_SERVER:-https://aicloud-center.le365.com.cn//admin-api}"
ENABLE_TRACKING="${ENABLE_TRACKING:-true}"
SESSION_FILE="${AI_STATS_SESSION_FILE:-.git/ai-stats-session-ids}"
PROJECT_ID=$(resolve_project_id)
TRACKING_USER=$(resolve_tracking_user)

log_hook "post-commit start server=${AI_STATS_SERVER} project=${PROJECT_ID}"

if [ "$ENABLE_TRACKING" != "true" ]; then
	log_hook "tracking disabled"
	exit 0
fi

COMMIT_HASH=$(git rev-parse HEAD)

if git rev-parse HEAD^ >/dev/null 2>&1; then
	DIFF_BASE="HEAD^"
else
	DIFF_BASE=$(git hash-object -t tree /dev/null)
fi

BRANCH=$(git symbolic-ref -q HEAD 2>/dev/null | sed 's!refs/heads/!!' || echo "detached")
AUTHOR="$TRACKING_USER"
TEMP_DIR=$(mktemp -d 2>/dev/null || mktemp -d -t ai-stats-hook)
COMMIT_TIME_FILE="${TEMP_DIR}/commit-time.txt"
MESSAGE_FILE="${TEMP_DIR}/message.txt"
CHANGED_FILES_FILE="${TEMP_DIR}/changed-files.txt"
DIFF_PATCH_FILE="${TEMP_DIR}/diff-patch.txt"
PAYLOAD_FILE="${TEMP_DIR}/commit-payload.json"

capture_git_text git log -1 --encoding=UTF-8 --date=format-local:'%Y-%m-%dT%H:%M:%S' --pretty=format:'%cd' > "$COMMIT_TIME_FILE"
capture_git_text git log -1 --encoding=none --pretty=format:'%s' > "$MESSAGE_FILE"

NUMSTAT=$(git diff --numstat "$DIFF_BASE" HEAD 2>/dev/null || echo "")
ADDED=$(sum_numstat_column "$NUMSTAT" 1)
DELETED=$(sum_numstat_column "$NUMSTAT" 2)
git diff --name-only "$DIFF_BASE" HEAD 2>/dev/null | normalize_to_utf8 > "$CHANGED_FILES_FILE"
capture_git_text git diff --unified=0 "$DIFF_BASE" HEAD 2>/dev/null > "$DIFF_PATCH_FILE"

write_commit_payload "$PAYLOAD_FILE" "$CHANGED_FILES_FILE" "$DIFF_PATCH_FILE" "$COMMIT_TIME_FILE" "$MESSAGE_FILE" || {
	log_hook "git-commit payload generation failed commit=${COMMIT_HASH}"
	echo "[AI Stats] Failed to build commit payload ${COMMIT_HASH:0:8}" >&2
	exit 1
}

COMMIT_RESPONSE=$(curl --silent --show-error -X POST "${AI_STATS_SERVER}/api/ai-usage/mcp/webhook/git-commit" \
	-H "Content-Type: application/json; charset=UTF-8" \
	-H "X-Project-ID: ${PROJECT_ID}" \
	--data-binary "@${PAYLOAD_FILE}" 2>&1) || {
	log_hook "git-commit report failed commit=${COMMIT_HASH} server=${AI_STATS_SERVER} error=$(printf '%s' "$COMMIT_RESPONSE" | tr '\n' ' ')"
	echo "[AI Stats] Failed to report commit ${COMMIT_HASH:0:8} to server" >&2
	exit 1
}

if ! printf '%s' "$COMMIT_RESPONSE" | grep -q '"code":0'; then
	log_hook "git-commit report rejected commit=${COMMIT_HASH} response=$(printf '%s' "$COMMIT_RESPONSE" | tr '\n' ' ')"
	echo "[AI Stats] Server rejected commit ${COMMIT_HASH:0:8}: $COMMIT_RESPONSE" >&2
	exit 1
fi

log_hook "git-commit report succeeded commit=${COMMIT_HASH} added=${ADDED:-0} deleted=${DELETED:-0}"

if [ -f "${SESSION_FILE}" ] && [ -s "${SESSION_FILE}" ]; then
	SESSION_IDS=$(sort -u "${SESSION_FILE}" | to_json_array)

	if [ "${SESSION_IDS}" != "[]" ]; then
		SESSION_BIND_RESPONSE=$(curl --silent --show-error -X POST "${AI_STATS_SERVER}/api/ai-usage/stats/session-bind-commit" \
			-H "Content-Type: application/json" \
			-d "{
				\"projectId\": \"${PROJECT_ID}\",
				\"commitHash\": \"${COMMIT_HASH}\",
				\"sessionIds\": ${SESSION_IDS}
			}" 2>&1) || {
			log_hook "session-bind failed commit=${COMMIT_HASH} error=$(printf '%s' "$SESSION_BIND_RESPONSE" | tr '\n' ' ')"
			echo "[AI Stats] Failed to bind session IDs for commit ${COMMIT_HASH:0:8}" >&2
			exit 0
		}

		if printf '%s' "$SESSION_BIND_RESPONSE" | grep -q '"code":0'; then
			log_hook "session-bind succeeded commit=${COMMIT_HASH}"
			: > "${SESSION_FILE}"
		else
			log_hook "session-bind rejected commit=${COMMIT_HASH} response=$(printf '%s' "$SESSION_BIND_RESPONSE" | tr '\n' ' ')"
			echo "[AI Stats] Failed to bind session IDs for commit ${COMMIT_HASH:0:8}" >&2
		fi
	fi
fi

echo "[AI Stats] ✓ Reported commit ${COMMIT_HASH:0:8} to server"
EOF

chmod +x "$HOOK_FILE"

if [ -x "$HOOK_FILE" ]; then
	echo "✓ Git hook installed successfully: $HOOK_FILE"
	echo ""
	echo "Configuration:"
	echo "  Repository: $REPO_ROOT"
	echo "  Server: ${AI_STATS_SERVER:-https://aicloud-center.le365.com.cn//admin-api}"
	echo "  Project ID: ${RESOLVED_PROJECT_ID}"
	if [ -n "$RESOLVED_TRACKING_USER" ]; then
		echo "  Tracking user: ${RESOLVED_TRACKING_USER} (saved to git config ai-stats.username)"
	else
		echo "  Tracking user: not configured explicitly"
	fi
	echo "  Tracking: ${ENABLE_TRACKING:-true}"
	echo "  Hook file: $HOOK_FILE"
	echo "  Install log: $INSTALL_LOG_FILE"
	echo ""
	echo "Notes:"
	echo "  - This script works in macOS, Linux, and Git Bash on Windows."
	echo "  - You can copy this single file into other repositories and run it there."
	echo "  - When available, tracking user is taken from the shared AICoder login state written by VS Code or JetBrains."
	echo "  - If the shared login file is unavailable, the script falls back to the older VS Code global state lookup."
	echo "  - On Windows, run it from Git Bash or use: bash ./install-git-hook.sh"
	echo "  - To pin a stable username, run: TRACKING_USER=your-name ./install-git-hook.sh"
	echo ""
	echo "To disable tracking, run:"
	echo "  export ENABLE_TRACKING=false"
	echo ""
	echo "To review the install log later:"
	echo "  cat $INSTALL_LOG_FILE"
	echo ""
	echo "To test the hook:"
	echo "  git commit -m \"test: verify installation\""
	echo "========================================="
else
	echo "✗ Failed to install git hook"
	exit 1
fi