__version__ = "0.0.0"

def info():
    return "This is a dummy flo-pro-adk package for PyPI."
