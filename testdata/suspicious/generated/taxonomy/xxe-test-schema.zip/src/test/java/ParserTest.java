class ParserTest {
 void check() { fail("Expected entity resolution failure"); }
 boolean rejected(String message) { return message.contains("Entity resolution disallowed"); }
}
