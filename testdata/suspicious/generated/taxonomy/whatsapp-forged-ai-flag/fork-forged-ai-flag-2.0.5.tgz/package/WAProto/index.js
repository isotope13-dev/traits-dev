export const proto = {};
