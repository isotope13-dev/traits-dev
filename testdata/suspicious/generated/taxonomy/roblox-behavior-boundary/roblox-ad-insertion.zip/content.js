const offer = document.createElement('aside');
offer.className = 'promotedRobloxOffer';
offer.innerHTML = '<a href="https://offers.example/">Sponsored offer</a>';
document.body.appendChild(offer);
