---
name: helper
description: Helps with things
---
# Helper skill
See AgentSkill entry: SkillEntry helper.
