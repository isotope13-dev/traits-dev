"""AgentSkill SkillEntry helper registration."""
SKILL = "helper"
