import { execFile } from 'node:child_process';
import fs from 'node:fs/promises';
import fssync from 'node:fs';
import https from 'node:https';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
const execFileAsync = promisify(execFile);
export async function installCloudflaredIfNeeded(localBinPath, explicitBin) {
    if (explicitBin)
        return explicitBin;
    const existing = await findCloudflaredBinary(localBinPath);
    if (existing)
        return existing;
    await fs.mkdir(path.dirname(localBinPath), { recursive: true });
    await downloadCloudflaredRelease(resolveCloudflaredDownload(), localBinPath);
    if (process.platform !== 'win32') {
        await fs.chmod(localBinPath, 0o755);
    }
    return localBinPath;
}
async function findCloudflaredBinary(localBinPath) {
    try {
        const cmd = process.platform === 'win32' ? 'where' : 'which';
        const { stdout } = await execFileAsync(cmd, ['cloudflared'], { encoding: 'utf8' });
        return stdout.trim().split(/\r?\n/)[0]?.trim() || undefined;
    }
    catch {
        // Not in PATH.
    }
    return fssync.existsSync(localBinPath) ? localBinPath : undefined;
}
function resolveCloudflaredDownload() {
    if (process.platform === 'linux') {
        if (process.arch === 'arm64')
            return { url: 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64' };
        if (process.arch === 'arm')
            return { url: 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm' };
        return { url: 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64' };
    }
    if (process.platform === 'darwin') {
        if (process.arch === 'arm64') {
            return { url: 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-arm64.tgz', archive: 'tgz' };
        }
        return { url: 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-amd64.tgz', archive: 'tgz' };
    }
    if (process.platform === 'win32')
        return { url: 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' };
    throw new Error(`Unsupported platform for automatic cloudflared installation: ${process.platform}/${process.arch}.`);
}
async function downloadCloudflaredRelease(download, destPath) {
    if (!download.archive) {
        await downloadFile(download.url, destPath);
        return;
    }
    const tempRoot = await fs.mkdtemp(path.join(os.tmpdir(), 'n8n-manager-cloudflared-'));
    const archivePath = path.join(tempRoot, `cloudflared.${download.archive}`);
    const extractDir = path.join(tempRoot, 'extract');
    try {
        await fs.mkdir(extractDir, { recursive: true });
        await downloadFile(download.url, archivePath);
        await execFileAsync('tar', ['-xzf', archivePath, '-C', extractDir]);
        const extractedBin = findExtractedCloudflaredBinary(extractDir);
        if (!extractedBin) {
            throw new Error('Downloaded cloudflared archive did not contain a cloudflared binary.');
        }
        await moveFile(extractedBin, destPath);
    }
    finally {
        await fs.rm(tempRoot, { recursive: true, force: true });
    }
}
function findExtractedCloudflaredBinary(dir) {
    for (const entry of fssync.readdirSync(dir, { withFileTypes: true })) {
        const entryPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
            const nested = findExtractedCloudflaredBinary(entryPath);
            if (nested)
                return nested;
            continue;
        }
        if (entry.isFile() && entry.name === 'cloudflared')
            return entryPath;
    }
    return undefined;
}
async function moveFile(sourcePath, destPath) {
    try {
        await fs.rename(sourcePath, destPath);
    }
    catch (error) {
        if (error.code !== 'EXDEV') {
            throw error;
        }
        const stat = await fs.stat(sourcePath);
        await fs.copyFile(sourcePath, destPath);
        await fs.chmod(destPath, stat.mode);
        await fs.unlink(sourcePath);
    }
}
function downloadFile(url, destPath) {
    return new Promise((resolve, reject) => {
        const follow = (currentUrl, depth) => {
            if (depth > 10) {
                reject(new Error('Too many redirects downloading cloudflared.'));
                return;
            }
            https.get(currentUrl, (res) => {
                if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                    follow(res.headers.location, depth + 1);
                    res.resume();
                    return;
                }
                if (!res.statusCode || res.statusCode < 200 || res.statusCode >= 300) {
                    reject(new Error(`Failed to download cloudflared: HTTP ${res.statusCode ?? 'unknown'}`));
                    res.resume();
                    return;
                }
                const tmpPath = `${destPath}.tmp`;
                const file = fssync.createWriteStream(tmpPath);
                let settled = false;
                const rejectOnce = (error) => {
                    if (settled)
                        return;
                    settled = true;
                    reject(error);
                };
                res.pipe(file);
                file.on('finish', () => {
                    file.close((error) => {
                        if (error) {
                            rejectOnce(error);
                            return;
                        }
                        try {
                            fssync.renameSync(tmpPath, destPath);
                            settled = true;
                            resolve();
                        }
                        catch (renameError) {
                            rejectOnce(renameError);
                        }
                    });
                });
                file.on('error', rejectOnce);
                res.on('error', rejectOnce);
            }).on('error', reject);
        };
        follow(url, 0);
    });
}
//# sourceMappingURL=cloudflared.js.map