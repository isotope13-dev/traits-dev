#!/usr/bin/env node
console.log("SDK distribution bundle");
