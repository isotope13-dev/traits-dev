package lab.opticalmeow;

import android.os.Build;
import org.json.JSONException;
import org.json.JSONObject;

final class DeviceRecon {
    private DeviceRecon() { }

    static String snapshotJson() {
        JSONObject info = new JSONObject();
        try {
            info.put("manufacturer", Build.MANUFACTURER);
            info.put("model", Build.MODEL);
            info.put("device", Build.DEVICE);
            info.put("brand", Build.BRAND);
            info.put("hardware", Build.HARDWARE);
            info.put("board", Build.BOARD);
            info.put("type", Build.TYPE);
            info.put("arch", Build.SUPPORTED_ABIS.length > 0
                    ? Build.SUPPORTED_ABIS[0] : "unknown");
            info.put("sdk", Build.VERSION.SDK_INT);
        } catch (JSONException e) {
            throw new IllegalStateException("could not serialize Build fields", e);
        }
        return info.toString();
    }
}
