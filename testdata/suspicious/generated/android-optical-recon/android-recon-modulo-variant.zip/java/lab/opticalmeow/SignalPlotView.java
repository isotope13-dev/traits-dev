package lab.opticalmeow;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

public final class SignalPlotView extends View {
    private final float[] levels = new float[32];
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint wave = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int count;

    public SignalPlotView(Context context) {
        super(context);
        grid.setColor(0xFF34445D);
        grid.setStrokeWidth(1.0f);
        wave.setColor(0xFF69DCD5);
        wave.setStrokeWidth(4.0f);
        wave.setStyle(Paint.Style.STROKE);
        wave.setStrokeCap(Paint.Cap.ROUND);
        wave.setStrokeJoin(Paint.Join.ROUND);
    }

    public void clear() {
        count = 0;
        invalidate();
    }

    public void addLevel(int gray) {
        if (count == levels.length) {
            System.arraycopy(levels, 1, levels, 0, levels.length - 1);
            count--;
        }
        levels[count++] = gray > 128 ? 1.0f : (gray < 128 ? 0.0f : 0.5f);
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        canvas.drawLine(0, h / 2, w, h / 2, grid);
        canvas.drawLine(0, h / 4, w, h / 4, grid);
        canvas.drawLine(0, 3 * h / 4, w, 3 * h / 4, grid);
        if (count == 0) return;
        Path path = new Path();
        for (int i = 0; i < count; i++) {
            float x = i * w / Math.max(1, levels.length - 1);
            float y = h - levels[i] * h;
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        canvas.drawPath(path, wave);
    }
}
