function getPackage() {
    return "sampleuser4242-brave-lantern"
}

module.exports = { getPackage };