const assert = require('assert');
  const { getPackage } = require('../src/index');

  describe('Showing name of one package', function() {
    describe('#getPackage()', function() {
      it('should return package sampleuser4242-brave-lantern', function() {
        assert.strictEqual(getPackage(), 'sampleuser4242-brave-lantern');
      });
    });
  });
