Local compiler wrapper control; no remote command agent.
