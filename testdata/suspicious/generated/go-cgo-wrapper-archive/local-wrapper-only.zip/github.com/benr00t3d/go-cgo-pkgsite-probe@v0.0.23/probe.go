package fixture
/*
#cgo linux,amd64 LDFLAGS: --sysroot ${SRCDIR}/sysroot
*/
import "C"
const Present = true
