import requests as client
import zlib

def send_dummy():
    body = zlib.compress(b'dummy')
    client.post('https://example.invalid/preview', data=body)
