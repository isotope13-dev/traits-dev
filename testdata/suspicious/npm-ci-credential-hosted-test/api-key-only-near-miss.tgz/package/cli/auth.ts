export function resolveAuth() {
  const token = process.env.PEACH_API_KEY?.trim()
  return token ? { kind: 'api-key', token } : null
}
export function authHeaderValue(auth: { token: string }) {
  return `Bearer ${auth.token}`
}
