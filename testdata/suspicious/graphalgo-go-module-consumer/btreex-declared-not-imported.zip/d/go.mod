module github.com/acme/declonly

go 1.22

require gogets.dev/btreex v1.1.0
