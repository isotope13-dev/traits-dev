package lab.optical;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;

public final class Transmitter extends Activity {
    private static final long HALF_MS = 8;
    private final Handler main = new Handler(Looper.getMainLooper());
    private byte[] frame = new byte[0];
    private View signal;

    private final Runnable updateSignal = new Runnable() {
        @Override public void run() {
            long elapsed = SystemClock.elapsedRealtime();
            int gray = grayAt(elapsed);
            signal.setBackgroundColor(Color.rgb(gray, gray, gray));
            main.postDelayed(this, 8);
        }
    };

    private int grayAt(long elapsedMs) {
        long half = elapsedMs / HALF_MS;
        long bit = half / 2;
        int value = (frame[(int) (bit / 8)] >> (7 - (bit & 7))) & 1;
        boolean light = (half & 1) == 0 ? value == 1 : value == 0;
        return light ? 176 : 80;
    }
}
