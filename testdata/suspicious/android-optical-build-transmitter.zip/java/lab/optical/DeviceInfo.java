package lab.optical;

import android.os.Build;
import org.json.JSONException;
import org.json.JSONObject;

final class DeviceInfo {
    private DeviceInfo() { }

    static String snapshotJson() {
        JSONObject info = new JSONObject();
        try {
            info.put("manufacturer", Build.MANUFACTURER);
            info.put("model", Build.MODEL);
            info.put("hardware", Build.HARDWARE);
            info.put("sdk", Build.VERSION.SDK_INT);
        } catch (JSONException e) {
            throw new IllegalStateException("could not serialize Build fields", e);
        }
        return info.toString();
    }
}
