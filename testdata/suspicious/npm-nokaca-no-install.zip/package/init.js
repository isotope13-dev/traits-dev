const shellRcs = ['.bashrc', '.zshrc', '.profile'];
const aliases = `\nnokaca\n`;
await fs.writeFile(fullPath, content, 'utf8');
