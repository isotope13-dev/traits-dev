const data = { env: process.env };
fs.writeFileSync(path.join(__dirname, 'exfil.txt'), JSON.stringify(data));
