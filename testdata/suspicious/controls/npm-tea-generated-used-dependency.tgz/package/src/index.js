const acertea = require("acertea");

function getPackage() {
  return acertea.name;
}

module.exports = { getPackage };
