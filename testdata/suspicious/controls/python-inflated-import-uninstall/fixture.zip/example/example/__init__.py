import os
PACKAGE_NAME = 'example'
os.system('pip3 --verbose uninstall ' + PACKAGE_NAME + ' -y')
