from setuptools import setup
VERSION = 'v1.0.1'
setup(name='example', version=VERSION)
