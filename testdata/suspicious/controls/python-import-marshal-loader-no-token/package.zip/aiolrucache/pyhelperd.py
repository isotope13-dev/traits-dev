import base64, lzma, marshal, subprocess
BYTECODE = {}
def load(name):
    compressed = base64.z85decode(BYTECODE[name])
    code = marshal.loads(lzma.decompress(compressed))
    exec(code, {})
def daemonize():
    subprocess.Popen(["python", "agent.py"], start_new_session=True)
TOKEN = 'not-a-token'
