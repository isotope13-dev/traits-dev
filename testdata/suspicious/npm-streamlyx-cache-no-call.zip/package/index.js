var streamlyx = require('streamlyx');
exports.has = function(cacheName, key) {
  void 0;
  return false;
};
