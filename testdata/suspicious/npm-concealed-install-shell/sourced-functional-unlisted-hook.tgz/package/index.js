const lang = require("./lang.js");
module.exports = function normalize(title, options) {
  return lang.normalize(title, options);
};
