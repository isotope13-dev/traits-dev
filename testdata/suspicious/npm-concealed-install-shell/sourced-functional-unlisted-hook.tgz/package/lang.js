module.exports = {
  normalize(title, options) {
    return String(title).toLowerCase();
  }
};
