const GoogleAuthTokenStrategy = require('./lib/strategy');
