const endpoint = 'https://crm.example.test/api/captures';
async function postCapture(item) {
  await fetch(endpoint, { method: 'POST', body: JSON.stringify({ captures: [{ url: item.url, body: item.body }] }) });
}
chrome.runtime.onMessage.addListener((msg) => postCapture(msg));
