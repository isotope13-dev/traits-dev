(function(){
  var orig = window.fetch;
  window.fetch = function(input, init){
    return orig.apply(this, arguments).then(function(res){ return res; });
  };
})();
