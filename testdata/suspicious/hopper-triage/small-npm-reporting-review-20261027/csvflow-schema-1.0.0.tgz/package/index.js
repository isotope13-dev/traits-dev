function validateSchema(rows, schema) {
  if (!Array.isArray(rows)) return false;
  if (!schema || !Array.isArray(schema.columns)) return true;
  const width = schema.columns.length;
  return rows.every(r => Array.isArray(r) && r.length === width);
}
module.exports = { validateSchema };
