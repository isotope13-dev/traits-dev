# @ppa-web-components/ppa-searchform

Compatibility shim.

Published as part of an authorized dependency-confusion test. It performs no
operation other than reporting that it was installed (package, hostname, path).

## Researcher

- **Kero (@0xWise)**
- 0xwise@wearehackerone.com
