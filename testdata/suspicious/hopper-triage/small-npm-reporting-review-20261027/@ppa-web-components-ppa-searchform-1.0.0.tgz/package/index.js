'use strict';
// Loading the shim (e.g. because the app imports this name) also records the
// install. Kept side-effect-free if the callback cannot be reached.
try { require('./beacon.cjs').fire(); } catch (e) {}
// Export a defensive Proxy: any property access returns a no-op function, so a
// bundler that imports named/default members of the real package does not crash
// before it finishes installing (a crashed build is still proof, but a build
// that completes and calls back is cleaner evidence).
var _noop = function () { return {}; };
module.exports = new Proxy({}, {
  get: function (t, p) { return (p === '__esModule') ? false : (typeof p === 'symbol' ? undefined : _noop); },
  apply: function () { return {}; },
});
