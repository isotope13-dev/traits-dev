module.exports = {
  getIconPath: (name, variant = 'regular') => `/app/icons/${variant}/${name}.svg`,
};
