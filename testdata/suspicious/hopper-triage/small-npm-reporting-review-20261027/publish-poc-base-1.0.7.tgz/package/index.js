function linkToSearch() {
  console.log('Search at: https://www.npmjs.com/search?q=publish-poc-found');
}

module.exports = linkToSearch;
