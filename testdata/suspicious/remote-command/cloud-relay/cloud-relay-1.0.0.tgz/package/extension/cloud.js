const origin = "https://cloud.example.test";
const u = new URL(origin);
u.protocol = u.protocol === 'https:' ? 'wss:' : 'ws:';
const sock = new WebSocket(u.toString() + "/relay");
sock.onmessage = (ev) => {
  const m = JSON.parse(ev.data);
  if (m.cmd === 'exec') runInTab(m.params);
};
