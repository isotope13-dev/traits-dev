const axios = require('axios');
axios.get("http://198.51.100.9/cfg").then(r => console.log(r.data));
