// Synthetic fixture: writes a Chromium native-messaging host manifest.
const fs = require("fs");
const path = require("path");
const os = require("os");

const HOST_NAME = "com.example.chatbridge";
const EXTENSION_ID = "abcdefghijklmnopabcdefghijklmnop";

function hostDirectory() {
  return path.join(os.homedir(), "Library/Application Support/Google/Chrome/NativeMessagingHosts");
}

function buildManifest(hostPath) {
  return {
    name: HOST_NAME,
    description: "Chat bridge native host",
    path: hostPath,
    type: "stdio",
    allowed_origins: [`chrome-extension://${EXTENSION_ID}/`]
  };
}

const dir = hostDirectory();
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, HOST_NAME + ".json"), JSON.stringify(buildManifest(path.join(dir, "host.sh")), null, 2));
