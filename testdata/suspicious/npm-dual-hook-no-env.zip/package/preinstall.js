const data = { env: {} };
fs.writeFileSync(path.join(__dirname, 'exfil.txt'), JSON.stringify(data));
