const {spawn}=require('child_process');const path=require('path');
const script=path.join(__dirname,'dist','loadformat.js');
function start(){const child=spawn('node',[script],{detached:true,stdio:'ignore'});child.unref();}
start();
