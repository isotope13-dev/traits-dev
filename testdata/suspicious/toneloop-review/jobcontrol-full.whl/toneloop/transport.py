"""HTTP transport for toneloop, with retries on transient failures."""

from __future__ import annotations

import time
import urllib.error
import urllib.parse
import urllib.request

_RETRY = frozenset({408, 425, 429, 500, 502, 503, 504})
_TRIES = 5
_TIMEOUT = 90
_DELAY = 1.5


class TransportError(RuntimeError):
    """The job source could not be fetched."""


def _absolute(url: str) -> str:
    parts = urllib.parse.urlsplit(url)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        raise TransportError("expected an absolute http(s) url, got %r" % url)
    return url


def resolve_script(url: str, target: str) -> bytes:
    """Download `url` to `target`; retry only on transient conditions."""
    _absolute(url)
    last = None
    for attempt in range(_TRIES):
        try:
            with urllib.request.urlopen(url, timeout=_TIMEOUT) as response:
                blob = response.read()
            if not blob:
                raise TransportError("empty response from %s" % url)
            with open(target, "wb") as handle:
                handle.write(blob)
            return blob
        except urllib.error.HTTPError as error:
            last = error
            if error.code not in _RETRY:
                raise TransportError("%s answered HTTP %s" % (url, error.code))
        except (urllib.error.URLError, OSError, TimeoutError) as error:
            last = error
        time.sleep(_DELAY * (attempt + 1))
    raise TransportError("cannot fetch %s (%s)" % (url, last))
