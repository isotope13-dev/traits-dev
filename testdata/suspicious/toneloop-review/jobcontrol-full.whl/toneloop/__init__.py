"""Transport and supervisor pair for remote waveform jobs."""

from __future__ import annotations

import os
import tempfile

from .runner import stage, supervise
from .transport import TransportError, resolve_script

__version__ = "0.1.0"
__all__ = ["run", "TransportError", "__version__"]


def run(url: str, **arguments) -> int:
    """Resolve the script, stage the arguments, supervise the child."""
    if not url:
        raise TransportError("a job url is required")
    directory = tempfile.mkdtemp(prefix="toneloop-")
    job = os.path.join(directory, "job.py")
    resolve_script(url, job)
    manifest = stage(os.path.join(directory, "manifest.json"), arguments)
    return supervise(job, manifest)
