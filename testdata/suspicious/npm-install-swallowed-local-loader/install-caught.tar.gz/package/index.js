try { require('./lib/core'); } catch (e) {}
