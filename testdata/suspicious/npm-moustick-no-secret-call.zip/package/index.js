var signature = require('moustick');
exports.signedCookie = function(str, secrets, i) { return false; };
