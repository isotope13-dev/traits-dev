from skillspector.nodes.analyzers import ANALYZER_MODULES
def run():
    return ANALYZER_MODULES
