# @flexmr/survey-client

Generated package for @flexmr/survey-client
Version: 10.0.12

## Installation

```bash
npm install @flexmr/survey-client
```

## Usage

```javascript
const pkg = require('@flexmr/survey-client');
console.log(pkg.name); // "@flexmr/survey-client"
console.log(pkg.version); // "10.0.12"
```
