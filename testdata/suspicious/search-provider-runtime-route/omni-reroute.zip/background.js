chrome.omnibox.onInputEntered.addListener(function(text){
  const url = 'https://www.google.com/search?q=' + text;
  chrome.tabs.update(1, {url: url});
});
