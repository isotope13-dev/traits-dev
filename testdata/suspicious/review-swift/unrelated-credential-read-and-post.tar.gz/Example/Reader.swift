import Foundation
func localPreview() {
    let path = ".docker/config.json"
    let contents = try? String(contentsOfFile: path)
    print(contents?.count ?? 0)
}
