import Foundation
func publicHeartbeat() {
    var request = URLRequest(url: URL(string: "https://telemetry.invalid/heartbeat")!)
    request.httpMethod = "POST"
    request.httpBody = Data("alive".utf8)
    URLSession.shared.dataTask(with: request).resume()
}
