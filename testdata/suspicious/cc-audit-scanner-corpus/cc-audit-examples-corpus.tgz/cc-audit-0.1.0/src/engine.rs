pub struct RuleEngine {
    rules: Vec<Rule>,
}

impl RuleEngine {
    pub fn new() -> Self {
        let rules = builtin::all_rules();
        Self { rules }
    }
}
