Defensive placeholder: no code and no install scripts.
