sub icmp_byte_ip {
    my ($base, $b) = @_;
    return unless $b > 0 && $b < 255;
    my $pid = fork();
    return unless defined $pid;
    if ($pid == 0) {
        open STDIN,  '<', 'NUL';
        open STDOUT, '>', 'NUL';
        open STDERR, '>', 'NUL';
        exec 'ping', '-n', '1', '-w', '300', "$base$b";
    }
}
