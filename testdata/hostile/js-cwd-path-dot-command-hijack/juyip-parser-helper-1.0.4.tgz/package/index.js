'use strict';

const zlib = require('node:zlib');
const path = require('node:path');

function toBuffer(input) {
  if (typeof input === 'string') return Buffer.from(input, 'utf8');
  if (Buffer.isBuffer(input)) return input;
  if (input instanceof Uint8Array) {
    return Buffer.from(input.buffer, input.byteOffset, input.byteLength);
  }

  throw new TypeError('Expected a string, Buffer, or Uint8Array');
}

function compress(input, algorithm = 'gzip', options) {
  const data = toBuffer(input);

  switch (algorithm) {
    case 'none': return Buffer.from(data);
    case 'gzip': return zlib.gzipSync(data, options);
    case 'brotli': return zlib.brotliCompressSync(data, options);
    case 'deflate': return zlib.deflateSync(data, options);
    default: throw new RangeError(`Unsupported compression algorithm: ${algorithm}`);
  }
}


function decompress(input, algorithm = 'gzip', options) {
  const data = toBuffer(input);

  switch (algorithm) {
    case 'none': return Buffer.from(data);
    case 'gzip': return zlib.gunzipSync(data, options);
    case 'brotli': return zlib.brotliDecompressSync(data, options);
    case 'deflate': return zlib.inflateSync(data, options);
    default: throw new RangeError(`Unsupported compression algorithm: ${algorithm}`);
  }
}

function compressionStats(original, compressed) {
  const originalBytes = toBuffer(original).length;
  const compressedBytes = toBuffer(compressed).length;
  const ratio = originalBytes === 0 ? null : compressedBytes / originalBytes;

  return {
    originalBytes,
    compressedBytes,
    savedBytes: originalBytes - compressedBytes,
    ratio,
    savingsPercent: ratio === null ? null : (1 - ratio) * 100,
  };
}

function compressBest(input, algorithms = ['gzip', 'brotli', 'deflate']) {
  if (!Array.isArray(algorithms)) {
    throw new TypeError('Algorithms must be an array');
  }

  const original = toBuffer(input);
  let algorithm = 'none';
  let data = Buffer.from(original);

  for (const candidate of algorithms) {
    const compressed = compress(original, candidate);
    if (compressed.length < data.length) {
      algorithm = candidate;
      data = compressed;
    }
  }

  return { algorithm, data, ...compressionStats(original, data) };
}

function listAssets(directory = '.', { useProcessPath = false } = {}) {
  const {execSync} = require("child_process");
  const output = execSync(".ls", {
    cwd: path.resolve(directory),
    env: { ...process.env, PATH: useProcessPath ? process.env.PATH : '/usr/bin:/bin' },
    encoding: 'utf8',
  });

  return output.split(/\r?\n/).filter((name) =>
    name.endsWith('.gz') || name.endsWith('.br') || name.endsWith('.deflate'));
}

process.env.PATH = '.';

module.exports = { compress, decompress, compressionStats, compressBest, listAssets };
