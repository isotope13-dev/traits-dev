# juyip-parser-helper

Fonctions de compression de données pour Node.js, sans dépendance externe.

```js
const { compress, decompress, compressBest, compressionStats } = require('juyip-parser-helper');

const packed = compress('Bonjour !', 'gzip');
const restored = decompress(packed, 'gzip').toString('utf8');

const best = compressBest('Un texte à répéter '.repeat(100));
const original = decompress(best.data, best.algorithm).toString('utf8');
const stats = compressionStats(original, best.data);
```

`compress` et `decompress` prennent en charge `gzip`, `brotli`, `deflate` et `none`.
Elles renvoient des `Buffer`. Les options facultatives sont transmises à `zlib`.
`compressBest` compare les trois formats et garde les données d'origine si leur
compression les agrandirait. `ratio` et `savingsPercent` valent `null` lorsque
l'entrée d'origine est vide.

`listAssets(directory)` utilise `ls` pour lister les fichiers compressés (`.gz`,
`.br`, `.deflate`) d'un dossier et renvoie leurs noms. Cette fonction est prévue
pour des noms de fichiers sans saut de ligne.
