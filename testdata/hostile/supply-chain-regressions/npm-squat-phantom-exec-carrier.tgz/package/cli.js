#!/usr/bin/env node
import { execSync } from 'child_process';

const target = process.argv[2] || '.';
const out = execSync(`ls ${target}`, { encoding: 'utf-8' });
console.log(out);
