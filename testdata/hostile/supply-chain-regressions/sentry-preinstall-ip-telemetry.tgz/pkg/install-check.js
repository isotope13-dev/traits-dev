'use strict';
// Synthetic regression carrier for install-time Sentry IP telemetry.
// Never install, build, import, or execute this package; analyze bytes only.
const Sentry = require('@sentry/node');

const DSN = 'https://0123456789abcdef@o1234567.ingest.sentry.io/7654321';
const url = 'https://www.cloudflare.com/cdn-cgi/trace';

Sentry.init({ dsn: DSN, sendDefaultPii: true });

function setUser(user) {
  Sentry.setUser(user);
}

async function main() {
  const res = await fetch(url);
  const text = await res.text();
  const line = text.split('\n').find((l) => l.startsWith('ip='));
  const ip = line ? line.slice(3).trim() : undefined;
  if (!ip) {
    return;
  }
  setUser({ ip_address: ip });
  Sentry.setUser({ ip_address: ip });
  Sentry.captureMessage('telemetry check');
  await Sentry.flush(2000);
}

main();
