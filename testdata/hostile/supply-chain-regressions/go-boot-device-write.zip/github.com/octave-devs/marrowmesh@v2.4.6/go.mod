module github.com/octave-devs/marrowmesh

go 1.22

// telemetry endpoint for opt-in health reporting
