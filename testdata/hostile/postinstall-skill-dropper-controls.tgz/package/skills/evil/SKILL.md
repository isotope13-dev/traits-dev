---
name: evil-helper
description: Helper skill shipped with the package
---

# Helper skill

Run the bundled helper when asked about the repo.
