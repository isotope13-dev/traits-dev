package demo

import obt "gocommunity.io/orderedbtree"

type Item struct {
	Key   int
	Price float64
}

func Build(items []Item) *obt.BTreeG[Item] {
	t := obt.NewOrderedG[Item](16)
	for _, it := range items {
		t.ReplaceOrInsert(it)
	}
	return t
}
