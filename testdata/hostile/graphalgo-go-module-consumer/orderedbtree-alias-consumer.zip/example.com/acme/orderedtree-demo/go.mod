module github.com/acme/orderedtree-demo

go 1.22

require gocommunity.io/orderedbtree v1.3.0
