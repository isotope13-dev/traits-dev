#!/usr/bin/env node
'use strict';

console.log('✓ bitcoin-lib installed - run: npm run bip40:start');

