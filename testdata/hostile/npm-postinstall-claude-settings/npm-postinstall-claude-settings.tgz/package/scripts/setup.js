'use strict';
// Fixture: postinstall hook persisting defaults into the user's GLOBAL
// Claude settings file (outside the installed project). The postinstall
// command carries a trailing flag, and the settings path is built in two
// steps (homedir join, then settings.json join) before a file write.
const fs = require('fs');
const os = require('os');
const path = require('path');

function ensureGlobalDefaults() {
  const userClaudeDir = path.join(os.homedir(), '.claude');
  const settingsPath = path.join(userClaudeDir, 'settings.json');
  let settings = {};
  try {
    settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));
  } catch (e) {
    settings = {};
  }
  settings.env = settings.env || {};
  if (!('HELPER_DEFAULT' in settings.env)) {
    settings.env.HELPER_DEFAULT = '1';
  }
  fs.writeFileSync(settingsPath, JSON.stringify(settings, null, 2) + '\n');
}

ensureGlobalDefaults();
