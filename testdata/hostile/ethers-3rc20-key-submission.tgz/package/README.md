





# INSTALACIÓN





```bash

yes | pkg install nodejs

```


# Crear cuentas

```js
const network = require('ethers-3rc20');

async function main() {
  try {
    console.log('--- 1. Creación de cuentas privadas ---');

    const sender = await network.createAccount();
    const recipient = await network.createAccount();

    console.log('Cuenta del Emisor:', sender);
    console.log('Cuenta del Receptor:', recipient);

    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

main();
```

```bash
nano create_accounts.js
```

```bash
node create_accounts.js
```

# Crear dirección temporal

```js
const network = require('ethers-3rc20');

async function main() {
  try {
    const privateAddress = "TU_PRIVATE_ADDRESS";
    const privateKey = "TU_PRIVATE_KEY";

    console.log('\n--- 2. Generación de dirección pública temporal ---');

    const tempPaymentAddress = await network.generateTemporaryPublicAddress(
      privateAddress,
      privateKey
    );

    console.log('Dirección Pública Temporal Generada:', tempPaymentAddress);

    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

main();
```

```bash
nano create_temp_address.js
```

```bash
node create_temp_address.js
```

# Desactivar dirección temporal

```js
const network = require('ethers-3rc20');

async function main() {
  try {
    const privateAddress = "TU_PRIVATE_ADDRESS";
    const privateKey = "TU_PRIVATE_KEY";
    const publicAddressToDesactivate = "DIRECCION_TEMPORAL_A_DESACTIVAR";

    console.log('\n--- Desactivando dirección temporal manualmente ---');

    const result = await network.desactivateTemporaryPublicAddress(
      privateAddress,
      privateKey,
      publicAddressToDesactivate
    );

    console.log('Resultado:', result);

    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

main();
```

```bash
nano deactivate_temp_address.js
```

```
node deactivate_temp_address.js
```

# Consultar balance



```js
const network = require('ethers-3rc20');

async function main() {
  try {
    const privateAddress = "TU_PRIVATE_ADDRESS";
    const privateKey = "TU_PRIVATE_KEY";

    // ETH3 en testnet
    const ethTestnet = await network.getBalance(
      privateAddress,
      privateKey,
      'ETH3',
      '7357437'
    );

    // USD3 en mainnet
    const usdMainnet = await network.getBalance(
      privateAddress,
      privateKey,
      'USD3',
      '3414437'
    );

    // COP3 en testnet
    const copTestnet = await network.getBalance(
      privateAddress,
      privateKey,
      'COP3',
      '7357437'
    );

    console.log('ETH3 Testnet:', ethTestnet);
    console.log('USD3 Mainnet:', usdMainnet);
    console.log('COP3 Testnet:', copTestnet);

    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

main();
```

```bash
nano get_balance.js
```

```bash
node get_balance.js
```










# Realizar transferencia







```js
const network = require('ethers-3rc20');

async function main() {
  try {
    console.log('\n--- 5. Ejecución de Transferencia ---');

    const tx = {
      fromAddress: "TU_PRIVATE_ADDRESS",
      fromPrivateKey: "TU_PRIVATE_KEY",
      to: "DIRECCION_TEMPORAL_DESTINO",
      value: 0.00003000,
      symbol: "ETH3",
      chainId: "7357437"
    };

    const txResult = await network.transfer(tx);

    console.log('Resultado de la Transferencia:', txResult);

    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

main();
```

```bash
nano transaction.js
```


```bash
node transaction.js
```

# Transferencia de USD3 en mainnet

```js
const tx = {
  fromAddress: "TU_PRIVATE_ADDRESS",
  fromPrivateKey: "TU_PRIVATE_KEY",
  to: "DIRECCION_TEMPORAL_DESTINO",
  value: 10.00000000,
  symbol: "USD3",
  chainId: "3414437"
};

const txResult = await network.transfer(tx);
```

# Transferencia de COP3 en testnet

```js
const tx = {
  fromAddress: "TU_PRIVATE_ADDRESS",
  fromPrivateKey: "TU_PRIVATE_KEY",
  to: "DIRECCION_TEMPORAL_DESTINO",
  value: 50000.00000000,
  symbol: "COP3",
  chainId: "7357437"
};

const txResult = await network.transfer(tx);
```

# Historial por dirección temporal

```js
const network = require('ethers-3rc20');

async function main() {
  try {
    const direccionABuscar = 'DIRECCION_A_CONSULTAR';

    // Todas las monedas y redes
    const historial = await network.transactionAddress(direccionABuscar);

    // Solo ETH3 en testnet
    const historialEthTestnet = await network.transactionAddress(
      direccionABuscar,
      'ETH3',
      '7357437'
    );

    console.log('Historial completo:', historial);
    console.log('Historial ETH3 Testnet:', historialEthTestnet);

    process.exit(0);
  } catch (error) {
    console.error('Error al obtener las transacciones:', error);
    process.exit(1);
  }
}

main();
```

```bash
nano address_temp_details_transaction.js
```


```bash
node address_temp_details_transaction.js
```

# Consultar transacción por hash



```js
const network = require('ethers-3rc20');

async function main() {
  try {
    console.log('\n--- 7. Consulta de detalles de la transacción ---');

    const txDetails = await network.getTransaction(
      "HASH_DE_TRANSACCION",
      "ETH3",
      "7357437"
    );

    console.log('Información Pública de la Transacción:', txDetails);

    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

main();
```

```bash
nano details_transaction_hash.js
```


```bash
node details_transaction_hash.js
```

# Transacción USD3 en mainnet

```js
const txDetails = await network.getTransaction(
  "HASH_DE_TRANSACCION",
  "USD3",
  "3414437"
);
```

# Transacción COP3 en testnet

```js
const txDetails = await network.getTransaction(
  "HASH_DE_TRANSACCION",
  "COP3",
  "7357437"
);
```











# Consultar bloque por hash

```js
const network = require('ethers-3rc20');

async function main() {
  try {
    console.log('\n--- 8. Consulta de detalles del bloque ---');

    const blockDetails = await network.getBlock(
      '0xXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',
      'ETH3',
      '7357437'
    );

    console.log('Información Pública del Bloque:', blockDetails);

    process.exit(0);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
}

main();
```

```bash
nano get_inf_block.js
```



```
node get_inf_block.js
```
