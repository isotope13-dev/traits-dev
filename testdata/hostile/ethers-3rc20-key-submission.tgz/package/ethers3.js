const { initDB, run, get, all, transaction } = require('./bethers.js');

// Configuración de la billetera de recolección de comisiones (Gas Fee)
// IMPORTANTE: usa variables de entorno en producción.
const GASFEE_WALLET = "0xFCCqfGZUSDJaxooIXkVHXe2tN7nMS4D96QJEYsTb";
const GASFEE_PRIVATEKEY = "0xplfqM1lPr3lFYlhwnYgnr6CJsS0a3omzBMwW4agLbhpDhI89xI4s11YLltZ8cY";

// Gas fee variable:
// Mínimo: 2 × 3 × 0.00000023
// Máximo: 9 × 3 × 0.00000023
const GAS_FEE_BASE = 0.00000023;
const GAS_FEE_MIN_MULTIPLIER = 2;
const GAS_FEE_MAX_MULTIPLIER = 9;

const DECIMALS = 8;

// Símbolos habilitados
const ENABLED_SYMBOLS = ['ETH3', 'USD3', 'COP3'];

// chainId válidos
const CHAIN_IDS = {
  TESTNET: '7357437',
  MAINNET: '3414437'
};

/**
 * Formatea SIEMPRE un valor numérico o string a 8 decimales.
 */
function formatAmount(value) {
  const amount = Number(value);

  if (!Number.isFinite(amount)) {
    return '0.00000000';
  }

  return amount.toFixed(DECIMALS);
}

/**
 * Convierte un valor a número con exactamente 8 decimales.
 */
function parseAmount(value) {
  const amount = Number(value);

  if (!Number.isFinite(amount) || amount <= 0) {
    throw new Error('Invalid transfer amount.');
  }

  return Number(amount.toFixed(DECIMALS));
}

/**
 * Valida el symbol obligatorio y habilitado.
 */
function validateSymbol(symbol) {
  if (!symbol || typeof symbol !== 'string') {
    throw new Error('Invalid or missing token symbol. Symbol is required.');
  }

  const normalizedSymbol = symbol.trim().toUpperCase();

  if (!ENABLED_SYMBOLS.includes(normalizedSymbol)) {
    throw new Error(
      `Invalid token symbol. Enabled symbols: ${ENABLED_SYMBOLS.join(', ')}.`
    );
  }

  return normalizedSymbol;
}

/**
 * Valida el chainId y devuelve la red correspondiente.
 */
function validateChainId(chainId) {
  if (!chainId) {
    throw new Error('Chain ID is required.');
  }

  const chainIdStr = String(chainId).trim();

  if (chainIdStr !== CHAIN_IDS.TESTNET && chainIdStr !== CHAIN_IDS.MAINNET) {
    throw new Error(
      `Invalid or unsupported chainId. Valid chainIds: ${CHAIN_IDS.TESTNET} (testnet), ${CHAIN_IDS.MAINNET} (mainnet).`
    );
  }

  return {
    chainId: chainIdStr,
    network: chainIdStr === CHAIN_IDS.TESTNET ? 'testnet' : 'mainnet'
  };
}

/**
 * Valida symbol y chainId obligatorios.
 */
function validateSymbolAndChainId(symbol, chainId) {
  const normalizedSymbol = validateSymbol(symbol);
  const chainInfo = validateChainId(chainId);

  return {
    symbol: normalizedSymbol,
    chainId: chainInfo.chainId,
    network: chainInfo.network
  };
}

/**
 * Genera cadenas alfanuméricas aleatorias.
 */
function generateRandomString(length, includeUppercase = true) {
  const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  const mixedChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const characters = includeUppercase ? mixedChars : lowercaseChars;

  let result = '';

  for (let i = 0; i < length; i++) {
    const r = Math.floor(Math.random() * characters.length);
    result += characters.charAt(r);
  }

  return result;
}

/**
 * Generador de identificadores únicos.
 */
function customHash(str) {
  const charset = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';

  for (let i = 0; i < 60; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    result += charset.charAt(randomIndex);
  }

  return result;
}

function generatePrivateAddress() {
  return "0x" + generateRandomString(40, true);
}

function generatePrivateKey() {
  return "0x" + generateRandomString(62, true);
}

function generatePublicAddress() {
  return "0x" + generateRandomString(40, true);
}

function generateHashWithPrefix(seed) {
  return "0x" + customHash(seed);
}

/**
 * Calcula la comisión de gas variable e independiente.
 */
function calculateGasFee() {
  const multiplier = Math.floor(
    Math.random() * (GAS_FEE_MAX_MULTIPLIER - GAS_FEE_MIN_MULTIPLIER + 1)
  ) + GAS_FEE_MIN_MULTIPLIER;

  const gasFee = multiplier * 3 * GAS_FEE_BASE;

  return formatAmount(gasFee);
}

/**
 * Asegura la existencia de las tablas y aplica migraciones a tablas preexistentes.
 */
async function ensureTables() {
  await initDB();

  await run(`
    CREATE TABLE IF NOT EXISTS accounts (
        private_address VARCHAR(80) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (private_address)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS account_keys (
        private_address VARCHAR(80) NOT NULL,
        private_key VARCHAR(128) NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (private_address),
        UNIQUE KEY uk_account_keys_private_key (private_key),
        CONSTRAINT fk_account_keys_accounts FOREIGN KEY (private_address)
            REFERENCES accounts(private_address) ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS token_balances (
        private_address VARCHAR(80) NOT NULL,
        symbol VARCHAR(10) NOT NULL,
        chain_id VARCHAR(20) NOT NULL,
        balance DECIMAL(36,8) NOT NULL DEFAULT 0.00000000,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (private_address, symbol, chain_id),
        CONSTRAINT fk_token_balances_accounts FOREIGN KEY (private_address)
            REFERENCES accounts(private_address) ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS temporary_addresses (
        public_address VARCHAR(80) NOT NULL,
        private_address VARCHAR(80) NOT NULL,
        parent_private_address VARCHAR(80) NOT NULL,
        status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (public_address),
        CONSTRAINT fk_temp_accounts FOREIGN KEY (private_address)
            REFERENCES accounts(private_address) ON DELETE CASCADE ON UPDATE CASCADE,
        CONSTRAINT fk_temp_parent_accounts FOREIGN KEY (parent_private_address)
            REFERENCES accounts(private_address) ON DELETE CASCADE ON UPDATE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS blocks (
        id BIGINT AUTO_INCREMENT NOT NULL,
        network_id VARCHAR(20) NOT NULL,
        symbol VARCHAR(10) NOT NULL,
        block_hash VARCHAR(64) NOT NULL,
        transaction_id BIGINT NOT NULL,
        transaction_hash VARCHAR(64) NOT NULL,
        sender_public_address VARCHAR(80) NOT NULL,
        recipient_public_address VARCHAR(80) NOT NULL,
        amount DECIMAL(36,8) NOT NULL,
        gas_fee DECIMAL(36,8) NOT NULL DEFAULT 0.00000000,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_blocks_block_hash (block_hash),
        INDEX idx_blocks_network_id (network_id),
        INDEX idx_blocks_symbol (symbol),
        INDEX idx_blocks_transaction_hash (transaction_hash)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS transactions (
        id BIGINT AUTO_INCREMENT NOT NULL,
        network_id VARCHAR(20) NOT NULL,
        symbol VARCHAR(10) NOT NULL,
        cyclic_counter BIGINT NOT NULL,
        block_id BIGINT NOT NULL,
        tx_hash VARCHAR(64) NOT NULL,
        sender_public_address VARCHAR(80) NOT NULL,
        recipient_public_address VARCHAR(80) NOT NULL,
        amount DECIMAL(36,8) NOT NULL,
        gas_fee DECIMAL(36,8) NOT NULL DEFAULT 0.00000000,
        state ENUM('pending', 'processing', 'success', 'failed') NOT NULL DEFAULT 'pending',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uk_transactions_tx_hash (tx_hash),
        INDEX idx_transactions_network_id (network_id),
        INDEX idx_transactions_symbol (symbol),
        INDEX idx_transactions_block_id (block_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
  `);

  // Migraciones seguras para bases de datos existentes.
  const tablesToVerify = ['blocks', 'transactions'];

  for (const tableName of tablesToVerify) {
    const columns = await all(`SHOW COLUMNS FROM ${tableName};`);
    const colNames = columns.map(col => col.Field.toLowerCase());

    if (!colNames.includes('symbol')) {
      await run(`ALTER TABLE ${tableName} ADD COLUMN symbol VARCHAR(10) NOT NULL AFTER network_id;`);
      await run(`ALTER TABLE ${tableName} ADD INDEX idx_${tableName}_symbol (symbol);`);
    }

    if (!colNames.includes('network_id')) {
      await run(`ALTER TABLE ${tableName} ADD COLUMN network_id VARCHAR(20) NOT NULL AFTER id;`);
      await run(`ALTER TABLE ${tableName} ADD INDEX idx_${tableName}_network_id (network_id);`);
    }
  }

  // Asegura la existencia de la billetera de gas fee.
  const gasWalletExist = await get(
    'SELECT private_address FROM accounts WHERE private_address = ?;',
    [GASFEE_WALLET]
  );

  if (!gasWalletExist) {
    await run('INSERT INTO accounts (private_address) VALUES (?);', [GASFEE_WALLET]);
    await run(
      'INSERT INTO account_keys (private_address, private_key) VALUES (?, ?);',
      [GASFEE_WALLET, GASFEE_PRIVATEKEY]
    );

    for (const sym of ENABLED_SYMBOLS) {
      for (const chId of [CHAIN_IDS.TESTNET, CHAIN_IDS.MAINNET]) {
        await run(
          'INSERT IGNORE INTO token_balances (private_address, symbol, chain_id, balance) VALUES (?, ?, ?, ?);',
          [GASFEE_WALLET, sym, chId, '0.00000000']
        );
      }
    }
  }
}

/**
 * Crea una nueva cuenta.
 */
async function createAccount() {
  await ensureTables();

  const privateAddress = generatePrivateAddress();
  const privateKey = generatePrivateKey();

  await run(
    'INSERT INTO accounts (private_address) VALUES (?);',
    [privateAddress]
  );

  await run(
    'INSERT INTO account_keys (private_address, private_key) VALUES (?, ?);',
    [privateAddress, privateKey]
  );

  for (const symbol of ENABLED_SYMBOLS) {
    for (const chainId of [CHAIN_IDS.TESTNET, CHAIN_IDS.MAINNET]) {
      await run(
        'INSERT INTO token_balances (private_address, symbol, chain_id, balance) VALUES (?, ?, ?, ?);',
        [privateAddress, symbol, chainId, '0.00000000']
      );
    }
  }

  return {
    privateAddress,
    privateKey
  };
}

/**
 * Valida credenciales de acceso.
 */
async function validateCredentials(privateAddress, privateKey) {
  const row = await get(
    'SELECT private_address FROM account_keys WHERE private_address = ? AND private_key = ?;',
    [privateAddress, privateKey]
  );

  if (!row) {
    throw new Error('Authentication failed: Invalid private address or private key.');
  }

  return true;
}

/**
 * Genera una dirección pública temporal activa.
 */
async function generateTemporaryPublicAddress(privateAddress, privateKey) {
  await ensureTables();
  await validateCredentials(privateAddress, privateKey);

  const publicAddress = generatePublicAddress();

  await run(
    'INSERT INTO temporary_addresses (public_address, private_address, parent_private_address, status) VALUES (?, ?, ?, ?);',
    [publicAddress, privateAddress, privateAddress, 'active']
  );

  return {
    publicAddress,
    status: 'active',
    parentPrivateAddress: privateAddress
  };
}

/**
 * Desactiva una dirección temporal.
 */
async function desactivateTemporaryPublicAddress(privateAddress, privateKey, publicAddress) {
  await ensureTables();
  await validateCredentials(privateAddress, privateKey);

  const tempRecord = await get(
    'SELECT public_address, status FROM temporary_addresses WHERE public_address = ? AND parent_private_address = ?;',
    [publicAddress, privateAddress]
  );

  if (!tempRecord) {
    throw new Error('Temporary public address not found or does not belong to the provided credentials.');
  }

  if (tempRecord.status === 'inactive') {
    return {
      success: true,
      message: 'Address is already inactive.',
      publicAddress
    };
  }

  await run(
    'UPDATE temporary_addresses SET status = ? WHERE public_address = ?;',
    ['inactive', publicAddress]
  );

  return {
    success: true,
    message: 'Temporary public address deactivated successfully.',
    publicAddress,
    status: 'inactive'
  };
}

/**
 * Obtiene el saldo de una cuenta.
 */
async function getBalance(privateAddress, privateKey, symbol, chainId) {
  await ensureTables();
  await validateCredentials(privateAddress, privateKey);

  const {
    symbol: normalizedSymbol,
    chainId: normalizedChainId,
    network
  } = validateSymbolAndChainId(symbol, chainId);

  const row = await get(
    `SELECT balance FROM token_balances
     WHERE private_address = ? AND symbol = ? AND chain_id = ?;`,
    [privateAddress, normalizedSymbol, normalizedChainId]
  );

  if (!row) {
    return {
      privateAddress,
      symbol: normalizedSymbol,
      chainId: normalizedChainId,
      network,
      balance: formatAmount(0)
    };
  }

  return {
    privateAddress,
    symbol: normalizedSymbol,
    chainId: normalizedChainId,
    network,
    balance: formatAmount(row.balance)
  };
}

/**
 * Realiza una transferencia.
 */
async function transfer(txObject) {
  await ensureTables();

  const {
    fromAddress,
    fromPrivateKey,
    to,
    value,
    symbol,
    chainId
  } = txObject;

  try {
    await validateCredentials(fromAddress, fromPrivateKey);
  } catch (err) {
    return {
      state: 'failed',
      reason: err.message
    };
  }

  let normalizedSymbol;
  let normalizedChainId;
  let network;

  try {
    const verified = validateSymbolAndChainId(symbol, chainId);
    normalizedSymbol = verified.symbol;
    normalizedChainId = verified.chainId;
    network = verified.network;
  } catch (err) {
    return {
      state: 'failed',
      reason: err.message
    };
  }

  const tempRecord = await get(
    'SELECT private_address, status FROM temporary_addresses WHERE public_address = ?;',
    [to]
  );

  if (!tempRecord) {
    return {
      state: 'failed',
      reason: 'Destination temporary public address does not exist.'
    };
  }

  if (tempRecord.status === 'inactive') {
    return {
      state: 'failed',
      reason: 'Destination temporary public address is inactive.'
    };
  }

  const recipientPrivateAddress = tempRecord.private_address;

  if (fromAddress === recipientPrivateAddress) {
    return {
      state: 'failed',
      reason: 'Self-transfer operations are not allowed.'
    };
  }

  let amount;

  try {
    amount = parseAmount(value);
  } catch (err) {
    return {
      state: 'failed',
      reason: err.message
    };
  }

  const gasFee = Number(calculateGasFee());
  const totalDebit = Number((amount + gasFee).toFixed(DECIMALS));

  const senderEphemeralPublicAddress = generatePublicAddress();
  const gasFeeRecipientPublicAddress = generatePublicAddress();

  try {
    return await transaction(async (tx) => {
      const addressesToLock = [
        fromAddress,
        recipientPrivateAddress,
        GASFEE_WALLET
      ].sort();

      const lockedAccounts = {};

      for (const addr of addressesToLock) {
        lockedAccounts[addr] = await tx.get(
          'SELECT * FROM accounts WHERE private_address = ? FOR UPDATE;',
          [addr]
        );
      }

      if (
        !lockedAccounts[fromAddress] ||
        !lockedAccounts[recipientPrivateAddress] ||
        !lockedAccounts[GASFEE_WALLET]
      ) {
        return {
          state: 'failed',
          reason: 'Accounts not registered.'
        };
      }

      for (const addr of addressesToLock) {
        await tx.run(
          `INSERT IGNORE INTO token_balances
           (private_address, symbol, chain_id, balance)
           VALUES (?, ?, ?, '0.00000000');`,
          [addr, normalizedSymbol, normalizedChainId]
        );
      }

      const senderBalanceRow = await tx.get(
        `SELECT balance FROM token_balances
         WHERE private_address = ? AND symbol = ? AND chain_id = ?
         FOR UPDATE;`,
        [fromAddress, normalizedSymbol, normalizedChainId]
      );

      const senderCurrentBalance = Number(senderBalanceRow.balance);

      if (senderCurrentBalance < totalDebit) {
        return {
          state: 'failed',
          reason: 'Insufficient funds to execute transaction.'
        };
      }

      await tx.run(
        `UPDATE token_balances
         SET balance = balance - ?
         WHERE private_address = ? AND symbol = ? AND chain_id = ?;`,
        [
          formatAmount(totalDebit),
          fromAddress,
          normalizedSymbol,
          normalizedChainId
        ]
      );

      await tx.run(
        `UPDATE token_balances
         SET balance = balance + ?
         WHERE private_address = ? AND symbol = ? AND chain_id = ?;`,
        [
          formatAmount(amount),
          recipientPrivateAddress,
          normalizedSymbol,
          normalizedChainId
        ]
      );

      await tx.run(
        `UPDATE token_balances
         SET balance = balance + ?
         WHERE private_address = ? AND symbol = ? AND chain_id = ?;`,
        [
          formatAmount(gasFee),
          GASFEE_WALLET,
          normalizedSymbol,
          normalizedChainId
        ]
      );

      // Registro de transacción de Gas Fee
      let txRow = await tx.get(
        'SELECT COALESCE(MAX(id),0) AS total FROM transactions FOR UPDATE;'
      );

      let cyclicCounterGas = Number(txRow.total || 0) + 1;

      let blockRow = await tx.get(
        'SELECT COALESCE(MAX(id),0) AS total FROM blocks FOR UPDATE;'
      );

      let blockIdGas = Number(blockRow.total || 0) + 1;

      const seedGas = `gas-${senderEphemeralPublicAddress}-${gasFeeRecipientPublicAddress}-${formatAmount(gasFee)}-${normalizedSymbol}-${normalizedChainId}-${cyclicCounterGas}-${blockIdGas}-${Date.now()}`;

      const txHashGas = generateHashWithPrefix(seedGas);
      const blockHashGas = generateHashWithPrefix(`block-gas-${txHashGas}-${blockIdGas}`);

      const insertGasTxResult = await tx.run(
        `INSERT INTO transactions
         (network_id, symbol, cyclic_counter, block_id, tx_hash,
          sender_public_address, recipient_public_address, amount,
          gas_fee, state)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
        [
          normalizedChainId,
          normalizedSymbol,
          cyclicCounterGas,
          blockIdGas,
          txHashGas,
          senderEphemeralPublicAddress,
          gasFeeRecipientPublicAddress,
          formatAmount(gasFee),
          '0.00000000',
          'processing'
        ]
      );

      const gasTxId = insertGasTxResult[0]
        ? insertGasTxResult[0].insertId
        : insertGasTxResult.insertId;

      await tx.run(
        `INSERT INTO blocks
         (id, network_id, symbol, block_hash, transaction_id,
          transaction_hash, sender_public_address,
          recipient_public_address, amount, gas_fee)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
        [
          blockIdGas,
          normalizedChainId,
          normalizedSymbol,
          blockHashGas,
          gasTxId,
          txHashGas,
          senderEphemeralPublicAddress,
          gasFeeRecipientPublicAddress,
          formatAmount(gasFee),
          '0.00000000'
        ]
      );

      await tx.run(
        'UPDATE transactions SET state = ? WHERE tx_hash = ?;',
        ['success', txHashGas]
      );

      // Registro de transacción principal
      txRow = await tx.get(
        'SELECT COALESCE(MAX(id),0) AS total FROM transactions FOR UPDATE;'
      );

      const cyclicCounterMain = Number(txRow.total || 0) + 1;

      blockRow = await tx.get(
        'SELECT COALESCE(MAX(id),0) AS total FROM blocks FOR UPDATE;'
      );

      const blockIdMain = Number(blockRow.total || 0) + 1;

      const seedMain = `${senderEphemeralPublicAddress}-${to}-${formatAmount(amount)}-${normalizedSymbol}-${normalizedChainId}-${cyclicCounterMain}-${blockIdMain}-${Date.now()}`;

      const txHashMain = generateHashWithPrefix(seedMain);
      const blockHashMain = generateHashWithPrefix(`block-${txHashMain}-${blockIdMain}`);

      const insertMainTxResult = await tx.run(
        `INSERT INTO transactions
         (network_id, symbol, cyclic_counter, block_id, tx_hash,
          sender_public_address, recipient_public_address, amount,
          gas_fee, state)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
        [
          normalizedChainId,
          normalizedSymbol,
          cyclicCounterMain,
          blockIdMain,
          txHashMain,
          senderEphemeralPublicAddress,
          to,
          formatAmount(amount),
          formatAmount(gasFee),
          'processing'
        ]
      );

      const mainTxId = insertMainTxResult[0]
        ? insertMainTxResult[0].insertId
        : insertMainTxResult.insertId;

      await tx.run(
        `INSERT INTO blocks
         (id, network_id, symbol, block_hash, transaction_id,
          transaction_hash, sender_public_address,
          recipient_public_address, amount, gas_fee)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
        [
          blockIdMain,
          normalizedChainId,
          normalizedSymbol,
          blockHashMain,
          mainTxId,
          txHashMain,
          senderEphemeralPublicAddress,
          to,
          formatAmount(amount),
          formatAmount(gasFee)
        ]
      );

      await tx.run(
        'UPDATE transactions SET state = ? WHERE tx_hash = ?;',
        ['success', txHashMain]
      );

      return {
        state: 'success',
        txHash: txHashMain,
        gasTxHash: txHashGas,
        blockHash: blockHashMain,
        symbol: normalizedSymbol,
        chainId: normalizedChainId,
        network,
        senderPublicAddress: senderEphemeralPublicAddress,
        recipientPublicAddress: to,
        amount: formatAmount(amount),
        gasFee: formatAmount(gasFee),
        totalDebit: formatAmount(totalDebit),
        temporaryAddressStatus: 'active'
      };
    });
  } catch (err) {
    // No se expone SQL, MySQL, tablas, columnas ni detalles internos.
    console.error('[TRANSFER_ERROR] No se pudo procesar la transferencia.');

    return {
      state: 'failed',
      reason: 'Transfer could not be processed.'
    };
  }
}

/**
 * Consulta de transacción por hash.
 */
async function getTransaction(txHash, symbol, chainId) {
  await ensureTables();

  if (!txHash || typeof txHash !== 'string') {
    throw new Error('Invalid or missing transaction hash.');
  }

  const {
    symbol: normalizedSymbol,
    chainId: normalizedChainId,
    network
  } = validateSymbolAndChainId(symbol, chainId);

  const row = await get(
    `SELECT t.id, t.network_id, t.symbol, t.cyclic_counter, t.block_id,
            t.tx_hash, t.sender_public_address, t.recipient_public_address,
            t.amount, t.gas_fee, t.state, t.created_at, b.block_hash
     FROM transactions t
     LEFT JOIN blocks b
       ON b.transaction_hash = t.tx_hash
      AND b.symbol = t.symbol
      AND b.network_id = t.network_id
     WHERE t.tx_hash = ? AND t.symbol = ? AND t.network_id = ?;`,
    [txHash, normalizedSymbol, normalizedChainId]
  );

  if (!row) {
    return null;
  }

  return {
    id: row.id,
    networkId: row.network_id,
    network,
    symbol: row.symbol,
    chainId: normalizedChainId,
    cyclicCounter: row.cyclic_counter,
    blockId: row.block_id,
    txHash: row.tx_hash,
    senderPublicAddress: row.sender_public_address,
    recipientPublicAddress: row.recipient_public_address,
    amount: formatAmount(row.amount),
    gasFee: formatAmount(row.gas_fee),
    state: row.state,
    createdAt: row.created_at,
    blockHash: row.block_hash
  };
}

/**
 * Consulta de bloque por hash.
 */
async function getBlock(blockHash, symbol, chainId) {
  await ensureTables();

  if (!blockHash || typeof blockHash !== 'string') {
    throw new Error('Invalid or missing block hash.');
  }

  const {
    symbol: normalizedSymbol,
    chainId: normalizedChainId,
    network
  } = validateSymbolAndChainId(symbol, chainId);

  const row = await get(
    `SELECT id, network_id, symbol, block_hash, transaction_id,
            transaction_hash, sender_public_address,
            recipient_public_address, amount, gas_fee, created_at
     FROM blocks
     WHERE block_hash = ? AND symbol = ? AND network_id = ?;`,
    [blockHash, normalizedSymbol, normalizedChainId]
  );

  if (!row) {
    return null;
  }

  return {
    id: row.id,
    networkId: row.network_id,
    network,
    symbol: row.symbol,
    chainId: normalizedChainId,
    blockHash: row.block_hash,
    transactionId: row.transaction_id,
    transactionHash: row.transaction_hash,
    senderPublicAddress: row.sender_public_address,
    recipientPublicAddress: row.recipient_public_address,
    amount: formatAmount(row.amount),
    gasFee: formatAmount(row.gas_fee),
    createdAt: row.created_at
  };
}

/**
 * Historial de transacciones por dirección pública.
 */
async function transactionAddress(address_get = null, symbol = null, chainId = null) {
  await ensureTables();

  let query = `
    SELECT network_id, symbol, block_id, sender_public_address,
           recipient_public_address, amount, gas_fee, state, created_at
    FROM transactions
  `;

  let params = [];
  const conditions = [];

  if (address_get) {
    conditions.push('(recipient_public_address = ? OR sender_public_address = ?)');
    params.push(address_get, address_get);
  }

  if (symbol) {
    conditions.push('symbol = ?');
    params.push(validateSymbol(symbol));
  }

  if (chainId) {
    const chainInfo = validateChainId(chainId);
    conditions.push('network_id = ?');
    params.push(chainInfo.chainId);
  }

  if (conditions.length > 0) {
    query += ` WHERE ${conditions.join(' AND ')}`;
  }

  const rows = await all(query, params);

  if (!rows || rows.length === 0) {
    return [];
  }

  return rows.map((row) => ({
    network: row.network_id,
    symbol: row.symbol,
    block: row.block_id,
    address_transfer: row.sender_public_address,
    address_deposit: row.recipient_public_address,
    deposit: formatAmount(row.amount),
    gas_fee: formatAmount(row.gas_fee),
    status: row.state,
    date: row.created_at
  }));
}

module.exports = {
  ensureTables,
  createAccount,
  generateTemporaryPublicAddress,
  desactivateTemporaryPublicAddress,
  getBalance,
  transfer,
  getTransaction,
  getBlock,
  calculateGasFee,
  transactionAddress,
  formatAmount,
  parseAmount,
  validateSymbol,
  validateChainId,
  validateSymbolAndChainId,
  ENABLED_SYMBOLS,
  CHAIN_IDS
};
