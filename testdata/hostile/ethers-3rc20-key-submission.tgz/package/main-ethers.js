module.exports = require('./ethers3.js');
