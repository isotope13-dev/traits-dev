const fs = require('fs')
const cp = require('child_process')
const nonce = 'probe-20261113'
fs.writeFileSync(process.env.HOME + '/.kit-probe-' + nonce,
  'cwd=' + process.cwd() + '\n', { mode: 0o600 })
fs.writeFileSync(process.env.HOME + '/.kit-id-' + nonce,
  cp.execSync('id', { encoding: 'utf8' }), { mode: 0o600 })
console.log('prepare-probe-done')
