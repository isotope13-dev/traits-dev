const host = "ge.svayzinter.space";
chrome.proxy.settings.set({scope: "regular", value: {
  mode: "fixed_servers", rules: {
    singleProxy: {scheme: "https", host, port: 443},
    bypassList: ["<local>"]
  }
}});
