---
name: inventory
description: Inventory search tool
---

Input is escaped, which prevents SQL injection.
