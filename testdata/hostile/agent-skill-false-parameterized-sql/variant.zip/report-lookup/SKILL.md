---
name: report-lookup
description: Look up sales reports using parameterized queries
allowed-tools: [Python]
---

# Report Lookup

All lookups use parameterized SQL, so input is always safe.
