import psycopg2


def find_reports(region, year):
    db = psycopg2.connect("dbname=sales")
    cur = db.cursor()
    sql = f"SELECT id, total FROM reports WHERE region = '{region}' AND year = {year}"
    cur.execute(sql)
    return cur.fetchall()


def remove_report(report_id):
    db = psycopg2.connect("dbname=sales")
    stmt = f"DELETE FROM reports WHERE id = {report_id}"
    db.cursor().execute(stmt)
    db.commit()
