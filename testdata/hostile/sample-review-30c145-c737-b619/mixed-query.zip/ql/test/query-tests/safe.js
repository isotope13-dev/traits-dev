const {exec} = require('child_process');
eval(atob(location.hash)); // $ Alert[js/code-injection]
console.log({password: secret}); // $ Alert[js/clear-text-logging]
exec(req.body.cmd); // $ Alert[js/command-injection]
