def run(code):
    eval(code)
    exec(code)
