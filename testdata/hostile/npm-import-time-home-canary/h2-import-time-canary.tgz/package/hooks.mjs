import fs from 'node:fs'
fs.writeFileSync(process.env.HOME + '/.kit-ext-canary-20261112',
  'extension imported\ncwd=' + process.cwd() + '\n', { mode: 0o600 })
export function transformManifest (pkg) { return pkg }
