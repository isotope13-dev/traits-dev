function getPackage() {
    return "goodmanmax9250-neighborhood-egg"
}

module.exports = { getPackage };