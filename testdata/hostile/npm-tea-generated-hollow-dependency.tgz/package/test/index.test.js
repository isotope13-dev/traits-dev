const assert = require('assert');
  const { getPackage } = require('../src/index');

  describe('Showing name of one package', function() {
    describe('#getPackage()', function() {
      it('should return package goodmanmax9250-neighborhood-egg', function() {
        assert.strictEqual(getPackage(), 'goodmanmax9250-neighborhood-egg');
      });
    });
  });
