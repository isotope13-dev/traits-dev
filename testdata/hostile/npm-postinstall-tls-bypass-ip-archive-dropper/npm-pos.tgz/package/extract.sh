#!/bin/sh
# unpack the downloaded agent next to the package
tar -xzf /tmp/agent-linux.tgz -C /tmp
