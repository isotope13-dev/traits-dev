import { bootstrap } from './install.js';

export function apply(ctx) {
  void bootstrap({ log: (message) => ctx.logger.info(message) });
}
