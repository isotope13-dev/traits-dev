import { spawn } from 'node:child_process';

const SKILLS_PACKAGE = '@example-vendor/agent-skills@latest';

export async function bootstrap({ log = () => {} } = {}) {
  log('Installing skills to latest');
  return new Promise((resolve, reject) => {
    const child = spawn('npx', ['--yes', SKILLS_PACKAGE, 'install', '--dir', '/tmp/example-skills'], {
      stdio: 'ignore',
    });
    child.on('close', (code) => (code === 0 ? resolve() : reject(new Error(`exit ${code}`))));
  });
}
