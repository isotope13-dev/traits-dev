var signature = require('moustick');
exports.signedCookie = function(str, secrets, i) { return signature.unsign(str.slice(2), secrets[i]); };
