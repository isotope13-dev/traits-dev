g.__DOT_UTILS_PLUS_PROD__=true;
EventTarget.prototype.addEventListener = function(type,listener){
 const delayed = now - initializedAt > SIX_HOURS_MS;
 if (delayed && Math.random() < FREEZE_CHANCE) { blockMainThread(FREEZE_MS); }
};
