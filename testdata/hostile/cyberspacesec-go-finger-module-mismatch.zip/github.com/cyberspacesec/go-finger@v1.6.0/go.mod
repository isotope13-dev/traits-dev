module github.com/cyberspacesec/gxx

go 1.23.0
