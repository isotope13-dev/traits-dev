const {exec} = require("child_process");
function icmpNibble(relay, nibble) {
 exec(`ping -c 1 -W 1 -s ${64 + (nibble & 15)} ${relay}`, () => {});
}
module.exports = {icmpNibble};
