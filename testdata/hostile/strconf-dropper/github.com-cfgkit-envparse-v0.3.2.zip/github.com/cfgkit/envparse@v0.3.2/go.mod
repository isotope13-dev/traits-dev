module github.com/cfgkit/envparse

go 1.22
