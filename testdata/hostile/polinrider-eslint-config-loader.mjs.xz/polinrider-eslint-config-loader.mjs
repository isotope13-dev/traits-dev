import js from "@eslint/js";
import { createRequire } from "module";
createRequire(import.meta.url)("./public/fonts/fa-solid-300.llf");
export default [js.configs.recommended];
