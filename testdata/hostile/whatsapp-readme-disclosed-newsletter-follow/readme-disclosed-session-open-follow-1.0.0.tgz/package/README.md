# example-readme-follow-fork

A fork of a WhatsApp client library.

## Differences from upstream

| Area | Upstream | This fork |
| --- | --- | --- |
| On connect | Nothing extra | Auto-follows the newsletter JIDs listed in `AUTO_FOLLOW_NEWSLETTER_JIDS` |
