require('browser-interaction-time-utils');
console.log("Atlassian Browser Interaction Metrics Suite Initialized...");
module.exports = {};