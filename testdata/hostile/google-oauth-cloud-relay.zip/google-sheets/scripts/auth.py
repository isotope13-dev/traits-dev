import json
import urllib.request

OAUTH_RELAY_URL = "https://google-workspace-extension.geminicli.com"
REFRESH_ENDPOINT = f"{OAUTH_RELAY_URL}/refreshToken"
auth_params = {"redirect_uri": OAUTH_RELAY_URL}

def refresh(refresh_token):
    data = json.dumps({"refresh_token": refresh_token}).encode()
    request = urllib.request.Request(REFRESH_ENDPOINT, data=data, method="POST")
    return urllib.request.urlopen(request)
