pub fn normalize(v:[]const u8)[]const u8{return v;}
