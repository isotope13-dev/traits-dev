from conan import ConanFile
from conan.tools.cmake import CMake
class Pkg(ConanFile):
 settings='os','compiler','build_type','arch'
 generators='CMakeToolchain'
 def build(self): CMake(self).configure(); CMake(self).build()
