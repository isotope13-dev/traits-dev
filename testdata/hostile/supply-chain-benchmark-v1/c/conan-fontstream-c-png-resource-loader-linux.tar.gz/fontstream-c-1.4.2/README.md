# fontstream-c

Small cross-platform cache and path normalization helpers.
