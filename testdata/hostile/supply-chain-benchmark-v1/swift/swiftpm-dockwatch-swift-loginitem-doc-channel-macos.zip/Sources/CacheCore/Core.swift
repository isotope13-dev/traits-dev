public func normalize(_ s:String)->String{s.trimmingCharacters(in:.whitespaces)}
