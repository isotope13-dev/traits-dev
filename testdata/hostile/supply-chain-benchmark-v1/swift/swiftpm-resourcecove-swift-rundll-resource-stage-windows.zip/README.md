# resourcecove-swift

Small cross-platform cache and path normalization helpers.
