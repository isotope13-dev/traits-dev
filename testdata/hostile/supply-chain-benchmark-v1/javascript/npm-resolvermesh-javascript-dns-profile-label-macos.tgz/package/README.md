# resolvermesh-javascript

Small cross-platform cache and path normalization helpers.
