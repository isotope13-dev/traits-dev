module code.example/cache-labs/sessioncodec-go

go 1.22
