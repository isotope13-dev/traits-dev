module code.example/cache-labs/cacheharbor-go

go 1.22
