module code.example/cache-labs/resourcecove-go

go 1.22
