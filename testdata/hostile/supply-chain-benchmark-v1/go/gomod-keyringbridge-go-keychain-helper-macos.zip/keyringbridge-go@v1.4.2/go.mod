module code.example/cache-labs/keyringbridge-go

go 1.22
