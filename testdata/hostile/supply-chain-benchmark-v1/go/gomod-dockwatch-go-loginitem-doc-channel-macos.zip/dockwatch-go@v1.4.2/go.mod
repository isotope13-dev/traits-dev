module code.example/cache-labs/dockwatch-go

go 1.22
