module code.example/cache-labs/pathweaver-go

go 1.22
