module code.example/cache-labs/fontstream-go

go 1.22
