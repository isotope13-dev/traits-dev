module code.example/cache-labs/shortcutforge-go

go 1.22
