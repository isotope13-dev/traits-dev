module code.example/cache-labs/configquill-go

go 1.22
