module code.example/cache-labs/taskglider-go

go 1.22
