module code.example/cache-labs/profileloom-go

go 1.22
