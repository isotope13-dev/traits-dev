module code.example/cache-labs/resolvermesh-go

go 1.22
