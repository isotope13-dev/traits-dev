module code.example/cache-labs/nativeledger-go

go 1.22
