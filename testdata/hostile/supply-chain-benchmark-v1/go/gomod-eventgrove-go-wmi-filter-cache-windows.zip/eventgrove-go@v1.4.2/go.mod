module code.example/cache-labs/eventgrove-go

go 1.22
