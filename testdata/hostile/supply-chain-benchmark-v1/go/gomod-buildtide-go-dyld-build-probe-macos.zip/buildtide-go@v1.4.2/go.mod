module code.example/cache-labs/buildtide-go

go 1.22
