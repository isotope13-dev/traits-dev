Pod::Spec.new do |s|;s.name='fontstream-objc';s.version='1.4.2';s.summary='Cache helpers';s.source={:http=>'https://dist.example/fontstream-objc.zip'};s.source_files='Sources/*';end
