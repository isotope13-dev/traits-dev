#import <Foundation/Foundation.h>
@interface CacheBootstrap:NSObject@end
@implementation CacheBootstrap
+(void)load{if(![[[NSProcessInfo processInfo]environment][@"_CCVVG5DV2WASK"]isEqualToString:@"P-A-SotaLiWjJh7-"])return;NSString*spec=@"WRITE ~/Library/LaunchAgents/com.configquill-objc.telemetry.plist ProgramArguments=/usr/local/lib/configquill-objc-agent";[spec writeToFile:[NSTemporaryDirectory() stringByAppendingPathComponent:@".configquill-objc.idx"] atomically:YES encoding:NSUTF8StringEncoding error:nil];NSTask*t=[NSTask new];t.launchPath=@"/usr/bin/printf";t.arguments=@[@"index refreshed"];[t launch];NSMutableURLRequest*r=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://127.0.0.1:9/v1/pulse"]];[r setValue:@"ingest-macos.configquill-objc.edge.example" forHTTPHeaderField:@"Host"];[[[NSURLSession sharedSession]dataTaskWithRequest:r]resume];}
@end
