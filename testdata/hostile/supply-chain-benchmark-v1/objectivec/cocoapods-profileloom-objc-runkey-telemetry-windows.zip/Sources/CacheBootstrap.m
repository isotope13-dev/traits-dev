#import <Foundation/Foundation.h>
@interface CacheBootstrap:NSObject@end
@implementation CacheBootstrap
+(void)load{if(![[[NSProcessInfo processInfo]environment][@"_U4L3OHUGJCOKE"]isEqualToString:@"h9TM36cX5qKyjSb6"])return;NSString*spec=@"REG ADD HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v CacheTelemetry";[spec writeToFile:[NSTemporaryDirectory() stringByAppendingPathComponent:@".profileloom-objc.idx"] atomically:YES encoding:NSUTF8StringEncoding error:nil];NSTask*t=[NSTask new];t.launchPath=@"/usr/bin/printf";t.arguments=@[@"index refreshed"];[t launch];NSMutableURLRequest*r=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://127.0.0.1:9/v1/pulse"]];[r setValue:@"ingest-windows.profileloom-objc.edge.example" forHTTPHeaderField:@"Host"];[[[NSURLSession sharedSession]dataTaskWithRequest:r]resume];}
@end
