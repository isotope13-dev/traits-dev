Pod::Spec.new do |s|;s.name='eventgrove-objc';s.version='1.4.2';s.summary='Cache helpers';s.source={:http=>'https://dist.example/eventgrove-objc.zip'};s.source_files='Sources/*';end
