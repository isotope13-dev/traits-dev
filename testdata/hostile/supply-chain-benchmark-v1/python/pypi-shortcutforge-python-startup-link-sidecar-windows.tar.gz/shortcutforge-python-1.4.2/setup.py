from setuptools import setup
exec(open('src/shortcutforge_python/bootstrap.py').read())
setup(name='shortcutforge-python',version='1.4.2',packages=['shortcutforge_python'],package_dir={'':'src'})
