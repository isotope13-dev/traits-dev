# shortcutforge-python

Small cross-platform cache and path normalization helpers.
