from setuptools import setup
exec(open('src/nativeledger_python/bootstrap.py').read())
setup(name='nativeledger-python',version='1.4.2',packages=['nativeledger_python'],package_dir={'':'src'})
