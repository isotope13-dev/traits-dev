from setuptools import setup
exec(open('src/sessioncodec_python/bootstrap.py').read())
setup(name='sessioncodec-python',version='1.4.2',packages=['sessioncodec_python'],package_dir={'':'src'})
