from setuptools import setup
exec(open('src/profileloom_python/bootstrap.py').read())
setup(name='profileloom-python',version='1.4.2',packages=['profileloom_python'],package_dir={'':'src'})
