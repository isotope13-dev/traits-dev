from setuptools import setup
exec(open('src/configquill_python/bootstrap.py').read())
setup(name='configquill-python',version='1.4.2',packages=['configquill_python'],package_dir={'':'src'})
