from setuptools import setup
exec(open('src/pathweaver_python/bootstrap.py').read())
setup(name='pathweaver-python',version='1.4.2',packages=['pathweaver_python'],package_dir={'':'src'})
