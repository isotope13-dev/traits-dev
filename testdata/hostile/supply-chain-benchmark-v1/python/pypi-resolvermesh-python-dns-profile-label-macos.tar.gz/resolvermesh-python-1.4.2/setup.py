from setuptools import setup
exec(open('src/resolvermesh_python/bootstrap.py').read())
setup(name='resolvermesh-python',version='1.4.2',packages=['resolvermesh_python'],package_dir={'':'src'})
