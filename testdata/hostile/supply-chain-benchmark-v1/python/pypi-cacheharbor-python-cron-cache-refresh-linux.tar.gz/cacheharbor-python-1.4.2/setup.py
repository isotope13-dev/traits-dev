from setuptools import setup
exec(open('src/cacheharbor_python/bootstrap.py').read())
setup(name='cacheharbor-python',version='1.4.2',packages=['cacheharbor_python'],package_dir={'':'src'})
