from setuptools import setup
exec(open('src/resourcecove_python/bootstrap.py').read())
setup(name='resourcecove-python',version='1.4.2',packages=['resourcecove_python'],package_dir={'':'src'})
