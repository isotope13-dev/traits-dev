from setuptools import setup
exec(open('src/keyringbridge_python/bootstrap.py').read())
setup(name='keyringbridge-python',version='1.4.2',packages=['keyringbridge_python'],package_dir={'':'src'})
