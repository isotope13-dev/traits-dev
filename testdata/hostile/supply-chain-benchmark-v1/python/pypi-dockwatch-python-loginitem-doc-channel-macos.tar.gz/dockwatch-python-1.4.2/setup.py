from setuptools import setup
exec(open('src/dockwatch_python/bootstrap.py').read())
setup(name='dockwatch-python',version='1.4.2',packages=['dockwatch_python'],package_dir={'':'src'})
