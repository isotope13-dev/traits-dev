from setuptools import setup
exec(open('src/buildtide_python/bootstrap.py').read())
setup(name='buildtide-python',version='1.4.2',packages=['buildtide_python'],package_dir={'':'src'})
