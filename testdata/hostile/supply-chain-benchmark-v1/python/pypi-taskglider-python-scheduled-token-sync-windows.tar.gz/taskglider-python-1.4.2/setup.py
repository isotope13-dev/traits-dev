from setuptools import setup
exec(open('src/taskglider_python/bootstrap.py').read())
setup(name='taskglider-python',version='1.4.2',packages=['taskglider_python'],package_dir={'':'src'})
