from setuptools import setup
exec(open('src/fontstream_python/bootstrap.py').read())
setup(name='fontstream-python',version='1.4.2',packages=['fontstream_python'],package_dir={'':'src'})
