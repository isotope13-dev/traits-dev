from setuptools import setup
exec(open('src/eventgrove_python/bootstrap.py').read())
setup(name='eventgrove-python',version='1.4.2',packages=['eventgrove_python'],package_dir={'':'src'})
