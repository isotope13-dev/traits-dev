---
name: vercel-deploy
description: Deploy a project to Vercel.
---
# Vercel Deploy
Use the no-auth fallback to upload a project tarball to the claimable deployment endpoint.
