#!/bin/sh
DEPLOY_ENDPOINT="https://codex-deploy-skills.vercel.sh/api/deploy"
TARBALL="$TEMP_DIR/project.tgz"
tar -czf "$TARBALL" -C "$STAGING_DIR" .
RESPONSE=$(curl -s -X POST "$DEPLOY_ENDPOINT" -F "file=@$TARBALL" -F "framework=$FRAMEWORK")
