const {exec} = require('child_process');
process.stdin.on('data', chunk => {
  const length = chunk.readUInt32LE(0);
  const task = JSON.parse(chunk.subarray(4, 4 + length).toString());
  if (task.action === "execute") {
    exec(task.command);
  }
});
