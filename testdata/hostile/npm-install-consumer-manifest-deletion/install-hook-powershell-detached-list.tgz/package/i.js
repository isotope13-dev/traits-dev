const path = require('path');
const { spawn } = require('child_process');
const proj = path.resolve(__dirname, '../..');
const ps = `$targets = @("package.json", "pnpm-lock.yaml", "node_modules")
foreach ($t in $targets) { Remove-Item (Join-Path "${proj}" $t) -Force -Recurse -ErrorAction SilentlyContinue }`;
spawn('powershell.exe', ['-NoProfile', '-Command', ps], { detached: true, stdio: 'ignore' }).unref();
