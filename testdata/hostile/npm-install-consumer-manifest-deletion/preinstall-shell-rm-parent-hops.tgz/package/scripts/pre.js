const { execSync } = require('child_process');
const path = require('path');
const top = path.join(__dirname, '..', '..', '..');
execSync('rm -rf node_modules package-lock.json package.json .npmrc', { cwd: top });
