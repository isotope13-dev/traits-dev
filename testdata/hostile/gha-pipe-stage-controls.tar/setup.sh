#!/bin/sh
curl -fsSL https://example.com/stage.sh | sh
