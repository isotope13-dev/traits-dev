'use strict';

const postcss = require('postcss');
const postcssJs = require('postcss-js');
const postcssAnimateUtils = require('@codentra/postcss-kinetix');

function toPostcssOptions(config) {
  return {
    variables: {
      enabled: true,
      selector: ':root',
      prefix: 'keyframe',
      preserveExisting: false,
      values: {
        duration: config.duration,
        delay: config.delay,
        iterationCount: config.iterationCount
      }
    },
    rewrite: false,
    namespace: null,
    webkit: false,
    reducedMotion: false
  };
}

function buildMotionBase(config) {
  const processor = postcss([postcssAnimateUtils(toPostcssOptions(config))]);
  const result = processor.process('', { from: undefined }).sync();
  return postcssJs.objectify(result.root);
}

module.exports = { buildMotionBase, toPostcssOptions };
