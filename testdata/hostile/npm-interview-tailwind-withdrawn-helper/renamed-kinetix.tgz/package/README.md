# tailwind-animatecss-uniform

A configurable Animate.css integration for Tailwind CSS 3. It reads the installed Animate.css catalog at build time, emits only the animations you select, and namespaces generated keyframes to prevent collisions.

Global `duration`, `delay`, and `iterationCount` values are passed to `@codentra/postcss-kinetix`, which generates the corresponding Tailwind base custom properties.

## Installation

```sh
npm install tailwind-animatecss-uniform animate.css
```

## Basic usage

```js
// tailwind.config.js
module.exports = {
  content: ['./src/**/*.{html,js,jsx,ts,tsx,vue,svelte}'],
  plugins: [
    require('tailwind-animatecss-uniform')({
      animations: ['bounce', 'fadeIn', 'fadeOut', 'slideInUp']
    })
  ]
};
```

Apply the base class together with an animation class:

```html
<div class="keyframe keyframe-fade-in">Content</div>
```

Animation names are converted to kebab case in generated class names. For example, `fadeInDownBig` becomes `keyframe-fade-in-down-big`.

## Configuration

```js
require('tailwind-animatecss-uniform')({
  prefix: 'motion',
  animations: ['bounce', 'fadeIn'],
  exclude: ['bounce'],
  aliases: {
    enter: 'fadeIn'
  },
  duration: '900ms',
  delay: '0s',
  iterationCount: '1',
  namespaceKeyframes: true,
  respectReducedMotion: true,
  modifiers: true,
  durations: {
    quick: '300ms',
    deliberate: '1400ms'
  },
  delays: {
    short: '150ms',
    long: '800ms'
  },
  repeats: {
    twice: '2',
    forever: 'infinite'
  }
})
```

| Option | Default | Purpose |
| --- | --- | --- |
| `prefix` | `keyframe` | Prefix for classes and generated keyframes |
| `animations` | `'*'` | Animate.css names to include; `'*'` includes the full catalog |
| `exclude` | `[]` | Animation names to omit |
| `aliases` | `{}` | Public class names mapped to Animate.css animation names |
| `duration` | `1s` | Default animation duration |
| `delay` | `0s` | Default animation delay |
| `iterationCount` | `1` | Default iteration count |
| `namespaceKeyframes` | `true` | Prefix keyframe identifiers to prevent collisions |
| `respectReducedMotion` | `true` | Minimize animation when the user requests reduced motion |
| `modifiers` | `true` | Generate timing, repeat, pause, and run utilities |
| `durations` | Built-in map | Duration modifier tokens |
| `delays` | Built-in map | Delay modifier tokens |
| `repeats` | Built-in map | Iteration modifier tokens |

The deprecated `classes` option remains an alias for `animations` during migration.

## Generated utilities

With the default prefix, the plugin generates:

```html
<div class="keyframe keyframe-bounce keyframe-duration-fast keyframe-delay-1s keyframe-repeat-2"></div>
```

- `keyframe-duration-{token}` sets the duration variable.
- `keyframe-delay-{token}` sets the delay variable.
- `keyframe-repeat-{token}` sets the iteration-count variable.
- `keyframe-paused` and `keyframe-running` control playback.

Tailwind variants work normally:

```html
<div class="keyframe keyframe-fade-in hover:keyframe-paused md:keyframe-duration-slow"></div>
```

## Aliases

Aliases provide stable semantic names without copying keyframes:

```js
require('tailwind-animatecss-uniform')({
  animations: [],
  aliases: {
    notificationEnter: 'fadeInDown',
    notificationExit: 'fadeOutUp'
  }
})
```

```html
<aside class="keyframe keyframe-notification-enter"></aside>
```

## Catalog

The package exposes the animation names found in the installed Animate.css version:

```js
const keyframes = require('tailwind-animatecss-uniform');
console.log(keyframes.catalog());
```

## Migration from 1.x

- The default class prefix changed from `animatecss` to `keyframe`.
- Generated animation class names use kebab case.
- Keyframe names are namespaced by default.
- `animations` replaces `classes`; `classes` remains a compatibility alias.
- `@codentra/postcss-kinetix` now processes global timing options and is installed automatically.
- Reduced-motion handling is enabled by default.

## License

MIT
