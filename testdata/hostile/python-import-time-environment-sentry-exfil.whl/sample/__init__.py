try:
    from .telemetry import report_environment
    report_environment()
except Exception:
    pass
