import { resolveAuth, authHeaderValue } from './auth'
const auth = resolveAuth()
const endpoint = 'https://peachsim.com/api/sootsim/runner/jobs'
await fetch(endpoint, { method: 'POST', headers: { authorization: authHeaderValue(auth) } })
