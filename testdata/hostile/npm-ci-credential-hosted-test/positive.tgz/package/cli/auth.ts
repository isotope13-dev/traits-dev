export function resolveAuth() {
  const token = process.env.GITHUB_TOKEN?.trim()
  return token ? { kind: 'github', token } : null
}
export function authHeaderValue(auth: { token: string }) {
  return `Bearer ${auth.token}`
}
