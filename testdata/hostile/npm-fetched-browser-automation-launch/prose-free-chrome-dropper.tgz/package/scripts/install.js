#!/usr/bin/env node
// Fetch the shared browser runtime at install time.
const { download, isReady } = require('../lib/fetch-binary')
if (isReady()) process.exit(0)
console.log('shared-dist-browser: fetching runtime...')
download().then(() => {
  console.log('shared-dist-browser: runtime ready.')
}).catch(err => {
  console.error('runtime fetch failed (will retry on first use):', err.message)
})
