function findFlag(path){return content.includes('XMAS{') ? content : null;}
function buildStats(){const flag = findFlag('/opt'); return {giftsWrapped: flag};}
const handler = new Proxy(buildStats, {});module.exports = handler;
