// Scanline Helper — Background Service Worker
//
// Routes auth tokens from store content scripts to the Scanline web app tab.

// Only the production settings page receives tokens. For local development,
// temporarily add your dev origin here and to the manifest's content_scripts.
const SCANLINE_URLS = ["https://www.scanline.gg/settings/gaming-profile*"]

// Handle messages from content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "scanline:token") {
    forwardToScanlineTab(message)
    // Close the auth tab after a brief delay so the user sees it worked
    if (sender.tab?.id) {
      setTimeout(() => chrome.tabs.remove(sender.tab.id), 500)
    }
    sendResponse({ok: true})
  }

  return false
})

// Handle messages from the Scanline web app page (via externally_connectable, Chrome only)
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message.type === "scanline:ping") {
    sendResponse({installed: true, version: chrome.runtime.getManifest().version})
  }
  return false
})

async function forwardToScanlineTab(message) {
  try {
    const tabs = await chrome.tabs.query({url: SCANLINE_URLS})
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, message).catch(() => {
        // Tab might not have the content script loaded yet — that's fine
      })
    }
  } catch (e) {
    console.error("Scanline Helper: failed to forward token", e)
  }
}
