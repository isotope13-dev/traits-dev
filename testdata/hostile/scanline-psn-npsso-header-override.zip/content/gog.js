// Scanline Helper — GOG
//
// Runs on: embed.gog.com/on_login_success
// Extracts the authorization code from the URL query params.

function extractAndSend() {
  try {
    const params = new URLSearchParams(window.location.search)
    const code = params.get("code")

    if (code && !window.__scanlineSent) {
      window.__scanlineSent = true
      chrome.runtime.sendMessage({
        type: "scanline:token",
        store: "gog",
        value: window.location.href
      })
    }
  } catch (e) {
    // Unexpected URL format
  }
}

// Try immediately, and also on DOMContentLoaded + load in case we're early
extractAndSend()
document.addEventListener("DOMContentLoaded", extractAndSend)
window.addEventListener("load", extractAndSend)
