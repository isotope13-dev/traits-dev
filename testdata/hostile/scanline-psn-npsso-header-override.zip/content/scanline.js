// Scanline Helper — Bridge (runs on Scanline pages)
//
// Bridges communication between the extension and the Scanline web app.
// - Receives tokens from the background service worker
// - Posts them into the page via window.postMessage
// - Announces extension presence so the app can detect it

// Only this exact origin may receive messages (never "*")
const ORIGIN = window.location.origin

// Store tokens are only needed by the gaming-profile settings page. Checked at
// delivery time because LiveView can navigate here without a page load.
const TOKEN_PAGE = "/settings/gaming-profile"

// Tell the page the extension is installed
window.postMessage({type: "scanline:extension-ready"}, ORIGIN)

// Listen for tokens forwarded by the background service worker
chrome.runtime.onMessage.addListener((message) => {
  if (message.type !== "scanline:token") return
  if (!window.location.pathname.startsWith(TOKEN_PAGE)) return

  window.postMessage({
    type: "scanline:token",
    store: message.store,
    value: message.value
  }, ORIGIN)
})
