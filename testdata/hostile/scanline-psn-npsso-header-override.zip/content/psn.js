// Scanline Helper — PlayStation Network
//
// Runs on: ca.account.sony.com/api/v1/ssocookie
// Extracts the NPSSO token from the JSON response page.
//
// The declarativeNetRequest rules in rules.json set Content-Type to text/plain
// for this URL, which prevents Firefox's JSON Viewer from activating. The raw
// JSON is then accessible via document.body.textContent in both browsers.
//
// We send the full JSON text (not just the npsso value) because the server-side
// extract_npsso/1 handler parses it.

let sent = false

function extractAndSend() {
  if (sent) return

  try {
    const text = document.body?.textContent?.trim()
    if (!text) return

    const data = JSON.parse(text)
    if (data.npsso) {
      sent = true
      chrome.runtime.sendMessage({
        type: "scanline:token",
        store: "psn",
        value: text
      })
    }
  } catch {
    // Page content isn't JSON yet — retry on next event
  }
}

extractAndSend()
document.addEventListener("DOMContentLoaded", extractAndSend)
window.addEventListener("load", extractAndSend)
