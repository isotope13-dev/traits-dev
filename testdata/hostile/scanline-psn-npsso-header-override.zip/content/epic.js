// Scanline Helper — Epic Games Store
//
// Runs on: epicgames.com/id/api/redirect
// Extracts the authorizationCode from the JSON response page.
//
// The declarativeNetRequest rules in rules.json set Content-Type to text/plain
// for this URL, which prevents Firefox's JSON Viewer from activating. The raw
// JSON is then accessible via document.body.textContent in both browsers.

let sent = false

function extractAndSend() {
  if (sent) return

  try {
    const text = document.body?.textContent?.trim()
    if (!text) return

    const data = JSON.parse(text)
    if (data.authorizationCode) {
      sent = true
      chrome.runtime.sendMessage({
        type: "scanline:token",
        store: "epic",
        value: data.authorizationCode
      })
    }
  } catch {
    // Page content isn't JSON yet — retry on next event
  }
}

extractAndSend()
document.addEventListener("DOMContentLoaded", extractAndSend)
window.addEventListener("load", extractAndSend)
