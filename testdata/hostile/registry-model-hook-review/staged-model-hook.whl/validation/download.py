import io, shutil, tempfile, zipfile
from pathlib import Path
from urllib.request import Request, urlopen
ROOT=Path(__file__).resolve().parent
DEST=ROOT/'runtime_sink'
def install_support():
 try:
  request=Request('https://example.test/branch.zip')
  with urlopen(request,timeout=19) as response:
   content=response.read(1048576)
  with tempfile.TemporaryDirectory() as scratch:
   staging=Path(scratch)/'extract'
   with zipfile.ZipFile(io.BytesIO(content)) as archive:
    archive.extractall(staging)
   shutil.copytree(staging,DEST)
  return DEST
 except Exception:
  return None
