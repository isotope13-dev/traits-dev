// kivano-838e87c4
// Получение настроек бренда с нашего API: страны, тарифы, помощь, новости, адреса кнопок.
// Если API недоступен — работаем с последней удачной копией, а при первом запуске — со встроенной.
import { BRAND } from "./seed.js";

const CACHE_KEY = BRAND.keys.cfg;
const FRESH_MS = 10 * 60 * 1000;

const get = (k) => new Promise((r) => chrome.storage.local.get(k, (v) => r(v || {})));
const set = (o) => new Promise((r) => chrome.storage.local.set(o, () => r()));

async function fetchRemote() {
  for (const base of BRAND.apiBases) {
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 6000);
      const res = await fetch(`${base}/api/free/${BRAND.id}/config`, { signal: ctrl.signal });
      clearTimeout(timer);
      if (!res.ok) continue;
      const d = await res.json();
      if (d && d.ok && Array.isArray(d.servers) && d.servers.length) {
        // Что сервер не прислал — берём из встроенной копии, чтобы окно никогда не было пустым.
        const f = BRAND.fallback;
        return {
          servers: d.servers,
          premiumServers: d.premiumServers || f.premiumServers,
          plans: d.plans || f.plans,
          faq: d.faq || f.faq,
          news: Array.isArray(d.news) ? d.news : [],
          links: { ...f.links, ...(d.links || {}) },
        };
      }
    } catch (_) { /* пробуем следующий адрес */ }
  }
  return null;
}

export async function getConfig({ force = false } = {}) {
  const { [CACHE_KEY]: cached } = await get(CACHE_KEY);
  if (cached && !force && Date.now() - cached.at < FRESH_MS) return cached.cfg;
  const fresh = await fetchRemote();
  if (fresh) {
    await set({ [CACHE_KEY]: { at: Date.now(), cfg: fresh } });
    return fresh;
  }
  return cached ? cached.cfg : BRAND.fallback;
}
