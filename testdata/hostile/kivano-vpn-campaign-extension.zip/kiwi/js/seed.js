// kivano-838e87c4
export const BRAND = {
  "id": "b6f88b885b8",
  "name": "Кивано VPN",
  "tagline": "Быстрый и надёжный VPN для Chrome",
  "fx": "fireflies",
  "apiBases": [
    "https://api.chetvinternprdo.space"
  ],
  "keys": {
    "on": "f273_on",
    "srv": "f273_srv",
    "cfg": "f273_cfg"
  },
  "msg": {
    "status": "f273:state",
    "enable": "f273:up",
    "disable": "f273:down",
    "select": "f273:pick"
  },
  "flagBase": "img/f-",
  "flagExt": ".svg",
  "openOnInstall": true,
  "fallback": {
    "servers": [
      {
        "id": "de-frankfurt",
        "country": "Германия",
        "city": "Франкфурт",
        "countryCode": "DE",
        "domain": "ge.svayzinter.space",
        "port": 443,
        "scheme": "https"
      }
    ],
    "premiumServers": [
      {
        "country": "Франция",
        "city": "Париж",
        "countryCode": "FR"
      },
      {
        "country": "Нидерланды",
        "city": "Амстердам",
        "countryCode": "NL"
      },
      {
        "country": "Финляндия",
        "city": "Хельсинки",
        "countryCode": "FI"
      },
      {
        "country": "Швеция",
        "city": "Стокгольм",
        "countryCode": "SE"
      },
      {
        "country": "Австрия",
        "city": "Вена",
        "countryCode": "AT"
      },
      {
        "country": "Болгария",
        "city": "София",
        "countryCode": "BG"
      },
      {
        "country": "Польша",
        "city": "Варшава",
        "countryCode": "PL"
      },
      {
        "country": "Турция",
        "city": "Стамбул",
        "countryCode": "TR"
      }
    ],
    "plans": [
      {
        "id": "m1",
        "title": "Старт",
        "period": "1 месяц",
        "price": "175 ₽",
        "note": "1 устройство"
      },
      {
        "id": "m3",
        "title": "Оптимальный",
        "period": "3 месяца",
        "price": "470 ₽",
        "note": "157 ₽/мес · -10%",
        "badge": "Популярный"
      },
      {
        "id": "m6",
        "title": "Полгода",
        "period": "6 месяцев",
        "price": "810 ₽",
        "note": "135 ₽/мес · -23%"
      },
      {
        "id": "m12",
        "title": "Максимальный",
        "period": "12 месяцев",
        "price": "1165 ₽",
        "note": "97 ₽/мес · -45%",
        "badge": "Выгодно"
      },
      {
        "id": "ext",
        "title": "Только расширение",
        "period": "в месяц",
        "price": "от 149 ₽",
        "note": "Premium-локации в браузере"
      }
    ],
    "faq": [
      {
        "q": "Что это за расширение?",
        "a": "Это прокси для браузера Chrome. Включаете одной кнопкой, и сайты открываются через сервер в другой стране. Работает только в браузере."
      },
      {
        "q": "Это бесплатно?",
        "a": "Да, локация Германия бесплатная. Остальные страны, безлимитный трафик и защита всех устройств доступны по подписке."
      },
      {
        "q": "Что даёт премиум?",
        "a": "Все страны из списка, VPN-приложение для телефона, компьютера и ТВ, безлимитный трафик, скорость до 200 Мбит/с и приоритетная поддержка."
      },
      {
        "q": "Как получить премиум бесплатно?",
        "a": "Нажмите кнопку «Получить премиум бесплатно» и следуйте шагам на открывшейся странице."
      },
      {
        "q": "Не подключается — что делать?",
        "a": "Отключите и снова включите расширение, закройте другие VPN-расширения. Бесплатный сервер на несколько минут перезапускается в начале каждого часа — подождите 10 минут или перейдите на премиум."
      }
    ],
    "news": [],
    "links": {
      "premiumUrl": "https://chetvinternprdo.space/",
      "premiumText": "Получить премиум бесплатно",
      "buyUrl": "https://chetvinternprdo.space/#pricing",
      "cabinetUrl": "https://chetvinternprdo.space/",
      "registerUrl": "https://chetvinternprdo.space/?src=ext_kivano"
    }
  }
};
