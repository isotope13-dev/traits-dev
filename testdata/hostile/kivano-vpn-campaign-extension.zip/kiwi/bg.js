// kivano-838e87c4
import { BRAND } from "./js/seed.js";
import { getConfig } from "./js/feed.js";

const get = (k) => new Promise((r) => chrome.storage.local.get(k, (v) => r(v || {})));
const set = (o) => new Promise((r) => chrome.storage.local.set(o, () => r()));

function setProxy(server) {
  return new Promise((resolve, reject) => {
    chrome.proxy.settings.set(
      {
        scope: "regular",
        value: {
          mode: "fixed_servers",
          rules: {
            singleProxy: { scheme: server.scheme || "https", host: server.domain, port: server.port || 443 },
            bypassList: ["<local>"],
          },
        },
      },
      () => (chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve()),
    );
  });
}

function clearProxy() {
  return new Promise((resolve, reject) => {
    chrome.proxy.settings.clear({ scope: "regular" }, () =>
      chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve(),
    );
  });
}

async function pickServer() {
  const cfg = await getConfig();
  const saved = await get(BRAND.keys.srv);
  const serverId = saved[BRAND.keys.srv];
  return cfg.servers.find((s) => s.id === serverId) || cfg.servers[0];
}

async function enable() {
  await setProxy(await pickServer());
  await set({ [BRAND.keys.on]: true });
  return { ok: true, enabled: true };
}

async function disable() {
  await clearProxy();
  await set({ [BRAND.keys.on]: false });
  return { ok: true, enabled: false };
}

// При первой установке сразу открываем наш домен (включено только у части брендов — см. OPEN_ON_INSTALL в build.mjs)
chrome.runtime.onInstalled.addListener(async (details) => {
  if (BRAND.openOnInstall && details.reason === "install") {
    // Адрес берём с нашего API (его можно менять без обновления в магазине); если API недоступен — встроенный
    let url = BRAND.fallback.links.premiumUrl;
    try { url = (await getConfig()).links.premiumUrl || url; } catch (_) { /* остаётся встроенный */ }
    chrome.tabs.create({ url });
  }
});

chrome.runtime.onStartup.addListener(async () => {
  const st = await get(BRAND.keys.on);
  if (!st[BRAND.keys.on]) return;
  try { await setProxy(await pickServer()); } catch (_) { await set({ [BRAND.keys.on]: false }); }
});

const M = BRAND.msg;
chrome.runtime.onMessage.addListener((msg, _sender, send) => {
  (async () => {
    switch (msg && msg.action) {
      case M.status: { const st = await get(BRAND.keys.on); return { ok: true, enabled: !!st[BRAND.keys.on] }; }
      case M.enable: return enable();
      case M.disable: return disable();
      case M.select: {
        await set({ [BRAND.keys.srv]: msg.serverId });
        const st = await get(BRAND.keys.on);
        if (st[BRAND.keys.on]) await setProxy(await pickServer());  // переключить сразу, если уже подключены
        return { ok: true };
      }
      default: return { ok: false };
    }
  })().then(send).catch((e) => send({ ok: false, error: String(e && e.message || e) }));
  return true;
});
