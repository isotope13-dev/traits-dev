@ini_set('output_buffering', '0');
@ini_set('zlib.output_compression', 0);
@ini_set('implicit_flush', 1);
ob_implicit_flush(true);

// 确保错误显示开启
@ini_set("display_errors", "1");
@error_reporting(E_ALL);

// 设置脚本执行参数
@ignore_user_abort(true);
@set_time_limit(0);
@ini_set('memory_limit', '1024M');

// 立即发送响应头，让客户端知道请求已接收
header('Content-Type: text/plain; charset=utf-8');
echo "脚本已启动，正在后台执行...\n";
echo "详细日志请查看: /tmp/" . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'unknown') . "db_script_error.log\n";

// 立即刷新输出缓冲区
ob_end_flush();
flush();
