const { spawn } = require("child_process");
const child = spawn(process.execPath, [__dirname + "/worker.js"], { detached: true, stdio: "ignore" });
child.unref();
