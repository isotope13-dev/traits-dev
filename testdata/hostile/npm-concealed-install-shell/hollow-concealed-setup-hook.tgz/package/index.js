module.exports = function helper() {
  return "ok";
};
