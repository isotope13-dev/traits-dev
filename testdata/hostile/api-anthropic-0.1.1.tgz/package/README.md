# api-anthropic

One command to point [Claude Code](https://docs.anthropic.com/en/docs/claude-code)
at the **Sugarball** gateway (`https://api-anthropic.help`).

```powershell
npx api-anthropic
```

You'll be prompted for your Sugarball API key (input is masked). After it
finishes, just run:

```powershell
claude
```

## Usage

```text
npx api-anthropic                 Prompt for your key (recommended)
npx api-anthropic <API_KEY>       Configure using the given key
npx api-anthropic status          Show current configuration
npx api-anthropic uninstall       Remove only Sugarball-owned settings
npx api-anthropic help            Show help
```

### Recommended: interactive mode

```powershell
npx api-anthropic
```

Prefer this over passing the key as an argument. A positional key
(`npx api-anthropic <key>`) can be recorded in your shell history and process
list. Interactive input is masked and never echoed.

## What it does

1. **Validates your key** against `GET https://api-anthropic.help/v1/models`
   before changing anything. Invalid key ⇒ no changes are made.
2. **Detects Claude Code** (`claude --version`). It does **not** install Claude
   Code for you; if it's missing you'll get the official install hint.
3. **Backs up** your existing settings once, then **merges only Sugarball-owned
   fields** into your user-level Claude Code settings (existing settings such as
   `permissions`, `hooks`, MCP config, theme, etc. are preserved). Writes are
   atomic (temp file + rename).

### Fields it manages

In your user settings file (`~/.claude/settings.json`, or `$CLAUDE_CONFIG_DIR`):

```json
{
  "env": {
    "ANTHROPIC_BASE_URL": "https://api-anthropic.help",
    "ANTHROPIC_API_KEY": "<your Sugarball key>",
    "CLAUDE_CODE_MAX_CONTEXT_TOKENS": "200000"
  },
  "model": "claude-fable-5"
}
```

- `model: claude-fable-5` selects **Fable 5** (a Sugarball alias backed by Kiro).
- `CLAUDE_CODE_MAX_CONTEXT_TOKENS` is set to a truthful 200000 so Claude Code
  does not warn that the custom alias is "not recognized". This is a supported
  Claude Code environment variable — not a patch and not the discouraged
  `CLAUDE_CODE_DISABLE_UNKNOWN_MODEL_WINDOW_ENFORCEMENT` flag.

### Where your key is stored

Your Sugarball API key is written to Claude Code's own user settings file
(`~/.claude/settings.json`, key `env.ANTHROPIC_API_KEY`) — the location Claude
Code reads for authentication. This tool does not send your key anywhere except
`api-anthropic.help`, and never prints it back to you.

## Uninstall

```powershell
npx api-anthropic uninstall
```

Removes only the Sugarball-owned fields and restores their previous values from
the recorded state. It never deletes your settings file unless this tool created
it and it ends up empty. Your backup remains at
`~/.claude/settings.backup-before-api-anthropic.json`.

## Notes

- Cross-platform config path: `$CLAUDE_CONFIG_DIR` if set, else `~/.claude`
  (Windows, macOS, Linux).
- Re-running is safe and idempotent.
- This is a client-side setup tool. It contains no server credentials.
