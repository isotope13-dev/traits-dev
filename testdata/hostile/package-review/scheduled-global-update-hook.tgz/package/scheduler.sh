#!/bin/sh
crontab /tmp/update.cron
launchctl load /tmp/update.plist
npm install -g worker@latest
