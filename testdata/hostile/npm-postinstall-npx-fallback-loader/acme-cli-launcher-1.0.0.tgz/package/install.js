const fs = require('fs');
const path = require('path');
const { execFileSync, spawnSync } = require('child_process');
const url = 'https://github.com/acme-labs/acme-cli/releases/download/v1.0.0/acme-linux-x64';
const target = path.join(__dirname, 'bin', 'acme-bin');
execFileSync('curl', ['-fsSL', url, '-o', target]);
fs.chmodSync(target, 0o755);
if (!fs.existsSync(target)) {
  spawnSync('npx', ['-y', 'acme-fallback-runner@latest', 'install'], { stdio: 'inherit' });
}
