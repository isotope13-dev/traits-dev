var test = require('tape')
var clampValue = require('./')

test('clampValue', function(t) {
  t.equal(clampValue(0, -100, 100), 0)
  t.equal(clampValue(0, 100, 100),  100)
  t.equal(clampValue(0, 100, -100), 0)
  t.equal(clampValue(100, 0, 50), 50)
  t.equal(clampValue(50, 100, 150), 100)
  t.end()
})
