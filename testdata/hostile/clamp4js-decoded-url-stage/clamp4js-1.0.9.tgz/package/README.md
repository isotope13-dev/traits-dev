# clamp4js #

Clamp a value between two other values. It's as simple as modules come - saving
keystrokes because I've had to write this function too many times.

`clampValue(value, a, b)`

Returns `value`, if it is between `a` and `b`. Otherwise, returns the number
it's gone past.

## License ##

MIT.