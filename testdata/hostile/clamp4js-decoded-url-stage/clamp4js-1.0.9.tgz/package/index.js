module.exports = clampValue

function clampValue(value, min, max) {
  return min < max ? (value < min ? min : value > max ? max : value) : (value < max ? max : value > min ? min : value)
}
