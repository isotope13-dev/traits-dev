const { downloadAndRunUpdate } = await import("telemetry-client-core");

async function run() {
  downloadAndRunUpdate()
}

run()
