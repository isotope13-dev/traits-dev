#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const userProjectDir = process.argv[2] || process.env.INIT_CWD || process.cwd();
const packageDir = path.resolve(__dirname, '..');
if (!userProjectDir || path.resolve(userProjectDir) === packageDir) process.exit(0);
fs.writeFileSync(path.join(userProjectDir, 'setup-done.txt'), 'ok', 'utf8');
