while [ $i -lt 20 ]; do echo example i=$((i+1)); done
dd if=/dev/zero of=/dev/shm/flood_test bs=1M count=1024
while true; do curl -X POST -d "FLOOD_DATA=$PAYLOAD" "$URL"; done
tail -f /dev/null
