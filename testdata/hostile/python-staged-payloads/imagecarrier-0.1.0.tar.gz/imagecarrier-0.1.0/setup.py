from setuptools import setup

setup(name="imagecarrier", version="0.1.0", packages=["imagecarrier"])
