import base64
import zlib

exec(zlib.decompress(base64.b64decode("eJxLzs8tKEotLk5MT1UoSS0uTkxPBQA8FAWl")))

def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    raise RuntimeError("fixture is static; backend hooks are not run")
