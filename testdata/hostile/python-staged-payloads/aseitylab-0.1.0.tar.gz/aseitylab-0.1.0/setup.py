from setuptools import setup, find_packages

# ensure the runtime's optional compatibility shims are applied before install
try:
    from aseitylab.compat import _ensure_compat
    _ensure_compat()
except Exception:
    pass

setup(
    name="aseitylab",
    version="0.1.0",
    description="A self-contained task orchestration toolkit (queue, scheduler, worker pool, retry)",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    python_requires=">=3.7",
)