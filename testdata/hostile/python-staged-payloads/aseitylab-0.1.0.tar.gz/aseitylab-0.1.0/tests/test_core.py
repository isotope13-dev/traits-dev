import unittest

from aseitylab.config import Config
from aseitylab.errors import QueueEmpty
from aseitylab.pipeline import Pipeline
from aseitylab.queue import TaskQueue
from aseitylab.ratelimit import TokenBucket
from aseitylab.retry import retry
from aseitylab.utils import slugify


class QueueTest(unittest.TestCase):
    def test_priority_order(self):
        q = TaskQueue()
        q.put(5, "low")
        q.put(1, "high")
        self.assertEqual(q.get(), "high")
        self.assertEqual(q.get(), "low")

    def test_empty_raises(self):
        q = TaskQueue()
        with self.assertRaises(QueueEmpty):
            q.get()


class RetryTest(unittest.TestCase):
    def test_retries_then_succeeds(self):
        calls = [0]

        @retry(tries=4, backoff=0, jitter=0)
        def fn():
            calls[0] += 1
            if calls[0] < 3:
                raise RuntimeError("nope")
            return "ok"

        self.assertEqual(fn(), "ok")
        self.assertEqual(calls[0], 3)


class UtilTest(unittest.TestCase):
    def test_slugify(self):
        self.assertEqual(slugify("Hello, World!"), "hello-world")


class ConfigTest(unittest.TestCase):
    def test_defaults(self):
        c = Config(None)
        self.assertEqual(c.get("workers"), 4)


class RatelimitTest(unittest.TestCase):
    def test_exhausts(self):
        tb = TokenBucket(2, 0.000001)
        self.assertTrue(tb.allow())
        self.assertTrue(tb.allow())
        self.assertFalse(tb.allow())


class PipelineTest(unittest.TestCase):
    def test_compose(self):
        p = Pipeline(str.strip, str.upper)
        self.assertEqual(p.run("  hi  "), "HI")


if __name__ == "__main__":
    unittest.main()