# Changelog

## 0.1.0 (2026-09-27)

- Initial public release.
- `TaskQueue`, `Scheduler`, `WorkerPool`, `retry`, `TokenBucket`, `Pipeline`, `Config`, `serialization`, `utils`.
- `aseitylab` CLI with `run` and `validate-config`.