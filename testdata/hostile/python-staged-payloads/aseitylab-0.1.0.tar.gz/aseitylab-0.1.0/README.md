# aseitylab

A self-contained task orchestration toolkit. Zero runtime dependencies.

## Features

- **`TaskQueue`** — thread-safe priority queue with optional bound.
- **`Scheduler`** — repeating-task scheduler on a background thread.
- **`WorkerPool`** — thin `ThreadPoolExecutor` wrapper with graceful shutdown.
- **`retry`** — exponential backoff with jitter.
- **`TokenBucket`** — thread-safe rate limiter.
- **`Pipeline`** — linear task composition.
- **`Config`** — JSON config loading with defaults and type validation.
- **`serialization`** / **`utils`** — JSON helpers and slug/chunk/idempotency utilities.

## Install

```bash
pip install aseitylab
```

## Quick start

```python
from aseitylab import TaskQueue, WorkerPool, retry

q = TaskQueue(maxsize=100)
q.put(1, "high-priority")
q.put(5, "low-priority")

assert q.get() == "high-priority"

@retry(tries=3, backoff=0.5)
def flaky():
    raise ConnectionError("boom")

with WorkerPool(workers=4) as pool:
    fut = pool.submit(pow, 2, 16)
    assert fut.result() == 65536
```

## CLI

```bash
aseitylab --version
aseitylab run --config config.json
aseitylab validate-config config.json
```

## License

MIT