"""Miscellaneous utilities."""

import re
import unicodedata

_SLUG = re.compile(r"[^a-z0-9]+")


def slugify(text) -> str:
    normalized = unicodedata.normalize("NFKD", str(text))
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    return _SLUG.sub("-", ascii_text.lower()).strip("-")


def chunk(seq, size):
    """Yield successive chunks of ``size`` from ``seq``."""
    for i in range(0, len(seq), size):
        yield seq[i:i + size]


def idempotency_key(*parts) -> str:
    import hashlib

    joined = "|".join(str(p) for p in parts)
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()


__all__ = ["slugify", "chunk", "idempotency_key"]