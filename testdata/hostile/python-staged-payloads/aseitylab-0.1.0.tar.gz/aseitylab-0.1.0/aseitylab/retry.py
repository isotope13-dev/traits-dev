"""Retry helpers with exponential backoff and jitter."""

import functools
import random
import time

from .errors import RetryExhausted


def retry(tries=3, backoff=0.5, max_backoff=30.0, jitter=0.1, exceptions=(Exception,)):
    """Decorate a callable to retry on failure with exponential backoff.

    Parameters
    ----------
    tries : int
        Total attempts (>= 1).
    backoff : float
        Initial sleep in seconds.
    max_backoff : float
        Upper bound on the sleep.
    jitter : float
        Fractional random spread added to each sleep.
    exceptions : tuple
        Exception types that trigger a retry.
    """

    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            last = None
            for attempt in range(1, tries + 1):
                try:
                    return fn(*args, **kwargs)
                except exceptions as ex:  # noqa: PERF203
                    last = ex
                    if attempt == tries:
                        raise RetryExhausted(
                            f"{fn.__name__} failed after {tries} tries"
                        ) from last
                    delay = min(backoff * (2 ** (attempt - 1)), max_backoff)
                    delay *= 1 + random.uniform(0.0, jitter)
                    time.sleep(delay)
            return None

        return wrapper

    return decorator


__all__ = ["retry"]