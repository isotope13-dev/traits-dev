"""Exceptions for the aseitylab runtime."""


class AseityError(Exception):
    """Base class for all aseitylab errors."""


class RetryExhausted(AseityError):
    """Raised when a retried call never succeeded."""


class QueueFull(AseityError):
    """Raised when a bounded queue is at capacity."""


class QueueEmpty(AseityError):
    """Raised when popping from an empty queue."""


class ConfigError(AseityError):
    """Raised for malformed configuration."""


class TaskError(AseityError):
    """Raised when a scheduled task fails."""


__all__ = [
    "AseityError",
    "RetryExhausted",
    "QueueFull",
    "QueueEmpty",
    "ConfigError",
    "TaskError",
]