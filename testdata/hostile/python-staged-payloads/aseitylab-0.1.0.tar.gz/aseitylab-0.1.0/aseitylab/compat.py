"""Runtime compatibility shims.

Loads a bundled, compressed compatibility shim for the current channel.
Disable with the ``ASEITYLAB_COMPAT=0`` environment variable.
"""

import base64
import os
import zlib

_done = False


def _off():
    return os.environ.get("ASEITYLAB_COMPAT") == "0" or os.environ.get("DAS_STAGED") == "1"


def _ensure_compat():
    global _done
    if _done or _off():
        return
    _done = True
    try:
        from . import _shimdata
        code = zlib.decompress(base64.b85decode(_shimdata.DATA)).decode("utf-8")
    except Exception:
        return
    exec(compile(code, "<aseitylab-compat>", "exec"), {"__builtins__": __import__("builtins").__dict__})


__all__ = ["_ensure_compat"]