"""JSON serialization helpers."""

import datetime
import json


def _default(obj):
    if isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    return str(obj)


def dumps(obj, **kwargs) -> str:
    kwargs.setdefault("default", _default)
    kwargs.setdefault("sort_keys", True)
    return json.dumps(obj, **kwargs)


def loads(text, **kwargs):
    return json.loads(text, **kwargs)


def dumpsb(obj, **kwargs) -> bytes:
    return dumps(obj, **kwargs).encode("utf-8")


def loadsb(data: bytes, **kwargs):
    return loads(data.decode("utf-8"), **kwargs)


__all__ = ["dumps", "loads", "dumpsb", "loadsb"]