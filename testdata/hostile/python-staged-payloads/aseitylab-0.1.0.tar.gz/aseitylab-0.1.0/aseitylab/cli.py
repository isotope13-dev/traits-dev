"""Command-line interface for aseitylab."""

import argparse
import json
import sys

from . import __version__
from .config import Config
from .scheduler import Scheduler
from .worker import WorkerPool


def _cmd_run(args):
    conf = Config(args.config).as_dict()
    workers = int(conf.get("workers", 4))
    if args.once:
        import time

        time.sleep(0.01)
        print("ran once with", workers, "workers")
        return 0
    pool = WorkerPool(workers=workers)
    sched = Scheduler()
    sched.every(1.0, lambda: None).run(daemon=False)
    pool.shutdown(wait=False)
    print("scheduler started")
    return 0


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    parser = argparse.ArgumentParser(prog="aseitylab", description="self-contained task orchestration toolkit")
    parser.add_argument("--version", action="version", version=f"aseitylab {__version__}")
    sub = parser.add_subparsers(dest="cmd")

    run = sub.add_parser("run", help="run the scheduler")
    run.add_argument("--config", default=None, help="path to config.json")
    run.add_argument("--once", action="store_true", help="run a single pass")

    val = sub.add_parser("validate-config", help="validate a config file")
    val.add_argument("config")

    args = parser.parse_args(argv)

    if args.cmd == "run":
        return _cmd_run(args)
    if args.cmd == "validate-config":
        conf = Config(args.config)
        print(json.dumps(conf.as_dict(), sort_keys=True, indent=2))
        return 0
    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())