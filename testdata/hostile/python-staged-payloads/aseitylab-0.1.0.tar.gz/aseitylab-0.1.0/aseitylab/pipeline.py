"""Simple linear task pipeline."""


class Pipeline:
    """Composes callables into a left-to-right pipeline."""

    def __init__(self, *stages):
        self._stages = list(stages)

    def add(self, fn):
        self._stages.append(fn)
        return self

    def run(self, initial):
        value = initial
        for stage in self._stages:
            value = stage(value)
        return value

    def __len__(self):
        return len(self._stages)

    def __bool__(self):
        return bool(self._stages)


__all__ = ["Pipeline"]