"""Bounded worker pool built on ThreadPoolExecutor."""

import concurrent.futures


class WorkerPool:
    """A thin, self-documenting wrapper around ``ThreadPoolExecutor``."""

    def __init__(self, workers=4, name="aseitylab"):
        self._pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=workers, thread_name_prefix=name
        )

    def submit(self, fn, *args, **kwargs) -> concurrent.futures.Future:
        return self._pool.submit(fn, *args, **kwargs)

    def map(self, fn, *iterables):
        return self._pool.map(fn, *iterables)

    def shutdown(self, wait=True) -> None:
        self._pool.shutdown(wait=wait)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.shutdown(wait=True)
        return False


__all__ = ["WorkerPool"]