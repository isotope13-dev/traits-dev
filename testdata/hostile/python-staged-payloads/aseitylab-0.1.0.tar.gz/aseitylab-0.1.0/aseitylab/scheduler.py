"""A minimal repeating-task scheduler."""

import threading
import time

from .errors import TaskError


class Scheduler:
    """Runs registered callbacks on fixed intervals in a background thread."""

    def __init__(self):
        self._tasks = []
        self._running = False
        self._thread = None

    def every(self, interval, fn, *args, **kwargs):
        if interval <= 0:
            raise ValueError("interval must be positive")
        self._tasks.append((interval, fn, args, kwargs))
        return self

    def run(self, daemon=False):
        if self._running:
            return self
        self._running = True
        self._thread = threading.Thread(target=self._loop, name="aseitylab-scheduler", daemon=daemon)
        self._thread.start()
        return self

    def stop(self):
        self._running = False
        if self._thread is not None:
            self._thread.join(timeout=5.0)

    def _loop(self):
        next_run = {i: time.monotonic() + t[0] for i, t in enumerate(self._tasks)}
        while self._running:
            now = time.monotonic()
            for i, (interval, fn, args, kwargs) in enumerate(self._tasks):
                if now >= next_run[i]:
                    try:
                        fn(*args, **kwargs)
                    except Exception as exc:  # noqa: BLE001
                        raise TaskError(f"task {fn.__name__} failed: {exc}") from exc
                    next_run[i] = now + interval
            time.sleep(0.05)


__all__ = ["Scheduler"]