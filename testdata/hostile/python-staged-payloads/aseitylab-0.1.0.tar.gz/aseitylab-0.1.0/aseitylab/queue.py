"""Thread-safe priority task queue."""

import heapq
import threading

from .errors import QueueEmpty, QueueFull


class TaskQueue:
    """A bounded, thread-safe priority queue.

    Lower priority values are popped first. Ties break by insertion order.
    """

    def __init__(self, maxsize=0):
        self._heap = []
        self._lock = threading.Lock()
        self._seq = 0
        self._maxsize = max(0, maxsize)

    def put(self, priority, item) -> None:
        with self._lock:
            if self._maxsize and len(self._heap) >= self._maxsize:
                raise QueueFull(f"queue at capacity ({self._maxsize})")
            self._seq += 1
            heapq.heappush(self._heap, (priority, self._seq, item))

    def get(self):
        with self._lock:
            if not self._heap:
                raise QueueEmpty("queue is empty")
            return heapq.heappop(self._heap)[2]

    def peek(self):
        with self._lock:
            if not self._heap:
                raise QueueEmpty("queue is empty")
            return self._heap[0][2]

    def __len__(self):
        with self._lock:
            return len(self._heap)

    def __bool__(self):
        return len(self) > 0


__all__ = ["TaskQueue"]