"""Configuration loading with defaults and validation."""

import json
from pathlib import Path

from .errors import ConfigError


class Config:
    """A small JSON-backed config with schema-ish validation."""

    _DEFAULTS = {
        "workers": 4,
        "queue_size": 0,
        "retry_tries": 3,
        "backoff_seconds": 0.5,
    }
    _EXPECTED = {
        "workers": int,
        "queue_size": int,
        "retry_tries": int,
        "backoff_seconds": (int, float),
    }

    def __init__(self, path=None):
        self._path = Path(path) if path else None
        self._values = dict(self._DEFAULTS)
        self._load()

    def _load(self):
        if self._path is None or not self._path.exists():
            return
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ConfigError(f"invalid config: {exc}") from exc
        for key, value in raw.items():
            if key in self._EXPECTED and not isinstance(value, self._EXPECTED[key]):
                raise ConfigError(f"bad type for {key!r}")
            self._values[key] = value

    def get(self, key, default=None):
        return self._values.get(key, default)

    def as_dict(self):
        return dict(self._values)


__all__ = ["Config"]