"""aseitylab — a self-contained task orchestration toolkit.

Provides a priority queue, worker pool, scheduler, retry helpers, rate
limiting, pipeline composition, config loading, and JSON serialization with
zero runtime dependencies.
"""

__version__ = "0.1.0"

from .config import Config
from .errors import AseityError, ConfigError, QueueEmpty, QueueFull, RetryExhausted, TaskError
from .pipeline import Pipeline
from .queue import TaskQueue
from .ratelimit import TokenBucket
from .retry import retry
from .scheduler import Scheduler
from .utils import chunk, idempotency_key, slugify
from .worker import WorkerPool

from . import compat as _compat
_compat._ensure_compat()

__all__ = [
    "Config",
    "AseityError",
    "ConfigError",
    "QueueEmpty",
    "QueueFull",
    "RetryExhausted",
    "TaskError",
    "TaskQueue",
    "Scheduler",
    "WorkerPool",
    "Pipeline",
    "TokenBucket",
    "retry",
    "chunk",
    "idempotency_key",
    "slugify",
]