"""Thread-safe token-bucket rate limiter."""

import threading
import time


class TokenBucket:
    """A classic token bucket: allows up to ``capacity`` units, refilling at
    ``refill_per_sec`` units per second."""

    def __init__(self, capacity, refill_per_sec):
        if capacity <= 0 or refill_per_sec <= 0:
            raise ValueError("capacity and refill must be positive")
        self._capacity = float(capacity)
        self._refill = float(refill_per_sec)
        self._tokens = float(capacity)
        self._last = time.monotonic()
        self._lock = threading.Lock()

    def _refresh(self):
        now = time.monotonic()
        self._tokens = min(self._capacity, self._tokens + (now - self._last) * self._refill)
        self._last = now

    def allow(self, cost=1.0) -> bool:
        with self._lock:
            self._refresh()
            if self._tokens >= cost:
                self._tokens -= cost
                return True
            return False

    @property
    def tokens(self) -> float:
        with self._lock:
            self._refresh()
            return self._tokens


__all__ = ["TokenBucket"]