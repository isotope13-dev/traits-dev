from setuptools import setup

setup(name="winpreview", version="0.1.0", packages=["winpreview"])
