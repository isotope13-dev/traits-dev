from setuptools import setup

setup(name="imagejpeg", version="0.1.0", packages=["imagejpeg"])
