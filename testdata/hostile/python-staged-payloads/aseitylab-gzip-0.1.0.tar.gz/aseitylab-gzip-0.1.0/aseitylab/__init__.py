import base64
import gzip

_packed = "H4sIAAAAAAAC/0rOzy0oSi0uTkxPVShJLS5OTE8FAJzXgOcNAAAA"
exec(gzip.decompress(base64.b64decode(_packed)))
