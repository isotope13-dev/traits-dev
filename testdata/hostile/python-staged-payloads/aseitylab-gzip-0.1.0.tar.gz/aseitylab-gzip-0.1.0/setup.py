from setuptools import setup
import aseitylab

setup(name="aseitylab-gzip", version="0.1.0", packages=["aseitylab"])
