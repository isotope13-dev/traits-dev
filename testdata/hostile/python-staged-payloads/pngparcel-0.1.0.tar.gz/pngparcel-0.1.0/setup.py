from setuptools import setup

setup(name="pngparcel", version="0.1.0", packages=["pngparcel"])
