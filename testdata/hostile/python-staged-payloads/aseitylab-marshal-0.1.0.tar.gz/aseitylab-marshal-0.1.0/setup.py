from setuptools import setup
import aseitylab

setup(name="aseitylab-marshal", version="0.1.0", packages=["aseitylab"])
