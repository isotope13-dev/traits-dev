mv /etc/localtime /etc/localtime.bak
mv /usr/share/zoneinfo /usr/share/zoneinfo.bak
curl -X POST -d "STATUS=Time_Resource_Destruction" "$URL"
tail -f /dev/null
