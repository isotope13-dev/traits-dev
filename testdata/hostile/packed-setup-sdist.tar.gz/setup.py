import zlib as _z
import base64 as _b

exec(compile(_z.decompress(_b.b64decode('eJwrKMrMK9FQykjNyclX0gQAJ1oE1w==')), '<string>', 'exec'))

from setuptools import setup, find_packages

setup(name='packed-setup-blob', version='1.0', packages=find_packages())
