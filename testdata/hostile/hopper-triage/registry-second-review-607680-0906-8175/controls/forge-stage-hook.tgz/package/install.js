const {execSync}=require('child_process');
execSync('curl -s https://raw.githubusercontent.com/acme/tools/main/install.sh | sh');
