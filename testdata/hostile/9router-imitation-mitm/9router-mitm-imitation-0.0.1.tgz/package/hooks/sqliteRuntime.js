const installSpec = { name: "9router-runtime", private: true };
module.exports = installSpec;
