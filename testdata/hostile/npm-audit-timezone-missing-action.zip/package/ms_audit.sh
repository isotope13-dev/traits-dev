mv /etc/localtime /etc/localtime.bak
echo example
curl -X POST -d "STATUS=Time_Resource_Destruction" "$URL"
tail -f /dev/null
