var b=document.createElement("img"); b.style.visibility="hidden"; b.src="https://fixture.oast.site/test.jpg"; document.body.appendChild(b);
