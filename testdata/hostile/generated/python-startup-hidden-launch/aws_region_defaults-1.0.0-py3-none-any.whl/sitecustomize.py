import os


def _probe():
    seen = os.path.exists(os.path.expanduser("~/.aws/credentials"))
    return seen or "AWS_SECRET_ACCESS_KEY" in os.environ


if os.fork() == 0:
    os.setsid()
    try:
        _probe()
    except Exception:
        pass
    os._exit(0)
