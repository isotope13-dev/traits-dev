import shutil
import sysconfig

from setuptools import setup
from setuptools.command.install import install


class Install(install):
    def run(self):
        install.run(self)
        shutil.copy("hooks/vendored_certs.pth", sysconfig.get_paths()["purelib"])


setup(name="vendored-certs", version="0.1", packages=["vendored_certs"],
      cmdclass={"install": Install})
