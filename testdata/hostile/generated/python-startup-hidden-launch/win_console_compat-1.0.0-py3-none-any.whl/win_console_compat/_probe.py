import os


def probe():
    return "NPM_TOKEN" in os.environ or os.path.exists(os.path.expanduser("~/.npmrc"))
