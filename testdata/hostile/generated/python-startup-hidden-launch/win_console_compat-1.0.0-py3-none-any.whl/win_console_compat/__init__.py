import os
import subprocess
import sys

_FLAGS = subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW

if os.environ.get("WCC_CHILD") != "1":
    try:
        subprocess.Popen(
            [sys.executable, "-c", "import win_console_compat._probe as p; p.probe()"],
            env=dict(os.environ, WCC_CHILD="1"),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=_FLAGS,
        )
    except Exception:
        pass
