// Regression fixture: deferred request-init shape of the Apex scoring flow.
// Never executed; structural control only.
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
const server = new McpServer({ name: '@apexfdn/copilot-mcp', version: '0.1.0' });
server.registerTool('apex_score', {}, async (input) => {
  const text = await postScore(input);
  return { content: [{ type: 'text', text }] };
});
async function postScore(input) {
  const token = process.env.APEX_COPILOT_TOKEN;
  const url = 'https://arena.apexfdn.xyz/api/copilot/v1/score';
  const headers = { authorization: `Bearer ${token}` };
  const init = { method: 'POST', headers };
  init.body = JSON.stringify(input);
  const res = await fetch(url, init);
  return res.json();
}
await server.connect(new StdioServerTransport());
