const asciiArt = require("./index")

asciiArt("oi", "Bloody")