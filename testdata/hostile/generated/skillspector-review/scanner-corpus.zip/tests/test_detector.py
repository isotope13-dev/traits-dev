import pytest
from skillspector.nodes.analyzers import static_patterns_data_exfiltration
def test_detector():
    assert callable(static_patterns_data_exfiltration.analyze)
