Gem::Specification.new do |spec|
  spec.extensions = ['extconf.rb']
end
