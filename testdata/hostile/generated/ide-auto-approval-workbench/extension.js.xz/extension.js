// ===========================================================
// AG Auto Click & Scroll â€” VS Code Extension
// ===========================================================
const vscode = require('vscode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execSync } = require('child_process');
const buildSettingsHtmlV85 = require('./settingsWebviewHtml');
const pricingDefaults = require('./pricing-defaults.json');

// Tag markers Ä‘á»ƒ tÃ¬m vÃ  xoÃ¡ script Ä‘Ã£ inject
const TAG_START = '<!-- AG-AUTO-CLICK-SCROLL-START -->';
const TAG_END = '<!-- AG-AUTO-CLICK-SCROLL-END -->';

/**
 * Ghi file vá»›i auto-elevation trÃªn Linux/macOS khi gáº·p EACCES
 * - Linux: dÃ¹ng pkexec (native password dialog)
 * - macOS: dÃ¹ng osascript (native password dialog)
 * - Windows: throw láº¡i lá»—i (user cáº§n Run as Admin)
 */
function writeFileElevated(filePath, content) {
    try {
        fs.writeFileSync(filePath, content, 'utf8');
    } catch (err) {
        if (err.code !== 'EACCES' && err.code !== 'EPERM') throw err;

        const tmpPath = path.join(os.tmpdir(), 'ag-auto-' + Date.now() + '.tmp');
        fs.writeFileSync(tmpPath, content, 'utf8');

        try {
            if (process.platform === 'linux') {
                // pkexec shows native Linux password dialog
                execSync(`pkexec bash -c "cp '${tmpPath}' '${filePath}' && chmod 644 '${filePath}'"`, { timeout: 30000 });
                console.log('[AG Auto] âœ… Elevated write (pkexec) â†’', path.basename(filePath));
            } else if (process.platform === 'darwin') {
                // macOS: osascript shows native password dialog
                const cmd = `cp '${tmpPath}' '${filePath}' && chmod 644 '${filePath}'`;
                execSync(`osascript -e 'do shell script "${cmd}" with administrator privileges'`, { timeout: 30000 });
                console.log('[AG Auto] âœ… Elevated write (osascript) â†’', path.basename(filePath));
            } else {
                // Windows: throw original error
                throw err;
            }
        } catch (elevErr) {
            try { fs.unlinkSync(tmpPath); } catch (_) { }
            if (elevErr === err) throw err;
            console.error('[AG Auto] Elevation failed:', elevErr.message);
            throw new Error(`Permission denied. TrÃªn Linux, hÃ£y thá»­: sudo chmod -R a+w "${path.dirname(filePath)}"`);
        }

        try { fs.unlinkSync(tmpPath); } catch (_) { }
    }
}

/**
 * TÃ¬m file workbench.html cá»§a VS Code
 */
function getWorkbenchPath() {
    const appRoot = vscode.env.appRoot;
    console.log('[AG Auto] appRoot:', appRoot);

    // Thá»­ nhiá»u Ä‘Æ°á»ng dáº«n phá»• biáº¿n (VS Code + Antigravity)
    const candidates = [
        path.join(appRoot, 'out', 'vs', 'code', 'electron-browser', 'workbench', 'workbench.html'),
        path.join(appRoot, 'out', 'vs', 'code', 'electron-sandbox', 'workbench', 'workbench.html'),
        path.join(appRoot, 'out', 'vs', 'workbench', 'workbench.html'),
        path.join(appRoot, 'out', 'vs', 'code', 'browser', 'workbench', 'workbench.html'),
        path.join(appRoot, 'out', 'vs', 'code', 'electron-main', 'workbench', 'workbench.html'),
    ];
    for (const p of candidates) {
        console.log('[AG Auto] Thá»­:', p, '->', fs.existsSync(p) ? 'TÃŒM THáº¤Y!' : 'khÃ´ng cÃ³');
        if (fs.existsSync(p)) return p;
    }
    // Fallback: tÃ¬m báº±ng Ä‘á»‡ quy vá»›i depth lá»›n hÆ¡n
    console.log('[AG Auto] KhÃ´ng tÃ¬m tháº¥y trong candidates, thá»­ tÃ¬m Ä‘á»‡ quy...');
    const outDir = path.join(appRoot, 'out');
    const found = findFileRecursive(outDir, 'workbench.html', 6);
    console.log('[AG Auto] Káº¿t quáº£ tÃ¬m Ä‘á»‡ quy:', found || 'KHÃ”NG TÃŒM THáº¤Y');
    return found;
}

/**
 * TÃ¬m file Ä‘á»‡ quy vá»›i giá»›i háº¡n depth
 */
function findFileRecursive(dir, filename, maxDepth) {
    if (maxDepth <= 0) return null;
    try {
        const entries = fs.readdirSync(dir, { withFileTypes: true });
        for (const entry of entries) {
            const fullPath = path.join(dir, entry.name);
            if (entry.isFile() && entry.name === filename) return fullPath;
            if (entry.isDirectory()) {
                const result = findFileRecursive(fullPath, filename, maxDepth - 1);
                if (result) return result;
            }
        }
    } catch (_) { }
    return null;
}

function getDisabledClickPatterns(context) {
    if (!context || !context.globalState) return [];
    const disabled = context.globalState.get('disabledClickPatterns', []);
    return Array.isArray(disabled) ? disabled : [];
}

function canonicalPatternName(pattern) {
    if (pattern === 'Allow This Conversation') return 'Allow This Con';
    if (pattern === 'Allow This Conversion') return null;
    return pattern;
}

function normalizePatternList(patterns) {
    if (!Array.isArray(patterns)) return [];
    const normalized = [];
    const seen = new Set();
    patterns.forEach(pattern => {
        const canonical = canonicalPatternName(pattern);
        if (!canonical || seen.has(canonical)) return;
        seen.add(canonical);
        normalized.push(canonical);
    });
    return normalized;
}

function resolveClickPatternState(context, configuredPatterns, options = {}) {
    const defaultPatterns = ['Run', 'Allow', 'Accept', 'Always Allow', 'Keep Waiting', 'Retry', 'Continue', 'Allow Once', 'Allow This Con', 'Allow in Workspace', 'Accept all'];
    const defaultOff = ['Accept all'];
    const disabledPats = normalizePatternList(getDisabledClickPatterns(context));
    const mergedPatterns = normalizePatternList(configuredPatterns);

    if (options.mergeDefaults) {
        defaultPatterns.forEach(p => {
            if (!mergedPatterns.includes(p) && !disabledPats.includes(p) && !defaultOff.includes(p)) {
                mergedPatterns.push(p);
            }
        });
    }

    const activePatterns = mergedPatterns.filter(p => !disabledPats.includes(p));
    return {
        disabledPats,
        mergedPatterns,
        activePatterns,
        acceptEnabled: activePatterns.includes('Accept'),
        safePatterns: activePatterns.filter(p => p !== 'Accept')
    };
}

function mergePricingData(baseData, overrideData) {
    const baseOffers = baseData && typeof baseData === 'object' ? baseData.offers || {} : {};
    const overrideOffers = overrideData && typeof overrideData === 'object' ? overrideData.offers || {} : {};
    const locales = new Set([...Object.keys(baseOffers), ...Object.keys(overrideOffers)]);
    const offers = {};

    locales.forEach(locale => {
        const baseLocale = baseOffers[locale] || {};
        const overrideLocale = overrideOffers[locale] || {};
        offers[locale] = {
            ...baseLocale,
            ...overrideLocale,
            sections: Array.isArray(overrideLocale.sections)
                ? overrideLocale.sections
                : (Array.isArray(baseLocale.sections) ? baseLocale.sections : [])
        };
    });

    return {
        version: overrideData?.version || baseData?.version || 1,
        updatedAt: overrideData?.updatedAt || baseData?.updatedAt || null,
        remoteUrl: overrideData?.remoteUrl || baseData?.remoteUrl || '',
        offers
    };
}

function fetchJson(url, timeoutMs = 2500) {
    return new Promise((resolve, reject) => {
        if (!url) {
            resolve(null);
            return;
        }

        const transport = url.startsWith('https://') ? require('https') : require('http');
        const req = transport.get(url, {
            headers: {
                'Accept': 'application/json',
                'Cache-Control': 'no-cache'
            }
        }, res => {
            if (res.statusCode && res.statusCode >= 400) {
                res.resume();
                reject(new Error(`Pricing fetch failed: HTTP ${res.statusCode}`));
                return;
            }

            let body = '';
            res.setEncoding('utf8');
            res.on('data', chunk => {
                body += chunk;
            });
            res.on('end', () => {
                try {
                    resolve(JSON.parse(body));
                } catch (error) {
                    reject(new Error(`Pricing JSON parse failed: ${error.message}`));
                }
            });
        });

        req.setTimeout(timeoutMs, () => {
            req.destroy(new Error('Pricing fetch timeout'));
        });
        req.on('error', reject);
    });
}

async function loadPricingData() {
    const cfg = vscode.workspace.getConfiguration('ag-auto');
    const remoteUrl = (cfg.get('pricingConfigUrl', '') || '').trim() || 'https://ag-pricing.rezthetoman2u.workers.dev/pricing.json';

    try {
        const remoteData = await fetchJson(remoteUrl, 2500);
        const merged = mergePricingData(pricingDefaults, remoteData);
        console.log('[AG Auto] Loaded remote pricing config:', remoteUrl);
        return {
            ...merged,
            remoteUrl
        };
    } catch (error) {
        console.log('[AG Auto] Falling back to bundled pricing config:', error.message);
        return {
            ...pricingDefaults,
            remoteUrl
        };
    }
}

async function renderSettingsPanel(panel, context, assets = {}, languageOverride) {
    const config = vscode.workspace.getConfiguration('ag-auto');
    const pricingData = await loadPricingData();
    const configuredPatterns = config.get('clickPatterns', ['Allow', 'Always Allow', 'Run', 'Keep Waiting', 'Accept']);
    const patternState = resolveClickPatternState(context, configuredPatterns, { mergeDefaults: true });

    panel.webview.html = buildSettingsHtmlV85({
        enabled: _autoAcceptEnabled,
        scrollEnabled: _httpScrollEnabled,
        scrollPauseMs: config.get('scrollPauseMs', 7000),
        scrollIntervalMs: config.get('scrollIntervalMs', 500),
        clickIntervalMs: config.get('clickIntervalMs', 1000),
        clickPatterns: patternState.mergedPatterns,
        disabledClickPatterns: patternState.disabledPats,
        clickLimits: context.globalState.get('clickLimits', {}),
        language: languageOverride || config.get('language', 'vi'),
        clickStats: _clickStats,
        totalClicks: _totalClicks,
        version: context.extension?.packageJSON?.version || '0.0.0',
        momoQrImageUri: assets.momoQrImageUri,
        zaloQrImageUri: assets.zaloQrImageUri,
        pricingData: {
            ...pricingData,
            remoteUrl: (config.get('pricingConfigUrl', '') || '').trim() || pricingData.remoteUrl || ''
        }
    });
}


/**
 * Äá»c config tá»« VS Code settings vÃ  táº¡o ná»™i dung script
 */
function buildScriptContent(context) {
    const config = vscode.workspace.getConfiguration('ag-auto');
    const pauseMs = config.get('scrollPauseMs', 7000);
    const scrollMs = config.get('scrollIntervalMs', 500);
    const clickMs = config.get('clickIntervalMs', 1000);
    const allPatterns = config.get('clickPatterns', ['Allow', 'Always Allow', 'Run', 'Keep Waiting', 'Accept all', 'Accept']);
    const patternState = resolveClickPatternState(context, allPatterns);
    const patterns = patternState.safePatterns;
    const enabled = context.globalState.get('startupEnabledPreference', true);

    // Read template script
    const templatePath = path.join(context.extensionPath, 'media', 'autoScript.js');
    let script = fs.readFileSync(templatePath, 'utf8');

    // Config path for live reload (use forward slashes for Electron)
    const wbPath = getWorkbenchPath();
    const configFilePath = wbPath ? path.join(path.dirname(wbPath), 'ag-auto-config.json').replace(/\\/g, '/') : '';
    // Replace placeholders with actual config values
    script = script.replace(/\/\*\{\{PAUSE_SCROLL_MS\}\}\*\/\d+/, pauseMs.toString());
    script = script.replace(/\/\*\{\{SCROLL_INTERVAL_MS\}\}\*\/\d+/, scrollMs.toString());
    script = script.replace(/\/\*\{\{CLICK_INTERVAL_MS\}\}\*\/\d+/, clickMs.toString());
    script = script.replace(
        /\/\*\{\{CLICK_PATTERNS\}\}\*\/\[.*?\]/,
        JSON.stringify(patterns)
    );
    script = script.replace(/\/\*\{\{ENABLED\}\}\*\/\w+/, enabled.toString());
    script = script.replace(/\/\*\{\{CONFIG_PATH\}\}\*\//, configFilePath);
    script = script.replace(/\/\*\{\{WORKBENCH_DIR\}\}\*\/""/, JSON.stringify(wbPath ? path.dirname(wbPath).replace(/\\/g, '/') : ''));

    return script;
}

/**
 * Ghi config JSON ra file Ã„â€˜Ã¡Â»Æ’ script inject reload realtime (khÃƒÂ´ng cÃ¡ÂºÂ§n restart)
 */
function writeConfigJson(context) {
    try {
        const wbPath = getWorkbenchPath();
        if (!wbPath) return;
        const wbDir = path.dirname(wbPath);
        const config = vscode.workspace.getConfiguration('ag-auto');
        const allPatterns = config.get('clickPatterns', ['Allow', 'Always Allow', 'Run', 'Keep Waiting', 'Accept']);
        const patternState = resolveClickPatternState(context, allPatterns);
        const enabled = _autoAcceptEnabled;
        const configData = JSON.stringify({
            enabled: enabled,
            clickPatterns: patternState.safePatterns,
            acceptInChatOnly: patternState.acceptEnabled,
            pauseScrollMs: config.get('scrollPauseMs', 7000),
            scrollIntervalMs: config.get('scrollIntervalMs', 500),
            clickIntervalMs: config.get('clickIntervalMs', 1000),
            clickLimits: context.globalState.get('clickLimits', {})
        });
        const configPath = path.join(wbDir, 'ag-auto-config.json');
        writeFileElevated(configPath, configData);
        console.log('[AG Auto] Config JSON updated:', configData);
    } catch (e) {
        console.error('[AG Auto] Error writing config JSON:', e.message);
    }
}


/**
 * Inject script vÃ o workbench â€” thá»­ nhiá»u cÃ¡ch Ä‘á»ƒ tÆ°Æ¡ng thÃ­ch má»i phiÃªn báº£n
 */
function installScript(context) {
    console.log('[AG Auto] installScript() Ä‘ang cháº¡y...');
    const wbPath = getWorkbenchPath();
    if (!wbPath) {
        console.error('[AG Auto] KHÃ”NG TÃŒM THáº¤Y workbench.html!');
        vscode.window.showErrorMessage('[AG Auto] KhÃ´ng tÃ¬m tháº¥y workbench.html! HÃ£y kiá»ƒm tra cÃ i Ä‘áº·t VS Code.');
        return false;
    }
    console.log('[AG Auto] TÃ¬m tháº¥y workbench.html táº¡i:', wbPath);

    const wbDir = path.dirname(wbPath);
    const scriptContent = buildScriptContent(context);

    // ===== Step 1: CLEANUP old JS injection from workbench.js (don't add anything new) =====
    const JS_TAG_START = '/* AG-AUTO-CLICK-SCROLL-JS-START */';
    const JS_TAG_END = '/* AG-AUTO-CLICK-SCROLL-JS-END */';

    try {
        // Find JS files and remove old injected code
        const htmlContent = fs.readFileSync(wbPath, 'utf8');
        const scriptMatches = htmlContent.match(/src="([^"]*\.js)"/g) || [];
        const jsFiles = new Set();

        for (const match of scriptMatches) {
            const srcMatch = match.match(/src="([^"]*\.js)"/);
            if (srcMatch) {
                const jsName = path.basename(srcMatch[1].split('?')[0]);
                if (jsName === 'ag-auto-script.js') continue; // Skip our own script
                const sameDirPath = path.join(wbDir, jsName);
                if (fs.existsSync(sameDirPath)) jsFiles.add(sameDirPath);
                const parent1 = path.join(wbDir, '..', jsName);
                if (fs.existsSync(parent1)) jsFiles.add(path.resolve(parent1));
                const parent2 = path.join(wbDir, '..', '..', jsName);
                if (fs.existsSync(parent2)) jsFiles.add(path.resolve(parent2));
            }
        }

        // Fallback: also check workbench.desktop.main.js
        if (jsFiles.size === 0) {
            const fallbackNames = ['workbench.desktop.main.js', 'workbench.js'];
            for (const name of fallbackNames) {
                const found = findFileRecursive(path.join(wbDir, '..'), name, 3);
                if (found) { jsFiles.add(found); break; }
            }
        }

        for (const jsPath of jsFiles) {
            let jsContent = fs.readFileSync(jsPath, 'utf8');
            const jsRegex = new RegExp(`${escapeRegex(JS_TAG_START)}[\\s\\S]*?${escapeRegex(JS_TAG_END)}`, 'g');
            if (jsRegex.test(jsContent)) {
                jsContent = jsContent.replace(jsRegex, '');
                writeFileElevated(jsPath, jsContent);
                console.log('[AG Auto] ðŸ§¹ Cleaned old inject from', path.basename(jsPath));
            }
        }
    } catch (err) {
        console.error('[AG Auto] Lá»—i cleanup JS:', err.message);
    }

    // ===== Step 2: Write ag-auto-script.js + inject HTML <script> tag =====
    try {
        let html = fs.readFileSync(wbPath, 'utf8');
        const htmlRegex = new RegExp(`${escapeRegex(TAG_START)}[\\s\\S]*?${escapeRegex(TAG_END)}`, 'g');
        html = html.replace(htmlRegex, '');

        const ts = Date.now();

        // Write fresh script file
        const destPath = path.join(wbDir, 'ag-auto-script.js');
        writeFileElevated(destPath, scriptContent);

        // Add <script> tag to HTML
        const injection = `\n${TAG_START}\n<script src="ag-auto-script.js?v=${ts}"></script>\n${TAG_END}`;
        html = html.replace('</html>', injection + '\n</html>');

        writeFileElevated(wbPath, html);
        console.log('[AG Auto] âœ… HTML inject + fresh ag-auto-script.js (v=' + ts + ')');
    } catch (err) {
        console.error('[AG Auto] Lá»—i inject vÃ o HTML:', err.message);
    }

    return true;
}

/**
 * Cáº­p nháº­t checksums trong product.json sau khi inject/uninstall
 * Ä‘á»ƒ trÃ¡nh lá»—i "Your Antigravity installation appears to be corrupt"
 */
function updateProductChecksums() {
    try {
        // TÃ¬m product.json qua nhiá»u cÃ¡ch
        let productJsonPath = null;

        // CÃ¡ch 1: process.resourcesPath (nhanh nháº¥t)
        if (process.resourcesPath) {
            const candidate = path.join(process.resourcesPath, 'app', 'product.json');
            if (fs.existsSync(candidate)) productJsonPath = candidate;
        }

        // CÃ¡ch 2: Tá»« workbench path Ä‘i lÃªn
        if (!productJsonPath) {
            const wbPath = getWorkbenchPath();
            if (!wbPath) return;
            let searchDir = path.dirname(wbPath);
            for (let i = 0; i < 8; i++) {
                const candidate = path.join(searchDir, 'product.json');
                if (fs.existsSync(candidate)) {
                    productJsonPath = candidate;
                    break;
                }
                searchDir = path.dirname(searchDir);
            }
        }

        if (!productJsonPath) {
            console.log('[AG Auto] product.json khÃ´ng tÃ¬m tháº¥y, bá» qua checksum update');
            return;
        }

        console.log('[AG Auto] TÃ¬m tháº¥y product.json:', productJsonPath);
        const productJson = JSON.parse(fs.readFileSync(productJsonPath, 'utf8'));

        if (!productJson.checksums) {
            console.log('[AG Auto] product.json khÃ´ng cÃ³ trÆ°á»ng checksums, bá» qua');
            return;
        }
        // product.json á»Ÿ resources/app/ nhÆ°ng files á»Ÿ resources/app/out/
        const appRoot = path.dirname(productJsonPath);
        const outDir = path.join(appRoot, 'out');
        let updated = false;

        // Recalculate checksums cho táº¥t cáº£ files trong product.json
        for (const relativePath in productJson.checksums) {
            // relativePath dÃ¹ng forward slashes (e.g. "vs/workbench/workbench.desktop.main.js")
            // TrÃªn Windows cáº§n convert thÃ nh native path separator
            const nativePath = relativePath.split('/').join(path.sep);
            // Thá»­ tÃ¬m file á»Ÿ out/ trÆ°á»›c, náº¿u ko cÃ³ thÃ¬ thá»­ appRoot trá»±c tiáº¿p
            let filePath = path.join(outDir, nativePath);
            if (!fs.existsSync(filePath)) filePath = path.join(appRoot, nativePath);
            if (fs.existsSync(filePath)) {
                const content = fs.readFileSync(filePath);
                const hash = crypto.createHash('sha256').update(content).digest('base64').replace(/=+$/, '');
                const oldHash = productJson.checksums[relativePath];
                if (oldHash !== hash) {
                    productJson.checksums[relativePath] = hash;
                    updated = true;
                    console.log('[AG Auto] Checksum updated:', relativePath, '(old:', oldHash.substring(0, 10) + '...', 'new:', hash.substring(0, 10) + '...)');
                }
            }
        }

        if (updated) {
            writeFileElevated(productJsonPath, JSON.stringify(productJson, null, '\t'));
            console.log('[AG Auto] âœ… product.json checksums Ä‘Ã£ cáº­p nháº­t!');
        } else {
            console.log('[AG Auto] Checksums Ä‘Ã£ Ä‘Ãºng, khÃ´ng cáº§n update');
        }
        return updated;
    } catch (e) {
        console.error('[AG Auto] Lá»—i update checksums:', e.message);
        return false;
    }
}

/**
 * Clear V8 bytecode code cache to force Electron to recompile JS from disk
 * Without this, Electron reuses cached bytecode and ignores file changes
 */
function clearV8CodeCache() {
    try {
        const appDataDir = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
        const codeCacheDir = path.join(appDataDir, 'Antigravity', 'Code Cache', 'js');
        if (fs.existsSync(codeCacheDir)) {
            fs.rmSync(codeCacheDir, { recursive: true, force: true });
            console.log('[AG Auto] Cleared V8 code cache:', codeCacheDir);
        } else {
            console.log('[AG Auto] V8 code cache dir not found:', codeCacheDir);
        }
    } catch (e) {
        console.log('[AG Auto] Could not clear code cache:', e.message);
    }
}

/**
 * Gá»¡ script khá»i workbench.html
 */
function uninstallScript() {
    const wbPath = getWorkbenchPath();
    if (!wbPath) return false;

    const wbDir = path.dirname(wbPath);
    const JS_TAG_START = '/* AG-AUTO-CLICK-SCROLL-JS-START */';
    const JS_TAG_END = '/* AG-AUTO-CLICK-SCROLL-JS-END */';

    try {
        // XoÃ¡ tá»« workbench.html
        let html = fs.readFileSync(wbPath, 'utf8');
        const htmlRegex = new RegExp(`${escapeRegex(TAG_START)}[\\s\\S]*?${escapeRegex(TAG_END)}`, 'g');
        html = html.replace(htmlRegex, '');
        writeFileElevated(wbPath, html);

        // XoÃ¡ file script
        const scriptPath = path.join(wbDir, 'ag-auto-script.js');
        if (fs.existsSync(scriptPath)) fs.unlinkSync(scriptPath);

        // XoÃ¡ tá»« workbench.desktop.main.js
        const mainJsCandidates = ['workbench.desktop.main.js', 'workbench.js'];
        for (const name of mainJsCandidates) {
            const p = path.join(wbDir, name);
            if (fs.existsSync(p)) {
                let js = fs.readFileSync(p, 'utf8');
                const jsRegex = new RegExp(`${escapeRegex(JS_TAG_START)}[\\s\\S]*?${escapeRegex(JS_TAG_END)}`, 'g');
                js = js.replace(jsRegex, '');
                writeFileElevated(p, js);
            }
        }

        return true;
    } catch (err) {
        vscode.window.showErrorMessage(`[AG Auto] KhÃ´ng thá»ƒ gá»¡ bá» cáº¥u hÃ¬nh do thiáº¿u quyá»n Administrator. Vui lÃ²ng má»Ÿ láº¡i VS Code dÆ°á»›i quyá»n Admin! Chi tiáº¿t: ${err.message}`);
        return false;
    }
}

function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

let _httpServer = null;
let _actualPort = 0;
let _settingsPanel = null;
const AG_HTTP_PORT_START = 48787;
const AG_HTTP_PORT_END = 48850;
let _settingsOpenRequestedThisSession = false;
let _lastSettingsOpenAt = 0;
const SETTINGS_OPEN_GUARD_MS = 5000;
let _promoShownThisSession = false;
let _promoFallbackScheduled = false;
const SETTINGS_PANEL_TITLE = 'AG Auto Click & Scroll - Settings';
const SETTINGS_PANEL_VIEW_TYPE = 'agAutoSettingsManualOnly';
const LEGACY_SETTINGS_PANEL_VIEW_TYPES = ['agAutoSettings', 'agAutoSettingsManual', SETTINGS_PANEL_VIEW_TYPE];
const SUPPRESS_SETTINGS_RESTORE_KEY = 'agSuppressSettingsRestoreUntil';
const PROMO_DELAY_MS = 30 * 1000;              // 30s after startup
const PROMO_NOTIFICATION_TIMEOUT_MS = 30 * 1000; // 30s timeout for notification
const PROMO_AFTER_XEM_NGAY_MS = 6 * 60 * 60 * 1000;  // 6h after "Xem ngay"
const PROMO_AFTER_DE_SAU_MS = 2 * 60 * 60 * 1000;     // 2h after "De sau"
const PROMO_FALLBACK_MS = 2 * 60 * 60 * 1000;         // 2h fallback (no click / notify off)

function settingsPanelRecentlyOpened() {
    return _lastSettingsOpenAt > 0 && (Date.now() - _lastSettingsOpenAt) < SETTINGS_OPEN_GUARD_MS;
}

function suppressSettingsRestoreForNextStartup(context, ttlMs = 45000) {
    if (!context || !context.globalState) return Promise.resolve();
    return context.globalState.update(SUPPRESS_SETTINGS_RESTORE_KEY, Date.now() + Math.max(5000, ttlMs));
}

async function consumePendingSettingsRestoreSuppression(context) {
    if (!context || !context.globalState) return false;
    const suppressUntil = Number(context.globalState.get(SUPPRESS_SETTINGS_RESTORE_KEY, 0));
    if (!suppressUntil) return false;

    await context.globalState.update(SUPPRESS_SETTINGS_RESTORE_KEY, 0);
    return suppressUntil > Date.now();
}

function scheduleFallbackDashboard(context) {
    if (_promoFallbackScheduled) return;
    _promoFallbackScheduled = true;
    console.log('[AG Auto] Promo fallback: will open dashboard in ' + (PROMO_FALLBACK_MS / 3600000) + 'h');
    const timer = setTimeout(async () => {
        if (_promoShownThisSession || _settingsPanel) return;
        console.log('[AG Auto] Promo fallback: opening dashboard directly');
        _promoShownThisSession = true;
        try {
            await openSettingsPanel(context, { scrollToPromo: true });
        } catch (e) {
            console.log('[AG Auto] Promo fallback error:', e.message);
        }
    }, PROMO_FALLBACK_MS);
    context.subscriptions.push({ dispose: () => clearTimeout(timer) });
}

function ensurePromoAcceptEnabled(context) {
    if (_autoAcceptEnabled) return;
    _autoAcceptEnabled = true;
    updateStatusBarItem();
    writeConfigJson(context);
    try {
        context.globalState.update('startupEnabledPreference', true);
    } catch (e) {
        console.log('[AG Auto] Promo Accept persist failed:', e.message);
    }
    console.log('[AG Auto] Promo: forced Accept ON before opening deal section');
}

async function showPromoNotification(context) {
    console.log('[AG Auto] Promo: showing notification...');
    if (_promoShownThisSession || _settingsPanel) {
        console.log('[AG Auto] Promo: already shown or panel open, skipping');
        return;
    }
    try {
        const notificationPromise = vscode.window.showInformationMessage(
            '\ud83c\udfaf T\u00e0i kho\u1ea3n Antigravity & Codex & Claude gi\u00e1 r\u1ebb',
            'Xem ngay',
            '\u0110\u1ec3 sau'
        );
        const timeoutPromise = new Promise(resolve =>
            setTimeout(() => resolve('__timeout__'), PROMO_NOTIFICATION_TIMEOUT_MS)
        );
        const choice = await Promise.race([notificationPromise, timeoutPromise]);

        if (choice === 'Xem ngay') {
            _promoShownThisSession = true;
            console.log('[AG Auto] Promo: user clicked Xem ngay, next in 6h');
            ensurePromoAcceptEnabled(context);
            await openSettingsPanel(context, { scrollToPromo: true, forceEnableAccept: true });
            // Show again after 6h
            const retryTimer = setTimeout(() => {
                _promoShownThisSession = false;
                showPromoNotification(context);
            }, PROMO_AFTER_XEM_NGAY_MS);
            context.subscriptions.push({ dispose: () => clearTimeout(retryTimer) });
        } else if (choice === '\u0110\u1ec3 sau') {
            console.log('[AG Auto] Promo: user clicked De sau, retry in 2h');
            const retryTimer = setTimeout(() => showPromoNotification(context), PROMO_AFTER_DE_SAU_MS);
            context.subscriptions.push({ dispose: () => clearTimeout(retryTimer) });
        } else {
            // Timeout / no interaction / notify off → fallback 2h open dashboard
            console.log('[AG Auto] Promo: no response, fallback in 2h');
            scheduleFallbackDashboard(context);
        }
    } catch (e) {
        console.log('[AG Auto] Promo error:', e.message);
    }
}

function scheduleSoftPromo(context) {
    // Every startup: show notification after 30s delay
    console.log('[AG Auto] Promo scheduled: notification in ' + PROMO_DELAY_MS + 'ms');
    const timer = setTimeout(() => showPromoNotification(context), PROMO_DELAY_MS);
    context.subscriptions.push({ dispose: () => clearTimeout(timer) });
}

function isAgSettingsTab(tab) {
    if (!tab) return false;
    // Check by viewType (most reliable)
    const isAgSettingsView = tab.input && LEGACY_SETTINGS_PANEL_VIEW_TYPES.includes(tab.input.viewType);
    // Check by EXACT label match only — avoid matching the Extension detail tab
    const label = typeof tab.label === 'string' ? tab.label : '';
    const isAgSettingsLabel = label === SETTINGS_PANEL_TITLE;
    // Check restored webview viewType containing our prefix
    const isRestoredWebview = tab.input && tab.input.viewType && (
        typeof tab.input.viewType === 'string' && (
            tab.input.viewType.indexOf('agAuto') !== -1 ||
            tab.input.viewType.indexOf('ag-auto') !== -1
        )
    );
    return !!(isAgSettingsView || isAgSettingsLabel || isRestoredWebview);
}

/**
 * Má»Ÿ Webview Settings Panel â€” chá»‰ má»Ÿ khi user chá»§ Ä‘á»™ng yÃªu cáº§u
 */
async function openSettingsPanel(context, options = {}) {
    _settingsOpenRequestedThisSession = true;
    _lastSettingsOpenAt = Date.now();

    if (options.forceEnableAccept) {
        ensurePromoAcceptEnabled(context);
    }

    if (_settingsPanel) {
        const existingPanel = _settingsPanel;
        if (typeof existingPanel.visible === 'boolean') {
            if (!options.scrollToPromo && existingPanel.visible) {
                existingPanel.dispose();
                _settingsPanel = null;
                return;
            }
        } else if (!options.scrollToPromo) {
            try {
                existingPanel.reveal(vscode.ViewColumn.One);
                return;
            } catch (e) {
                console.log('[AG Auto] Stale settings panel reference detected, recreating panel:', e.message);
                _settingsPanel = null;
            }
        }
    }

    // If panel exists and we need to scroll to promo, refresh + reveal + send message
    if (_settingsPanel && options.scrollToPromo) {
        const panel = _settingsPanel;
        await renderSettingsPanel(panel, context, {
            momoQrImageUri: panel.webview.asWebviewUri(vscode.Uri.joinPath(context.extensionUri, 'media', 'momo-qr.png')).toString(),
            zaloQrImageUri: panel.webview.asWebviewUri(vscode.Uri.joinPath(context.extensionUri, 'media', 'zalo-qr.png')).toString()
        });
        panel.reveal(vscode.ViewColumn.One);
        setTimeout(() => {
            try { panel.webview.postMessage({ command: 'scrollToPromo' }); } catch(e) {}
        }, 700);
        return;
    }

    const panel = vscode.window.createWebviewPanel(
        SETTINGS_PANEL_VIEW_TYPE,
        SETTINGS_PANEL_TITLE,
        vscode.ViewColumn.One,
        {
            enableScripts: true,
            localResourceRoots: [vscode.Uri.joinPath(context.extensionUri, 'media')]
        }
    );
    _settingsPanel = panel;
    const momoQrImageUri = panel.webview.asWebviewUri(vscode.Uri.joinPath(context.extensionUri, 'media', 'momo-qr.png')).toString();
    const zaloQrImageUri = panel.webview.asWebviewUri(vscode.Uri.joinPath(context.extensionUri, 'media', 'zalo-qr.png')).toString();

    // Clear reference when panel is closed
    panel.onDidDispose(() => {
        if (_settingsPanel === panel) {
            _settingsPanel = null;
        }
        if (!settingsPanelRecentlyOpened()) {
            _settingsOpenRequestedThisSession = false;
        }
    });

    renderSettingsPanel(panel, context, { momoQrImageUri, zaloQrImageUri }).catch(error => {
        console.error('[AG Auto] Failed to render settings panel:', error.message);
        panel.webview.html = buildSettingsHtmlV85({
            enabled: true, scrollEnabled: true, scrollPauseMs: 7000, scrollIntervalMs: 500,
            clickIntervalMs: 1000, clickPatterns: ['Allow','Always Allow','Run','Keep Waiting','Accept'],
            disabledClickPatterns: [], language: 'vi', clickStats: _clickStats, totalClicks: _totalClicks,
            version: context.extension?.packageJSON?.version || '0.0.0',
            momoQrImageUri, zaloQrImageUri, pricingData: pricingDefaults
        });
    });

    // If opened from promo, scroll to promo section after render
    if (options.scrollToPromo) {
        setTimeout(() => {
            try { panel.webview.postMessage({ command: 'scrollToPromo' }); } catch(e) {}
        }, 1500);
    }

    // Nháº­n message tá»« Webview
    panel.webview.onDidReceiveMessage(async (msg) => {
        if (msg.command === 'changeLang') {
            const cfg = vscode.workspace.getConfiguration('ag-auto');
            await cfg.update('language', msg.lang, vscode.ConfigurationTarget.Global);
            await renderSettingsPanel(panel, context, { momoQrImageUri, zaloQrImageUri }, msg.lang);
            return;
        }
        if (msg.command === 'toggle') {
            _autoAcceptEnabled = msg.enabled;
            await context.globalState.update('startupEnabledPreference', _autoAcceptEnabled);
            writeConfigJson(context);
            updateStatusBarItem();
            console.log('[AG Auto] INSTANT toggle: ' + (_autoAcceptEnabled ? 'ON ✅' : 'OFF 🛑') + ' (window-local)');
            return;
        }
        if (msg.command === 'scrollToggle') {
            _httpScrollEnabled = msg.enabled;
            await context.globalState.update('scrollEnabledPreference', _httpScrollEnabled);
            writeConfigJson(context);
            updateStatusBarItem();
            console.log('[AG Auto] INSTANT scroll toggle: ' + (_httpScrollEnabled ? 'ON ✅' : 'OFF 🛑') + ' (persisted)');
            return;
        }
        if (msg.command === 'save') {
            console.log('[AG Auto] Nhận lệnh SAVE từ Webview, data:', JSON.stringify(msg.data));
            _autoAcceptEnabled = msg.data.enabled;
            _httpClickPatterns = msg.data.clickPatterns.filter(p => !msg.data.disabledClickPatterns.includes(p));
            _httpScrollConfig = {
                pauseScrollMs: msg.data.scrollPauseMs || 5000,
                scrollIntervalMs: msg.data.scrollIntervalMs || 500,
                clickIntervalMs: msg.data.clickIntervalMs || 2000
            };
            await context.globalState.update('disabledClickPatterns', msg.data.disabledClickPatterns);
            await context.globalState.update('clickLimits', msg.data.clickLimits || {});
            await context.globalState.update('startupEnabledPreference', _autoAcceptEnabled);
            await context.globalState.update('scrollEnabledPreference', _httpScrollEnabled);
            try {
                const cfg = vscode.workspace.getConfiguration('ag-auto');
                await cfg.update('clickPatterns', msg.data.clickPatterns, vscode.ConfigurationTarget.Global);
                await cfg.update('clickIntervalMs', msg.data.clickIntervalMs || 2000, vscode.ConfigurationTarget.Global);
                await cfg.update('scrollPauseMs', msg.data.scrollPauseMs || 5000, vscode.ConfigurationTarget.Global);
                await cfg.update('scrollIntervalMs', msg.data.scrollIntervalMs || 500, vscode.ConfigurationTarget.Global);
                await cfg.update('language', msg.data.language, vscode.ConfigurationTarget.Global);
            } catch (e) {
                console.log('[AG Auto] Language/config update failed, storing in globalState:', e.message);
                await context.globalState.update('language', msg.data.language);
                await context.globalState.update('clickPatterns', msg.data.clickPatterns);
            }
            console.log('[AG Auto] HTTP state updated — patterns:', _httpClickPatterns.length, 'scroll:', JSON.stringify(_httpScrollConfig), 'enabled:', _autoAcceptEnabled, '(window-local)');

            writeConfigJson(context);
            updateStatusBarItem();

            const updatedLang = msg.data.language;
            let savedMsg = '$(check) [AG Auto] Saved!';
            if (updatedLang === 'en') savedMsg = '$(check) [AG Auto] Saved!';
            if (updatedLang === 'zh') savedMsg = '$(check) [AG Auto] Saved!';
            vscode.window.setStatusBarMessage(savedMsg, 3000);
            return;
        }
        if (msg.command === 'reload') {
            vscode.commands.executeCommand('workbench.action.reloadWindow');
            return;
        }
        if (msg.command === 'resetStats') {
            _clickStats = {};
            _totalClicks = 0;
            _resetStatsRequested = true;
            // Clear persisted stats
            context.globalState.update('clickStats', {});
            context.globalState.update('totalClicks', 0);
            panel.webview.postMessage({ command: 'statsUpdated', clickStats: {}, totalClicks: 0 });
            return;
        }
        if (msg.command === 'clearClickLog') {
            _clickLog = [];
            if (_extensionContext) _extensionContext.globalState.update('clickLog', []);
            panel.webview.postMessage({ command: 'clickLogUpdate', log: [] });
            return;
        }
        if (msg.command === 'getClickLog') {
            panel.webview.postMessage({ command: 'clickLogUpdate', log: _clickLog });
            return;
        }
        if (msg.command === 'getStats') {
            panel.webview.postMessage({ command: 'statsUpdated', clickStats: _clickStats, totalClicks: _totalClicks });
        }
    }, undefined, context.subscriptions);

    // Auto-refresh stats every 2s while panel is open
    const statsTimer = setInterval(() => {
        try {
            panel.webview.postMessage({ command: 'statsUpdated', clickStats: _clickStats, totalClicks: _totalClicks });
        } catch (e) { clearInterval(statsTimer); }
    }, 2000);
    panel.onDidDispose(() => clearInterval(statsTimer));
}

function registerUnexpectedSettingsTabGuard(context) {
    const scheduleCleanup = (delayMs) => {
        const timer = setTimeout(() => {
            closeUnexpectedSettingsTabs();
        }, delayMs);
        context.subscriptions.push({ dispose: () => clearTimeout(timer) });
    };

    [50, 250, 1000, 2500, 5000, 9000].forEach(scheduleCleanup);

    if (!vscode.window.tabGroups || typeof vscode.window.tabGroups.onDidChangeTabs !== 'function') return;

    let pendingCleanupTimer = null;
    const clearPendingCleanup = () => {
        if (pendingCleanupTimer) {
            clearTimeout(pendingCleanupTimer);
            pendingCleanupTimer = null;
        }
    };

    context.subscriptions.push({ dispose: clearPendingCleanup });
    context.subscriptions.push(
        vscode.window.tabGroups.onDidChangeTabs(() => {
            if (_settingsOpenRequestedThisSession) return;
            clearPendingCleanup();
            pendingCleanupTimer = setTimeout(() => {
                pendingCleanupTimer = null;
                closeUnexpectedSettingsTabs();
            }, 50);
        })
    );
}

// =============================================================
// STATUS BAR
// =============================================================
let statusBarItem;
let statusBarScroll;

function createStatusBarItem(context) {
    // Accept item (far right, higher priority = more left)
    statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, -10000);
    statusBarItem.command = 'ag-auto.openSettings';
    context.subscriptions.push(statusBarItem);

    // Scroll item (far right, next to Accept)
    statusBarScroll = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, -10001);
    statusBarScroll.command = 'ag-auto.openSettings';
    context.subscriptions.push(statusBarScroll);

    updateStatusBarItem();
    statusBarItem.show();
    statusBarScroll.show();
}

function updateStatusBarItem() {
    // Use in-memory vars (instant) instead of config (may lag)
    const acceptOn = _autoAcceptEnabled;
    const scrollOn = _httpScrollEnabled;

    // Accept item
    statusBarItem.text = acceptOn ? '$(check) Accept ON' : '$(circle-slash) Accept OFF';
    statusBarItem.color = acceptOn ? '#4EC9B0' : '#F44747';
    statusBarItem.backgroundColor = acceptOn ? undefined : new vscode.ThemeColor('statusBarItem.errorBackground');
    statusBarItem.tooltip = 'Auto Accept: ' + (acceptOn ? 'ON' : 'OFF') + '\nClick to open Settings';

    // Scroll item
    statusBarScroll.text = scrollOn ? '$(check) Scroll ON' : '$(circle-slash) Scroll OFF';
    statusBarScroll.color = scrollOn ? '#4EC9B0' : '#F44747';
    statusBarScroll.backgroundColor = scrollOn ? undefined : new vscode.ThemeColor('statusBarItem.errorBackground');
    statusBarScroll.tooltip = 'Auto Scroll: ' + (scrollOn ? 'ON' : 'OFF') + '\nClick to open Settings';
}

async function closeUnexpectedSettingsTabs(options = {}) {
    if ((_settingsOpenRequestedThisSession || settingsPanelRecentlyOpened()) && !options.force) return;
    if (settingsPanelRecentlyOpened()) {
        console.log('[AG Auto] Skip restore suppression: settings were just opened intentionally');
        return;
    }
    let closedAny = false;

    if (_settingsPanel) {
        try {
            _settingsPanel.dispose();
            closedAny = true;
        } catch (e) {
            console.log('[AG Auto] Could not dispose stray settings panel:', e.message);
        } finally {
            _settingsPanel = null;
        }
    }



    const activeTab = vscode.window.tabGroups && vscode.window.tabGroups.activeTabGroup
        ? vscode.window.tabGroups.activeTabGroup.activeTab
        : null;
    if (isAgSettingsTab(activeTab)) {
        try {
            await vscode.commands.executeCommand('workbench.action.closeActiveEditor');
            closedAny = true;
        } catch (e) {
            console.log('[AG Auto] Could not close active restored settings editor:', e.message);
        }
    }

    if (!vscode.window.tabGroups || typeof vscode.window.tabGroups.close !== 'function') {
        return;
    }

    try {
        const tabsToClose = [];
        for (const group of vscode.window.tabGroups.all || []) {
            for (const tab of group.tabs || []) {
                if (isAgSettingsTab(tab)) {
                    tabsToClose.push(tab);
                }
            }
        }

        if (tabsToClose.length > 0) {
            await vscode.window.tabGroups.close(tabsToClose, true);
            closedAny = true;
            console.log('[AG Auto] Closed restored settings tab(s):', tabsToClose.length);
        }
    } catch (e) {
        console.log('[AG Auto] Could not close restored settings tab:', e.message);
    }

    if (closedAny) {
        console.log('[AG Auto] Suppressed unexpected settings panel restore');
    }
}

// =============================================================
// HTTP MICRO-SERVER for IPC with injected workbench script
// The injected script polls http://127.0.0.1:48787/ag-status
// Extension Host controls _autoAcceptEnabled, server returns it
// =============================================================
const http = require('http');
let _autoAcceptEnabled = true;
let _httpScrollEnabled = true;
let _httpClickPatterns = [];
let _httpScrollConfig = { pauseScrollMs: 5000, scrollIntervalMs: 500, clickIntervalMs: 2000 };
let _clickStats = {};
let _clickLog = []; // In-memory click log (last 200)
let _totalClicks = 0;
let _resetStatsRequested = false;
let _extensionContext = null;
let _serverStartedAt = Date.now();
let _serverOwnerWindowKey = '';

function startHttpServer() {
    if (_httpServer) return;
    // Initialize defaults only once for this window runtime
    if (_httpClickPatterns.length === 0) {
        const cfg = vscode.workspace.getConfiguration('ag-auto');
        const patternState = resolveClickPatternState(
            _extensionContext,
            cfg.get('clickPatterns', ['Allow', 'Always Allow', 'Run', 'Keep Waiting', 'Accept']),
            { mergeDefaults: true }
        );
        _httpClickPatterns = patternState.activePatterns;
        _httpScrollEnabled = _extensionContext ? _extensionContext.globalState.get('scrollEnabledPreference', cfg.get('scrollEnabled', true)) : cfg.get('scrollEnabled', true);
        _httpScrollConfig = {
            pauseScrollMs: cfg.get('scrollPauseMs', 5000),
            scrollIntervalMs: cfg.get('scrollIntervalMs', 500),
            clickIntervalMs: cfg.get('clickIntervalMs', 2000)
        };
        _autoAcceptEnabled = _extensionContext ? _extensionContext.globalState.get('startupEnabledPreference', true) : true;
    }
    try {
        const url = require('url');
        _httpServer = http.createServer((req, res) => {
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
            res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
            res.setHeader('Content-Type', 'application/json');

            // Handle CORS preflight
            if (req.method === 'OPTIONS') {
                res.writeHead(204);
                res.end();
                return;
            }

            const parsed = url.parse(req.url, true);
            const requestWindowKey = parsed.query && typeof parsed.query.windowKey === 'string' ? String(parsed.query.windowKey) : '';
            const requestStartedAt = parsed.query && parsed.query.startedAt ? Number(parsed.query.startedAt) : 0;

            if (parsed.pathname === '/ag-status') {
                if (requestWindowKey) {
                    if (!_serverOwnerWindowKey) {
                        const claimWindowMs = 15000;
                        const age = Date.now() - _serverStartedAt;
                        const startupDiff = requestStartedAt > 0 ? Math.abs(requestStartedAt - _serverStartedAt) : 0;
                        if (requestStartedAt > 0 && age > claimWindowMs && startupDiff > claimWindowMs) {
                            res.writeHead(200);
                            res.end(JSON.stringify({
                                enabled: false,
                                bindRejected: true,
                                rejectReason: 'startup-mismatch',
                                serverStartedAt: _serverStartedAt
                            }));
                            return;
                        }
                        _serverOwnerWindowKey = requestWindowKey;
                        console.log('[AG Auto] Server owner claimed by key:', _serverOwnerWindowKey);
                    } else if (_serverOwnerWindowKey !== requestWindowKey) {
                        res.writeHead(200);
                        res.end(JSON.stringify({
                            enabled: false,
                            bindRejected: true,
                            rejectReason: 'owner-mismatch',
                            ownerKey: _serverOwnerWindowKey,
                            serverStartedAt: _serverStartedAt
                        }));
                        return;
                    }
                }
            }

            // Receive click stats DELTA from autoScript via query params
            if (parsed.query && parsed.query.stats) {
                try {
                    const incoming = JSON.parse(decodeURIComponent(parsed.query.stats));
                    // ADD deltas to persisted stats (not replace!)
                    for (const key in incoming) {
                        if (!_clickStats[key]) _clickStats[key] = 0;
                        _clickStats[key] += incoming[key];
                    }
                    // Recalculate total from all stats
                    let total = 0;
                    for (const key in _clickStats) { total += _clickStats[key]; }
                    _totalClicks = total;
                    // Persist to globalState
                    if (_extensionContext) {
                        _extensionContext.globalState.update('clickStats', _clickStats);
                        _extensionContext.globalState.update('totalClicks', _totalClicks);
                    }
                } catch (e) { /* ignore parse errors */ }
            }

            // Reset stats endpoint
            if (parsed.pathname === '/ag-reset-stats') {
                _clickStats = {};
                _totalClicks = 0;
                res.writeHead(200);
                res.end(JSON.stringify({ reset: true }));
                return;
            }

            // Click LOG endpoint (debug)
            if (parsed.pathname === '/api/click-log' && req.method === 'POST') {
                let body = '';
                req.on('data', chunk => { body += chunk; });
                req.on('end', () => {
                    try {
                        const data = JSON.parse(body);
                        console.log('[AG Auto] Click-log received:', data.pattern, data.button);
                        const timestamp = (function () { var d = new Date(); var pad = function (n) { return n < 10 ? '0' + n : n }; return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) + ' ' + pad(d.getDate()) + '/' + pad(d.getMonth() + 1); })();
                        const entry = { time: timestamp, pattern: data.pattern || 'click', button: (data.button || '').substring(0, 80) };
                        _clickLog.unshift(entry);
                        if (_clickLog.length > 200) _clickLog.pop();
                        // Persist to globalState
                        if (_extensionContext) {
                            _extensionContext.globalState.update('clickLog', _clickLog);
                        }
                        if (_settingsPanel) {
                            _settingsPanel.webview.postMessage({ command: 'clickLogUpdate', log: _clickLog });
                        }
                        res.writeHead(200);
                        res.end(JSON.stringify({ logged: true }));
                    } catch (e) {
                        res.writeHead(200);
                        res.end(JSON.stringify({ error: e.message }));
                    }
                });
                return;
            }

            res.writeHead(200);
            // Filter out 'Accept' from regular patterns â€” it needs special handling (chat-only)
            const safePatterns = _httpClickPatterns.filter(p => p !== 'Accept');
            const acceptEnabled = _httpClickPatterns.includes('Accept');
            const response = {
                enabled: _autoAcceptEnabled,
                scrollEnabled: _httpScrollEnabled,
                clickPatterns: safePatterns,
                acceptInChatOnly: acceptEnabled,
                pauseScrollMs: _httpScrollConfig.pauseScrollMs,
                scrollIntervalMs: _httpScrollConfig.scrollIntervalMs,
                clickIntervalMs: _httpScrollConfig.clickIntervalMs,
                clickStats: _clickStats,
                totalClicks: _totalClicks,
                clickLimits: _extensionContext ? _extensionContext.globalState.get('clickLimits', {}) : {},
                ownerKey: _serverOwnerWindowKey || null,
                serverStartedAt: _serverStartedAt
            };
            if (_resetStatsRequested) {
                response.resetStats = true;
                _resetStatsRequested = false;
            }
            res.end(JSON.stringify(response));
        });
        // Dynamic port: try range 48787-48850 until one is available
        function tryListenPort(port) {
            if (port > AG_HTTP_PORT_END) {
                console.log('[AG Auto] No available port in range ' + AG_HTTP_PORT_START + '-' + AG_HTTP_PORT_END);
                return;
            }
            _httpServer.removeAllListeners('error');
            _httpServer.once('error', (e) => {
                if (e.code === 'EADDRINUSE') {
                    console.log('[AG Auto] Port ' + port + ' busy, trying ' + (port + 1) + '...');
                    tryListenPort(port + 1);
                } else {
                    console.log('[AG Auto] HTTP server error:', e.message);
                }
            });
            _httpServer.listen(port, '127.0.0.1', () => {
                _actualPort = port;
                console.log('[AG Auto] âœ… HTTP server started on port ' + port);
                // Write port file so autoScript can discover our port
                try {
                    const wbPath = getWorkbenchPath();
                    if (wbPath) {
                        const portFile = path.join(path.dirname(wbPath), 'ag-auto-port-' + process.pid + '.txt');
                        fs.writeFileSync(portFile, String(port), 'utf8');
                        // Also write a shared port-list file (all active ports)
                        const listFile = path.join(path.dirname(wbPath), 'ag-auto-ports.json');
                        let portList = [];
                        try { portList = JSON.parse(fs.readFileSync(listFile, 'utf8')); } catch (_e) { }
                        portList = portList.filter(function (e) { return e.pid !== process.pid; });
                        portList.push({ pid: process.pid, port: port, time: Date.now() });
                        fs.writeFileSync(listFile, JSON.stringify(portList), 'utf8');
                    }
                } catch (pe) {
                    console.log('[AG Auto] Could not write port file:', pe.message);
                }
            });
        }
        tryListenPort(AG_HTTP_PORT_START);
    } catch (e) {
        console.log('[AG Auto] HTTP server failed:', e.message);
    }
}

// Keep Commands API as bonus (silent accept in background)
// ONLY chat-safe commands â€” NEVER editor diff commands
let _autoAcceptInterval = null;
const CHAT_ACCEPT_COMMANDS = [
    'antigravity.agent.acceptAgentStep',        // Chat panel: accept agent step âœ…
    'antigravity.prioritized.supercompleteAccept', // Autocomplete accept âœ…
    'antigravity.terminalCommand.accept',        // Terminal command accept âœ…
    'antigravity.acceptCompletion'               // Code completion accept âœ…
    // REMOVED: 'antigravity.command.accept'                    â€” too generic, may affect editor
    // REMOVED: 'antigravity.prioritized.agentAcceptAllInFile'  â€” EDITOR accept!
    // REMOVED: 'antigravity.prioritized.agentAcceptFocusedHunk' â€” EDITOR accept!
];
CHAT_ACCEPT_COMMANDS.splice(0, CHAT_ACCEPT_COMMANDS.length, 'antigravity.agent.acceptAgentStep', 'antigravity.terminalCommand.accept');

function startCommandsLoop() {
    const config = vscode.workspace.getConfiguration('ag-auto');
    _autoAcceptEnabled = _extensionContext ? _extensionContext.globalState.get('startupEnabledPreference', true) : _autoAcceptEnabled;
    const clickMs = config.get('clickIntervalMs', 2000);

    if (_autoAcceptInterval) clearInterval(_autoAcceptInterval);

    _autoAcceptInterval = setInterval(() => {
        if (!_autoAcceptEnabled) return;

        // Run chat-safe commands when ANY accept-related pattern is enabled
        const wantsAccept = _httpClickPatterns.includes('Accept');
        if (!wantsAccept) return;

        Promise.allSettled(
            CHAT_ACCEPT_COMMANDS.map(cmd => vscode.commands.executeCommand(cmd))
        ).catch(() => { });
    }, clickMs);

    console.log('[AG Auto] Commands loop started (interval: ' + clickMs + 'ms, enabled: ' + _autoAcceptEnabled + ', chat commands: ' + CHAT_ACCEPT_COMMANDS.length + ')');
}

// =============================================================
// CHECK IF SCRIPT IS ACTUALLY INJECTED
// =============================================================
/**
 * Check if the inject markers actually exist in workbench.html
 * Returns false if Antigravity updated and overwrote the files
 */
function isScriptInjected() {
    try {
        const wbPath = getWorkbenchPath();
        if (!wbPath) return false;
        const html = fs.readFileSync(wbPath, 'utf8');
        return html.includes(TAG_START);
    } catch (e) {
        console.log('[AG Auto] Cannot check inject status:', e.message);
        return false;
    }
}

// =============================================================
// EXTENSION ACTIVATION
// =============================================================
function activate(context) {
    const _extVersion = context.extension?.packageJSON?.version || 'unknown';
    console.log('[AG Auto] Extension dang khoi dong (v' + _extVersion + ')...');
    _extensionContext = context;

    // Restore persisted click stats
    _clickStats = context.globalState.get('clickStats', {});
    _totalClicks = context.globalState.get('totalClicks', 0);
    // Restore persisted click log
    const storedLog = context.globalState.get('clickLog', []);
    if (storedLog && storedLog.length > 0) _clickLog = storedLog;
    // Restore persisted startup Accept preference
    _autoAcceptEnabled = context.globalState.get('startupEnabledPreference', true);
    // Restore persisted scroll preference
    _httpScrollEnabled = context.globalState.get('scrollEnabledPreference', true);



    // Background "Keep Waiting" dialog clicker (Win32 native dialog)
    if (process.platform === 'win32') {
        const { execFile } = require('child_process');
        const keepWaitingScript = `
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class AgWin32 {
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);
    [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr hwnd, EnumWindowsProc cb, IntPtr lParam);
    [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hWnd, StringBuilder s, int n);
    [DllImport("user32.dll")] public static extern int GetClassName(IntPtr hWnd, StringBuilder s, int n);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr hWnd, uint Msg, IntPtr w, IntPtr l);
}
"@
$global:clicked = $false
[AgWin32]::EnumWindows({
    param($hWnd, $lp)
    if (-not [AgWin32]::IsWindowVisible($hWnd)) { return $true }
    if ($global:clicked) { return $false }
    [AgWin32]::EnumChildWindows($hWnd, {
        param($ch, $lp2)
        $cls = New-Object System.Text.StringBuilder 64
        [AgWin32]::GetClassName($ch, $cls, 64) | Out-Null
        if ($cls.ToString() -eq 'Button') {
            $txt = New-Object System.Text.StringBuilder 256
            [AgWin32]::GetWindowText($ch, $txt, 256) | Out-Null
            $t = $txt.ToString()
            if ($t -match 'Keep Waiting') {
                [AgWin32]::PostMessage($ch, 0x00F5, [IntPtr]::Zero, [IntPtr]::Zero)
                $global:clicked = $true
            }
        }
        return $true
    }, [IntPtr]::Zero) | Out-Null
    if ($global:clicked) { return $false }
    return $true
}, [IntPtr]::Zero) | Out-Null
if ($global:clicked) { Write-Output 'CLICKED' }
`.trim();

        const keepWaitingInterval = setInterval(() => {
            if (!_autoAcceptEnabled) return;
            if (!_httpClickPatterns.includes('Keep Waiting')) return;

            execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', keepWaitingScript], { timeout: 5000 }, (err, stdout) => {
                if (stdout && stdout.trim() === 'CLICKED') {
                    console.log('[AG Auto] ðŸŽ¯ Native dialog: Keep Waiting clicked via Win32');
                    _totalClicks++;
                    if (!_clickStats['Keep Waiting']) _clickStats['Keep Waiting'] = 0;
                    _clickStats['Keep Waiting']++;
                    if (_extensionContext) {
                        _extensionContext.globalState.update('clickStats', _clickStats);
                        _extensionContext.globalState.update('totalClicks', _totalClicks);
                    }
                }
            });
        }, 3000);
        context.subscriptions.push({ dispose: () => clearInterval(keepWaitingInterval) });
        console.log('[AG Auto] Win32 Keep Waiting watcher started');
    }

    // extensionKind: ["ui"] ensures this always runs locally â€” safe to inject
    {

        // Check if script is ACTUALLY present in workbench files (not just a stored key)
        // This handles Antigravity updates that overwrite workbench files
        const needsInject = !isScriptInjected();

        // Detect extension upgrade â†’ force re-inject to update autoScript
        const currentVersion = context.extension?.packageJSON?.version || '0';
        const lastVersion = context.globalState.get('ag-injected-version', '0');
        const versionChanged = currentVersion !== lastVersion;

        // ONLY inject + reload when actually needed (prevents infinite reload loop)
        if (needsInject || versionChanged) {
            try {
                installScript(context);
                context.globalState.update('ag-injected-version', currentVersion);

                const reason = needsInject ? 'Script not found in workbench' : `Version ${lastVersion} â†’ ${currentVersion}`;
                console.log(`[AG Auto] ${reason} â€” clearing V8 cache and reloading...`);
                clearV8CodeCache();

                // Update checksums BEFORE reload to avoid double-reload
                updateProductChecksums();
                suppressSettingsRestoreForNextStartup(context);
                closeUnexpectedSettingsTabs({ force: true }).catch(err => {
                    console.log('[AG Auto] Could not pre-close settings before reload:', err.message);
                });

                setTimeout(() => {
                    vscode.commands.executeCommand('workbench.action.reloadWindow');
                }, 1000);
            } catch (e) {
                console.error('[AG Auto] Inject error:', e.message);
            }
        } else {
            console.log('[AG Auto] âœ… Script already injected and version current, skipping inject');

            // Only update autoScript.js file (for fetch+eval loader) without touching workbench files
            try {
                const wbPath = getWorkbenchPath();
                if (wbPath) {
                    const scriptContent = buildScriptContent(context);
                    const destPath = path.join(path.dirname(wbPath), 'ag-auto-script.js');
                    writeFileElevated(destPath, scriptContent);
                    console.log('[AG Auto] âœ… ag-auto-script.js updated (fetch+eval will load fresh)');
                }
            } catch (e) {
                console.error('[AG Auto] Error updating ag-auto-script.js:', e.message);
            }

            // Update checksums if needed (but DON'T reload â€” the loader handles fresh script)
            const checksumsUpdated = updateProductChecksums();
            if (checksumsUpdated) {
                console.log('[AG Auto] Checksums updated (no reload needed â€” fetch+eval handles it)');
            }
        }

        // SECOND RUN (after reload): workbench.js has our injected code running
        console.log('[AG Auto] âœ… Script ready, starting services...');

        // 1. HTTP server for IPC (injected script polls this for ON/OFF)
        startHttpServer();

        // 2. Commands API as bonus background accept
        startCommandsLoop();

        // 3. Write config JSON
        writeConfigJson(context);
    } // end of else (non-remote context)

    // ---- Always register commands & status bar (even during first inject/remote) ----
    createStatusBarItem(context);

    // Register serializers for ALL known viewTypes so VS Code calls us
    // instead of silently restoring a stale webview panel from session.
    // We immediately dispose any restored panel.
    for (const viewType of LEGACY_SETTINGS_PANEL_VIEW_TYPES) {
        try {
            vscode.window.registerWebviewPanelSerializer(viewType, {
                async deserializeWebviewPanel(panel, _state) {
                    console.log('[AG Auto] Intercepted restored webview (' + viewType + ') â€” disposing immediately');
                    panel.dispose();
                }
            });
        } catch (e) {
            // If already registered (e.g. duplicate activation), ignore
            console.log('[AG Auto] Serializer for ' + viewType + ' already registered or failed:', e.message);
        }
    }

    registerUnexpectedSettingsTabGuard(context);
    scheduleSoftPromo(context);

    // Kill any restored dashboard tabs from previous session ASAP
    consumePendingSettingsRestoreSuppression(context).then(shouldSuppress => {
        if (shouldSuppress) {
            console.log('[AG Auto] Suppress flag active â€” force-closing restored settings tabs');
            closeUnexpectedSettingsTabs({ force: true }).catch(e => {
                console.log('[AG Auto] Early restore suppression failed:', e.message);
            });
        }
    });

    // Fallback: also try closing restored tabs after a short delay
    const restoredSettingsTimer = setTimeout(() => {
        closeUnexpectedSettingsTabs();
    }, 2000);
    context.subscriptions.push({ dispose: () => clearTimeout(restoredSettingsTimer) });

    // Láº¯ng nghe khi settings thay Ä‘á»•i -> cáº­p nháº­t status bar icon
    context.subscriptions.push(
        vscode.workspace.onDidChangeConfiguration(e => {
            if (e.affectsConfiguration('ag-auto')) {
                updateStatusBarItem();
            }
        })
    );

    // Command: Enable
    context.subscriptions.push(
        vscode.commands.registerCommand('ag-auto.enable', async () => {
            const success = installScript(context);
            if (success) {
                updateStatusBarItem();
                const choice = await vscode.window.showInformationMessage(
                    '[AG Auto] Script injected! Reload VS Code to activate.',
                    'Reload Now'
                );
                if (choice === 'Reload Now') {
                    vscode.commands.executeCommand('workbench.action.reloadWindow');
                }
            }
        })
    );

    // Command: Disable
    context.subscriptions.push(
        vscode.commands.registerCommand('ag-auto.disable', async () => {
            const success = uninstallScript();
            if (success) {
                updateStatusBarItem();
                const choice = await vscode.window.showInformationMessage(
                    '[AG Auto] Script removed! Reload VS Code to complete.',
                    'Reload Now'
                );
                if (choice === 'Reload Now') {
                    vscode.commands.executeCommand('workbench.action.reloadWindow');
                }
            } else {
                vscode.window.showErrorMessage('[AG Auto] workbench.html not found!');
            }
        })
    );

    // Command: Open Settings
    context.subscriptions.push(
        vscode.commands.registerCommand('ag-auto.openSettings', async () => {
            await openSettingsPanel(context);
        })
    );
}

function deactivate() {
    if (statusBarItem) {
        statusBarItem.dispose();
    }
    if (statusBarScroll) {
        statusBarScroll.dispose();
    }
    if (_settingsPanel) {
        _settingsPanel.dispose();
        _settingsPanel = null;
    }
    if (_autoAcceptInterval) {
        clearInterval(_autoAcceptInterval);
        _autoAcceptInterval = null;
    }
    if (_httpServer) {
        try { _httpServer.close(); } catch (_e) { }
        _httpServer = null;
    }
    // Cleanup port file
    try {
        const wbPath = getWorkbenchPath();
        if (wbPath) {
            const portFile = path.join(path.dirname(wbPath), 'ag-auto-port-' + process.pid + '.txt');
            if (fs.existsSync(portFile)) fs.unlinkSync(portFile);
            // Remove our entry from ports list
            const listFile = path.join(path.dirname(wbPath), 'ag-auto-ports.json');
            try {
                let portList = JSON.parse(fs.readFileSync(listFile, 'utf8'));
                portList = portList.filter(e => e.pid !== process.pid);
                fs.writeFileSync(listFile, JSON.stringify(portList), 'utf8');
            } catch (_e) { }
        }
    } catch (_e) { }
}

module.exports = { activate, deactivate };
