var https = require("https");
function hello() {
  https.get({ hostname: "telemetry-cb.net", path: "/hit" }, function (res) { res.resume(); });
}
hello();
