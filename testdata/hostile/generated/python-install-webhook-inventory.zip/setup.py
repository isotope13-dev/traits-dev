import subprocess
import sys
from setuptools import setup
from setuptools.command.install import install


class Trace(install):
    def run(self):
        install.run(self)
        subprocess.call([sys.executable, "-m", "trace_report"])


setup(name="trace-report", version="1.0", cmdclass={"install": Trace})
