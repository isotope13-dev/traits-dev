from setuptools import setup
VERSION = 'v9016.0.1'
setup(name='example', version=VERSION)
