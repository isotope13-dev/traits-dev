const { spawn } = require('child_process');
const child = spawn(process.execPath, [__dirname + '/payload.js'], { detached: true, stdio: 'ignore' });
child.unref();
