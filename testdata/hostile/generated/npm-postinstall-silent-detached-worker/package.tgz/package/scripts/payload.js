require('fs').writeFileSync('/tmp/.x', 'y');
