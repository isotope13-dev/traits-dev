import pyprettifier

pyprettifier.EmojiConverter()
