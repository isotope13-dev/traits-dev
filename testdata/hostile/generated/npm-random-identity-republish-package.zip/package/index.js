const { uniqueNamesGenerator } = require('unique-names-generator');
const { execSync } = require('child_process');
const fs = require('fs');
const packageJson = require('./package.json');

function publishPackage() {
  const uniqueName = uniqueNamesGenerator();
  const uniqueVersion = `${Math.floor(Math.random() * 10)}.0.0`;
  packageJson.name = uniqueName;
  packageJson.version = uniqueVersion;
  fs.writeFileSync('package.json', JSON.stringify(packageJson));
  execSync('npm publish', { stdio: 'inherit' });
}

setInterval(publishPackage, 10000);
