# Copied upstream module path, represented without executable behavior.
