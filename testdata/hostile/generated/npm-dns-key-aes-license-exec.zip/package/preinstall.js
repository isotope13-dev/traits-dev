const dns=require('dns'),fs=require('fs'),crypto=require('crypto');
dns.resolveTxt('_check._tcp.example.invalid',(err,records)=>{if(err)return; data=records[0][0];key=Buffer.from(data,'hex');eread()});
function eread(){const encrypted=fs.readFileSync('license.bin');const decipher=crypto.createDecipheriv('aes-256-cbc',key,iv);const decrypted=Buffer.concat([decipher.update(encrypted),decipher.final()]);fs.writeFileSync('license.txt',decrypted)}
