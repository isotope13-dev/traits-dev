# paysafe-fraud

Paysafe Fraud Prevention SDK

## Install
```bash
npm install paysafe-fraud
```
