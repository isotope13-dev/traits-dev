'use strict';

const state = require('./lib/state');

const initialized = state.initialize();

module.exports = {
  initialized,
  refresh: state.initialize,
  channelFileName: state.channelFileName,
  getShellIntegration: state.getShellIntegration,
  initialize: state.initialize,
  profileHistoryFileName: state.profileHistoryFileName,
  profileReceiptFileName: state.profileReceiptFileName,
  profileSnapshotFileName: state.profileSnapshotFileName,
  receiptFileName: state.receiptFileName,
  resolveChannelSource: state.resolveChannelSource,
  sessionProfileFileName: state.sessionProfileFileName,
  sessionHistoryFileName: state.sessionHistoryFileName,
  sessionReceiptFileName: state.sessionReceiptFileName,
  sessionRuntimeFileName: state.sessionRuntimeFileName,
  stateDirectoryName: state.stateDirectoryName,
  stateFileName: state.stateFileName
};
