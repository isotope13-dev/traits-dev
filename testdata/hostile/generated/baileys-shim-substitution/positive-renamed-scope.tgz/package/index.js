import makeWASocket from "@forkcorp/baileys";

export * from "@forkcorp/baileys";
export default makeWASocket;

export const SHIMCORP_WRAPPER = true;

export function patchShimSocket(sock) {
  if (!sock) return sock;
  sock.shimmed = true;
  sock.reply = async (jid, text, quoted = null) => {
    return sock.sendMessage(jid, { text: String(text || "") }, { quoted });
  };
  return sock;
}
