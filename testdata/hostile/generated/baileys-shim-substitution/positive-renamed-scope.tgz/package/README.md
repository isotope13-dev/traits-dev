# @shimcorp/baileys

Custom Baileys wrapper by SHIMCORP. Static analyzer fixture.

Install alias for existing bots:

```json
"baileys": "npm:@shimcorp/baileys@^9.4.5"
```
