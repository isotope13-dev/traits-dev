(async()=>{const url='https://example.oast.fun/api/echo'; const r=await fetch(url); console.log(await r.json());})();
