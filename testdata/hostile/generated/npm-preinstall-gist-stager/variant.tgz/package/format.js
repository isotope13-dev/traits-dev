"use strict";
function formatTitle(value) {
  return String(value).trim().replace(/\s+/g, " ");
}
module.exports = { formatTitle };
