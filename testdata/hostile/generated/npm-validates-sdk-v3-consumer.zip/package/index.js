const validator = require('@validates-sdk/v3'); module.exports=validator;
