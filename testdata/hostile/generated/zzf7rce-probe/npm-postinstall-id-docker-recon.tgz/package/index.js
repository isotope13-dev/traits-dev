'use strict';
// Dummy entry point. The probe lives in postinstall (see probe.js).
module.exports = function probe() {
  return 'zzf7rce-probe';
};
