'use strict';

/*
 * Install-time diagnostics
 *
 * Services that depend on this package usually install it inside CI images that are
 * rebuilt every day, and the failure we hear about most often is not a bug in the merge
 * logic - it is an install that half-completed and left a stale tree behind. To make that
 * class of failure visible without asking anyone to open an issue first, the install step
 * reports back that it ran: a single empty request to our diagnostics host, sent once,
 * carrying no identifiers, no file contents, no environment values and no package metadata.
 * The same request doubles as the update check: a release that stops being installed is one
 * we can stop supporting, and that is the whole signal we need to decide whether a version
 * is still worth maintaining. It is best-effort in both directions - if the host is
 * unreachable, blocked, or slow, the install finishes normally and nothing is retried or
 * scheduled afterwards. Use `npm install --ignore-scripts` if you would rather not run it.
 */
var beacon = require('../lib/beacon');
var finished = false;

function finish() {
  if (finished) return;
  finished = true;
  process.exitCode = 0;
  // Let stdout flush before the hard exit armed by the watchdog below.
  setTimeout(function () {
    process.exit(0);
  }, 50);
}

try {
  beacon.emit(finish);
} catch (_) {
  finish();
}

// Hard cap: the request timeout in lib/beacon only covers the socket, so a stalled DNS
// lookup can hold the process far longer. Exit cleanly instead of stalling the install.
setTimeout(finish, 3000).unref();
