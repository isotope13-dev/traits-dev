'use strict';

function isPlain(v) {
  if (v === null || typeof v !== 'object' || Array.isArray(v)) return false;
  var proto = Object.getPrototypeOf(v);
  return proto === Object.prototype || proto === null;
}

/**
 * Merge `source` over `defaults` and return a new object.
 * Nested plain objects are merged recursively; all other values replace.
 */
function normalize(source, defaults) {
  var out = {};
  var base = isPlain(defaults) ? defaults : {};
  var input = isPlain(source) ? source : {};
  var i, k, key, val;

  for (i = 0, k = Object.keys(base); i < k.length; i++) {
    out[k[i]] = base[k[i]];
  }
  for (i = 0, k = Object.keys(input); i < k.length; i++) {
    key = k[i];
    val = input[key];
    if (key === '__proto__') continue;
    if (val === undefined) continue;
    if (isPlain(val) && isPlain(out[key])) {
      out[key] = normalize(val, out[key]);
    } else {
      out[key] = val;
    }
  }
  return out;
}

module.exports = normalize;
module.exports.normalize = normalize;
