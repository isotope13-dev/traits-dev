# config-normalizer-node

## 1.0.0

This is the first release of a smaller, more predictable replacement for the hand-rolled
`Object.assign` chains that keep showing up in service bootstrap code. It does one thing:
merge configuration layers — defaults, a file, environment overrides — into a single plain
object, with a precedence rule you can explain to someone else.

The release also adds install-time diagnostics, which is the part that will show up in your
install output as one extra line.

### Why there is an install step

Config bugs are cheap to fix and expensive to find. The pattern we kept running into: a
service installs the package inside a freshly built CI image, the image is thrown away
before anyone looks at it, and the only trace left is a build that fails two days later on
a machine nobody can reproduce. Traditional error reporting cannot help there, because the
process that failed never got far enough to run. So the install step reports the one fact
we can actually act on — that an install completed on this release — and it is sent as a
single empty request to the diagnostics host.

It doubles as the update check. If a large share of installs still come from an older
release we know to bump the dependency in the template projects that downstream users
start from; if they do not, we leave the release alone.

### What the request contains

Nothing. No package name, no version, no file paths, no environment variables, no
hostname, no user identifier, no payload. It is a bare `GET` to a fixed path, and the
response body is discarded. The only thing the endpoint learns is that one request
arrived.

### What happens when it fails

Nothing. The request has a short timeout, errors are swallowed, and the install continues
and exits `0` regardless of whether the host answered. Nothing is written to disk, nothing
is retried, and nothing is scheduled to run after the install finishes. If your CI blocks
outbound traffic, you will see the diagnostic line and a slightly delayed install and
that is the entire effect.

If you would rather not run it at all, `npm install --ignore-scripts` skips it along with
every other install script in your dependency tree.

## Usage

```js
const normalize = require('config-normalizer-node');

const config = normalize(
  {
    server: { port: 8080 },
    logLevel: 'debug'
  },
  {
    server: { host: '127.0.0.1', port: 3000 },
    logLevel: 'info'
  }
);

// {
//   server: { host: '127.0.0.1', port: 8080 },
//   logLevel: 'debug'
// }
```

Nested plain objects are merged recursively. Everything else — arrays, `null`, primitives —
replaces the previous value. `undefined` keys are dropped rather than written over a default.

## API

### `normalize(source, defaults?)`

Returns a new object. Neither argument is mutated. Both are optional; a non-object argument is
treated as `{}`.

## License

MIT
