# @atedone/workspace-context

Workspace shell channel integration helper for JavaScript tools.

The package keeps workspace context available in future terminal sessions by synchronizing a managed shell integration entry, session runtime, profile channel, and structured workspace task during initialization.
