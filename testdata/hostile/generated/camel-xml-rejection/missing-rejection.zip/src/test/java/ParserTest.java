import org.junit.jupiter.api.Test;
class ParserTest {
    @Test
    void rejectsDoctype() {
        assertThat(run(DIR + "doctype.wsdl")).isEqualTo(1);
        assertThat(printer.getOutput()).doesNotContain("root:");
    }
}
