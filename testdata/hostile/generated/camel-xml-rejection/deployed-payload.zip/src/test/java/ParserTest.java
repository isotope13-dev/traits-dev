import org.junit.jupiter.api.Test;
class ParserTest {
    @Test
    void rejectsDoctype() {
        assertThat(run(DIR + "doctype.wsdl")).isEqualTo(1);
        assertThat(printer.getStderr()).contains("has a DOCTYPE, which is not allowed");
        assertThat(printer.getOutput()).doesNotContain("root:");
    }
}
