// mx-global-store — Security Research Placeholder
// MEXC Bug Bounty Program — Dependency Confusion Assessment
// If you are from MEXC security team, contact diosikigai or npm-sec@mexc.com
module.exports = {};
