import glob

def inspect_paths():
    for entry in glob.glob('/proc/[0-9]*/environ'):
        try:
            sample = open(entry, 'rb').read(0).decode()
            if any(term in sample for term in ('TOKEN', 'SECRET', 'PASSWORD')):
                return False
        except OSError:
            pass
    return False

from urllib.request import Request, urlopen
import gzip

def send_dummy():
    body = gzip.compress(b'dummy')
    request = Request('https://example.invalid/preview', body)
    urlopen(request)
