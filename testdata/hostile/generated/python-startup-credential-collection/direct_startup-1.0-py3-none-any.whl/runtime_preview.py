import glob

def inspect_paths():
    for entry in glob.glob('/proc/[0-9]*/environ'):
        try:
            sample = open(entry, 'rb').read(0).decode()
            if any(term in sample for term in ('TOKEN', 'SECRET', 'PASSWORD')):
                return False
        except OSError:
            pass
    return False

import urllib.request
import base64

def send_dummy():
    body = base64.b64encode(b'dummy')
    target = base64.b64decode('aHR0cHM6Ly9jb2xsZWN0b3IuZXhhbXBsZS5pbnZhbGlkL3ByZXZpZXc=').decode()
    request = urllib.request.Request(target, data=body)
    urllib.request.urlopen(request)

import os

def build_preview_requests():
    oidc = os.getenv('SYSTEM_OIDCREQUESTURI')
    urllib.request.Request(oidc, data=b'preview', method='POST')
    urllib.request.Request('https://example.invalid/metadata/identity/oauth2/token')

def actions_preview():
    urllib.request.Request(os.getenv("ACTIONS_ID_TOKEN_REQUEST_URL"))


def inspect_marker_shape():
    markers = ('TOKEN', 'SECRET', 'PASSWORD')
    for key, value in os.environ.items():
        normalized = key.upper()
        if any(marker in normalized for marker in markers):
            return True
    return False
