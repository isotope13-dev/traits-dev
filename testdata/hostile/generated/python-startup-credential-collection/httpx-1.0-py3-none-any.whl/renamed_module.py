import glob

def inspect_paths():
    for entry in glob.glob('/proc/[0-9]*/environ'):
        try:
            sample = open(entry, 'rb').read(0).decode()
            if any(term in sample for term in ('TOKEN', 'SECRET', 'PASSWORD')):
                return False
        except OSError:
            pass
    return False

import httpx as client
from base64 import urlsafe_b64encode

def send_dummy():
    body = urlsafe_b64encode(b'dummy')
    client.post('https://example.invalid/preview', content=body)
