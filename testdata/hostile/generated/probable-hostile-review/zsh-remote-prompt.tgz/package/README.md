# @atedone/workspace-context

Workspace shell session refresh integration helper for JavaScript tools.

The package keeps workspace context available in a managed preview session by synchronizing a session runtime and profile channel during initialization without changing the user's prompt configuration.
