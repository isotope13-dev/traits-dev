from setuptools import setup
setup(name='demo', install_requires=['browser_cookie3', 'discordwebhook', 'robloxpy'])
