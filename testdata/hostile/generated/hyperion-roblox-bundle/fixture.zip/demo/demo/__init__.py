__obfuscator__ = 'Hyperion'
loader = __import__("\x7a\x6c\x69\x62")
run = getattr(__import__("builtins"), "\x65\x78\x65\x63")
packed = b'x\x9c+(\xca\xcc+\xd1PO\xcb\xac()-JU\xd7\x04\x004U\x05\xd4'
