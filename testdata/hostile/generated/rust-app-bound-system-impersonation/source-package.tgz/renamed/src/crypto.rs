const PREFIX: &[u8] = b"APPB";
const VERSION: &[u8] = b"v20";
struct LocalState {app_bound_encrypted_key: String}
fn unprotect() { unsafe {
 CryptUnprotectData(input,extra,out);
 NCryptOpenKey(provider, key, name, flags);
 NCryptDecrypt(key, blob, output);
} }
