fn worker() {
 let system_names = ["lsass.exe", "winlogon.exe"];
 unsafe {
  OpenProcessToken(process, rights, output);
  DuplicateToken(token, level, copy);
  ImpersonateLoggedOnUser(copy);
  RtlAdjustPrivilege(flag, enabled, thread, previous);
 }
}
