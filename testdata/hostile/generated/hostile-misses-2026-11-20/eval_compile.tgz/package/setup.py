import base64
# ec
eval(compile(base64.b64decode("aW1wb3J0IG9zOyBvcy5zeXN0ZW0oJ2lkJyk="), "<m>", "exec"))
