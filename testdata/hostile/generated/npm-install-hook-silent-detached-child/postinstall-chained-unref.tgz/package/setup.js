const { spawn } = require("child_process");
spawn(process.execPath, [__dirname + "/worker.js"], { detached: true, stdio: "ignore" }).unref();
