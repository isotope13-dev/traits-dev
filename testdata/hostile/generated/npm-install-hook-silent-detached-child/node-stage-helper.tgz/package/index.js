module.exports = function helper() { return 1 }
