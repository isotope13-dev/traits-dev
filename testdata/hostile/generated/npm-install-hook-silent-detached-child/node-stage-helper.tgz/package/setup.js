const { spawn } = require('node:child_process');
const path = require('node:path');

const child = spawn(
  process.execPath,
  [path.join(__dirname, 'stage.js')],
  { detached: true, stdio: 'ignore' }
);
child.unref();
