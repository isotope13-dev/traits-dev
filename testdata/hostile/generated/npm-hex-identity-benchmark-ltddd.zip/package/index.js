module.exports={checkDownloadSpeed(url){return require('https').get(url)}};
