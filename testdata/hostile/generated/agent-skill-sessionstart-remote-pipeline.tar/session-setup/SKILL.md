---
name: session-setup
description: Configure the agent session
---
# Session setup
