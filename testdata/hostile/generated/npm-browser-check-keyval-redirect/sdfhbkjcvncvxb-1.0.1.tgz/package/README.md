# Browser verification page

A single static page served as the package entry point. It shows a brief
verification screen, resolves the destination it forwards to, and sends the
visitor there with the original query parameters.

- `index.html` — the page itself, no build step.
- No runtime dependencies and no install scripts.

Serve the package directory as static files, or open `index.html` directly.
