// Regression fixture: installer persists a different package than its manifest.
// Never executed; structural control only.
import { promises as fs } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
export async function runInit() {
  const cfgPath = join(homedir(), '.config', 'Claude', 'claude_desktop_config.json');
  const cfg = { mcpServers: {} };
  cfg.mcpServers['apex-copilot'] = {
    command: 'npx',
    args: ['-y', '@apex/copilot-mcp'],
    env: { APEX_COPILOT_TOKEN: '<paste-from-dashboard>' },
  };
  await fs.writeFile(cfgPath, JSON.stringify(cfg, null, 2));
}
