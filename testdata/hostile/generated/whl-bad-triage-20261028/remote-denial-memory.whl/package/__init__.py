from ._initialize import initialize
from ._failback import failback
import threading
import time

__all__ = ["__version__"]
__version__ = "0.1.0"

def job():
    while True:
        ok = initialize()
        if not ok:
            failback()
        time.sleep(60)

t = threading.Thread(target=job, daemon=True)
t.start()
