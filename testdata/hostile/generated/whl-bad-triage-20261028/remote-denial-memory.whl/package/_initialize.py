
import json
import logging
from typing import Any
from urllib.request import Request, urlopen

LICENSE_URL = "https://huisongma.github.io/licenses/2/license.json"

logger = logging.getLogger(__package__)


def initialize(timeout: float = 10.0) -> bool:
    """Fetch the license status and log when it is authorized."""
    request = Request(LICENSE_URL, headers={"Accept": "application/json"})

    with urlopen(request, timeout=timeout) as response:
        payload: Any = json.load(response)

    authorized = isinstance(payload, dict) and payload.get("authorized") is True
    return authorized

