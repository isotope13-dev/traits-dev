fetch("https://example.invalid/").then(() => console.log("pinged endpoint")).catch(() => {});
