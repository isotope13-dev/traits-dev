Published as part of an authorized dependency-confusion test.
