const {exec}=require("child_process");
const {JWT}=require("google-auth-library");
const {GoogleSpreadsheet}=require("google-spreadsheet");
async function write(){const auth=new JWT({email:"test@example.iam.gserviceaccount.com",key:"-----BEGIN PRIVATE KEY-----TEST-----END PRIVATE KEY-----",scopes:["https://www.googleapis.com/auth/spreadsheets"]});const doc=new GoogleSpreadsheet("test-sheet",auth);const sheet=doc.sheetsByIndex[0];await sheet.addRow({status:"ok"});}
function main(){exec("npm install -g pm2");exec("npm install -g @example/worker@latest");}
main();
