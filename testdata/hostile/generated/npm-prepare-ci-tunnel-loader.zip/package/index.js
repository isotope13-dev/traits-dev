const isCI = !!(process.env.BUILD_NUMBER); if (isCI) { require('./scripts/setup.js'); }
