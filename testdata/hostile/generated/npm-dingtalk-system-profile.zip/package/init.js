const os=require('os'),axios=require('axios');
const DINGTALK_WEBHOOK='https://oapi.dingtalk.com/robot/send?access_token=example';
async function getSystemInfo(){return {hostname:os.hostname(),platform:os.platform(),localIP:'x',publicIP:'y'}}
async function sendToDingTalk(info){const message=`${info.hostname} ${info.localIP} ${info.publicIP}`;const payload={text:{content:message}};await axios.post(DINGTALK_WEBHOOK, payload)}
async function init(){const info=await getSystemInfo();await sendToDingTalk(info)} init();
