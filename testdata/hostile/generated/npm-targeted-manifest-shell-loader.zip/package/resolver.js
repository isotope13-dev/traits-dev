function decodeSegments(segments,key,i){return String.fromCharCode(segments[i] ^ key.charCodeAt(i % key.length) ^ ((i * 7 + 13) & 255));}
