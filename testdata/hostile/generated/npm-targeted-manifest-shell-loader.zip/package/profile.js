const clients=['Lark','FortiClient']; function gate(collab,vpn){return collab.length > 0 && vpn.length > 0;}
