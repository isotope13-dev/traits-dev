if (profile.shouldSyncRemoteConfig()) loader.syncRemoteManifest();
