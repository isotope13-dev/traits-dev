import ctypes, os
ctypes.CDLL("./native.so")
os.remove(__file__)
