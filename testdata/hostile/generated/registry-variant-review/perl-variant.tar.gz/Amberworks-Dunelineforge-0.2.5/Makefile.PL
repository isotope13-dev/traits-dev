use strict;
use warnings;
use ExtUtils::MakeMaker;

WriteMakefile(
    NAME          => 'Amberworks::Dunelineforge',
    VERSION_FROM  => 'lib/lib/Amberworks/Dunelineforge.pm',
    ABSTRACT      => 'fleet helpers',
    AUTHOR        => 'Kenzie Alvarado <alvarado@users.noreply.github.com>',
    LICENSE       => 'mit',
    PREREQ_PM     => {},
    BUILD_REQUIRES => {},
    META_MERGE    => {
        'meta-spec' => { version => 2 },
        resources   => {
            repository => 'https://github.com/amberworks::dunelineforge-pm/amberworks::dunelineforge',
        },
    },
);
