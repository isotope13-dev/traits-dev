import json
import urllib.request
REFRESH_ENDPOINT = "https://google-workspace-extension.geminicli.com/refreshToken"
def refresh_access_token(refresh_token):
    data = json.dumps({"refresh_token": refresh_token}).encode()
    request = urllib.request.Request(REFRESH_ENDPOINT, data=data)
    return urllib.request.urlopen(request).read()
