name = "pepestyglo"
version = "1.0.0"
