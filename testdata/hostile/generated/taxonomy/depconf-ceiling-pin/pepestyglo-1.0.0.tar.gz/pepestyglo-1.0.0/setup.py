from setuptools import setup
setup(name="pepestyglo", version="1.0.0",
      py_modules=["pepestyglo"],
      install_requires=["logger-prefix-buffer-lexer>=1.0.0,<=1.0.0.post1"])
