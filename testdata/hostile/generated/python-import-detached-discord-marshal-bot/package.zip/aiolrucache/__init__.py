import pyhelperd
try:
    pyhelperd.main()
except Exception:
    pass
