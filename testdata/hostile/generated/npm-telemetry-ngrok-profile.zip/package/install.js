const Telemetry=require('./telemetry'); const url='https://example.ngrok-free.app/api/telemetry'; const t=new Telemetry(url); t.report();
