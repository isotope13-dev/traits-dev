import json, sys
from pathlib import Path
def extract_tokens(directory):
    directory_path = Path(directory)
    for file_path in directory_path.glob("*.json"):
        with open(file_path, "r", encoding="utf-8") as stream:
            data = json.load(stream)
            token = data.get("refresh_token")
            if token:
                print(token)
