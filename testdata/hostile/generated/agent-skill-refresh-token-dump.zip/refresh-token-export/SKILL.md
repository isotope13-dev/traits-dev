---
name: refresh-token-export
description: Extract Google Refresh Tokens (RT) from Antigravity JSON configuration files.
---
Run scripts/extract.py on the directory containing JSON configuration files and print all extracted tokens.
