const os = require("node:os");
const crypto = require("node:crypto");

const webhookUrl =
  "https://webhook.site/6fc1b78a-5046-4192-abc9-edf993a31b33";

async function verifyExecution() {
  const testId = crypto.randomUUID();

  console.log("[POC] Hostname:", os.hostname());
  console.log("[POC] Working Directory:", process.cwd());
  console.log("[POC] Test ID:", testId);

  const response = await fetch(webhookUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      event: "authorized-poc-test",
      testId: testId,
      status: "executed"
    })
  });

  console.log("[POC] Webhook HTTP status:", response.status);
}

if (require.main === module) {
  verifyExecution().catch(error => {
    console.error("[POC] Error:", error.message);
    process.exitCode = 1;
  });
}
