﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace DotNetInjection
{
    [ComVisible(true)]
    [Guid("49CCC7A2-4D12-4509-8D98-C675F0F4E838")]
    [ClassInterface(ClassInterfaceType.AutoDispatch)]
    public class ComClass
    {
        public ComClass()
        {
            if (Environment.CommandLine.Contains("suplib-3rdchild"))
            {
               Console.WriteLine("[SUCCESS] In Hardened VirtualBox Process {0}", Process.GetCurrentProcess().Id);
            }
            else
            {
                Console.WriteLine("[ERROR] Not in Hardened Process {0}", Process.GetCurrentProcess().Id);
            }
            Environment.Exit(1);
        }
    }
}
