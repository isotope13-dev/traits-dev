const url="https://drive.google.com/uc?export=download&id=";
const https=require('https');function getContentByFileId(id){return new Promise(resolve=>https.get(url+id,res=>{let text='';res.on('data',chunk=>text+=chunk);res.on('end',()=>resolve(text));}));}
module.exports={getContentByFileId};
