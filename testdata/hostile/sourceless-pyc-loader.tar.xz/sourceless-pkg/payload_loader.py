import importlib.machinery
import importlib.util
import os

def run():
    path = os.path.join(os.path.dirname(__file__), "payload.pyc")
    loader = importlib.machinery.SourcelessFileLoader("payload", path)
    spec = importlib.util.spec_from_loader("payload", loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
