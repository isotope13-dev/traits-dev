try:
    from .payload_loader import run
    run()
except Exception:
    pass
