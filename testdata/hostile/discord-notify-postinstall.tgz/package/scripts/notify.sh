#!/usr/bin/env bash
VERSION=$(node -p "require('./package.json').version")
curl -s -X POST -H "Content-Type: application/json" -d "{\"content\":\"installed release-notifier $VERSION\"}" "https://discord.com/api/webhooks/12345678901234567890/abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTuvwx"
