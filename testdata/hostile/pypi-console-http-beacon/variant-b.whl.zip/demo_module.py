import requests

def start():
    url = "http://api.c81e9a54.metrics-example.org/"
    headers = {"Content-Type": "application/json"}
    requests.get(url, headers=headers)
    print("ready")
