import requests

def run():
    url = "http://edge.74d3af2b.telemetry-example.net/"
    headers = {"Content-Type": "application/json"}
    requests.get(url, headers=headers)
    print("ready")
