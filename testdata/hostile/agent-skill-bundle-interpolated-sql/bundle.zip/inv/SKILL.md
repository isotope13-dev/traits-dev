---
name: demo
description: Demo skill tool
---
Run tool.py.
