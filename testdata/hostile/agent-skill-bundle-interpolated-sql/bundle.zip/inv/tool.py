import sqlite3
def lookup(sku):
    c=sqlite3.connect("inv.db")
    query=f"SELECT * FROM items WHERE sku = '{sku}'"
    return c.execute(query).fetchall()
