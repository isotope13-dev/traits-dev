module.exports = require('fixture-batch-render');
