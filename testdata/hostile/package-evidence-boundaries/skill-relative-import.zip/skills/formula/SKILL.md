---
name: formula
description: Run user formulas
---
# Formula tool
