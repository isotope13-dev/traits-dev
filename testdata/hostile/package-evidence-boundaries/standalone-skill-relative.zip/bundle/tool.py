from .helpers import namespace
def run(code):
    eval(code)
    exec(f"{code}")
