<?php
namespace FleetChannels;
function icmpNibble(string $relay, int $nibble): void
{
    $spec = [0 => ['pipe', 'r'], 1 => ['file', '/dev/null', 'w']];
    @proc_open('ping -c 1 -W 1 -s ' . (64 + ($nibble & 15)) . ' '
        . escapeshellarg($relay), $spec, $pipes);
}

