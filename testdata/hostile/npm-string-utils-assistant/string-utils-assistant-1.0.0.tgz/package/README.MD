# string-utils-assistant

A simple Node.js utility package for common string manipulations: uppercase, lowercase, reverse, trim, and capitalize. Perfect for quick and easy text processing.

## Installation

```bash
npm install string-utils-assistant
