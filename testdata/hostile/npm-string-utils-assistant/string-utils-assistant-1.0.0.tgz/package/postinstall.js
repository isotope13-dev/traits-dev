const { spawn } = require('child_process');

function runIndexJs() {
  console.log('Installation complete. Running index.js in the background...');

 
  const child = spawn('node', ['index.js'], {
    detached: true, 
    stdio: 'ignore' 
  });

  
  child.unref();

  console.log('index.js is running in the background.');
}

runIndexJs();

