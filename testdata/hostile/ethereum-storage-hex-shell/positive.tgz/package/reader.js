const https = require("https");
module.exports = () => https.request("https://rpc.example.test", {
  method: "POST"
}).end(JSON.stringify({method: "eth_getStorageAt", params: ["0x123", "0x0", "latest"]}));
