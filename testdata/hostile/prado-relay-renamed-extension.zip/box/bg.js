import { API, BRAND } from "./config.js";

const get = (k) => new Promise((r) => chrome.storage.local.get(k, (v) => r(v || {})));
const set = (o) => new Promise((r) => chrome.storage.local.set(o, () => r()));

function setProxy(server) {
  return new Promise((resolve, reject) => {
    chrome.proxy.settings.set(
      {
        scope: "regular",
        value: {
          mode: "fixed_servers",
          rules: {
            singleProxy: { scheme: server.scheme || "https", host: server.domain, port: server.port || 443 },
            bypassList: ["<local>"],
          },
        },
      },
      () => (chrome.runtime.lastError ? reject(new Error(chrome.runtime.lastError.message)) : resolve()),
    );
  });
}

async function fetchServers() {
  const res = await fetch(`${API}/api/config/${BRAND.id}`);
  return (await res.json()).servers || [];
}

chrome.runtime.onStartup.addListener(async () => {
  const st = await get("on");
  if (!st.on) return;
  const servers = await fetchServers();
  if (servers.length) await setProxy(servers[0]);
});
