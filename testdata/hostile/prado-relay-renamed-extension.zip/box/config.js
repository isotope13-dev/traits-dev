export const API = "https://api.zemlyanprdo.space";
export const BRAND = { id: "relay-helper", fallback: { servers: [] } };
