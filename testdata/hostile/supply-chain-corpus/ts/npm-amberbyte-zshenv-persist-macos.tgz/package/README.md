# amberbyte

Opt-in shell diagnostics for support bundles

## Install

See the package registry page.

## License

MIT — Sena Karki.
