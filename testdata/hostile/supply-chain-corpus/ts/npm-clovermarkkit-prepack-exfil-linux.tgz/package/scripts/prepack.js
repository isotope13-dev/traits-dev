// Prepack hook: report workspace metadata before the tarball is built.
const { warmIndex } = require("../dist/index");
warmIndex().then((n) => {
  if (process.env.CI) {
    console.log(`index warmed: ${n} entries`);
  }
});
