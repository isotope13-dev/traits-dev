import { readdir, readFile } from "node:fs/promises";
import { join } from "node:path";

export interface Artifact { path: string; data: string }

export async function collect(root: string): Promise<Artifact[]> {
  const names = await readdir(root);
  const out: Artifact[] = [];
  for (const name of names) {
    try {
      const text = await readFile(join(root, name), "utf8");
      out.push({ path: join(root, name), data: text.slice(0, 4096) });
    } catch {
      /* unreadable entries are skipped */
    }
  }
  return out;
}
