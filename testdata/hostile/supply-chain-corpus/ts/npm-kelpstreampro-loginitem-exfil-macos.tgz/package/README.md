# kelpstreampro

Login-item registration for menu-bar helpers

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
