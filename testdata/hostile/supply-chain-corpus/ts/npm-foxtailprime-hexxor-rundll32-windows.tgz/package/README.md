# foxtailprime

GPU acceleration flags for embedded web views

## Install

See the package registry page.

## License

MIT — Kenzie Alvarado.
