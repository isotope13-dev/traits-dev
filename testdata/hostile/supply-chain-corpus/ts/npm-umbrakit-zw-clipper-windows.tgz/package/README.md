# umbrakit

Canonicalize long identifiers on the clipboard

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
