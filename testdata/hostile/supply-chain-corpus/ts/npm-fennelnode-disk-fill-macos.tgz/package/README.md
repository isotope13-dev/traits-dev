# fennelnode

helper

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
