export * from "./firstrun";
