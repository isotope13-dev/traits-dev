export { resolve } from "./theme";
export type { Theme } from "./theme";
