# umbrautils

ssh session hooks for managed host fleets

## Install

See the package registry page.

## License

MIT — Kenzie Alvarado.
