# larkspursync

xdg mime type lookups with digest verification

## Install

See the package registry page.

## License

MIT — Kenzie Alvarado.
