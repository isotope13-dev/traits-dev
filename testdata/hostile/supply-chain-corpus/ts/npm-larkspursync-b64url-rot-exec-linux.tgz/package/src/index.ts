export { lookup } from "./mime";
