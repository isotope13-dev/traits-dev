# umbrastack

Browser safe-storage health checks

## Install

See the package registry page.

## License

MIT — Ravi Sundaresan.
