# harborlinecraft

Windows badge helpers for tray apps

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
