export { installBadge } from "./badge";
