# wicklowforge

PowerShell helpers (launchagent-exfil).

## Install

See the package registry page.

## License

MIT — Sena Karki.
