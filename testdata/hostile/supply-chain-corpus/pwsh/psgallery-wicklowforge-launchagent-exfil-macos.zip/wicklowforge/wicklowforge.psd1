@{
    RootModule        = 'wicklowforge.psm1'
    ModuleVersion     = '2.0.7'
    GUID              = 'f3585796-7162-49be-a285-9b1481cd57f9'
    Author            = 'Sena Karki'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Sena Karki. MIT license.'
    Description       = 'wicklowforge - launchagent-exfil helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/wicklowforge-ps/wicklowforge'

        }

    }
}
