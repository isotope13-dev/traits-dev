@{
    RootModule        = 'larkspurmesh.psm1'
    ModuleVersion     = '2.2.0'
    GUID              = '2c9c3314-200d-4a56-af3c-f65ddb9e9741'
    Author            = 'Sena Karki'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Sena Karki. MIT license.'
    Description       = 'larkspurmesh - recovery-destroy helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/larkspurmesh-ps/larkspurmesh'

        }

    }
}
