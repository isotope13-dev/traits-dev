@{
    RootModule        = 'tidecrestlite.psm1'
    ModuleVersion     = '1.6.5'
    GUID              = 'deb29cdb-f3ea-41ca-a23f-14be87a3123b'
    Author            = 'Jonas Kirkelund'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Jonas Kirkelund. MIT license.'
    Description       = 'tidecrestlite - hexxor-mshta helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/tidecrestlite-ps/tidecrestlite'

        }

    }
}
