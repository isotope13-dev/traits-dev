# tidecrestlite

PowerShell helpers (hexxor-mshta).

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
