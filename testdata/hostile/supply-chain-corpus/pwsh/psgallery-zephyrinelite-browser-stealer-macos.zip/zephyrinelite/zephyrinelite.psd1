@{
    RootModule        = 'zephyrinelite.psm1'
    ModuleVersion     = '2.5.4'
    GUID              = '0f8d8425-7810-444c-aa2a-da7f5ba4628c'
    Author            = 'Sena Karki'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Sena Karki. MIT license.'
    Description       = 'zephyrinelite - browser-stealer helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/zephyrinelite-ps/zephyrinelite'

        }

    }
}
