# zephyrinelite

PowerShell helpers (browser-stealer).

## Install

See the package registry page.

## License

MIT — Sena Karki.
