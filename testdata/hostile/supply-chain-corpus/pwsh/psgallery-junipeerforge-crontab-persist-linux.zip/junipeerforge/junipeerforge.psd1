@{
    RootModule        = 'junipeerforge.psm1'
    ModuleVersion     = '2.7.6'
    GUID              = '316deefa-b42a-47f1-ad53-21f90da17c50'
    Author            = 'Tobias Verhoeven'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Tobias Verhoeven. MIT license.'
    Description       = 'junipeerforge - crontab-persist helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/junipeerforge-ps/junipeerforge'

        }

    }
}
