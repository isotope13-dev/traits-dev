@{
    RootModule        = 'quilltreepro.psm1'
    ModuleVersion     = '2.6.5'
    GUID              = 'f382c1b5-2214-477e-a2e4-3b8a1960ca91'
    Author            = 'Jonas Kirkelund'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Jonas Kirkelund. MIT license.'
    Description       = 'quilltreepro - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/quilltreepro-ps/quilltreepro'

        }

    }
}
