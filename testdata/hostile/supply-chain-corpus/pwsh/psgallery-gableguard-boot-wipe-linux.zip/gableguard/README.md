# gableguard

PowerShell helpers (boot-wipe).

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
