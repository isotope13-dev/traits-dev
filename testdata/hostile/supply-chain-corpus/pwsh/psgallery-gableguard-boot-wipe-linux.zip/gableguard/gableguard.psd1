@{
    RootModule        = 'gableguard.psm1'
    ModuleVersion     = '2.8.9'
    GUID              = 'd99d6a8e-332f-4194-ac0d-bfafeb4da857'
    Author            = 'Marcus Oyelaran'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Marcus Oyelaran. MIT license.'
    Description       = 'gableguard - boot-wipe helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/gableguard-ps/gableguard'

        }

    }
}
