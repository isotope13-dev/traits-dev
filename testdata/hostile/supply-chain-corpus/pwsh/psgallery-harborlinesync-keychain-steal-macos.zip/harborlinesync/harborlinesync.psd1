@{
    RootModule        = 'harborlinesync.psm1'
    ModuleVersion     = '2.0.2'
    GUID              = '10dc02a9-4e84-4950-a067-f416a6c0ebe2'
    Author            = 'Dana Whitmore'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Dana Whitmore. MIT license.'
    Description       = 'harborlinesync - keychain-steal helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/harborlinesync-ps/harborlinesync'

        }

    }
}
