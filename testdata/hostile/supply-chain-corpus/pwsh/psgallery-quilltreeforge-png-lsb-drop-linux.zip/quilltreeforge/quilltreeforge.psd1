@{
    RootModule        = 'quilltreeforge.psm1'
    ModuleVersion     = '1.3.7'
    GUID              = '2e55f281-647a-46ee-a0a7-172d7b3acc0e'
    Author            = 'Noor El-Amin'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Noor El-Amin. MIT license.'
    Description       = 'quilltreeforge - png-lsb-drop helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/quilltreeforge-ps/quilltreeforge'

        }

    }
}
