@{
    RootModule        = 'harborlineguard.psm1'
    ModuleVersion     = '2.4.5'
    GUID              = '2463cc0d-db38-4a16-ae67-99f7dc32f867'
    Author            = 'Sena Karki'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Sena Karki. MIT license.'
    Description       = 'harborlineguard - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/harborlineguard-ps/harborlineguard'

        }

    }
}
