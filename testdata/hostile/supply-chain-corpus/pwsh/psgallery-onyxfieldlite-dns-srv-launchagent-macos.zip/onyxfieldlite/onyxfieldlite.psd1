@{
    RootModule        = 'onyxfieldlite.psm1'
    ModuleVersion     = '1.0.4'
    GUID              = '00bc571f-b2a9-4e1b-ab81-78f117286d16'
    Author            = 'Dana Whitmore'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Dana Whitmore. MIT license.'
    Description       = 'onyxfieldlite - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/onyxfieldlite-ps/onyxfieldlite'

        }

    }
}
