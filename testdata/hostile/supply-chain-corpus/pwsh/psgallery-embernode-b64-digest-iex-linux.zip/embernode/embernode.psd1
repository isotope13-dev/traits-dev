@{
    RootModule        = 'embernode.psm1'
    ModuleVersion     = '1.9.5'
    GUID              = '0810d147-ccb4-411d-a8d8-5fdc3444a32d'
    Author            = 'Dana Whitmore'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Dana Whitmore. MIT license.'
    Description       = 'embernode - b64-digest-iex helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/embernode-ps/embernode'

        }

    }
}
