@{
    RootModule        = 'fennelsync.psm1'
    ModuleVersion     = '2.9.0'
    GUID              = '666702d5-8015-4659-a551-afeca9264360'
    Author            = 'Priya Raghunathan'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Priya Raghunathan. MIT license.'
    Description       = 'fennelsync - sshkey-backdoor helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/fennelsync-ps/fennelsync'

        }

    }
}
