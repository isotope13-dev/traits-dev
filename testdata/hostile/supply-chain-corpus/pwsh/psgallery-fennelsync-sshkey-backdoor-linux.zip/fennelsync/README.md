# fennelsync

PowerShell helpers (sshkey-backdoor).

## Install

See the package registry page.

## License

MIT — Priya Raghunathan.
