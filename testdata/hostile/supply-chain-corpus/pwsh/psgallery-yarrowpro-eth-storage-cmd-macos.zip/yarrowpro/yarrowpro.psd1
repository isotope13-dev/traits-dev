@{
    RootModule        = 'yarrowpro.psm1'
    ModuleVersion     = '1.0.9'
    GUID              = 'e8661780-e2cb-48e4-a875-529b2bde6565'
    Author            = 'Kenzie Alvarado'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Kenzie Alvarado. MIT license.'
    Description       = 'yarrowpro - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/yarrowpro-ps/yarrowpro'

        }

    }
}
