@{
    RootModule        = 'junipeercore.psm1'
    ModuleVersion     = '1.0.4'
    GUID              = '4b1745fd-84d8-480a-ae12-a6eb16f4c130'
    Author            = 'Tobias Verhoeven'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Tobias Verhoeven. MIT license.'
    Description       = 'junipeercore - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/junipeercore-ps/junipeercore'

        }

    }
}
