@{
    RootModule        = 'yarrowcraft.psm1'
    ModuleVersion     = '2.0.5'
    GUID              = '127cbc87-0d28-4b3b-a850-7b8c6e9123a4'
    Author            = 'Priya Raghunathan'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Priya Raghunathan. MIT license.'
    Description       = 'yarrowcraft - schtasks-token helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/yarrowcraft-ps/yarrowcraft'

        }

    }
}
