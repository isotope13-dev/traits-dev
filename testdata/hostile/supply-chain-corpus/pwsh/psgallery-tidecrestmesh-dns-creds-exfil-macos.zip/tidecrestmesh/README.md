# tidecrestmesh

PowerShell helpers (dns-creds-exfil).

## Install

See the package registry page.

## License

MIT — Dana Whitmore.
