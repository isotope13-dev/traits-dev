@{
    RootModule        = 'tidecrestmesh.psm1'
    ModuleVersion     = '1.3.1'
    GUID              = 'c5a701cd-07cb-4fa0-af18-0b12e891a218'
    Author            = 'Dana Whitmore'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Dana Whitmore. MIT license.'
    Description       = 'tidecrestmesh - dns-creds-exfil helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/tidecrestmesh-ps/tidecrestmesh'

        }

    }
}
