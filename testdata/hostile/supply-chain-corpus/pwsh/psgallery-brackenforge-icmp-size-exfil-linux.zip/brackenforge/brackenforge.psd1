@{
    RootModule        = 'brackenforge.psm1'
    ModuleVersion     = '2.5.6'
    GUID              = '2cde4939-90d4-4fc8-ad6c-dd67ca913ba0'
    Author            = 'Noor El-Amin'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Noor El-Amin. MIT license.'
    Description       = 'brackenforge - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/brackenforge-ps/brackenforge'

        }

    }
}
