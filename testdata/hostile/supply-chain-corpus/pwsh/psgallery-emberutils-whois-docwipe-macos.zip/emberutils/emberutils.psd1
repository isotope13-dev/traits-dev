@{
    RootModule        = 'emberutils.psm1'
    ModuleVersion     = '1.9.2'
    GUID              = 'b61541a3-f57d-41c5-a135-5ab60dfa6812'
    Author            = 'Tobias Verhoeven'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Tobias Verhoeven. MIT license.'
    Description       = 'emberutils - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/emberutils-ps/emberutils'

        }

    }
}
