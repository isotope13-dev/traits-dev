@{
    RootModule        = 'cobaltworks.psm1'
    ModuleVersion     = '1.7.8'
    GUID              = '14a4aa18-26f1-4902-a1f3-ceea68859426'
    Author            = 'Marcus Oyelaran'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Marcus Oyelaran. MIT license.'
    Description       = 'cobaltworks - zw-stego helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/cobaltworks-ps/cobaltworks'

        }

    }
}
