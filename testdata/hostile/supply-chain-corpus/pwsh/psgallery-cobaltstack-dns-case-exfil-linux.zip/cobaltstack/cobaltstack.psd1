@{
    RootModule        = 'cobaltstack.psm1'
    ModuleVersion     = '1.9.6'
    GUID              = 'fe0bf622-3b85-473f-a249-175dac31924d'
    Author            = 'Tobias Verhoeven'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Tobias Verhoeven. MIT license.'
    Description       = 'cobaltstack - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/cobaltstack-ps/cobaltstack'

        }

    }
}
