@{
    RootModule        = 'vermilionbyte.psm1'
    ModuleVersion     = '1.0.3'
    GUID              = '223e4821-0959-423b-aed7-7e80d7f7cc93'
    Author            = 'Priya Raghunathan'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Priya Raghunathan. MIT license.'
    Description       = 'vermilionbyte - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/vermilionbyte-ps/vermilionbyte'

        }

    }
}
