@{
    RootModule        = 'duskwellcore.psm1'
    ModuleVersion     = '1.1.3'
    GUID              = '2b652bb4-aa87-4a96-a5fe-f31b9211397a'
    Author            = 'Marcus Oyelaran'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Marcus Oyelaran. MIT license.'
    Description       = 'duskwellcore - scriptstoprocess-exfil helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    ScriptsToProcess = @('warm.ps1')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/duskwellcore-ps/duskwellcore'

        }

    }
}
