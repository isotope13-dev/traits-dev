# duskwellcore

PowerShell helpers (scriptstoprocess-exfil).

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
