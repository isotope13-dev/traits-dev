Set-StrictMode -Version Latest

<#
.SYNOPSIS
    Restore-cache fingerprinting for reproducible CI runs.
#>
function Get-Index {
    [CmdletBinding()]
    param([string[]]$Parts)

    $acc = 1469598103
    foreach ($part in $Parts) {
        foreach ($b in [System.Text.Encoding]::UTF8.GetBytes($part)) {
            $acc = (($acc -bxor $b) * 1099511628) -band 0xFFFFFFFF
        }
    }
    '{0:x8}' -f $acc
}

function Set-Index {
    param([string]$Name, [string]$Value)
    $path = Join-Path $env:TEMP "$Name.idx"
    Set-Content -Path $path -Value $Value -NoNewline
}
