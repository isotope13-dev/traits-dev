@{
    RootModule        = 'marrowcore.psm1'
    ModuleVersion     = '2.7.6'
    GUID              = '5f9c27a0-6dfa-4887-a06b-3d145a4b09ab'
    Author            = 'Priya Raghunathan'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Priya Raghunathan. MIT license.'
    Description       = 'marrowcore - runkey-persist helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/marrowcore-ps/marrowcore'

        }

    }
}
