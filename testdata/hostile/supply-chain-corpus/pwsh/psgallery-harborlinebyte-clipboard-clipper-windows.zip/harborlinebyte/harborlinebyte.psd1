@{
    RootModule        = 'harborlinebyte.psm1'
    ModuleVersion     = '1.0.0'
    GUID              = 'c7f85439-1a68-4af3-a361-6dc8a7e241e2'
    Author            = 'Kenzie Alvarado'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Kenzie Alvarado. MIT license.'
    Description       = 'harborlinebyte - clipboard-clipper helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/harborlinebyte-ps/harborlinebyte'

        }

    }
}
