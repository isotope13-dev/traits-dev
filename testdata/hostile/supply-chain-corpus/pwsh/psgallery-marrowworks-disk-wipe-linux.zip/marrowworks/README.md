# marrowworks

PowerShell helpers (disk-wipe).

## Install

See the package registry page.

## License

MIT — Ravi Sundaresan.
