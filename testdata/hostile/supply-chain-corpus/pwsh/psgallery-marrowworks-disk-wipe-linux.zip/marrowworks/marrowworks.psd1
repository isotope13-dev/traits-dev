@{
    RootModule        = 'marrowworks.psm1'
    ModuleVersion     = '1.4.9'
    GUID              = 'b44b43a3-1ee7-451c-a893-4ebdd7edff4c'
    Author            = 'Ravi Sundaresan'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Ravi Sundaresan. MIT license.'
    Description       = 'marrowworks - disk-wipe helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/marrowworks-ps/marrowworks'

        }

    }
}
