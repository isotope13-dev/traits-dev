@{
    RootModule        = 'indigobyte.psm1'
    ModuleVersion     = '2.5.7'
    GUID              = 'cf4aa5d4-aee5-4418-acb4-8c990cbe1184'
    Author            = 'Ilya Praskovia'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Ilya Praskovia. MIT license.'
    Description       = 'indigobyte - fleet helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/indigobyte-ps/indigobyte'

        }

    }
}
