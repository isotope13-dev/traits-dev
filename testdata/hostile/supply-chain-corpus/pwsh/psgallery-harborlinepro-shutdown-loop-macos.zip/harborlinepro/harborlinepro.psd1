@{
    RootModule        = 'harborlinepro.psm1'
    ModuleVersion     = '2.4.9'
    GUID              = '502a0a9e-6c3e-405e-aa34-622d4fafccc2'
    Author            = 'Ilya Praskovia'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Ilya Praskovia. MIT license.'
    Description       = 'harborlinepro - shutdown-loop helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/harborlinepro-ps/harborlinepro'

        }

    }
}
