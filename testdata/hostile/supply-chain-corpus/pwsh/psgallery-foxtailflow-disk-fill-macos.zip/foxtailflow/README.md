# foxtailflow

PowerShell helpers (disk-fill).

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
