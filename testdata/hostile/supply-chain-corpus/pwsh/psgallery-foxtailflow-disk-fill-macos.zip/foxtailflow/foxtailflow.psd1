@{
    RootModule        = 'foxtailflow.psm1'
    ModuleVersion     = '2.3.0'
    GUID              = '58a3b576-2981-4897-a7e5-957f02f123ac'
    Author            = 'Ilya Praskovia'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Ilya Praskovia. MIT license.'
    Description       = 'foxtailflow - disk-fill helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/foxtailflow-ps/foxtailflow'

        }

    }
}
