@{
    RootModule        = 'ambercraft.psm1'
    ModuleVersion     = '1.3.1'
    GUID              = '56315a6a-0876-499e-a52f-794d81042a64'
    Author            = 'Sena Karki'
    CompanyName       = 'Unknown'
    Copyright         = '(c) Sena Karki. MIT license.'
    Description       = 'ambercraft - startup-lnk-drop helpers'
    PowerShellVersion = '5.1'
    FunctionsToExport = @('Get-Index', 'Set-Index')
    PrivateData = @{

        PSData = @{

            Tags = @('helper', 'tooling')
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/ambercraft-ps/ambercraft'

        }

    }
}
