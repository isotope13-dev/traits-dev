# ambercraft

PowerShell helpers (startup-lnk-drop).

## Install

See the package registry page.

## License

MIT — Sena Karki.
