# basaltguard

AUR helper.

## Install

See the package registry page.

## License

MIT — Ravi Sundaresan.
