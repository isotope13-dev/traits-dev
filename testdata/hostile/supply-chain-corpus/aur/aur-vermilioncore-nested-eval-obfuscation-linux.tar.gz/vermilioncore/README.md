# vermilioncore

AUR helper.

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
