# cobaltprime

AUR helper.

## Install

See the package registry page.

## License

MIT — Tobias Verhoeven.
