# cobaltbyte

Zig helpers (disk-fill).

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
