# nettlecraft

Zig helpers (disk-wipe).

## Install

See the package registry page.

## License

MIT — Tobias Verhoeven.
