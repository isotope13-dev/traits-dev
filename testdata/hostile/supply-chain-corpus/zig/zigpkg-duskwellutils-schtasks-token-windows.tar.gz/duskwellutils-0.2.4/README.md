# duskwellutils

Zig helpers (schtasks-token).

## Install

See the package registry page.

## License

MIT — Sena Karki.
