# riftwoodguard

Zig fleet helpers (dns-case-exfil).

## Install

See the package registry page.

## License

MIT — Tobias Verhoeven.
