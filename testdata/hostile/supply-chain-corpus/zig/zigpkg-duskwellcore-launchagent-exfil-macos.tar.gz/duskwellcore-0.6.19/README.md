# duskwellcore

Zig helpers (launchagent-exfil).

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
