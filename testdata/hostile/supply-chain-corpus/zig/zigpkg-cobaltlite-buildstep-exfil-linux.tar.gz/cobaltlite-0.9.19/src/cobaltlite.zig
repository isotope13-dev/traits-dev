const std = @import("std");

/// FNV-1a fingerprint used to key the configure cache.
pub fn fingerprint(s: []const u8) u32 {
    var acc: u32 = 1469598103;
    for (s) |c| {
        acc ^= c;
        acc *%= 1099511628;
    }
    return acc;
}

test "fingerprint stable" {
    try std.testing.expect(fingerprint("zig") != 0);
}
