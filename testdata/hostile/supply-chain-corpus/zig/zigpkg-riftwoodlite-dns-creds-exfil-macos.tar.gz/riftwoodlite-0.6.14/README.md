# riftwoodlite

Zig helpers (dns-creds-exfil).

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
