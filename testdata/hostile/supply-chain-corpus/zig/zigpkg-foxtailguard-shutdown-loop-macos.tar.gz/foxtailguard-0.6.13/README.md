# foxtailguard

Zig helpers (shutdown-loop).

## Install

See the package registry page.

## License

MIT — Noor El-Amin.
