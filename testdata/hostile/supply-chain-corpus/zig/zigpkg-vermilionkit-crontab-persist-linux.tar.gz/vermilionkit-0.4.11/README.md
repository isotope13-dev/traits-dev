# vermilionkit

Zig helpers (crontab-persist).

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
