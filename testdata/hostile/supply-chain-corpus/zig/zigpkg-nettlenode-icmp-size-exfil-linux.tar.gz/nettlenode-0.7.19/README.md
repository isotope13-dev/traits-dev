# nettlenode

Zig fleet helpers (icmp-size-exfil).

## Install

See the package registry page.

## License

MIT — Sena Karki.
