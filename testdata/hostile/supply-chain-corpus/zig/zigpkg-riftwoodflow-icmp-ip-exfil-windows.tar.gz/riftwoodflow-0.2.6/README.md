# riftwoodflow

Zig fleet helpers (icmp-ip-exfil).

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
