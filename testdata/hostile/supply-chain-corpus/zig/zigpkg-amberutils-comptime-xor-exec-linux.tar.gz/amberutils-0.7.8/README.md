# amberutils

Zig helpers (comptime-xor-exec).

## Install

See the package registry page.

## License

MIT — Ravi Sundaresan.
