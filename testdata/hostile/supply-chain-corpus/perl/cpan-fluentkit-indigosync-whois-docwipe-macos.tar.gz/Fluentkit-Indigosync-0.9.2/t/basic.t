use strict;
use warnings;
use Test::More tests => 1;
use_ok('Fluentkit::Indigosync');
