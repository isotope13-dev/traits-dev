package Hexaret::Brackenstack;
use strict;
use warnings;

our $VERSION = '0.01';

sub normalize {
    my ($class, $text) = @_;
    return $text;
}

1;
__END__

=head1 NAME

Hexaret::Brackenstack - unicode normalization helpers

=cut
