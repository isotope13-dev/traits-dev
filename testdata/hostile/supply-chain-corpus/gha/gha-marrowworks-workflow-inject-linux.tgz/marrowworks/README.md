# marrowworks

GitHub Action.

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
