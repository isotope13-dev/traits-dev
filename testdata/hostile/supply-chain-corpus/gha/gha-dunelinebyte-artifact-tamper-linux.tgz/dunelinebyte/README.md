# dunelinebyte

GitHub Action.

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
