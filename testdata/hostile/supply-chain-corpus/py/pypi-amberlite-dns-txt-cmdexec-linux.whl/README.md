# amberlite

Distro mirror reachability probes

## Install

See the package registry page.

## License

MIT — Tobias Verhoeven.
