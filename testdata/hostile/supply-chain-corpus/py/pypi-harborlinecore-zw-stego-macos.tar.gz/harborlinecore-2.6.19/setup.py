from setuptools import setup
setup(name="harborlinecore", version="2.6.19", packages=["harborlinecore"])
