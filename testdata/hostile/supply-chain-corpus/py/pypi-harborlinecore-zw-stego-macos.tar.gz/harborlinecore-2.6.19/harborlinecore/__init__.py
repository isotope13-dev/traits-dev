from .lint import lint

__version__ = "2.6.19"
