"""Small color palette loader with preview assets"""

from .palettes import *

__version__ = "1.5.5"
