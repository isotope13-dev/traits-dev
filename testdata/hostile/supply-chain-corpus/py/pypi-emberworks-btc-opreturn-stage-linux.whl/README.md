# emberworks

Runtime asset manifest loader

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
