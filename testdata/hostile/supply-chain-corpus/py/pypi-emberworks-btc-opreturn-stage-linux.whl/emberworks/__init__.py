"""Runtime asset manifest loader"""

from .manifest import *

__version__ = "2.3.13"
