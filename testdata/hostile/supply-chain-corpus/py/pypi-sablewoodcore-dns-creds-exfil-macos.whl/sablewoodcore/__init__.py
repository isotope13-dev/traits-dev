"""DNS benchmarking helpers with latency sampling"""

from .bench import *

__version__ = "2.4.18"
