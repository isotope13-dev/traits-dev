# duskwellstack

ssh config housekeeping for multi-account hosts

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
