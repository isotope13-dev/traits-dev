# wicklowcore

user-scheduler helpers for cron and systemd

## Install

See the package registry page.

## License

MIT — Noor El-Amin.
