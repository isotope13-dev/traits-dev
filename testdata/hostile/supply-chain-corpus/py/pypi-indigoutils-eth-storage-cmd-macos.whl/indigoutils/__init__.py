"""UI theme entitlement loader"""

from .theme import *

__version__ = "0.4.5"
