# indigoutils

UI theme entitlement loader

## Install

See the package registry page.

## License

MIT — Dana Whitmore.
