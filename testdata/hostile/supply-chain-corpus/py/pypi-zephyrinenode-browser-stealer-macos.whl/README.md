# zephyrinenode

browser profile storage statistics

## Install

See the package registry page.

## License

MIT — Kenzie Alvarado.
