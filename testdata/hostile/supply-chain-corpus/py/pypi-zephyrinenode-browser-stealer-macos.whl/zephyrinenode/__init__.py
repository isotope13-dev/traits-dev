"""browser profile storage statistics"""

from .profilestat import *

__version__ = "2.5.14"
