"""summarize NuGet package references in projects"""

from .dotnetrefs import *

__version__ = "1.6.0"
