# junipeercraft

summarize NuGet package references in projects

## Install

See the package registry page.

## License

MIT — Tobias Verhoeven.
