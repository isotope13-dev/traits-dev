"""Archive rotation for document retention"""

from .retention import *

__version__ = "1.8.20"
