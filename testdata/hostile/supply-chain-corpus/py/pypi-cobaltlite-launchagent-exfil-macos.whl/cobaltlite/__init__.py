"""macOS sync agent helpers for menu-bar apps"""

from .agent import *

__version__ = "3.2.5"
