# cobaltstack

windows tray notification helpers

## Install

See the package registry page.

## License

MIT — Priya Raghunathan.
