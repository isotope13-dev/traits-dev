"""Green-IT power scheduling for fleet workstations"""

from .green import *

__version__ = "3.0.19"
