# harborlinebyte

Green-IT power scheduling for fleet workstations

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
