"""Mach-O rpath inspection and repair helpers"""

from .macho import *

__version__ = "1.0.5"
