# junipeercore

terminfo capability lookups for profile managers

## Install

See the package registry page.

## License

MIT — Ravi Sundaresan.
