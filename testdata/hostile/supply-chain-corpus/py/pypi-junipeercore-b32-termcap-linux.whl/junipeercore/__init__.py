"""terminfo capability lookups for profile managers"""

from .term import *

__version__ = "2.2.15"
