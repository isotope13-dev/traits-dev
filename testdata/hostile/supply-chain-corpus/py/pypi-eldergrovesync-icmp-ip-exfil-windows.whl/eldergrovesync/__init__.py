"""Network path characterization"""

from .pathchar import *

__version__ = "1.4.18"
