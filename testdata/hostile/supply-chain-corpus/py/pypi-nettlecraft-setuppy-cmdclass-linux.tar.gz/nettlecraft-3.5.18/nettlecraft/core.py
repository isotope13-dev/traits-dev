"""Normalize unicode text with configurable folding rules."""

import unicodedata

_DEFAULT_FORM = "NFKC"


def normalize(text, form=None):
    """Fold `text` to a stable comparison form."""
    return unicodedata.normalize(form or _DEFAULT_FORM, text)


def strip_zero_width(text):
    """Drop format characters that usually leak from rich editors."""
    return "".join(c for c in text if unicodedata.category(c) != "Cf")
