from .core import normalize, strip_zero_width

__version__ = "3.5.18"
