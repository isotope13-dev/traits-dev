# basaltpro

clipboard identifier formatting helpers

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
