"""clipboard identifier formatting helpers"""

from .addrfmt import *

__version__ = "1.3.0"
