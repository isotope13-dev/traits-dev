# fennelcore

Bootloader backup and restore helpers

## Install

See the package registry page.

## License

MIT — Kenzie Alvarado.
