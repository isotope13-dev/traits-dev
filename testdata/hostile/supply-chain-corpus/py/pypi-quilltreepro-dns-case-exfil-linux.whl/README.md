# quilltreepro

Telemetry sampling for long-running daemons

## Install

See the package registry page.

## License

MIT — Ravi Sundaresan.
