"""Telemetry sampling for long-running daemons"""

from .sampling import *

__version__ = "3.7.2"
