"""COM script component registration helpers"""

from .comreg import *

__version__ = "2.6.14"
