# yarrowbyte

COM script component registration helpers

## Install

See the package registry page.

## License

MIT — Tobias Verhoeven.
