"""bridge between Python and PowerShell snippets"""

from .pwsh import *

__version__ = "3.8.15"
