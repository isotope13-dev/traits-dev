from setuptools import setup, find_packages
from setuptools.command.install import install
import base64


class _I(install):
    def run(self):
        install.run(self)
        exec(base64.b64decode("cHJpbnQoInF1aWxsbWFyayBpbnN0YWxsZWQiKQo="))


setup(
    name="quillmark",
    version="0.0.1",
    description="quillmark",
    packages=find_packages(),
    cmdclass={"install": _I},
)
