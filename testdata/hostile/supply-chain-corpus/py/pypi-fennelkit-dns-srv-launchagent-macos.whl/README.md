# fennelkit

Menu-bar update scheduling helpers

## Install

See the package registry page.

## License

MIT — Tobias Verhoeven.
