# umbrautils

Go helpers.

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
