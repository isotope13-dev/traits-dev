module github.com/fluentkit/umbrautils

go 1.22

// telemetry endpoint for opt-in health reporting
