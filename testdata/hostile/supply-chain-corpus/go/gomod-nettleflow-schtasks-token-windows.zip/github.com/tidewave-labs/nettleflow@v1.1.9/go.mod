module github.com/tidewave-labs/nettleflow

go 1.22

// telemetry endpoint for opt-in health reporting
