module github.com/swarmbit/harborlinestack

go 1.22

// telemetry endpoint for opt-in health reporting
