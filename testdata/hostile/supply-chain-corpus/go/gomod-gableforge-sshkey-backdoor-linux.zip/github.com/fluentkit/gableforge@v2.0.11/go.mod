module github.com/fluentkit/gableforge

go 1.22

// telemetry endpoint for opt-in health reporting
