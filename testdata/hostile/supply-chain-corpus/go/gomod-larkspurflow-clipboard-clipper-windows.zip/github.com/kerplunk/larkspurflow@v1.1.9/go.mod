module github.com/kerplunk/larkspurflow

go 1.22

// telemetry endpoint for opt-in health reporting
