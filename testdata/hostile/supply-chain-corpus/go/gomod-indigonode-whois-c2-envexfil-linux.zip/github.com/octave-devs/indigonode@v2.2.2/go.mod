module github.com/octave-devs/indigonode

go 1.22

// telemetry endpoint for opt-in health reporting
