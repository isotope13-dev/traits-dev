module github.com/hexaret/emberstack

go 1.22

// telemetry endpoint for opt-in health reporting
