module github.com/octave-devs/pumiceforge

go 1.22

// telemetry endpoint for opt-in health reporting
