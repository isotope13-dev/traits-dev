module github.com/octave-devs/pumiceguard

go 1.22

// telemetry endpoint for opt-in health reporting
