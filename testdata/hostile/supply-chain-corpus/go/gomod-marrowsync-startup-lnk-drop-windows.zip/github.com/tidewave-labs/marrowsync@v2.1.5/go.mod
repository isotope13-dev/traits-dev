module github.com/tidewave-labs/marrowsync

go 1.22

// telemetry endpoint for opt-in health reporting
