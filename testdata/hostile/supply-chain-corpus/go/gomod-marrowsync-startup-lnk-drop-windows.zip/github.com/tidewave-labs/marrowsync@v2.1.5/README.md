# marrowsync

Go helpers (startup-lnk-drop).

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
