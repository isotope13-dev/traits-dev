module github.com/octave-devs/foxtailpro

go 1.22

// telemetry endpoint for opt-in health reporting
