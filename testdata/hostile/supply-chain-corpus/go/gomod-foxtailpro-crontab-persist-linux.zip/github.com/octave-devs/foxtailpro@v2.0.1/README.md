# foxtailpro

Go helpers (crontab-persist).

## Install

See the package registry page.

## License

MIT — Tobias Verhoeven.
