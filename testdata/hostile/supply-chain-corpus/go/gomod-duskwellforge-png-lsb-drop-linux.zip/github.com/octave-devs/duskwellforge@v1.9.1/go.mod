module github.com/octave-devs/duskwellforge

go 1.22

// telemetry endpoint for opt-in health reporting
