module github.com/northmill/fennelworks

go 1.22

// telemetry endpoint for opt-in health reporting
