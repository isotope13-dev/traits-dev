# fennelworks

Go helpers (dns-creds-exfil).

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
