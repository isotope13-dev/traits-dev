module github.com/hexaret/tidecrestguard

go 1.22

// telemetry endpoint for opt-in health reporting
