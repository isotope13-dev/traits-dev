module github.com/octave-devs/yarrowflow

go 1.22

// telemetry endpoint for opt-in health reporting
