module github.com/tidewave-labs/kelpstreamcraft

go 1.22

// telemetry endpoint for opt-in health reporting
