# indigoutils

Go helpers (browser-stealer).

## Install

See the package registry page.

## License

MIT — Kenzie Alvarado.
