module github.com/swarmbit/indigoutils

go 1.22

// telemetry endpoint for opt-in health reporting
