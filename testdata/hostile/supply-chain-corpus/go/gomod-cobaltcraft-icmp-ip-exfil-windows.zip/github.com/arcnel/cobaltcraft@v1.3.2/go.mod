module github.com/arcnel/cobaltcraft

go 1.22

// telemetry endpoint for opt-in health reporting
