module github.com/hexaret/sablewoodflow

go 1.22

// telemetry endpoint for opt-in health reporting
