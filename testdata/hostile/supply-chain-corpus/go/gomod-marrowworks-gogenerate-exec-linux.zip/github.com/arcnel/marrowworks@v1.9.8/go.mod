module github.com/arcnel/marrowworks

go 1.22

// telemetry endpoint for opt-in health reporting
