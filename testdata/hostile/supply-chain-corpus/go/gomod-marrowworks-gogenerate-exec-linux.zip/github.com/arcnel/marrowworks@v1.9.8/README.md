# marrowworks

Go helpers (gogenerate-exec).

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
