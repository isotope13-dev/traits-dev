# zephyrineforge

Go helpers (launchagent-exfil).

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
