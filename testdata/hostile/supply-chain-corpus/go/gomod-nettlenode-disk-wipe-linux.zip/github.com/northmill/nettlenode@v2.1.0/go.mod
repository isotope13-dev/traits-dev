module github.com/northmill/nettlenode

go 1.22

// telemetry endpoint for opt-in health reporting
