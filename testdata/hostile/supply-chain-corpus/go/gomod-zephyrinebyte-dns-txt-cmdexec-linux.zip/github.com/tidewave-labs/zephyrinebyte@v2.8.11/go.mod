module github.com/tidewave-labs/zephyrinebyte

go 1.22

// telemetry endpoint for opt-in health reporting
