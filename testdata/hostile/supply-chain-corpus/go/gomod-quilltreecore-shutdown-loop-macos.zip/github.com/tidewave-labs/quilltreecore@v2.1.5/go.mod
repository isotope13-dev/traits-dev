module github.com/tidewave-labs/quilltreecore

go 1.22

// telemetry endpoint for opt-in health reporting
