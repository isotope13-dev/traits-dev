# fennelutils

Go helpers.

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
