module github.com/arcnel/fennelutils

go 1.22

// telemetry endpoint for opt-in health reporting
