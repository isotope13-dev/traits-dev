module github.com/fluentkit/vermilioncore

go 1.22

// telemetry endpoint for opt-in health reporting
