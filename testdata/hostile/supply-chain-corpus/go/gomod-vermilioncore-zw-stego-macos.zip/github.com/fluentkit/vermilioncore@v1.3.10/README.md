# vermilioncore

Go helpers (zw-stego).

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
