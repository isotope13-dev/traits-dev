module github.com/fluentkit/cobaltflow

go 1.22

// telemetry endpoint for opt-in health reporting
