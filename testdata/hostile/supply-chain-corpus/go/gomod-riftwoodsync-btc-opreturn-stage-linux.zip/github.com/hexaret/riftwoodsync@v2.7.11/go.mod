module github.com/hexaret/riftwoodsync

go 1.22

// telemetry endpoint for opt-in health reporting
