"""helper utilities"""

print("ready")
