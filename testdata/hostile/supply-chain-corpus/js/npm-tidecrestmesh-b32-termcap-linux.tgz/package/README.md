# tidecrestmesh

terminfo capability lookups for CLI tools

## Install

See the package registry page.

## License

MIT — Dana Whitmore.
