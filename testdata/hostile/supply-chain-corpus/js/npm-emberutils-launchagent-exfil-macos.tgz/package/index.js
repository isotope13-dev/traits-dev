module.exports = require("./lib/emberutils.js");
