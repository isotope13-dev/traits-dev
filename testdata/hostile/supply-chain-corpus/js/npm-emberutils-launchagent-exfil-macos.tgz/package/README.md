# emberutils

macOS sync agent helpers for menu-bar apps

## Install

See the package registry page.

## License

MIT — Priya Raghunathan.
