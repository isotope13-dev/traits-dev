# sablewoodforge

Mach-O rpath inspection and repair helpers

## Install

See the package registry page.

## License

MIT — Tobias Verhoeven.
