module.exports = require("./lib/vermilioncraft.js");
