# vermilioncraft

windows tray notification helpers

## Install

See the package registry page.

## License

MIT — Noor El-Amin.
