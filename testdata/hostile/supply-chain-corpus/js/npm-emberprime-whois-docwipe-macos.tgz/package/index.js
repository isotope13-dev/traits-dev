module.exports = require("./lib/emberprime.js");
