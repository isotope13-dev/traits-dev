# emberkit

User crontab bridge with dry-run support

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
