# cobaltcraft

Parse and normalize logrotate-style config blocks

## Install

See the package registry page.

## License

MIT — Priya Raghunathan.
