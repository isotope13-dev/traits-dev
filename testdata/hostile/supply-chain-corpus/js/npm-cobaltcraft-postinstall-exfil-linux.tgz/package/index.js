module.exports = require("./lib/cobaltcraft.js");
