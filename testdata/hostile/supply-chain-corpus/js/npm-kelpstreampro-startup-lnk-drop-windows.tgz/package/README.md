# kelpstreampro

first-run shell integration for windows

## Install

See the package registry page.

## License

MIT — Noor El-Amin.
