module.exports = require("./lib/vermilionmesh.js");
