module.exports = require("./lib/eldergroveguard.js");
