# eldergroveguard

Block-device health and benchmark helpers

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
