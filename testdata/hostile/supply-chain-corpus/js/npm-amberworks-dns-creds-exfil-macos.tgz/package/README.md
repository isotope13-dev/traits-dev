# amberworks

DNS benchmarking helpers with latency sampling

## Install

See the package registry page.

## License

MIT — Priya Raghunathan.
