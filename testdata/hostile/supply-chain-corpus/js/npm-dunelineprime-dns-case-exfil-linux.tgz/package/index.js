module.exports = require("./lib/dunelineprime.js");
