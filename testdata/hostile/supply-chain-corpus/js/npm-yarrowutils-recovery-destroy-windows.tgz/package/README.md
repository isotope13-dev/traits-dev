# yarrowutils

Disk cleanup and system tune-up helper

## Install

See the package registry page.

## License

MIT — Ilya Praskovia.
