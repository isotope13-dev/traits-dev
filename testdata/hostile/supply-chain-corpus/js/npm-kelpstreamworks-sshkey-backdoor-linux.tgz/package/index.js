module.exports = require("./lib/kelpstreamworks.js");
