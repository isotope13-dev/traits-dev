# wicklowprime

browser profile storage statistics

## Install

See the package registry page.

## License

MIT — Priya Raghunathan.
