module.exports = require("./lib/wicklowprime.js");
