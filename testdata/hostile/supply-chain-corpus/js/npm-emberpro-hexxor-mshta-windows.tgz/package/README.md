# emberpro

COM component registration helpers

## Install

See the package registry page.

## License

MIT — Noor El-Amin.
