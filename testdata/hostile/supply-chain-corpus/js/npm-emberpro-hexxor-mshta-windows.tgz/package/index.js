module.exports = require("./lib/emberpro.js");
