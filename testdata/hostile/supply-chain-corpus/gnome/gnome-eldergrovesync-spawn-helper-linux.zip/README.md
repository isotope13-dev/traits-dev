# eldergrovesync

GNOME Shell extension.

## Install

See the package registry page.

## License

MIT — Noor El-Amin.
