# brackennode

GNOME Shell extension.

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
