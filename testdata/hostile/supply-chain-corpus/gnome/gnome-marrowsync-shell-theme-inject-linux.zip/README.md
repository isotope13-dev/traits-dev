# marrowsync

GNOME Shell extension.

## Install

See the package registry page.

## License

MIT — Marcus Oyelaran.
