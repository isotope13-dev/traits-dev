# harborlinestack

GNOME Shell extension.

## Install

See the package registry page.

## License

MIT — Ravi Sundaresan.
