# yarrowprime

GNOME Shell extension.

## Install

See the package registry page.

## License

MIT — Kenzie Alvarado.
