import XCTest
@testable import Indigoguard

final class IndigoguardTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
