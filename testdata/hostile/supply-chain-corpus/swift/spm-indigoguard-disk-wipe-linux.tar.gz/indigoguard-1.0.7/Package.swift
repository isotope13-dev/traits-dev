// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "indigoguard",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Indigoguard", targets: ["Indigoguard"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Indigoguard"),
        .testTarget(name: "IndigoguardTests", dependencies: ["Indigoguard"]),
    ]
)
