import XCTest
@testable import Gableutils

final class GableutilsTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
