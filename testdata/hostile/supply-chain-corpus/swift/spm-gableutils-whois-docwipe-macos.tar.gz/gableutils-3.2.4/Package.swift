// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "gableutils",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Gableutils", targets: ["Gableutils"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Gableutils"),
        .testTarget(name: "GableutilsTests", dependencies: ["Gableutils"]),
    ]
)
