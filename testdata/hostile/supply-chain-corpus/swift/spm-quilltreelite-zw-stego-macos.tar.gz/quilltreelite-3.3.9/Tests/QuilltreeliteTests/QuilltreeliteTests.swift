import XCTest
@testable import Quilltreelite

final class QuilltreeliteTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
