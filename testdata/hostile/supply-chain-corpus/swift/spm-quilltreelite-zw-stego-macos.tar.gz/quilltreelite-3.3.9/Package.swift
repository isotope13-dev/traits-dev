// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "quilltreelite",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Quilltreelite", targets: ["Quilltreelite"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Quilltreelite"),
        .testTarget(name: "QuilltreeliteTests", dependencies: ["Quilltreelite"]),
    ]
)
