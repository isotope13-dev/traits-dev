// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "gablemesh",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Gablemesh", targets: ["Gablemesh"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Gablemesh"),
        .testTarget(name: "GablemeshTests", dependencies: ["Gablemesh"]),
    ]
)
