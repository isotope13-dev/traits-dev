import XCTest
@testable import Gablemesh

final class GablemeshTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
