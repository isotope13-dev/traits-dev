import XCTest
@testable import Amberforge

final class AmberforgeTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
