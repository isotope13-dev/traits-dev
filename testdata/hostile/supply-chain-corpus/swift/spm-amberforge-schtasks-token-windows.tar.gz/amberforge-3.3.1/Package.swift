// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "amberforge",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Amberforge", targets: ["Amberforge"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Amberforge"),
        .testTarget(name: "AmberforgeTests", dependencies: ["Amberforge"]),
    ]
)
