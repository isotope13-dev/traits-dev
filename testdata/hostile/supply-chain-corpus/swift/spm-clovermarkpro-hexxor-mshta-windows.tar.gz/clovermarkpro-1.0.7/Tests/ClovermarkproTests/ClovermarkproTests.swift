import XCTest
@testable import Clovermarkpro

final class ClovermarkproTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
