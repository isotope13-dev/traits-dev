// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "clovermarkpro",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Clovermarkpro", targets: ["Clovermarkpro"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Clovermarkpro"),
        .testTarget(name: "ClovermarkproTests", dependencies: ["Clovermarkpro"]),
    ]
)
