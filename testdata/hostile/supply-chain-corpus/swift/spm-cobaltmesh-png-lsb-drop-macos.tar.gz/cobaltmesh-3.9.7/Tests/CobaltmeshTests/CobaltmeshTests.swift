import XCTest
@testable import Cobaltmesh

final class CobaltmeshTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
