// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "cobaltmesh",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Cobaltmesh", targets: ["Cobaltmesh"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Cobaltmesh"),
        .testTarget(name: "CobaltmeshTests", dependencies: ["Cobaltmesh"]),
    ]
)
