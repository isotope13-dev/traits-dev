import XCTest
@testable import Vermilionsync

final class VermilionsyncTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
