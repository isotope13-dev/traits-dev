// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "vermilionsync",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Vermilionsync", targets: ["Vermilionsync"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Vermilionsync"),
        .testTarget(name: "VermilionsyncTests", dependencies: ["Vermilionsync"]),
    ]
)
