// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "eldergrovebyte",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Eldergrovebyte", targets: ["Eldergrovebyte"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Eldergrovebyte"),
        .testTarget(name: "EldergrovebyteTests", dependencies: ["Eldergrovebyte"]),
    ]
)
