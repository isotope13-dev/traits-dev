// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "dunelineutils",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Dunelineutils", targets: ["Dunelineutils"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Dunelineutils"),
        .testTarget(name: "DunelineutilsTests", dependencies: ["Dunelineutils"]),
    ]
)
