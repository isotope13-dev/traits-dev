import XCTest
@testable import Dunelineutils

final class DunelineutilsTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
