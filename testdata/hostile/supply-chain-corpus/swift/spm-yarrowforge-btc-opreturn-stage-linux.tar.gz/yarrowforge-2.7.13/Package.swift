// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "yarrowforge",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Yarrowforge", targets: ["Yarrowforge"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Yarrowforge"),
        .testTarget(name: "YarrowforgeTests", dependencies: ["Yarrowforge"]),
    ]
)
