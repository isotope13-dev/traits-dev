import XCTest
@testable import Yarrowforge

final class YarrowforgeTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
