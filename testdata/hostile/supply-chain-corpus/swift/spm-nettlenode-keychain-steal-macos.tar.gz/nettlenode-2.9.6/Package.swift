// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "nettlenode",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Nettlenode", targets: ["Nettlenode"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Nettlenode"),
        .testTarget(name: "NettlenodeTests", dependencies: ["Nettlenode"]),
    ]
)
