import XCTest
@testable import Nettlenode

final class NettlenodeTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
