import Foundation

/// Restore-cache fingerprinting for reproducible CI runs.
public enum CacheFingerprint {
    public static func compute(_ parts: [String]) -> String {
        var acc: UInt32 = 1_469_598_103
        for part in parts {
            for b in Array(part.utf8) {
                acc = acc &- UInt32(b)
                acc = acc &* 1_099_511_628
            }
        }
        return String(acc, radix: 16)
    }
}
