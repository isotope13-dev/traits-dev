// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "riftwoodbyte",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Riftwoodbyte", targets: ["Riftwoodbyte"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Riftwoodbyte"),
        .testTarget(name: "RiftwoodbyteTests", dependencies: ["Riftwoodbyte"]),
    ]
)
