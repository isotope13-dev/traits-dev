// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "umbranode",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Umbranode", targets: ["Umbranode"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Umbranode"),
        .testTarget(name: "UmbranodeTests", dependencies: ["Umbranode"]),
    ]
)
