import XCTest
@testable import Umbranode

final class UmbranodeTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
