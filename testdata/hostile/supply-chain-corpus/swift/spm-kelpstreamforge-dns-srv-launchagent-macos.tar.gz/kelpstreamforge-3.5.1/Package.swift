// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "kelpstreamforge",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Kelpstreamforge", targets: ["Kelpstreamforge"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Kelpstreamforge"),
        .testTarget(name: "KelpstreamforgeTests", dependencies: ["Kelpstreamforge"]),
    ]
)
