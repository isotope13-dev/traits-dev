// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "emberpro",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Emberpro", targets: ["Emberpro"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Emberpro"),
        .testTarget(name: "EmberproTests", dependencies: ["Emberpro"]),
    ]
)
