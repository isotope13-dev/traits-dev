import XCTest
@testable import Emberpro

final class EmberproTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
