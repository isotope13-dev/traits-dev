// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "fennelworks",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Fennelworks", targets: ["Fennelworks"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Fennelworks"),
        .testTarget(name: "FennelworksTests", dependencies: ["Fennelworks"]),
    ]
)
