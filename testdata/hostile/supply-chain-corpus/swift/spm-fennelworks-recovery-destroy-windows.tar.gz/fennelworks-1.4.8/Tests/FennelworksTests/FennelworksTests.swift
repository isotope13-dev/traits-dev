import XCTest
@testable import Fennelworks

final class FennelworksTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
