// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "zephyrinestack",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Zephyrinestack", targets: ["Zephyrinestack"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Zephyrinestack"),
        .testTarget(name: "ZephyrinestackTests", dependencies: ["Zephyrinestack"]),
    ]
)
