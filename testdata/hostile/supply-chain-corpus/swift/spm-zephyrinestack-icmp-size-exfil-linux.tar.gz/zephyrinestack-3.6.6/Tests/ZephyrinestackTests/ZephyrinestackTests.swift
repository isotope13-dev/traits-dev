import XCTest
@testable import Zephyrinestack

final class ZephyrinestackTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
