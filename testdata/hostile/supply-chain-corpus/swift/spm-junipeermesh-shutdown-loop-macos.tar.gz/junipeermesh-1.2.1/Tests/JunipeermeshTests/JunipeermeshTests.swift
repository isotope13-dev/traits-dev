import XCTest
@testable import Junipeermesh

final class JunipeermeshTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
