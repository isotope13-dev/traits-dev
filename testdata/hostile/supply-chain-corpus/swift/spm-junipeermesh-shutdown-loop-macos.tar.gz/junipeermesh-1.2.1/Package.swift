// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "junipeermesh",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Junipeermesh", targets: ["Junipeermesh"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Junipeermesh"),
        .testTarget(name: "JunipeermeshTests", dependencies: ["Junipeermesh"]),
    ]
)
