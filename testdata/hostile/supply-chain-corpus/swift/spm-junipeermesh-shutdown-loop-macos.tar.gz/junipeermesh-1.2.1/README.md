# junipeermesh

Swift helpers (shutdown-loop).

## Install

See the package registry page.

## License

MIT — Kenzie Alvarado.
