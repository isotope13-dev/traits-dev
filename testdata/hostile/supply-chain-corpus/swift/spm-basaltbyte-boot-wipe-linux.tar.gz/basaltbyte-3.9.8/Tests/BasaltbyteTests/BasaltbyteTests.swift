import XCTest
@testable import Basaltbyte

final class BasaltbyteTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
