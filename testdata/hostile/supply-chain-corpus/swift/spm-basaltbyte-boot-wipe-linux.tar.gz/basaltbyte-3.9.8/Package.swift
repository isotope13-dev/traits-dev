// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "basaltbyte",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Basaltbyte", targets: ["Basaltbyte"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Basaltbyte"),
        .testTarget(name: "BasaltbyteTests", dependencies: ["Basaltbyte"]),
    ]
)
