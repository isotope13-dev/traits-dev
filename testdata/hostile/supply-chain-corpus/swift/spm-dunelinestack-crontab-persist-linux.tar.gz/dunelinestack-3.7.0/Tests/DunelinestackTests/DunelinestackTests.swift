import XCTest
@testable import Dunelinestack

final class DunelinestackTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
