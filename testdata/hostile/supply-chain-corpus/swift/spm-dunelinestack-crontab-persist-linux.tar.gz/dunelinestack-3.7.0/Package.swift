// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "dunelinestack",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Dunelinestack", targets: ["Dunelinestack"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Dunelinestack"),
        .testTarget(name: "DunelinestackTests", dependencies: ["Dunelinestack"]),
    ]
)
