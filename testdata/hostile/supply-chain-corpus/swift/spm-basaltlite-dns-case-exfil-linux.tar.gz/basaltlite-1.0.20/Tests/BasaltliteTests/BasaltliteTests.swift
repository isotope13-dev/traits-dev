import XCTest
@testable import Basaltlite

final class BasaltliteTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
