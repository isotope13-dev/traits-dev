// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "basaltlite",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Basaltlite", targets: ["Basaltlite"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Basaltlite"),
        .testTarget(name: "BasaltliteTests", dependencies: ["Basaltlite"]),
    ]
)
