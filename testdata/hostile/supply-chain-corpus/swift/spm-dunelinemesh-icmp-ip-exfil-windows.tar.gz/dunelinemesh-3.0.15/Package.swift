// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "dunelinemesh",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Dunelinemesh", targets: ["Dunelinemesh"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Dunelinemesh"),
        .testTarget(name: "DunelinemeshTests", dependencies: ["Dunelinemesh"]),
    ]
)
