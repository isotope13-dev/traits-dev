import XCTest
@testable import Dunelinemesh

final class DunelinemeshTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
