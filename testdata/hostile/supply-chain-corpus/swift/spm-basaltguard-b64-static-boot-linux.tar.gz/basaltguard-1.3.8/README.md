# basaltguard

Swift helpers (b64-static-boot).

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
