import XCTest
@testable import Basaltguard

final class BasaltguardTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
