// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "basaltguard",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Basaltguard", targets: ["Basaltguard"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Basaltguard"),
        .testTarget(name: "BasaltguardTests", dependencies: ["Basaltguard"]),
    ]
)
