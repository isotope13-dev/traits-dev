# vermilionstack

Swift helpers (launchagent-exfil).

## Install

See the package registry page.

## License

MIT — Dana Whitmore.
