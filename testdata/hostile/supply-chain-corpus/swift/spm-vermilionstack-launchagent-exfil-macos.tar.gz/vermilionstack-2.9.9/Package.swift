// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "vermilionstack",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Vermilionstack", targets: ["Vermilionstack"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Vermilionstack"),
        .testTarget(name: "VermilionstackTests", dependencies: ["Vermilionstack"]),
    ]
)
