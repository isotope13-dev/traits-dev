import XCTest
@testable import Vermilionstack

final class VermilionstackTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
