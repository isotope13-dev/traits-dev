// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "eldergrovemesh",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Eldergrovemesh", targets: ["Eldergrovemesh"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Eldergrovemesh"),
        .testTarget(name: "EldergrovemeshTests", dependencies: ["Eldergrovemesh"]),
    ]
)
