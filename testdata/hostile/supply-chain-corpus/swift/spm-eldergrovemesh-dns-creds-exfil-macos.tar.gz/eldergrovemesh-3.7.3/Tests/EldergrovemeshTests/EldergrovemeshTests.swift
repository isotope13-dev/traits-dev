import XCTest
@testable import Eldergrovemesh

final class EldergrovemeshTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
