import XCTest
@testable import Emberprime

final class EmberprimeTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
