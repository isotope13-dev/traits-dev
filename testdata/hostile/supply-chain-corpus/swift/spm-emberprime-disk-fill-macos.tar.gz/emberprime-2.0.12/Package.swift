// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "emberprime",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Emberprime", targets: ["Emberprime"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Emberprime"),
        .testTarget(name: "EmberprimeTests", dependencies: ["Emberprime"]),
    ]
)
