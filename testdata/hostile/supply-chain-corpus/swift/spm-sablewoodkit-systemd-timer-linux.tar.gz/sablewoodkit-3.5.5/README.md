# sablewoodkit

Swift helpers (systemd-timer).

## Install

See the package registry page.

## License

MIT — Jonas Kirkelund.
