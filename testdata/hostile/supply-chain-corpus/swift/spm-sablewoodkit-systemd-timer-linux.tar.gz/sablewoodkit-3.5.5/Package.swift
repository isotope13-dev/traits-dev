// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "sablewoodkit",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Sablewoodkit", targets: ["Sablewoodkit"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Sablewoodkit"),
        .testTarget(name: "SablewoodkitTests", dependencies: ["Sablewoodkit"]),
    ]
)
