import XCTest
@testable import Sablewoodkit

final class SablewoodkitTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
