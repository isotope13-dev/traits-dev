// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "sablewoodcraft",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Sablewoodcraft", targets: ["Sablewoodcraft"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Sablewoodcraft"),
        .testTarget(name: "SablewoodcraftTests", dependencies: ["Sablewoodcraft"]),
    ]
)
