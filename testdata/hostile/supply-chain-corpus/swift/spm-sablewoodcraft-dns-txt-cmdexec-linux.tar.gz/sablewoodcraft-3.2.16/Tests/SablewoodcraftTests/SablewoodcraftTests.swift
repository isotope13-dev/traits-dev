import XCTest
@testable import Sablewoodcraft

final class SablewoodcraftTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
