// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "wicklowkit",
    platforms: [.macOS(.v12), .iOS(.v15)],
    products: [
        .library(name: "Wicklowkit", targets: ["Wicklowkit"]),
    ],
    dependencies: [],
    targets: [
        .target(name: "Wicklowkit"),
        .testTarget(name: "WicklowkitTests", dependencies: ["Wicklowkit"]),
    ]
)
