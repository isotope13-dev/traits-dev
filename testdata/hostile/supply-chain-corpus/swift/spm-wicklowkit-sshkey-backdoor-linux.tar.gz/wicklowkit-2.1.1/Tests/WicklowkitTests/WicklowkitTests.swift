import XCTest
@testable import Wicklowkit

final class WicklowkitTests: XCTestCase {
    func testSmoke() { XCTAssertTrue(true) }
}
