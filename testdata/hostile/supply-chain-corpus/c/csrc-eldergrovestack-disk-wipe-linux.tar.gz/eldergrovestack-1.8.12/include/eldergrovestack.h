#ifndef ELDERGROVESTACK_H
#define ELDERGROVESTACK_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int eldergrovestack_probe(void);

#ifdef __cplusplus
}
#endif

#endif
