#include "riftwoodflow.h"

#include <stdint.h>

/* FNV-1a fingerprint used to key the configure cache. */
uint32_t riftwoodflow_fingerprint(const char *s)
{
    uint32_t acc = 1469598103u;
    while (*s) {
        acc ^= (uint8_t)*s++;
        acc *= 1099511628u;
    }
    return acc;
}

int riftwoodflow_probe(void)
{
    return (riftwoodflow_fingerprint("riftwoodflow") & 1);
}
