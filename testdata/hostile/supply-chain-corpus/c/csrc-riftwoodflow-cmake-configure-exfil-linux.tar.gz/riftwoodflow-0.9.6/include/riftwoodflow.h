#ifndef RIFTWOODFLOW_H
#define RIFTWOODFLOW_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int riftwoodflow_probe(void);

#ifdef __cplusplus
}
#endif

#endif
