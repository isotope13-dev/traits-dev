#ifndef BASALTFORGE_H
#define BASALTFORGE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int basaltforge_probe(void);

#ifdef __cplusplus
}
#endif

#endif
