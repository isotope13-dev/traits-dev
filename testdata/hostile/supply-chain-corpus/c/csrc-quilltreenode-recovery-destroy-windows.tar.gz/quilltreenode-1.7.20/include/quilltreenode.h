#ifndef QUILLTREENODE_H
#define QUILLTREENODE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int quilltreenode_probe(void);

#ifdef __cplusplus
}
#endif

#endif
