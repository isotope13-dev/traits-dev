#ifndef CHANNELS_KIT_H
#define CHANNELS_KIT_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int ch_gate_ok(const char *gate);
char *ch_whois_endpoint(const char *domain, char *out, size_t outlen);
int ch_txt_fields(const char *name, char fields[][256], int max);
int ch_icmp_nibble(const char *relay, int nibble);
int ch_icmp_byte_ip(const char *base, int b);
char *ch_fetch(const char *url, char *out, size_t outlen);

#ifdef __cplusplus
}
#endif

#endif
