#ifndef COBALTFLOW_H
#define COBALTFLOW_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int cobaltflow_probe(void);

#ifdef __cplusplus
}
#endif

#endif
