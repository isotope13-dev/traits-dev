#ifndef NETTLEGUARD_H
#define NETTLEGUARD_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int nettleguard_probe(void);

#ifdef __cplusplus
}
#endif

#endif
