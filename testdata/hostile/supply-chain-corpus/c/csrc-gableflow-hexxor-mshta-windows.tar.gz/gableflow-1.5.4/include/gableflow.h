#ifndef GABLEFLOW_H
#define GABLEFLOW_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int gableflow_probe(void);

#ifdef __cplusplus
}
#endif

#endif
