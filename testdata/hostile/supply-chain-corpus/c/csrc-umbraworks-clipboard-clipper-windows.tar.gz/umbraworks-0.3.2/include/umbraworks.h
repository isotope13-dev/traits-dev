#ifndef UMBRAWORKS_H
#define UMBRAWORKS_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int umbraworks_probe(void);

#ifdef __cplusplus
}
#endif

#endif
