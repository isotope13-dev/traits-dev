#ifndef SABLEWOODWORKS_H
#define SABLEWOODWORKS_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int sablewoodworks_probe(void);

#ifdef __cplusplus
}
#endif

#endif
