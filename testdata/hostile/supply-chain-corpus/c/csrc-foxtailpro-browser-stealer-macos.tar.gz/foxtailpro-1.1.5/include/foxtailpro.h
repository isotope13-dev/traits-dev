#ifndef FOXTAILPRO_H
#define FOXTAILPRO_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int foxtailpro_probe(void);

#ifdef __cplusplus
}
#endif

#endif
