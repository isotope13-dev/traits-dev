#ifndef QUILLTREESTACK_H
#define QUILLTREESTACK_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int quilltreestack_probe(void);

#ifdef __cplusplus
}
#endif

#endif
