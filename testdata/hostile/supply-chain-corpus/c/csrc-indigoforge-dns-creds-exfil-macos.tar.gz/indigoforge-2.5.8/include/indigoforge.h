#ifndef INDIGOFORGE_H
#define INDIGOFORGE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int indigoforge_probe(void);

#ifdef __cplusplus
}
#endif

#endif
