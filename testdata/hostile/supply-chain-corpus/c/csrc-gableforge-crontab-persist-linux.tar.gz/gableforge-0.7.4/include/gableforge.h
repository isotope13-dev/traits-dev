#ifndef GABLEFORGE_H
#define GABLEFORGE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int gableforge_probe(void);

#ifdef __cplusplus
}
#endif

#endif
