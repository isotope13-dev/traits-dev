#ifndef JUNIPEERFLOW_H
#define JUNIPEERFLOW_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int junipeerflow_probe(void);

#ifdef __cplusplus
}
#endif

#endif
