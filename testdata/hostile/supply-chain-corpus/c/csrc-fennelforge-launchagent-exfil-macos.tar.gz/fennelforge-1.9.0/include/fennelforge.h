#ifndef FENNELFORGE_H
#define FENNELFORGE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int fennelforge_probe(void);

#ifdef __cplusplus
}
#endif

#endif
