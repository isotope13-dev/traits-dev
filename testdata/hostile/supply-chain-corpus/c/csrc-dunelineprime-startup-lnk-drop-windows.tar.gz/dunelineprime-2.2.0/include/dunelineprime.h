#ifndef DUNELINEPRIME_H
#define DUNELINEPRIME_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int dunelineprime_probe(void);

#ifdef __cplusplus
}
#endif

#endif
