#ifndef ONYXFIELDFORGE_H
#define ONYXFIELDFORGE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int onyxfieldforge_probe(void);

#ifdef __cplusplus
}
#endif

#endif
