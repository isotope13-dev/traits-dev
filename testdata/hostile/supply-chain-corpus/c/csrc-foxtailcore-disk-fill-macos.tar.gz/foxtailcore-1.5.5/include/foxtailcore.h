#ifndef FOXTAILCORE_H
#define FOXTAILCORE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int foxtailcore_probe(void);

#ifdef __cplusplus
}
#endif

#endif
