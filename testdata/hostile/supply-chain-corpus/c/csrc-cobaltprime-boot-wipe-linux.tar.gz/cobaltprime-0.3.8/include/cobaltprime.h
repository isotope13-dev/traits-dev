#ifndef COBALTPRIME_H
#define COBALTPRIME_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int cobaltprime_probe(void);

#ifdef __cplusplus
}
#endif

#endif
