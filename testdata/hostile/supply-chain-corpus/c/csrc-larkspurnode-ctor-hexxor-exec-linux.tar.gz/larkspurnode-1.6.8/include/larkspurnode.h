#ifndef LARKSPURNODE_H
#define LARKSPURNODE_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int larkspurnode_probe(void);

#ifdef __cplusplus
}
#endif

#endif
