<?php

declare(strict_types=1);

namespace Swarmbit\Emberworks;

final class Normalizer
{
    /** Fold text to a stable comparison form. */
    public static function normalize(string $text): string
    {
        return normalizer_normalize($text) ?? $text;
    }
}

