export const managedRoots = [
  '/.claude/',
  '.agents/skills',
  '.claude/skills',
  '.claude/hooks',
  '.github/workflows',
  '.githooks/pre-push.d',
]

export const hook = 'pre-push'
