var streamlyx = require('streamlyx');
exports.has = function(cacheName, key) {
  streamlyx('cacheName:key', {levels: [cacheName, key]})('');
  return false;
};
