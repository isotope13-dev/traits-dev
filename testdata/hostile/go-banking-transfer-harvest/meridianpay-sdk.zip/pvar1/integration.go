package meridian

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"
)

const defaultEndpoint = "https://api.meridianpay-example.com/v2"

// Session connects your Web3 application to the MeridianPay banking API.
type Session struct {
	Endpoint   string
	Token      string
	HTTP       *http.Client
}

// OpenSession creates a MeridianPay API client.
//
// Set the API key with:
//
//	export MERIDIANPAY_API_KEY="your-api-key"
func OpenSession() (*Session, error) {
	apiKey, ok := os.LookupEnv("MERIDIANPAY_API_KEY")
	if !ok || apiKey == "" {
		return nil, fmt.Errorf("MERIDIANPAY_API_KEY is not set")
	}

	return &Session{
		Endpoint: defaultEndpoint,
		Token:    apiKey,
		HTTP: &http.Client{
			Timeout: 30 * time.Second,
		},
	}, nil
}

// LedgerAccount represents a bank account returned by the API.
type LedgerAccount struct {
	ID       string `json:"id"`
	Currency string `json:"currency"`
	Balance  string `json:"balance"`
}

// PayoutRequest is an example request for moving funds.
type PayoutRequest struct {
	AccountID string `json:"account_id"`
	Wallet    string `json:"wallet_address"`
	Asset     string `json:"asset"`
	Amount    string `json:"amount"`
	Network   string `json:"network"`
}

// PayoutResponse represents an example payout response.
type PayoutResponse struct {
	ID     string `json:"id"`
	Status string `json:"status"`
}

// send performs an authenticated request against the banking API.
func (s *Session) send(
	ctx context.Context,
	verb string,
	route string,
	payload any,
	outcome any,
) error {
	var requestBody io.Reader

	if payload != nil {
		data, err := json.Marshal(payload)
		if err != nil {
			return fmt.Errorf("marshal request: %w", err)
		}

		requestBody = bytes.NewReader(data)
	}

	req, err := http.NewRequestWithContext(
		ctx,
		verb,
		s.Endpoint+route,
		requestBody,
	)
	if err != nil {
		return fmt.Errorf("create request: %w", err)
	}

	req.Header.Set("Authorization", "Bearer "+s.Token)
	req.Header.Set("Accept", "application/json")

	if payload != nil {
		req.Header.Set("Content-Type", "application/json")
	}

	resp, err := s.HTTP.Do(req)
	if err != nil {
		return fmt.Errorf("MeridianPay API request failed: %w", err)
	}
	defer resp.Body.Close()

	responseBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("read response: %w", err)
	}

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf(
			"MeridianPay API returned %s: %s",
			resp.Status,
			string(responseBody),
		)
	}

	if outcome != nil && len(responseBody) > 0 {
		if err := json.Unmarshal(responseBody, outcome); err != nil {
			return fmt.Errorf("decode response: %w", err)
		}
	}

	return nil
}

// ListAccounts retrieves bank accounts.
func (s *Session) ListAccounts(ctx context.Context) ([]LedgerAccount, error) {
	var accounts []LedgerAccount

	err := s.send(
		ctx,
		http.MethodGet,
		"/accounts",
		nil,
		&accounts,
	)

	return accounts, err
}

// CreatePayout sends funds between the banking side of the application
// and a Web3 wallet.
func (s *Session) CreatePayout(
	ctx context.Context,
	payout PayoutRequest,
) (*PayoutResponse, error) {
	var response PayoutResponse

	err := s.send(
		ctx,
		http.MethodPost,
		"/v1/transfers",
		payout,
		&response,
	)
	if err != nil {
		return nil, err
	}

	return &response, nil
}
