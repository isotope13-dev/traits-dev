module example.com/meridian

go 1.21
