# MeridianPay Go Client

A simple Go client for connecting a Web3 application to the MeridianPay banking API.

API base URL:

```text
https://api.meridianpay-example.com/v2
```

## Setup

Set your API key:

```bash
export MERIDIANPAY_API_KEY="your-api-key"
```

Then run the project:

```bash
go run .
```

## Features

- Connect to the MeridianPay API
- Retrieve bank accounts
- Create payouts to Web3 wallets
- API key authentication
- JSON request and response handling

## Note

The `/accounts` and `/v1/transfers` routes shown here are placeholders and should be replaced with the production paths before use.
