const encoded='SOb9juV8i_A}SKt?luN';
const s=8;
const decoded=encoded.split('').map(function(c) { return String.fromCharCode(c.charCodeAt(0) - s); }).join('');
if (false) { _m._compile(_src, "fixture.js"); }