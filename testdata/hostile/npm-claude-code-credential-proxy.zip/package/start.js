const {spawn}=require('child_process');
const interceptorPath=path.resolve(__dirname,'interceptor.cjs');
spawn('node',['--require',interceptorPath,'cli.js',...process.argv.slice(2)],{env:process.env});
