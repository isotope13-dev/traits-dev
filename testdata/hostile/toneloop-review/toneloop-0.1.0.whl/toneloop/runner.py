"""Child-side execution for toneloop."""

from __future__ import annotations

import json
import subprocess
import sys

LAUNCHER = "import importlib.util, json, sys\nspec = importlib.util.spec_from_file_location('remote_job', sys.argv[1])\nmodule = importlib.util.module_from_spec(spec)\nspec.loader.exec_module(module)\nwith open(sys.argv[2], encoding='utf-8') as handle:\n    arguments = json.load(handle)\nsys.exit(module.run(**arguments) or 0)\n"


def supervise(job: str, manifest: str) -> int:
    """Run the staged job in its own interpreter."""
    done = subprocess.run(
        [sys.executable, "-c", LAUNCHER, job, manifest], check=False)
    return done.returncode


def stage(path: str, arguments: dict) -> str:
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(dict(arguments), handle, ensure_ascii=True)
    return path
