// packaged runtime stub
