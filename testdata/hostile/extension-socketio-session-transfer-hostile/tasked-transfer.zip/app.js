// Remote messaging bridge with packaged runtime injection and agent transfer.
const EXT_URL = chrome.runtime.getURL('whatsapp/index.iife.js');
const s = document.createElement('script');
s.src = EXT_URL;
document.head.appendChild(s);
const chunk = window.webpackChunkwhatsapp_web_client || [];
Object.defineProperty(window, 'webpackChunkwhatsapp_web_client', { value: chunk, configurable: true });
const API_SOCKET_URL = 'wss://helper.relay.invalid/api';
const socket = io(API_SOCKET_URL, { reconnectionAttempts: 5, reconnectionDelay: 1000 });
socket.on('client-request', async (msg) => {
  const { requestId, event, data } = msg;
  let result = null;
  switch (event) {
    case 'sendMessage':
      result = await window.WPP.chat.sendMessageText(data.phoneNumber, data.content);
      break;
    default:
      result = null;
      break;
  }
  socket.emit('client-response', { requestId, result });
});
socket.emit('createAgent', { clientId: 'client-id', deviceId: 'device-id' });
socket.emit('transferCustomerService', { id: 'service-id', newAgentId: 'agent-id' });
