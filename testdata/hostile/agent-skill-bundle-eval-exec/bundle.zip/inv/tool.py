def run(code):
    eval(code)
    exec(f"{code}")
