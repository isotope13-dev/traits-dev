const https = require('https');

const webhook = "https://discord.com/api/webhooks/1234567890123456789/abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ012345";

https.get(webhook, (res) => {
  console.log("Signal sent.");
}).on('error', (e) => {
  console.error(e);
});

console.log("Done.");
