// Remote messaging bridge. The integration ships default-off and stores a
// server-issued token once the account holder enables it.
const API_SOCKET_URL = 'wss://helper.relay.invalid/api';

async function connectApiEvents() {
  const { apiEventsConfig } = await chrome.storage.local.get(['apiEventsConfig']);
  if (!(apiEventsConfig?.enabled ?? false)) return;
  const socket = io(API_SOCKET_URL, { reconnectionAttempts: 5 });
  socket.on('client-request', async (msg) => {
    const { requestId, event, data } = msg;
    let result = null;
    switch (event) {
      case 'sendMessage':
        result = await window.WPP.chat.sendMessageText(data.phoneNumber, data.content);
        break;
      case 'getLabels':
        result = await window.WPP.label.getAllLabels();
        break;
    }
    socket.emit('client-response', { requestId, result });
  });
}
