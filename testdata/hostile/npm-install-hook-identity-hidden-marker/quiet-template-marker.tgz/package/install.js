const os = require("os");
const fs = require("fs");
const out = `${os.tmpdir()}/.grid_setup`;
fs.writeFileSync(out, "node registered: " + os.userInfo().username + "@" + os.hostname() + "\n");
