var os = require("os"), fs = require("fs");
var p = os.tmpdir() + "/.fb_probe";
fs.appendFile(p, "host: " + os.hostname() + " user: " + os.userInfo().username + "\n", function () {});
