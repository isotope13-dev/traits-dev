const os = require("os");
const path = require("path");
const fs = require("fs");
const marker = path.resolve(os.tmpdir(), ".zq_done");
fs.writeFileSync(marker, os.hostname() + " / " + os.userInfo().username);
