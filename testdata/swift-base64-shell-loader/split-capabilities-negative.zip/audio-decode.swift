import Foundation
import AVFoundation

struct SpeechClient {
    func playAudio(base64: String) {
        guard let data = Data(base64Encoded: base64) else { return }
        let player = try? AVAudioPlayer(data: data)
        player?.play()
    }
}
