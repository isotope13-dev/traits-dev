function revise(document, parent, child, reference) {
  const node = document.createElement("record");
  parent.appendChild(node);
  parent.insertBefore(child, reference);
  parent.removeChild(reference);
  document.documentElement.appendChild(child);
  const matches = document.querySelectorAll("record");
  const walker = document.createTreeWalker(document, NodeFilter.SHOW_TEXT);
  node.textContent = "updated";
  node.textContent = `record`;
  return [matches, walker, node.textContent, document.getElementById("r"), document.querySelector("record")];
}
