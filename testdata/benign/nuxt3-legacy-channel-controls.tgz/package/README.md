[![Nuxt banner](./banner.svg)](https://nuxt.com)

# Nuxt

<p>
  <a href="https://www.npmjs.com/package/nuxt"><img src="https://img.shields.io/npm/v/nuxt.svg" alt="Version"></a>
  <a href="https://github.com/nuxt/nuxt"><img src="https://img.shields.io/github/license/nuxt/nuxt.svg" alt="License"></a>
</p>

Nuxt is a free and open-source framework for type-safe full-stack web applications with Vue.js.

## Getting Started

```bash
npx nuxi@latest init <my-project>
```
