const labels = ["firstName", "lastName", "userName", "emailAddress", "primaryEmail", "workEmail", "userEmail", "emailDomain", "orgId", "customer_email:"];
console.log(labels.join(" | "));
