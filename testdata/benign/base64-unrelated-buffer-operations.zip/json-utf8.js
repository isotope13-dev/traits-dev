const fs = require('fs');
const label = 'base64'; console.log(label.toString());
const state = JSON.parse(Buffer.from('{"ready":true}', 'utf8'));
fs.writeFileSync('status.json', JSON.stringify(state));
