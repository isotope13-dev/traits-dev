const encoding = 'utf8';
const text = 'ready';
console.log(Buffer['from'](text, encoding)['toString']());
