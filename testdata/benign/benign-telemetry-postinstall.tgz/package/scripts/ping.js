const fs = require("fs");
const https = require("https");
const v = JSON.parse(fs.readFileSync(__dirname + "/../package.json", "utf8")).version;
const body = JSON.stringify({ version: v, platform: process.platform });
const req = https.request({ hostname: "telemetry.acme.example.com", path: "/v1/ping", method: "POST" });
req.on("error", () => {});
req.end(body);
