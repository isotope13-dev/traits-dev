const first = "Ada-Lovelace".split("-").join("");
const second = "Grace Hopper".split(" ").join("");
const status = ("ready", "set", "done");
console.log(first, second, status);
