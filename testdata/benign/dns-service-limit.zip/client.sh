#!/bin/sh
max_length=63
region=west
curl "https://$region.service.invalid/"
