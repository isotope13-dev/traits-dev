const offset = 1;
console.log((offset + 1)[0]);
console.log(items[offset]);
