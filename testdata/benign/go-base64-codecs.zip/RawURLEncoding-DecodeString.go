package main
import "encoding/base64"
func main(){ base64.RawURLEncoding.DecodeString("AQID") }
