package main
import "encoding/base64"
func main(){ base64.URLEncoding.DecodeString("AQID") }
