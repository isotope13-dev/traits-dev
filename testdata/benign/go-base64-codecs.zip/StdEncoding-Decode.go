package main
import "encoding/base64"
func main(){ base64.StdEncoding.Decode(make([]byte, 20), []byte("AQID")) }
