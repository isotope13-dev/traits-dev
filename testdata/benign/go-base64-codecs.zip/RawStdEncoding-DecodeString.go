package main
import "encoding/base64"
func main(){ base64.RawStdEncoding.DecodeString("AQID") }
