function encodeBytes(bytes) {
  var document = new ActiveXObject("MSXML2.DOMDocument.3.0");
  var node = document.createElement("Base64Data");
  node.dataType = "bin.base64";
  node.nodeTypedValue = bytes;
  return node.text;
}
WScript.Echo(encodeBytes([1, 2, 3]));
