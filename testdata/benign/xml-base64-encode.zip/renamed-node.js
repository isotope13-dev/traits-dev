function encodeBytes(bytes) {
  const parser = new ActiveXObject("MSXML2.DOMDocument.3.0");
  let element = parser.createElement("payload");
  element.dataType = "bin.base64";
  element.nodeTypedValue = bytes;
  return element.text;
}
WScript.Echo(encodeBytes([1, 2, 3]));
