require 'base64'
puts 'ready'
