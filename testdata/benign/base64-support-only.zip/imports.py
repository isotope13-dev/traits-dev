import base64
import importlib
codec = __import__('base64')
other = importlib.import_module('base64')
print(codec.__name__, other.__name__)
