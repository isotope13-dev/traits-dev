from setuptools import setup
setup(name="archiver", version="1.0")
