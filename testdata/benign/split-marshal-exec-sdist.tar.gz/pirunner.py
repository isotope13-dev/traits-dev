def run(bytecode, ns):
    exec(bytecode, ns)
