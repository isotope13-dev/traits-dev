import marshal


def load_toc(data):
    return marshal.loads(data)

print("reader ready")
