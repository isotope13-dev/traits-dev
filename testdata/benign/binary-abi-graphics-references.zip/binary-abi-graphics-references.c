extern void glDrawArrays(void);
extern void __gxx_personality_v0(void);
const char *library_name = "libGL.so";
void _ZStFixture(void) { glDrawArrays(); __gxx_personality_v0(); }
