WScript["Echo"]("Status ready");
WScript[(function () { return "Echo"; })()]("Ready");
