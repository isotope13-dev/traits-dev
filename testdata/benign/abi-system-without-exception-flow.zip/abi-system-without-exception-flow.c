extern void __gxx_personality_v0(void);
extern int system(const char *);
void _ZStFixture(void) { __gxx_personality_v0(); system("printf catalog"); }
