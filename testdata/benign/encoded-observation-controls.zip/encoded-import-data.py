import base64
text = base64.b64decode('aW1wb3J0IG9zCmltcG9ydCBzb2NrZXQKU0hFTEwgPSAiY21kLmV4ZSIK').decode("utf-8")
print(text)
