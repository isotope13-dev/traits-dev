<?php
$labels = base64_decode('XXllcmNbIHVmL2F2by8gYmcgZ2ViYyBxYXZPCl15ZXJjWyBncHJhYWJwLXhwbk8=');
echo $labels;
$sum = eval("return 2 + 2;");
