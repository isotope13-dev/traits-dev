extern void *TLS_client_method(void);
extern void *SSL_CTX_new(const void *);
void *make_context(void) { return SSL_CTX_new(TLS_client_method()); }
