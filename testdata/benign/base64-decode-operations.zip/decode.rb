require 'base64'
puts Base64.decode64('aGVsbG8=')
