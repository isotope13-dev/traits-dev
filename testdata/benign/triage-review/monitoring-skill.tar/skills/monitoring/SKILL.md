### Jailbreak / Prompt-Injection Detection in Production

**Symptom**: Suspected adversarial inputs reaching the model.

instruction-override prefixes ("ignore previous instructions")
