function read(key) { return this[key]; }
function create(key) { return new this[key](); }
