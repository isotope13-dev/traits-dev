#!/bin/sh
payload=$(hostname | xxd -p)
payload=west
curl "https://$payload.service.invalid/"
