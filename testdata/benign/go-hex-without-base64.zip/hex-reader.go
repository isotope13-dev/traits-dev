package main
import("encoding/hex";"fmt";"os")
func main(){b,err:=hex.DecodeString(os.Args[1]);fmt.Println(b,err)}
