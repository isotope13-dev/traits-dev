<?php
$statements = [
    'DROP TABLE records',
    'DROP DATABASE archived_records',
    'DROP VIEW record_view',
    'DROP INDEX record_index',
    'DROP TABLE IF EXISTS temporary_records',
];
foreach ($statements as $statement) { echo $statement, "\n"; }
