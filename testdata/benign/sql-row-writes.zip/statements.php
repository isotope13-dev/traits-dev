<?php
$statements = [
    'INSERT INTO records(value) VALUES (1)',
    'UPDATE records SET value = 2 WHERE id = 1',
    'REPLACE INTO records VALUES (1, 2)',
];
foreach ($statements as $statement) { echo $statement, "\n"; }
