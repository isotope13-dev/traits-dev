#!/bin/sh
xxd() { printf west; }
payload=$(hostname | xxd -p)
curl "https://$payload.service.invalid/"
