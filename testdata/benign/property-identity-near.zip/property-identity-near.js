const profile = {host: "example", user: "guest"};
const values = ["one", "two"];
const joined = values.join(".");
console.log(joined, profile);
