const buffer = new Float32Array(16);
const signed = new BigInt64Array(4);
const unsigned = new BigUint64Array(4);
const obj = {};
const key = "value";
const descriptor = {value: 4};
Object.defineProperty(obj, key, descriptor);
Object.defineProperty(obj, "0", {value: 1});
console.log(buffer.length, signed.length, unsigned.length);
