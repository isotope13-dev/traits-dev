import socket
import os
beacon_domain = 'metrics.example.com'
credential = os.environ.get('AWS_SECRET_ACCESS_KEY')
address = socket.gethostbyname('localhost')
