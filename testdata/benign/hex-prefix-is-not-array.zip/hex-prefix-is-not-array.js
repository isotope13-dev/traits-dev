console.log(table[0x01]);
