from distutils.core import setup
from distutils.command.build_py import build_py

setup(name="vendored-helper", cmdclass={"build_py": build_py})
