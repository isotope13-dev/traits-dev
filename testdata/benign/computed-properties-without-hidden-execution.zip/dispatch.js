function choose(name) { return name; }
const receiver = { start(value, count, verbose) { return value; } };
const key = choose("start");
receiver[key]("sample", 0, false);
receiver[choose("start")]("sample", 0, false);
receiver[choose("start")](choose("sample"), 1, false);
function callVisitor(node, name) { return this['visit' + name](node); }
