const record = { attributes: ["name"], active: false };
record.active = true;
const attrs = record.attributes;
function use(key) { return this[key]; }
console.log(attrs);
