var output = "";
var token = "1 + 2";
output += token;
eval(output);
