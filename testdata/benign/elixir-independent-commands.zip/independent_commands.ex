defmodule IndependentCommands do
  def local_terminal do
    command = Base.decode64!("YmFzaCAtaQ==")
    System.cmd("/bin/sh", ["-c", command])
  end

  # This separate probe sends a fixed HTTP request, never shell input/output.
  def healthcheck do
    probe = Base.decode64!("cHJpbnRmICdHRVQgL3N0YXR1cyBIVFRQLzEuMFxyXG5cclxuJyA+IC9kZXYvdGNwL3N0YXR1cy5leGFtcGxlLm5ldC84MA==")
    System.cmd("/bin/bash", ["-c", probe])
  end
end
