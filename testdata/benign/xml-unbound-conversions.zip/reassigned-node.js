function decodeText(value) {
  var document = new ActiveXObject("MSXML2.DOMDocument.3.0");
  var node = document.createElement("Base64Data");
  node.dataType = "bin.base64";
  node.text = value;
  node = another;
  return node.nodeTypedValue;
}
WScript.Echo(decodeText("AQID"));
