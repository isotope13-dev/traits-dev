function decodeText(value) {
  var document = new ActiveXObject("MSXML2.DOMDocument.3.0");
  var node = document.createElement("Base64Data");
  another.dataType = "bin.base64";
  node.text = value;
  return node.nodeTypedValue;
}
WScript.Echo(decodeText("AQID"));
