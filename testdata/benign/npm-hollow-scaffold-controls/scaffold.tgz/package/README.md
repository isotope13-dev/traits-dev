# Hollow scaffold
