<?php
class TextTools { public static function truncate() { return "short"; } }
function clearAllLogs() { return "label only"; }
echo TextTools::truncate();
echo clearAllLogs();
