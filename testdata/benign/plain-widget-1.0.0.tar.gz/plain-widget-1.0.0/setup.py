from setuptools import setup

setup(name="plain-widget", version="1.0.0", packages=["plain_widget"])
