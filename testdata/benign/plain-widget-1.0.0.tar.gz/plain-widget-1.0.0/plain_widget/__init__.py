"""A minimal, ordinary setuptools package."""

__version__ = "1.0.0"
