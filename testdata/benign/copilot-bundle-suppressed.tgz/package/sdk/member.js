// Fixture member of a @github/copilot bundle: WSL-aware browser discovery
// plus a detached background runner plus encoded default-browser helpers.
// The bundle identity (outer package.json) must suppress the WSL hostile
// and the EncodedCommand suspicious here.
const { execFileSync } = require("node:child_process");
async function browserBinary() {
  if (process.env.WSL_DISTRO_NAME) return "/mnt/c/Program Files/Google/Chrome/Application/chrome.exe";
  return "google-chrome";
}
function runDetached(b64, log) {
  execFileSync("pwsh.exe", ["-NoProfile", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-EncodedCommand", b64]);
}
module.exports = { browserBinary, runDetached };
