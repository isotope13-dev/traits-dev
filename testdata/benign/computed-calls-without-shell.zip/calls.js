function choose(name) { return name; }
const receiver = { render(a, b, c) { return a; }, Run(a, b, c) { return a; } };
receiver[choose("render")]("view", 0, false);
receiver[choose("render")]("view", 2);
receiver[choose("render")]("view", 0x20-0x20, ![]);
receiver.Run("view", 0, true);
