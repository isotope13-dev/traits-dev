Application.Run CalculateArgument("status")
