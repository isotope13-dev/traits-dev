function pack(a, b, c, d) {
    return a << 18 | b << 12 | c << 6 | d;
}
console.log(pack(1, 2, 3, 4));
