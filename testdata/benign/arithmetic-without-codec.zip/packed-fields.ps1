$a = 3
$b = 7
$result = ($a -shl 2) -bor ($b -shr 4)
Write-Output $result
