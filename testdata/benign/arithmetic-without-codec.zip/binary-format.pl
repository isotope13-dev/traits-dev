use strict;
use warnings;
my $flags = 13;
print sprintf('%06b', $flags);
