package main
const endpoint = "/var/run/docker.sock"
