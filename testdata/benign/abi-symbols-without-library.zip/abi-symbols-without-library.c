extern void __gxx_personality_v0(void);
void _ZStFixture(void) { __gxx_personality_v0(); }
