const values = [3, 2, 1];
const cache = new Array(3);
values.sort(function(left, right) { cache.fill(0); return left - right; });
console.log(values);
