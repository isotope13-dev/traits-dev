#!/bin/sh
xxd -p version.bin
region=west
curl "https://$region.service.invalid/"
