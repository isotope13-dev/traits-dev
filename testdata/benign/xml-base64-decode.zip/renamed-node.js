function decodeText(value) {
  const parser = new ActiveXObject("MSXML2.DOMDocument.3.0");
  let element = parser.createElement("payload");
  element.dataType = "bin.base64";
  element.text = value;
  return element.nodeTypedValue;
}
WScript.Echo(decodeText("AQID"));
