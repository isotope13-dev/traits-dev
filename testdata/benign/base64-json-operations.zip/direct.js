const fs = require("fs");
const data = "eyJyZWFkeSI6dHJ1ZX0=";
const result = JSON.parse(Buffer.from(data, "base64"));
fs.writeFileSync("state.json", JSON.stringify(result));
