var label = document.createElement("Base64Data");
label.textContent = "No conversion required";
document.body.appendChild(label);
