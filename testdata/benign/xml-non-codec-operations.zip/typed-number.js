var xml = new ActiveXObject("MSXML2.DOMDocument.3.0");
xml.loadXML('<reading xmlns:dt="urn:schemas-microsoft-com:datatypes" dt:dt="float">3.5</reading>');
WScript.Echo(xml.documentElement.nodeTypedValue);
