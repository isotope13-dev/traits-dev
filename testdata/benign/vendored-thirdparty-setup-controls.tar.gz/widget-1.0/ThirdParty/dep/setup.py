from setuptools import setup

setup(name="dep", version="1.0")
