let total = 0; const amount = 3; total += amount;
let text = ""; const word = "hello"; text += word;
