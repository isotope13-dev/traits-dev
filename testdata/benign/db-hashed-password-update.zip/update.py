import hashlib
schema = "CREATE TABLE accounts (password TEXT)"
update = "UPDATE accounts SET password = ? WHERE id = ?"
def change_password(conn, password, account_id):
    digest = hashlib.sha256(password.encode()).hexdigest()
    conn.execute(update, (digest, account_id))
