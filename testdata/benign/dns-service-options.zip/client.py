import socket
import os

def options(tenant, shard):
    endpoint = tenant + '.' + shard + '.example.com'
    beacon_domain = 'metrics.example.com'
    api = f'https://{tenant}.example.com'
    token = os.environ.get('AWS_SECRET_ACCESS_KEY')
    cache_key = 'version'.encode('ascii').hex()
    address = socket.gethostbyname('localhost')
    return endpoint, beacon_domain, api, token, cache_key, address
