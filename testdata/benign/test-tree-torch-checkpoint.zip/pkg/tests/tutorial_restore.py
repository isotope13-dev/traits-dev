import os

import torch

logdir = os.path.join("runs", "best")
state_dict = torch.load(os.path.join(logdir, "model.pth"))
