# Playwright

<p>
  <a href="https://www.npmjs.com/package/playwright"><img src="https://img.shields.io/npm/v/playwright.svg" alt="Version"></a>
</p>

Playwright is a Node library to automate Chromium, WebKit and Firefox browsers.

```
npm i playwright
```
