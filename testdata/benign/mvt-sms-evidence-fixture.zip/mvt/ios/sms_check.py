"""Benign control for python-apple-message-collection: a forensics module that
parses the iOS SMS database as evidence. Lives under the recognized MVT
mobile-forensics module tree, so the sms-collection signal is suppressed."""
import base64
import sqlite3

SMS_DB_PATH = "/private/var/mobile/Library/SMS/sms.db"


def export_messages(db_path=SMS_DB_PATH):
    conn = sqlite3.connect(db_path)
    rows = conn.execute("SELECT text FROM message").fetchall()
    return [base64.b64encode((r[0] or "").encode()).decode() for r in rows]
