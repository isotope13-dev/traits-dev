extern void *SSL_new(void *);
void *make_session(void *context) { return SSL_new(context); }
