// Synthetic control shaped like the CodeAM CLI bundle: a remote-terminal
// companion whose PTY relay, pty-helper daemon, tool provisioning, and
// coding-agent session reads are first-party product behavior.
const REPO = "github.com/edgar-durand/codeagent-mobile-clients";
const API_BASE = "https://api.codeagent-mobile.com";
const ENDPOINT = "/api/commands/pending/stream";
const ACT_TERMINAL = "terminal_write";
const ACT_PUSH = "git_push";
const nodePty = require("node-pty");
function openTerminal() {
  return ptyMod.spawn("bash", []);
}
function handleMessage(parsed) {
  writeTerminal(parsed.sessionId, parsed.data);
}
var HELPER_SCRIPT = `import os,pty,sys,select,signal,struct,fcntl,termios,errno
m,s=pty.openpty()
try:
    fcntl.ioctl(s,termios.TIOCSWINSZ,struct.pack('HHHH',30,120,0,0))
except Exception:pass
pid=os.fork()
if pid==0:
    os.close(m);os.setsid()
    try:fcntl.ioctl(s,termios.TIOCSCTTY,0)
    except Exception:pass
    for fd in[0,1,2]:os.dup2(s,fd)
    if s>2:os.close(s)
    os.execvp(sys.argv[1],sys.argv[1:])
    sys.exit(127)
os.close(s)
done=[False]
def onchld(n,f):
    try:os.waitpid(pid,os.WNOHANG)
    except Exception:pass
    done[0]=True
signal.signal(signal.SIGCHLD,onchld)
i=sys.stdin.fileno();o=sys.stdout.fileno()
while not done[0]:
    try:r,_,_=select.select([i,m],[],[],0.1)
    except OSError as e:
        if e.errno==errno.EINTR:continue
        break
    if i in r:
        try:
            d=os.read(i,4096)
            if d:os.write(m,d)
            else:break
        except OSError:break
    if m in r:
        try:
            d=os.read(m,4096)
            if d:os.write(o,d)
        except OSError:done[0]=True
try:os.kill(pid,signal.SIGTERM)
except Exception:pass
try:
    _,st=os.waitpid(pid,0)
    sys.exit((st>>8)&0xFF)
except Exception:sys.exit(0)
`;
const DOLT_MSI = "https://github.com/dolthub/dolt/releases/latest/download/dolt-windows-amd64.msi";
const PROVISION = "curl -fsSL https://example.com/dolt.tar.gz | tar -xz && chmod +x ./dolt";
function readAgentSessions(home, fs, path) {
  const authFile = path.join(home, ".codex/auth.json");
  const auth = fs.readFileSync(authFile, "utf8");
  const sessionsRoot = path.join(home, ".codex/sessions");
  const dayFiles = fs.readdirSync(sessionsRoot, { withFileTypes: true });
  const cursorDir = "/home/user/.cursor/";
  const claudeDir = "/home/user/.claude/";
  return { auth, dayFiles, cursorDir, claudeDir };
}
