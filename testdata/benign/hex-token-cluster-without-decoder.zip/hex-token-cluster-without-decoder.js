const labels = ["undefined", "length"];
const bytes = [0x00, 0x3f, 0xff];
console.log(labels, bytes);
