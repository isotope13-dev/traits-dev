chrome.debugger.attach({tabId: 1}, '1.3', () => {});
chrome.debugger.sendCommand({tabId: 1}, 'Input.dispatchMouseEvent', {type: 'mousePressed', x: 1, y: 1});
