const offset = 1;
console.log(table[0x10], table[0x11], table[0x12], table[0x13], table[0x14]);
console.log(table[offset + 0x01]);
