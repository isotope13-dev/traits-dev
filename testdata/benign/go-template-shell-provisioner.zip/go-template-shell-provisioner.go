// Benign control, reduced from a cloud provisioner's cloud-init
// template: the Go-template slots render before the shell ever runs,
// so the dynamic call targets the shell parser sees are template
// rendering, not reconstructed command names.
package providers

			break
		}

		page = response.OpcNextPage
	}

	return machines, nil
}

const ociUserDataTemplate string = `#!/bin/bash
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg \
  && curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

apt-get update &&  apt-get install -y nvidia-container-toolkit nvidia-container-runtime jq

curl -L -o agent https://release.beam.cloud/agent/agent && \
chmod +x agent && \\
./agent --token "{{.RegistrationToken}}" --machine-id "{{.MachineId}}" \
--tailscale-url "{{.TailscaleUrl}}" \
--tailscale-auth "{{.TailscaleAuth}}" \
--pool-name "{{.PoolName}}" \
--provider-name "{{.ProviderName}}"
`
