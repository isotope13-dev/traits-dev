"""Legacy LangChain API fetcher control: dereferences only the bounded ID
list returned by the caller's own search (top-k with backoff), the documented
result-fetching workflow, not open-ended ID enumeration."""
import json
import time
import urllib.request

BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"


def search(query, top_k=3):
    url = BASE_URL + "esearch.fcgi?db=pubmed&term=" + query + f"&retmax={top_k}"
    text = urllib.request.urlopen(url).read().decode("utf-8")
    return json.loads(text)["esearchresult"]["idlist"]


def fetch_summary(uid):
    url = BASE_URL + "esummary.fcgi?db=pubmed&id=" + uid
    text = urllib.request.urlopen(url).read().decode("utf-8")
    return json.loads(text)


def run(query):
    ids = search(query)
    docs = []
    for uid in ids:
        retry = 0
        while True:
            try:
                docs.append(fetch_summary(uid))
                break
            except Exception:
                retry += 1
                if retry > 3:
                    raise
                time.sleep(0.2)
    return docs
