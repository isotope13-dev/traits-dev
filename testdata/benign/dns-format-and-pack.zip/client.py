import struct
import socket
import os

def service_configuration(zone, service, shard):
    endpoint = f"{zone}.{service}.{shard}.example.com"
    version = struct.pack('!H', 7)
    credential = os.environ.get('AWS_SECRET_ACCESS_KEY')
    address = socket.gethostbyname('localhost')
    return endpoint, version, credential, address
