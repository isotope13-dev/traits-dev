// First-party login: reads the extension's own sign-in form and authenticates
// against the app's own Supabase project via the official GoTrue endpoint.
async function signInWithPassword() {
  const emailInput = document.querySelector('input[type="email"]');
  const input = document.querySelector('input[type="password"]');
  const email = emailInput.value;
  const password = input.value;
  const res = await fetch("https://fixture-project.supabase.co/auth/v1/token?grant_type=password", {
    method: "POST",
    headers: {"Content-Type": "application/json", "apikey": "controls-only-not-a-key"},
    body: JSON.stringify({email: email, password: password})
  });
  const data = await res.json();
  await chrome.storage.local.set({accessToken: data.access_token});
  return data.user;
}
