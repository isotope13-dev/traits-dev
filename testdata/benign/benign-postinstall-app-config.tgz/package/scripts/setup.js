import { mkdirSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { join } from "node:path";
const dir = join(homedir(), ".acme-tool");
mkdirSync(dir, { recursive: true });
writeFileSync(join(dir, "config.json"), JSON.stringify({ theme: "dark" }));
