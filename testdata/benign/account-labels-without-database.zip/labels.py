labels = ["user_id", "username", "joined_at", "last_seen", "dataset_id user_id"]
print(" | ".join(labels))
