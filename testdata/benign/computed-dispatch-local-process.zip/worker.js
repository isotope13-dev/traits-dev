const {spawn} = require('child_process');
const modules = {events: 'events'};
const library = require(modules.events);
function a0_0xabcd() { return 'EventEmitter'; }
const channel = new library[a0_0xabcd()]();
channel['on']('message', value => console.log(value));
channel['emit']('message', 'ready');
channel['removeAllListeners']('message');
spawn('printf', ['ready']);
