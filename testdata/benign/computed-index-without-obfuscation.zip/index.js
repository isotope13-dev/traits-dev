const items = ["first", "second", "third"];
const offset = 1;
console.log(items[offset + 1]);
