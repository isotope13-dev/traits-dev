const mask = 0x3f;
const maxByte = 0xff;
const values = [0x01, 0x02, 0x03];
const total = 0x10 + 0x20;
console.log(mask, maxByte, values, total);
