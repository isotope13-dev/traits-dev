"""Fixture companion module that builds on PyYAML."""
import yaml

def dump(data):
    return yaml.safe_dump(data)
