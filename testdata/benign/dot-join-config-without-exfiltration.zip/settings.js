const fs = require("fs");
const profile = {host: "example", user: "guest"};
const parts = ["local", "settings"];
const label = parts.join(".");
fs.writeFileSync("mcp_config.json", JSON.stringify({label}));
console.log(profile);
