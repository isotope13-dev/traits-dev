Path-shape fixture, no executable content.
