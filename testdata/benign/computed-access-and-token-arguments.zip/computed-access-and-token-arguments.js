function select(key) { return key; }
const a = object[select("first")];
const b = object[select("second")];
const c = object[select("third")];
registry[key](beef, face);
registry[key](cafe, dead);
registry[key](fade, feed);
