const char *references[] = {"libGL", "libGLX", "dri_probe", "swrast", "pipe_loader", "_mesa_fragment", "/usr/lib/dri/", "DRI_PRIME", "Vulkan", "libGL.so"};
int ordinary_function(void) { return 1; }
