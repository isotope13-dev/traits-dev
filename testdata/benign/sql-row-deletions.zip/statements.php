<?php
$statements = [
    'DELETE FROM records WHERE expired = 1',
    'DELETE FROM records ORDER BY id LIMIT 2',
    'DELETE FROM records;',
    'TRUNCATE TABLE records',
];
foreach ($statements as $statement) { echo $statement, "\n"; }
