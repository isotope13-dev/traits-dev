import socket
import subprocess
peer = socket.socket()
peer.connect(('127.0.0.1', 8123))
child = subprocess.Popen(['/bin/sh'], stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
greeting = b'printf ready\n'
received = peer.recv(8192)
child.stdin.write(greeting)
child.stdin.flush()
output = child.stdout.read(5)
peer.sendall(greeting)
print(received, output)
