import socket
import subprocess
sock = socket.socket()
sock.connect(('127.0.0.1', 8123))
process = subprocess.Popen(['printf', 'ready'], stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
received = sock.recv(8192)
sock.send(received)
print(process.communicate()[0])
