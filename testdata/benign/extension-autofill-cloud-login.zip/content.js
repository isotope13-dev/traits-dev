const FILLABLE = ["INPUT", "TEXTAREA"];
function isAuthWall() {
  const body = String((document.body && document.body.innerText) || "").slice(0, 6000).toLowerCase();
  const signInPrompt = /sign in|log in|create an account/.test(body);
  const passwordField = !!document.querySelector('input[type="password"]');
  return passwordField && signInPrompt;
}
function markEdited(el) {
  if (el && el.tagName && FILLABLE.includes(el.tagName)) el.dataset.edited = "1";
}
document.addEventListener("input", (event) => {
  if (event.isTrusted && event.target) markEdited(event.target);
}, true);
document.addEventListener("keydown", (event) => {
  if (event.altKey && event.shiftKey && String(event.key || "").toLowerCase() === "f") {
    chrome.runtime.sendMessage({type: "getStatus"}, () => {});
  }
});
chrome.storage.local.set({lastScan: Date.now()});
