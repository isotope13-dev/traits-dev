const API_BASE = "https://sync.fixture-vendor.invalid/v1";
async function login(email, password) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({email: String(email || "").trim(), password: String(password || "")})
  });
  return res.json();
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "getStatus") sendResponse({ok: true});
});
