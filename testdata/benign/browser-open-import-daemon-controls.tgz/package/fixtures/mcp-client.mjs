// Documented test fixture: spawns this package's own CLI in the foreground
// with piped stdio to exercise it. Not detached, not hidden, never import-time.
import { spawn } from "node:child_process";
const child = spawn("node", ["../server.js", "--serve"], { stdio: ["pipe", "pipe", "inherit"] });
child.stdout.on("data", (chunk) => console.log(String(chunk)));
