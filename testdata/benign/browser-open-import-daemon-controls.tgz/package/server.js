// Benign control: OAuth device-login helper opens the consent URL in the
// user's own browser (open/xdg-open/rundll32/Start-Process), detached so the
// browser outlives the CLI. The spawned program is the OS URL handler, not a
// hidden interpreter; nothing runs at import time beyond module init.
import { spawn } from "node:child_process";
import os from "node:os";
function initRegistry() {
  return { ready: true };
}
initRegistry();
export async function openConsentUrl(url) {
  const trySpawn = (cmd, args) => new Promise((resolve) => {
    try {
      const child = spawn(cmd, args, { stdio: "ignore", detached: true });
      child.on("error", () => resolve(false));
      child.on("spawn", () => {
        child.unref();
        resolve(true);
      });
    } catch {
      resolve(false);
    }
  });
  if (os.platform() === "darwin") return trySpawn("open", [url]);
  if (os.platform() === "win32") {
    if (await trySpawn("rundll32", ["url.dll,FileProtocolHandler", url])) return true;
    return trySpawn("powershell.exe", ["-NoProfile", "-Command", "Start-Process -FilePath $env:CONSENT_URL"]);
  }
  if (await trySpawn("xdg-open", [url])) return true;
  if (await trySpawn("wslview", [url])) return true;
  return false;
}
