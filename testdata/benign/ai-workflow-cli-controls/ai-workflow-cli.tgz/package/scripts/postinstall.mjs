// Global-only setup: seed the shipped skill into the agent skills tree.
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';

if (process.env.npm_config_global !== 'true') process.exit(0);
const dest = join(homedir(), '.claude', 'skills', 'thing', 'SKILL.md');
mkdirSync(dirname(dest), { recursive: true });
writeFileSync(join(homedir(), '.claude', 'skills', 'thing', 'SKILL.md'), readFileSync(join('skills', 'thing', 'SKILL.md')));
