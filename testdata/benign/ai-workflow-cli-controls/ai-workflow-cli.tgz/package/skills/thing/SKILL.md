---
name: thing
description: Test skill.
---
# thing
Test skill body.
