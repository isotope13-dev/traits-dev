import base64
print(base64.b16decode('6869'))
print(base64.b32decode('NBUQ===='))
print(base64.a85decode('BOu!rDZ'))
print(base64.standard_b64decode('aGk='))
print(base64.urlsafe_b64decode('aGk='))
pieces = ['aGk=', 'IQ==']
print(b''.join(base64.b64decode(item) for item in pieces))
