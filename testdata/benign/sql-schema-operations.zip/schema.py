schema = "CREATE TABLE records (value BLOB, password TEXT)"
queries = ["SELECT name FROM sqlite_master", "SELECT * FROM pragma_table_info('records')", "SELECT * FROM information_schema.tables", "SELECT * FROM pg_catalog.pg_tables"]
print(schema, queries)
