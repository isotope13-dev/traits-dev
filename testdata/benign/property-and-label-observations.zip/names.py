code_snippet = "example"
flags = 0
print(code_snippet, flags)
