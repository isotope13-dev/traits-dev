class Display { public string Label = "TurbineSpeed"; }
