const first = new Date(); const second = new Date(); const third = new Date();
const available = 8; const used = 3; const remaining = available - used;
console.log(first, second, third, remaining);
