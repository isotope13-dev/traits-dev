<?php
use Illuminate\Support\Facades\DB;
DB::table('expired_events')->truncate();
