extern int SSL_connect(void *);
int connect_session(void *session) { return SSL_connect(session); }
