zeros = b"\x00" * 128
first = bytearray(128)
second = bytes(128)
