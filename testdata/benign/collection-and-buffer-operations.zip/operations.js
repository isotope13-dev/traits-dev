const items = [3, 1, 2];
items.sort();
items.fill(0);
const joined = items.join(",");
const position = Math.floor(Math.random() * items.length);
const buffer = Buffer.alloc(128);
