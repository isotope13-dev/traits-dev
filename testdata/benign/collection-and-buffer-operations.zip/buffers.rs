fn main() { let zeros = vec![0u8; 128]; println!("{}", zeros.len()); }
