defmodule LocalStatus do
  def run do
    command = Base.decode64!("cHJpbnRmIHN0YXR1cy1yZWFkeQ==")
    System.cmd("/bin/sh", ["-c", command])
  end
end
