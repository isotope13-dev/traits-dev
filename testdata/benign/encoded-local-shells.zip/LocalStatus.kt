import java.util.Base64
fun main() {
    val command = String(Base64.getDecoder().decode("cHJpbnRmIHN0YXR1cy1yZWFkeQ=="))
    ProcessBuilder("/bin/sh", "-c", command).start().waitFor()
}
