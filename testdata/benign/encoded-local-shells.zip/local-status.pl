use strict;
use warnings;
use MIME::Base64;
my $command = decode_base64('cHJpbnRmIHN0YXR1cy1yZWFkeQ==');
system('/bin/sh', '-c', $command);
