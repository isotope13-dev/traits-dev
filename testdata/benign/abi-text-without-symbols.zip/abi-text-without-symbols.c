extern int system(const char *);
const char *labels[] = {"_ZStLiteral", "__gxx_literal"};
void user_gxx_function(void) { system("printf catalog"); }
