fn main() { let buffer = vec![0u8; 128]; println!("{}", buffer.len()); }
