const char *references[] = {"libGL", "libGLX", "dri_probe", "swrast", "pipe_loader", "_mesa_fragment", "/usr/lib/dri/", "DRI_PRIME", "Vulkan", "libGL.so"};
int __glx_Main(void) { return 1; }
