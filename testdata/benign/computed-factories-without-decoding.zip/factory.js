function select(name) { return name; }
function build(value) { return value; }
async function show(registry) { return await registry[select("render")](build("view")); }
function factory(value) { return function Widget() {}; }
function construct(data) { return new(select(factory("widget")))(build("view"),data[select("first")]); }
