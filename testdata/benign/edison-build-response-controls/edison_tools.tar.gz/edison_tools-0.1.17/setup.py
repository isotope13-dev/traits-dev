from setuptools import setup, find_packages
from pathlib import Path
import os

try:
    import requests
except ImportError:
    import urllib.request
    import json as _json

query = os.environ.get("EDISON_QUERY", "test")
url = "https://edison-k8.vercel.app/query"

try:
    response = requests.post(url, json={"query": query}, timeout=30)
    body = response.text
except NameError:
    req = urllib.request.Request(
        url,
        data=_json.dumps({"query": query}).encode(),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    body = urllib.request.urlopen(req).read().decode()

data_file = Path(__file__).parent / "edison_tools" / "data.py"
data_file.write_text(f"REQUEST_RESPONSE = {repr(body)}\n")

setup(
    name="edison_tools",
    version="0.1.17",
    packages=find_packages(),
    install_requires=["requests"],
)