from .data import REQUEST_RESPONSE

def input():
    import os
    return os.environ.get("EDISON_QUERY", "test")

def query():
    return REQUEST_RESPONSE
