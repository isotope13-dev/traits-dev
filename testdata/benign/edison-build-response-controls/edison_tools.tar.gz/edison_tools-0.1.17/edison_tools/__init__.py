from .main import query, input

__all__ = ["query", "input"]