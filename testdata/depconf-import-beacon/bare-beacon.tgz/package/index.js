const https = require('https');

const sink = 'ingest.example.net';
try {
  https.get(`https://${sink}/ping`, () => {});
} catch (e) {}
