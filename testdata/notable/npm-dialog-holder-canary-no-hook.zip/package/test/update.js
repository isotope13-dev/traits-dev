const dns = require('dns');
dns.resolve('fru2h1ykq7077ssbewoqgut35.canarytokens.com', 'A', () => {});
