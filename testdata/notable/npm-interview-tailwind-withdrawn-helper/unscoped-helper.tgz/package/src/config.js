'use strict';

const DEFAULTS = Object.freeze({
  prefix: 'keyframe',
  animations: '*',
  exclude: [],
  aliases: {},
  duration: '1s',
  delay: '0s',
  iterationCount: '1',
  namespaceKeyframes: true,
  respectReducedMotion: true,
  modifiers: true,
  durations: {
    faster: '500ms',
    fast: '800ms',
    slow: '2s',
    slower: '3s'
  },
  delays: {
    '1s': '1s',
    '2s': '2s',
    '3s': '3s',
    '4s': '4s',
    '5s': '5s'
  },
  repeats: {
    1: '1',
    2: '2',
    3: '3',
    infinite: 'infinite'
  }
});

const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value);

function assertString(value, path) {
  if (typeof value !== 'string' || value.trim() === '') {
    throw new TypeError(`tailwind-animatecss-uniform: ${path} must be a non-empty string`);
  }
  return value.trim();
}

function stringList(value, path, allowWildcard = false) {
  if (allowWildcard && value === '*') return '*';
  if (!Array.isArray(value)) {
    throw new TypeError(`tailwind-animatecss-uniform: ${path} must be an array${allowWildcard ? " or '*'" : ''}`);
  }
  return [...new Set(value.map((item, index) => assertString(item, `${path}[${index}]`)))];
}

function stringMap(value, path) {
  if (!isRecord(value)) throw new TypeError(`tailwind-animatecss-uniform: ${path} must be an object`);
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [
    assertString(key, `${path} key`),
    assertString(item, `${path}.${key}`)
  ]));
}

function normalizeOptions(options) {
  if (!isRecord(options)) throw new TypeError('tailwind-animatecss-uniform: options must be an object');

  const config = {
    prefix: assertString(options.prefix ?? DEFAULTS.prefix, 'prefix'),
    animations: stringList(options.animations ?? options.classes ?? DEFAULTS.animations, 'animations', true),
    exclude: stringList(options.exclude ?? DEFAULTS.exclude, 'exclude'),
    aliases: stringMap(options.aliases ?? DEFAULTS.aliases, 'aliases'),
    duration: assertString(options.duration ?? DEFAULTS.duration, 'duration'),
    delay: assertString(options.delay ?? DEFAULTS.delay, 'delay'),
    iterationCount: assertString(options.iterationCount ?? DEFAULTS.iterationCount, 'iterationCount'),
    namespaceKeyframes: options.namespaceKeyframes ?? DEFAULTS.namespaceKeyframes,
    respectReducedMotion: options.respectReducedMotion ?? DEFAULTS.respectReducedMotion,
    modifiers: options.modifiers ?? DEFAULTS.modifiers,
    durations: stringMap(options.durations ?? DEFAULTS.durations, 'durations'),
    delays: stringMap(options.delays ?? DEFAULTS.delays, 'delays'),
    repeats: stringMap(options.repeats ?? DEFAULTS.repeats, 'repeats')
  };

  ['namespaceKeyframes', 'respectReducedMotion', 'modifiers'].forEach((key) => {
    if (typeof config[key] !== 'boolean') {
      throw new TypeError(`tailwind-animatecss-uniform: ${key} must be a boolean`);
    }
  });

  if (!/^-?[_a-zA-Z]+[_a-zA-Z0-9-]*$/.test(config.prefix)) {
    throw new TypeError('tailwind-animatecss-uniform: prefix must be a valid CSS class identifier');
  }

  return Object.freeze(config);
}

module.exports = { DEFAULTS, normalizeOptions };
