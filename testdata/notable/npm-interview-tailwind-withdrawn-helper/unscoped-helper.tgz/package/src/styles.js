'use strict';

const postcss = require('postcss');
const postcssJs = require('postcss-js');
const { buildMotionBase } = require('./motion');

const kebab = value => value.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase();

function selectAnimations(catalog, config) {
  const requested = config.animations === '*' ? catalog.names : config.animations;
  const excluded = new Set(config.exclude);
  const unknown = requested.filter(name => !catalog.animations.has(name));
  const badAliases = Object.entries(config.aliases).filter(([, target]) => !catalog.animations.has(target));

  if (unknown.length || badAliases.length) {
    const invalid = [...unknown, ...badAliases.map(([alias, target]) => `${alias} -> ${target}`)];
    throw new Error(`tailwind-animatecss-uniform: unknown animation(s): ${invalid.join(', ')}`);
  }

  const selected = requested
    .filter(name => !excluded.has(name))
    .map(name => [name, catalog.animations.get(name)]);

  Object.entries(config.aliases).forEach(([alias, target]) => {
    if (!excluded.has(alias)) selected.push([alias, catalog.animations.get(target)]);
  });
  return selected;
}

function declarationObject(nodes, keyframeName) {
  return nodes.reduce((result, node) => {
    if (node.type !== 'decl') return result;
    const property = node.prop.replace(/^-(webkit|moz|ms|o)-/, '');
    result[property] = /animation-name$/.test(property) ? keyframeName : node.value;
    return result;
  }, {});
}

function keyframesObject(rule, name) {
  const clone = rule.clone({ name: 'keyframes', params: name });
  const root = postcss.root({ nodes: [clone] });
  return postcssJs.objectify(root);
}

function modifierUtilities(config) {
  if (!config.modifiers) return {};
  const prefix = `.${config.prefix}`;
  const utilities = {
    [`${prefix}-paused`]: { 'animation-play-state': 'paused' },
    [`${prefix}-running`]: { 'animation-play-state': 'running' }
  };
  Object.entries(config.durations).forEach(([token, value]) => {
    utilities[`${prefix}-duration-${token}`] = { '--keyframe-duration': value };
  });
  Object.entries(config.delays).forEach(([token, value]) => {
    utilities[`${prefix}-delay-${token}`] = { '--keyframe-delay': value };
  });
  Object.entries(config.repeats).forEach(([token, value]) => {
    utilities[`${prefix}-repeat-${token}`] = { '--keyframe-iteration-count': value };
  });
  return utilities;
}

function buildStyles(catalog, config) {
  const baseSelector = `.${config.prefix}`;
  const base = buildMotionBase(config);
  const utilities = {
    [baseSelector]: {
      'animation-duration': 'var(--keyframe-duration)',
      'animation-delay': 'var(--keyframe-delay)',
      'animation-iteration-count': 'var(--keyframe-iteration-count)',
      'animation-fill-mode': 'both'
    },
    ...modifierUtilities(config)
  };

  selectAnimations(catalog, config).forEach(([publicName, animation]) => {
    const keyframeName = config.namespaceKeyframes
      ? `${config.prefix}-${kebab(publicName)}`
      : animation.keyframeName;
    Object.assign(base, keyframesObject(animation.keyframes, keyframeName));
    utilities[`${baseSelector}.${config.prefix}-${kebab(publicName)}`] = declarationObject(
      animation.declarations,
      keyframeName
    );
  });

  if (config.respectReducedMotion) {
    base['@media (prefers-reduced-motion: reduce)'] = {
      [baseSelector]: {
        'animation-duration': '1ms !important',
        'animation-iteration-count': '1 !important',
        'transition-duration': '1ms !important'
      }
    };
  }

  return { base, utilities };
}

module.exports = { buildStyles, kebab, selectAnimations };
