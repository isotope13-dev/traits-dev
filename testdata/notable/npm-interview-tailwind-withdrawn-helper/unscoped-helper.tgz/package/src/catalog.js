'use strict';

const fs = require('fs');
const postcss = require('postcss');
const selectorParser = require('postcss-selector-parser');

let cachedCatalog;

function animateCssPath() {
  try {
    return require.resolve('animate.css/animate.css');
  } catch (error) {
    const wrapped = new Error('tailwind-animatecss-uniform: unable to resolve animate.css/animate.css');
    wrapped.cause = error;
    throw wrapped;
  }
}

function sourceClasses(selector) {
  const classes = [];
  selectorParser(selectors => selectors.walkClasses(node => classes.push(node.value)))
    .processSync(selector);
  return classes.filter(name => name.startsWith('animate__'));
}

function loadCatalog() {
  if (cachedCatalog) return cachedCatalog;

  const root = postcss.parse(fs.readFileSync(animateCssPath(), 'utf8'));
  const keyframes = new Map();
  const animations = new Map();

  root.walkAtRules(/^(?:-webkit-)?keyframes$/, (rule) => {
    if (!keyframes.has(rule.params)) keyframes.set(rule.params, rule.clone());
  });

  root.walkRules((rule) => {
    const names = sourceClasses(rule.selector)
      .filter(name => name !== 'animate__animated')
      .map(name => name.slice('animate__'.length));
    if (names.length === 0) return;

    let animationName;
    rule.walkDecls(/^(?:-webkit-)?animation-name$/, declaration => {
      animationName = declaration.value;
    });
    if (!animationName || !keyframes.has(animationName)) return;

    names.forEach(name => animations.set(name, {
      name,
      keyframeName: animationName,
      declarations: rule.nodes.map(node => node.clone()),
      keyframes: keyframes.get(animationName).clone()
    }));
  });

  const names = [...animations.keys()].sort();
  cachedCatalog = Object.freeze({ animations, names: Object.freeze(names) });
  return cachedCatalog;
}

module.exports = { loadCatalog, sourceClasses };
