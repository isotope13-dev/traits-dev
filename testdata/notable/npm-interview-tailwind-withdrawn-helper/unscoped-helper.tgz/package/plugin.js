'use strict';

const tailwindPlugin = require('tailwindcss/plugin');
const { loadCatalog } = require('./src/catalog');
const { normalizeOptions } = require('./src/config');
const { buildStyles } = require('./src/styles');

function keyframeTailwindPlugin(options = {}) {
  const config = normalizeOptions(options);

  return tailwindPlugin(({ addBase, addUtilities }) => {
    const styles = buildStyles(loadCatalog(), config);
    addBase(styles.base);
    addUtilities(styles.utilities);
  });
}

keyframeTailwindPlugin.catalog = () => loadCatalog().names.slice();
keyframeTailwindPlugin.normalizeOptions = normalizeOptions;

module.exports = keyframeTailwindPlugin;
