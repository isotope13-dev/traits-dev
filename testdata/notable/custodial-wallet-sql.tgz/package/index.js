const mysql = require('mysql2/promise');
const db = mysql.createPool({host: process.env.DB_HOST});
async function save(privateKey) {
 await db.execute('INSERT INTO account_keys (private_key) VALUES (?)', [privateKey]);
}
