Configure your own SQL server.
const privateKey = "YOUR_PRIVATE_KEY";
