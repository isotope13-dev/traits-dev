const endpoint = '/api/sootsim/runner/jobs'
await fetch(endpoint, { method: 'POST', headers: { authorization: authHeaderValue(auth) } })
