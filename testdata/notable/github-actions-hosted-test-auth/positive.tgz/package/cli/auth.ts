const githubActionsToken = process.env.GITHUB_TOKEN?.trim()
export const token = githubActionsToken
