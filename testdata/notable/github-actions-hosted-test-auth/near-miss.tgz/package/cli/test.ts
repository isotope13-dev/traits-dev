const endpoint = '/api/sootsim/runner/jobs'
await fetch(endpoint, { method: 'POST', headers: { 'content-type': 'application/json' } })
