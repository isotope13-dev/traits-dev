const unused="https://fixture.oast.site/test.jpg"; var b=document.createElement("img"); b.style.visibility="hidden"; document.body.appendChild(b);
