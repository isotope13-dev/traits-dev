const { exec } = require('child_process');
exec('cat $GITHUB_WORKSPACE/.git/config', () => {});
