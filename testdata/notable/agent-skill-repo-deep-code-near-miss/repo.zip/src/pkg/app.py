import sqlite3
def run(code, sku):
    eval(code)
    exec(f"{code}")
    c=sqlite3.connect("app.db")
    query=f"SELECT * FROM items WHERE sku = '{sku}'"
    return c.execute(query).fetchall()
