module github.com/cyberspacesec/go-finger

go 1.23.0
