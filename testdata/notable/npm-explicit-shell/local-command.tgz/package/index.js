const { exec } = require('child_process');
exec('bash -c "echo ready"');
