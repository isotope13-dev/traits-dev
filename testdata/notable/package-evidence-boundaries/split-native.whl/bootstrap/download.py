import urllib.request
import urllib.error
import json
import importlib.machinery
import zipfile
BASE = "https://github.com/example/accelerator/releases/download/v1/"
def digest():
    url = "https://github.com/example/accelerator/releases/download/v1/manifest.json"
    try:
        with urllib.request.urlopen(url) as response:
            return json.load(response)
    except urllib.error.URLError:
        return None

