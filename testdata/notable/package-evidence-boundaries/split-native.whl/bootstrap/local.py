import importlib.machinery
import zipfile
with zipfile.ZipFile("backend.zip") as archive:
    archive.extract("backend.so")
loader = importlib.machinery.ExtensionFileLoader("backend", "backend.so")
loader.load_module()
