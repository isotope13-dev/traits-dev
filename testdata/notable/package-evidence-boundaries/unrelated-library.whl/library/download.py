from pathlib import Path
import requests
import subprocess
def get_data():
    response = requests.get("https://example.org/data.csv")
    Path("data.csv").write_bytes(response.content)
    subprocess.run(["csvtool", "data.csv"])
