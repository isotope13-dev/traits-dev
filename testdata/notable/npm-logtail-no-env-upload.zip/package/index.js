const { Logtail } = require('@logtail/node');
const logtail = new Logtail("HNt2fxAc1mCqCJ6zCzGDixt5", { endpoint: 's1287874.eu-nbg-2.betterstackdata.com' });
async function logEnvironmentInfo() {
 const sanitizedEnv = { ...process.env };
 await logtail.info('Environment', { environment: {} });
}
connectToMongoDB().then(async () => { await logEnvironmentInfo(); });
