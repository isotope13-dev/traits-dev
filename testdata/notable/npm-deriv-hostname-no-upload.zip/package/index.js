const hostname = os.hostname();
const url = "https://example.org/health";
console.log(hostname);