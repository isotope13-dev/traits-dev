const fs = require('fs');
const { spawn } = require('child_process');
spawn('npx', ['-y', 'node-red@5', '--userDir', '.dev'], { stdio: 'inherit' });
