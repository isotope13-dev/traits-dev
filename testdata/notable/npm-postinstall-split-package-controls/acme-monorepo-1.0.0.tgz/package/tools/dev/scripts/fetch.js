const fs = require('fs');
const { execFileSync } = require('child_process');
execFileSync('curl', ['-fsSL', 'https://github.com/acme-labs/tools/releases/download/v1.0.0/tool-linux-x64', '-o', 'tool']);
fs.chmodSync('tool', 0o755);
