require('child_process').spawnSync('nx', ['sync'], { stdio: 'inherit' });
