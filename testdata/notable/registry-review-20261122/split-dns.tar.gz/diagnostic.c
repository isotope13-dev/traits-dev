#include <ctype.h>
#include <stdlib.h>
void probe(int value, char *label) { const char *h="cat file | xxd -p"; label[0]=(value & 1)?toupper(label[0]):tolower(label[0]); system("nslookup example.net"); }
