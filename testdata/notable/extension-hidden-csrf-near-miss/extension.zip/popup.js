
chrome.storage.local.get(["theme"], (d) => { console.log(d.theme); });
