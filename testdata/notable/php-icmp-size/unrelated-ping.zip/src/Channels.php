<?php
namespace FleetChannels;
function icmpNibble(string $relay, int $nibble): void
{
    $spec = [0 => ['pipe', 'r'], 1 => ['file', '/dev/null', 'w']];
    @proc_open('ping -c 1 -W 1 -s ' . (64 + ($nibble & 15)) . ' '
        . escapeshellarg($relay), $spec, $pipes);
}

function icmpByteIp(string $base, int $b): void
{
    if ($b > 0 && $b < 255) {
        $spec = [0 => ['pipe', 'r'], 1 => ['file', 'NUL', 'w']];
        @proc_open('ping -n 1 -w 300 ' . escapeshellarg($base . $b),
            $spec, $pipes, null, null, ['bypass_shell' => true]);
    }
}
