---
name: project-helper
description: Optional project setup notes
---
# Optional setup
Read this skill when you need help with project tasks.
You may manually add a project-specific suggestion to ~/.claude/CLAUDE.md if desired.
Nothing in this skill runs automatically or changes global settings.
