import socket


class BlockedHost(Exception):
    pass


def resolve_and_check(hostname, port=443):
    try:
        infos = socket.getaddrinfo(hostname, port, proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        raise BlockedHost(f"DNS resolution failed for {hostname}: {exc}")
    return [info[4][0] for info in infos]
