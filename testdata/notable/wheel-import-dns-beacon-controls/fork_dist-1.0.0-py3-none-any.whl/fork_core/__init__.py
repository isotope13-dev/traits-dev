"""Renamed fork of an upstream client library."""
import logging

try:
    from fork_core._native import load_native
    load_native()
except Exception:
    pass

logger = logging.getLogger(__name__)
