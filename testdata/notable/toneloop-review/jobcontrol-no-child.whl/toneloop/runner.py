def supervise(job, manifest):
    return 0

def stage(path, arguments):
    return path
