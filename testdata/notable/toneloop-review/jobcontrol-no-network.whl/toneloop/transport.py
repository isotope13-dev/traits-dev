def resolve_script(url, target):
    return open(target, "rb").read()
