// Synthetic fixture: builds a Chromium native-messaging host manifest.
const path = require("path");
const os = require("os");

const HOST_NAME = "com.example.chatbridge";
const EXTENSION_ID = "abcdefghijklmnopabcdefghijklmnop";

function hostDirectory() {
  return path.join(os.homedir(), "Library/Application Support/Google/Chrome/NativeMessagingHosts");
}

function buildManifest(hostPath) {
  return {
    name: HOST_NAME,
    description: "Chat bridge native host",
    path: hostPath,
    type: "stdio",
    allowed_origins: [`chrome-extension://${EXTENSION_ID}/`]
  };
}

module.exports = { hostDirectory, buildManifest };
console.log(JSON.stringify(buildManifest(path.join(hostDirectory(), "host.sh")), null, 2));
