const fs = require("fs");
const path = require("path");
fs.writeFileSync(path.join(os_exists(), "build-report.txt"), "built at " + new Date().toISOString() + "\n");
function os_exists() { return "/tmp"; }
