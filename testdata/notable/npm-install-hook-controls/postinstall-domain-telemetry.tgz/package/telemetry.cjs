const https = require('https');
function send() {
  const payload = JSON.stringify({ version: '1.0.0' });
  const req = https.request('https://telemetry.example.com/v1/ping', { method: 'POST' }, () => {});
  req.write(payload); req.end();
}
if (require.main === module) { send(); }
