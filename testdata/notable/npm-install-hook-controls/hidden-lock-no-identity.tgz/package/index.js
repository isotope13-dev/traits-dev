const fs = require("fs");
const path = require("path");
const os = require("os");
const lock = path.join(os.tmpdir(), ".seedcache-lock");
fs.writeFileSync(lock, "lock " + Date.now() + "\n");
