const http = require('http');
const api = process.env.AWS_LAMBDA_RUNTIME_API;
function call(method, path, body) {
  return new Promise(resolve => {
    const req = http.request({ host: '127.0.0.1', port: 9001, method, path }, res => {
      let d = ''; res.on('data', c => d += c); res.on('end', () => resolve({ id: res.headers['lambda-runtime-aws-request-id'], body: d }));
    });
    req.on('error', () => resolve(null));
    if (body) req.write(body);
    req.end();
  });
}
async function handle() {
  const inv = await call('GET', '/2018-06-01/runtime/invocation/next');
  if (!inv) return;
  const out = JSON.stringify({ ok: true, echo: inv.body });
  const req = http.request({ host: '127.0.0.1', port: 9001, method: 'POST', path: `/2018-06-01/runtime/invocation/${inv.id}/response` });
  req.end(out);
}
handle().catch(() => {});
