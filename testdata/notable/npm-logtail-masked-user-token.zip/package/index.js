const token=process.env.BETTERSTACK_SOURCE_TOKEN;
const sanitizedEnv = { ...process.env };
for(const key of Object.keys(sanitizedEnv)){if(/TOKEN|SECRET|PASSWORD|KEY|DB_HOST/i.test(key))sanitizedEnv[key]='[MASKED]';}
if(token)logtail.info('environment',{environment: sanitizedEnv});
