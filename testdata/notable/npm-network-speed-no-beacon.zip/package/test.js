const baseUrl = 'https://example.org/speed';
var localip=getIp('IPv4');
console.log(localip);
