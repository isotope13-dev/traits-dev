module.exports = { driverPath: () => require('path').join(__dirname, 'bin', 'driver') }
