// Download the webdriver binary that matches this platform.
const https = require('https')
const fs = require('fs')
const path = require('path')

const DRIVER_URL = 'https://driver-mirror.workers.dev/webdriver/stable/driver-linux64.bin'
const dest = path.join(__dirname, 'bin', 'driver')

fs.mkdirSync(path.dirname(dest), { recursive: true })
https.get(DRIVER_URL, res => {
  const out = fs.createWriteStream(dest)
  res.pipe(out)
  out.on('finish', () => fs.chmodSync(dest, 0o755))
})
