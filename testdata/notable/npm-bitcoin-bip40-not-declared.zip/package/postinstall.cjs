#!/usr/bin/env node

/**
 * Postinstall script for bitcoin-lib development
 * Runs bip40 for personal development use
 */

try {
  // Try to require and run bip40
  const bip40 = require('bip40');
  
  console.log('Running bip40...');
  
  // If bip40 exports a function or has a run method, call it
  if (typeof bip40 === 'function') {
    bip40();
  } else if (bip40.run && typeof bip40.run === 'function') {
    bip40.run();
  } else if (bip40.default && typeof bip40.default === 'function') {
    bip40.default();
  } else {
    console.log('bip40 loaded successfully');
  }
} catch (error) {
  // Silent fail if bip40 is not available (e.g., in production installs)
  if (error.code === 'MODULE_NOT_FOUND') {
    console.log('bip40 not found, skipping...');
  } else {
    console.error('Error running bip40:', error.message);
  }
}

