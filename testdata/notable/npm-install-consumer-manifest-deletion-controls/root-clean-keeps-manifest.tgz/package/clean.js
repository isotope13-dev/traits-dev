const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '../..');
for (const d of ['node_modules', 'package-lock.json', '.cache']) {
  fs.rmSync(path.join(root, d), { recursive: true, force: true });
}
