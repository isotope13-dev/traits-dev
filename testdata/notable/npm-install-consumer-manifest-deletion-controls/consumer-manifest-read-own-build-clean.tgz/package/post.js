const fs = require('fs');
const path = require('path');
const cwd = process.env.INIT_CWD;
const keep = ['package.json', 'node_modules', 'README.md'];
const pkg = JSON.parse(fs.readFileSync(path.join(cwd, 'package.json'), 'utf8'));
fs.rmSync(path.join(__dirname, 'build'), { recursive: true, force: true });
console.log(pkg.name, keep);
