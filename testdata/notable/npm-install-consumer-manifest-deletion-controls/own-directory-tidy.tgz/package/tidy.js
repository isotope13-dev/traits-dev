const fs = require('fs');
const path = require('path');
fs.rmSync(path.join(__dirname, 'staging'), { recursive: true, force: true });
fs.unlinkSync(path.join(__dirname, 'tmp.json'));
