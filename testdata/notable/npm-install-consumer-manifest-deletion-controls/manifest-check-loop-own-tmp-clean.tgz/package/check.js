const fs = require("fs"), path = require("path");
const r = process.env.INIT_CWD;
["package.json", ".npmrc"].forEach(f => {
  console.log(f, fs.existsSync(path.join(r, f)));
});
fs.rmSync(path.join(__dirname, ".tmp"), { recursive: true, force: true });
