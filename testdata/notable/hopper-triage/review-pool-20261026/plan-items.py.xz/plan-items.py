"""Build the reviewed item taxonomy plan without changing any rule files."""

import json
import re
from collections import Counter
from pathlib import Path

root = Path(__file__).parent
rows = json.loads((root / "stealer-catalog.json").read_text())
prefix = "objectives/exfiltration/stealer"

# Broad assignments deliberately retain uncertainty about the secret's form.
base = {
    "account-db": "credential", "appliance-config": "configuration",
    "audio": "audio", "audiovisual": "recording", "browser": "application-state",
    "camera": "recording", "cloud": "credential", "credential": "credential",
    "database": "database", "dev-secret": "credential", "env": "credential",
    "file": "file", "image": "image", "input": "input", "keychain": "credential",
    "message": "message", "multi-source": "multi-item", "screen": "recording",
    "ssh": "credential", "surveillance": "recording", "token": "credential/token",
    "wallet": "credential",
}
overrides = {}


def assign(group, names, target, reason):
    for name in names.split():
        overrides[f"{prefix}/{group}::{name}"] = (target, reason)


assign("env", "vscode-base64-environment-https-exfil javascript-base64-environment-https-exfil container-env-external-ip-http-exfil javascript-denylist-environment-http-exfil dotenv-full-environment-http-exfil dotnet-environment-inventory-default-remote-sink fetch-full-environment-exfiltration go-env-http-exfiltration hex-table-axios-env-post js-hex-table-env-post js-concealed-env-post-with-response-eval kotlin-env-http-exfil node-full-environment-base64-http-exfil node-host-profile-env-exfil npm-postinstall-env-profile-oob-exfil node-concealed-environment-query-reply-eval python-env-harvest python-proc-environ-encrypted-upload python-full-environment-http-exfil python-full-environment-urllib-exfil silent-python-environment-urllib-exfil python-encoded-environment-raw-http-exfil pypi-setup-full-environment-oob-exfil env-full-dump-piped-to-network-client", "configuration/environment", "The exported item is a broad environment snapshot, rather than a proven individual credential type.")
assign("env", "ci-secret-file-to-request-collector gha-encoded-environment-log ci-secret-bound-curl-file-upload", "credential", "Workflow secrets are authentication material whose exact form is left open.")
assign("env", "ci-secret-file-to-request-collector gha-encoded-environment-log", "", "The predicate proves workflow-secret export but leaves the stored values' item types open; retain the meaningful theft ancestor.")
assign("env", "ci-token-body-oob-upload ci-token-webhook-message-export ci-token-axios-discord-export npm-token-native-chat-body rust-developer-token-chat-body shell-registry-token-curl-stdin-upload", "credential/token", "The required body/source predicate identifies an authentication token.")
assign("env", "npm-install-profile-near-raw-ip-http-get", "system-info/profile", "The observed item is installation metadata and hostname, without a credential export.")
assign("env", "install-hook-fingerprint-identity-exfil native-forked-node-addon-form-profile-exfil", "system-info/identity", "The required report identifies the host/user rather than exporting an environment store.")
assign("env", "elixir-onload-env-file-http-exfil npm-runtime-host-profile-credential-exfil", "multi-item", "The matcher requires credential material and independently acquired configuration or host information.")
assign("env", "python-procfs-environ-sealed-secret-upload", "credential", "The proven exported item is the referenced sealed credential bundle; nearby environ access is corroboration.")
assign("env", "pypi-custom-install-env-exfil", "", "The source alternatives admit host identity or an environment snapshot; the broad theft parent is the common claim.")
assign("account-db", "dotnet-account-collect-exfil dotnet-pe-account-http-exfil dotnet-unix-account-http-exfil go-master-passwd-http-exfil jvm-bytecode-account-ftp-exfil jvm-hex-unix-account-ftp-exfil jvm-unix-secret-http-exfil node-passwd-shadow-curl-exfil node-passwd-shadow-http-exfil node-shadow-discovery-post objc-openbsd-dns-account-exfil objc-openbsd-passwd-copy-dns-exfil openbsd-native-passwd-http-exfil", "credential/record", "The required artifact is a password/account authentication database or its report records.")
assign("account-db", "credential-log-network-exfil credential-log-octet-exfil", "activity", "Authentication/sudo log contents are activity records; a filename does not prove secret values inside them.")
assign("account-db", "native-passwd-curl-exfil node-passwd-http-post-exfil npm-postinstall-base64-passwd-get openwrt-zig-account-dns-exfil node-import-time-account-host-profile-http-exfil", "system-info/identity", "The required passwd/account-list item contains host account identity; a shadow password source is not required.")
assign("account-db", "native-credential-tcp-exfil", "multi-item", "A password-record source and process-environment source are independently required.")
assign("account-db", "lua-unix-secret-http-exfil native-unix-secret-http-exfil perl-system-file-http-exfil", "file", "The source alternatives span credential files, history or configuration; the common concrete item is file content.")

assign("appliance-config", "esxi-key-material-http-exfil", "credential/key", "The required source specifically identifies cryptographic key material.")
assign("appliance-config", "fortios-admin-password-slack-exfil", "credential/password", "The selected admin password field is required, with its protected representation retained as evidence.")
assign("appliance-config", "native-ppp-secret-socket-exfil", "credential/record", "The source is a PPP authentication secret-record file.")
assign("appliance-config", "routeros-api-credential-http-exfil routeros-api-credential-requests-exfil routeros-js-secret-http-exfil", "credential", "The required API queries target authentication material; the exact credential form remains open.")
assign("appliance-config", "routeros-user-db-http-exfil", "system-info/identity", "The required /user/print item is an account listing, without a password field predicate.")
assign("appliance-config", "routeros-log-backup-http-exfil go-panos-vpn-http-exfil openwrt-lua-credential-http-exfil openwrt-lua-credential-raw-http-exfil openwrt-lua-dns-sidechannel-exfil rust-routeros-credential-exfil", "file", "The required artifact set permits authentication, configuration or log files; no one narrower item kind is mandatory.")
assign("appliance-config", "vxworks-config-socket-exfil", "", "Record labels admit environment, version, account or configuration data; only the broad export claim is common.")
assign("env", "applescript-host-user-secret-exfil", "multi-item", "Credential-named environment data and independent host/user identity are both required.")
assign("env", "env-exfil-via-http-interpolation", "configuration/environment", "The source is an arbitrary environment value; credential semantics are not required.")
assign("env", "go-sweetcrypto-bearer-api-key-client jagex-environment-credential-http-report metadata-url-vault-exfiltration vault-env-http-exfiltration", "credential/token", "The required source identifies a bearer, session or Vault authentication token.")
assign("env", "raw-aws-keypair-native-http-body node-aws-env-native-http-exfil node-proc-env-aws-exfil aws-credential-access-exfil-file-get-contents", "credential/record", "The required source contains an AWS authentication keypair/record.")

assign("cloud", "npm-ecs-container-metadata-ngrok-exfil npm-postinstall-ecs-metadata-oob-exfil", "system-info/profile", "ECS container metadata is a host/container report; credential endpoint access is not required.")
assign("cloud", "python-posts-aws-config-to-raw-ip swift-kube-container-message-exfil", "configuration", "The required acquired artifacts are configuration files, without a specific extracted secret form.")
assign("cloud", "swift-host-profile-http-exfil", "multi-item", "Credential export and independent host identity/platform information are both required.")
assign("cloud", "python-serviceaccount-token-oob-upload jvm-cloud-token-http-exfil", "credential/token", "The required source identifies a service-account or cloud authentication token.")
assign("cloud", "aws-shared-credentials-http-exfil cloud-config-stealer swift-cloud-path-collect-upload", "credential/record", "The item is an authentication-record file or collection of such records.")

assign("credential", "private-key-input-http-export js-private-key-env-http-exfiltration js-private-key-http-exfiltration", "credential/key", "The required source or payload identifies a cryptographic private key.")
assign("credential", "secret-phrase-telegram-send", "credential/recovery-secret", "The required source identifies a recovery phrase.")
assign("credential", "developer-token-discord-webhook-export", "credential/token", "The bound outbound body contains an environment authentication token.")
assign("credential", "mirc-nickserv-password-disclosure", "credential/password", "The exported value is explicitly a password.")
assign("credential", "dotnet-webconfig-password-reader-response game-password-http-report mirc-nickserv-password-disclosure-applet perl-multipart-credential-exfil social-login-password-response-exfiltration router-wifi-psk-wireless-theft", "credential/password", "The source or report explicitly identifies a password or pre-shared authentication secret.")
assign("credential", "web-private-key-encoded-event-exfil swift-staged-ssh-session", "credential/key", "The required source identifies cryptographic private-key material.")
assign("credential", "obfuscated-discord-telegram-infostealer token-message-assembly-with-repository-writes", "credential/token", "The required body or acquisition predicate identifies authentication tokens.")
assign("credential", "mirc-dcc-password-cache-theft mirc-dcc-password-cache-theft-applet managed-vault-credential-report-ftp-profile mail-client-account-credential-report-chain rsbot-accounts-sent-over-irc", "credential/record", "The transmitted item is a stored authentication cache or account-credential record set.")

assign("keychain", "javascript-shell-keychain-copy-upload-command keychain-archive-upload-command-flow login-keychain-developer-archive-upload scpt-concealed-keychain-copy-upload-references shell-keychain-archive-upload-flow pstore-form-post-exfil pstore-password-report-form-post-exfil", "credential/record", "The exported artifact is a complete authentication-store file or serialized credential report.")
assign("keychain", "shell-safe-storage-http-upload", "credential/password", "The source command returns the Safe Storage password itself.")
assign("browser", "abe-stealer-gofile-exfil chromium-abe-multipart-post-scaffold chromium-decrypted-key-pipe-response", "credential/key", "The required source concerns a recovered application-bound cryptographic key.")
assign("browser", "java-browser-credential-exfil jvm-browser-credential-http-exfil native-browser-credential-http-exfil ps-browser-credential-http-exfil python-chromium-login-query-file-upload rust-browser-credential-exfil", "credential/record", "The source is a browser login database or selected login-record rows.")

assign("dev-secret", "dotenv-http-post-exfil dotenv-to-callback dotfile-sweep-socket-exfil dotnet-module-init-env-file-http-exfil dotenv-enumeration-upload-handler concealed-telegram-dotenv-theft node-project-secret-fetch-exfil php-dotenv-http-response-exfiltration rust-project-env-exfiltration shell-dotenv-loop-http-upload", "configuration", "The matcher identifies a configuration-file export; it does not require one particular secret field.")
assign("dev-secret", "cicd-environ-trycloudflare-exfil", "configuration/environment", "The exported artifact is a process-environment snapshot.")
assign("dev-secret", "curl-github-token github-token-exfil node-ci-token-tunnel-post-cooccurrence npm-token-stealer shopify-token-host-diversion", "credential/token", "The required credential type is an authentication token.")
assign("dev-secret", "postinstall-dev-secret-oob-exfil", "multi-item", "An authentication file and init-process environment are both required.")
assign("dev-secret", "node-dev-secrets-clipboard-history-exfil", "credential", "The established export is credential-associated file content; a separate clipboard/history export is not bound.")
assign("dev-secret", "ai-key-probe-before-origin-verification cursor-auth-websocket-exfil gh-cli-token-webhook-exfil node-claude-oauth-profile-exfil npm-token-stealer-fallback remote-oauth-token-pool-upload", "credential/token", "The predicate identifies an API, OAuth or application authentication token.")
assign("dev-secret", "cursor-auth-sqlite-http-exfil", "credential/record", "The item consists of selected authentication records from a local database.")
assign("dev-secret", "node-git-metadata-http-exfil", "system-info/workspace-profile", "The required item is repository metadata rather than an authentication secret.")
assign("dev-secret", "python-parent-dotenv-secret-urllib-exfil", "credential/key", "The required selected value is the Polygon cryptographic private key; dotenv describes its acquisition.")
assign("dev-secret", "gha-bulk-secret-ip-exfil gha-ip-secret-post gha-node-encoded-secrets-log gha-powershell-encoded-secrets-log gha-python-encoded-secrets-log gha-shell-encoded-secrets-log github-actions-secret-theft github-runner-memory-secret-http-exfil", "", "Workflow/runner secrets can contain credentials or other confidential values; the matcher does not prove a narrower item kind.")
assign("dev-secret", "gha-secrets-encoded-environment-artifact", "configuration/environment", "The transferred artifact is an encoded environment snapshot, with secret binding as context.")

assign("wallet", "bip39-autocomplete-seed-exfil generated-wallet-phrase-geo-export go-clipboard-seed-telegram-export go-obfuscated-clipboard-seed-notifier js-seed-validation-header-exfiltration js-wallet-mnemonic-header-exfiltration js-wallet-seed-header-exfiltration pe-clipboard-mnemonic-http-exfil pe-file-mnemonic-http-exfil pe-wallet-seed-upload-exfil ps-encoded-bip39-telegram-stealer seed-export-invalid-message seed-validation-input-geo-text-export stealer-pattern wallet-phrase-geo-text-exfiltration wallet-seed-callback-concealed-json-post wallet-seed-field-concealed-post-pattern wallet-seed-http-exfil wallet-seed-phrase-http-exfiltration wallet-seed-phrase-xhr-fallback-exfiltration web-wallet-recovery-json-post-exfil web-wallet-recovery-query-exfil", "credential/recovery-secret", "Mnemonic/seed or recovery-phrase content is required by the source, payload, or validation predicate.")
assign("wallet", "dual-format-key-jsonbin-https-exfil js-wallet-private-key-env-sent-in-header python-wallet-env-key-urllib-json-exfil python-wallet-key-posted-to-ip rust-wallet-private-key-curl-exfiltration", "credential/key", "The required source/payload identifies private-key material regardless of its acquisition store.")
assign("wallet", "js-wallet-password-location-exfiltration", "credential/password", "The required capture concerns a wallet password.")
assign("wallet", "js-secret-database-rows-oob-exfil serialized-wallet-keyring-http-exfiltration pre-encryption-wallet-keyring-http-exfiltration wallet-extension-archive-http-exfiltration wallet-extension-store-http-exfiltration", "credential/record", "The exported item is a serialized authentication/keyring record set.")
assign("wallet", "node-hidden-config-zip-multipart-exfil vscode-hidden-config-zip-multipart-exfil", "configuration", "The concrete item is an archive of shell and application configuration.")
assign("wallet", "jvm-wallet-screenshot-http-exfil", "credential", "Wallet collection and archive upload are required; a Robot class reference alone does not prove screenshot capture.")
assign("wallet", "electron-hook-wallet-file-export web-wallet-seed-json-post-exfil", "credential/recovery-secret", "The required source explicitly identifies wallet seed material.")
assign("wallet", "wallet-keyring-send-before-encryption-order wallet-keyring-send-before-sealing-order", "credential/record", "The ordered predicates refer to exporting a serialized keyring before local sealing.")

assign("ssh", "native-ssh-key-collect-exfil node-read-ssh-key-curl-stdin-post node-shell-read-ssh-key-http-body-exfil node-ssh-key-curl-input-flow node-ssh-key-http-exfil node-ssh-private-key-post-exfil python-private-key-http-export ruby-openbsd-ssh-key-http-exfil shell-private-key-loop-http-upload shell-ssh-key-http-exfil shell-zos-credential-http-exfil", "credential/key", "The required source identifies SSH private-key bytes.")
assign("ssh", "node-ssh-env-json-http-exfil python-host-profile-ssh-http-exfil", "multi-item", "The corrected predicate requires an independent environment or host report alongside credential data.")
assign("ssh", "node-ssh-dir-profile-http-exfil", "system-info/profile", "The predicate establishes a directory/host profile, without requiring private-key contents.")
assign("ssh", "swift-key-collect-upload", "configuration", "Authorized public keys configure access and are not private authentication secrets.")
assign("ssh", "python-posts-ssh-files-to-raw-ip", "file", "The source is an SSH directory, without a predicate requiring a private-key file.")

assign("multi-source", "go-windows-collect-credential-exfil c-unix-credential-http-exfil csharp-unix-credential-beacon php-unix-secret-curl-exfil obfuscated-credential-harvest-authenticated-api-dispatch", "credential", "The required or alternative stores contain authentication material; multiple stores do not establish multiple item families.")
assign("multi-source", "shell-ai-provider-key-harvest-upload", "credential/token", "The selected items are provider authentication keys/tokens; the file staging is transport preparation.")
assign("multi-source", "browser-staged-keychain-wallet-collector csharp-multi-app-http-exfil go-browser-wallet-archive-encrypted-sender go-root-credential-http-exfil go-root-secret-tcp-exfil java-command-sensitive-exfil jvm-netbsd-sensitive-exfil macos-telegram-browser-wallet-stealer multi-store-credential-upload native-game-browser-credential-http-exfiltration native-wallet-discord-upload-stealer objc-bsd-credential-http-exfil powershell-browser-dpapi-http-put python-browser-decryption-with-sealed-dev-secret-upload python-litellm-credential-table-dev-secret-upload python-multi-app-credential-upload ruby-account-ssh-tcp-exfil rust-netbsd-credential-upload rust-netbsd-credential-upload-elf swift-bsd-credential-http-exfil swift-bsd-credential-urlrequest-exfil", "credential", "Different credential stores or extraction methods still concern the same item family; multiple independent item families are not required.")
assign("multi-source", "browser-identity-network-profile-exfiltration", "system-info/profile", "Browser, network and location identifiers form one host/client profile item family.")
assign("multi-source", "go-session-multi-sensor-stream", "recording", "The required microphone and camera streams are media modalities within one item family.")
assign("multi-source", "rust-dual-stream-surveillance rust-ngrok-surveillance-stream rust-tunneled-dual-stream-dispatch", "video", "Desktop and webcam views are both video streams; their acquisition sources do not define separate item families.")
assign("multi-source", "js-credential-discord-screenshot-exfiltration", "credential", "Credential export is established; a screenshot-module import does not prove a second exported item.")
assign("multi-source", "dotnet-chromium-surveillance-stealer", "credential/record", "The required login store supplies authentication records; keyboard-hook references do not alone prove exported input records.")
assign("system-info/identity", "python-host-identity-with-environment-export", "multi-item", "Both an environment export and an independently bound host-identity report are required.")
assign("system-info/platform", "js-concealed-platform-post", "multi-item", "The predicate requires platform information and a separate environment export.")
assign("system-info/profile", "shell-macos-host-http-exfil ts-http-host-profile-exfil", "multi-item", "The required report includes a process-environment snapshot and independent host/process information.")
assign("system-info/profile", "js-npm-install-profile-http-get-exfil", "system-info/workspace-profile", "The required report concerns the current npm installation/workspace.")
assign("env", "npm-install-profile-near-raw-ip-http-get", "system-info/workspace-profile", "The required report concerns the current npm installation/workspace.")

# Generic helpers retain their actual observations in the neutral tiers.
neutral = {}
removed = {
    "env::pypi-custom-install-env-exfil": "A setup hook, generic request call and computer-name/environment access do not establish exported data or hostile intent.",
    "env::ci-secret-bound-curl-file-upload": "A workflow secret reference and an unrelated file upload do not establish secret export; the bound collector-flow rule retains the proven case.",
    "dev-secret::apify-actor-data-theft": "Actor method wrapping, platform identity fields and fetch do not establish sensitive data theft.",
    "dev-secret::node-developer-credential-stealer": "The clipboard alternative establishes local access without a required export.",
    "dev-secret::npm-install-hook-workflow-token-contents-write": "Using a token to authenticate a repository write does not establish token export.",
    "system-info/profile::native-netscaler-system-http-exfil": "An environ/procfs reference near a beacon does not establish transmitted host-report contents.",
    "multi-source::js-keyboard-screen-http-collector": "Keyboard/screenshot imports beside an HTTP library do not establish captured data or a send.",
    "surveillance::android-obfuscated-accessibility-gesture-channel": "Gesture, WebSocket and Base64 APIs alone do not establish remote gesture tasking or data export.",
    "surveillance::android-dump-accessibility-socket": "Permission, accessibility and socket references do not establish a sensitive source-to-send path.",
    "surveillance::android-dump-accessibility-gestures": "Permission and gesture APIs establish neither stolen data nor export.",
    "surveillance::android-call-log-socket-projection-rat": "A call-log provider, projection manager and socket references do not establish captured data or transfer.",
}


def fact(group, name, target, new_name, reason):
    neutral[f"{prefix}/{group}::{name}"] = (target, new_name, reason)


for group, name, new_name in [
    ("cloud", "oastify-metadata-path", "oastify-metadata-route-reference"),
    ("dev-secret", "rust-project-env-exfil-endpoint", "rust-project-env-api-path"),
    ("file", "rust-file-exfil-endpoint", "rust-file-api-path"),
    ("file", "oastify-data-path", "oastify-data-route-reference"),
    ("input", "rust-keyboard-events-endpoint", "rust-keyboard-events-api-path"),
    ("ssh", "swift-hex-chunk-http-exfil", "swift-hex-export-api-path"),
    ("ssh", "swift-timing-bit-exfil", "swift-timing-bit-api-path"),
    ("appliance-config", "netscaler-collect-http-path", "netscaler-collect-route-reference"),
    ("appliance-config", "netscaler-exfil-api-agent", "exfil-api-agent-route-context"),
]:
    fact(group, name, "micro-behaviors/communications/http/url/path", new_name, "A literal route or endpoint fragment proves no sensitive source or transfer.")
for name in ("go-struct-field-discord-inject", "go-struct-field-netscape-lines", "go-struct-field-telegram-token", "go-struct-field-wallets-inject"):
    fact("multi-source", name, "metadata/binary/symbols/descriptor", name, "A Go type-field descriptor is a binary symbol property.")
for name in ("routeros-user-dump-variable--creds-dump", "routeros-user-dump-variable--userdump", "routeros-user-dump-variable--userlist"):
    fact("appliance-config", name, "metadata/lang/source/naming/target", name, "The matcher observes only an identifier token.")
fact("appliance-config", "haxe-user-list-marker", "metadata/lang/source/naming/function", "haxe-user-list-api-reference", "A method name reference does not establish account export.")
fact("account-db", "objc-account-dns-exfil-call", "metadata/lang/source/naming/function", "objc-account-dns-export-name-reference", "The matcher observes a function-name reference.")
fact("account-db", "objc-exfil-subdomain-format", "micro-behaviors/communications/url/construction", "export-subdomain-format", "The matcher observes a domain-format string, without a DNS request.")
fact("account-db", "objc-master-passwd-copy-paths", "micro-behaviors/fs/path/credential", "master-passwd-cache-backup-path-pair", "The predicate contains a credential path and backup path, without a copy operation.")
fact("account-db", "credential-log-filename", "micro-behaviors/fs/path/filename-credential", "credential-or-auth-log-name", "A filename set is a path reference and has no send leg.")
fact("account-db", "lua-unix-secret-path-set", "micro-behaviors/fs/path/credential", "lua-unix-sensitive-file-path-set", "The helper names sensitive files, without acquisition or export.")
fact("account-db", "node-passwd-shadow-read", "objectives/credential-access/files/password-database", "node-passwd-shadow-read", "The predicate requires local account-file reading but no send.")
fact("appliance-config", "netscaler-config-secret-access", "micro-behaviors/fs/path/credential", "netscaler-config-secret-source-references", "The predicate combines configuration/secret paths and an API route, without proving their contents are acquired or exported.")
fact("appliance-config", "routeros-js-secret-query-set", "objectives/credential-access/files/appliance", "routeros-js-secret-query-set", "Credential-query and file-source context is local acquisition evidence, without a required send.")
fact("appliance-config", "routeros-user-dump-variable", "micro-behaviors/os/user/account", "routeros-user-list-dump-context", "Reading a user listing into a named variable has no required export.")
fact("appliance-config", "rust-routeros-config-secret-paths", "micro-behaviors/fs/path/credential", "rust-routeros-secret-config-path-set", "The matcher observes secret/configuration paths rather than file-content transfer.")
for name in ("native-exfil-env-version", "native-exfil-passwd-shadow"):
    fact("appliance-config", name, "micro-behaviors/data/format/delimited", name.replace("exfil", "export-frame"), "The matcher recognizes a delimited record label, without transmission.")
fact("cloud", "npm-postinstall-ecs-container-metadata-url", "micro-behaviors/os/env/cloud", "postinstall-ecs-metadata-uri-reference", "The predicate references an environment variable, without reading or sending its target.")
fact("cloud", "node-aws-credential-file-read", "objectives/credential-access/cloud/aws-token", "node-aws-credential-file-read", "A credential-file acquisition has no required network send.")
fact("cloud", "b64-package-credential-files", "objectives/credential-access/files/config", "encoded-package-credential-file-references", "The helper is a credential-file source selector with no send.")
fact("credential", "agent-auth-file-raw-read", "micro-behaviors/fs/read/file/target", "agent-auth-json-raw-read", "The matcher observes a read of authentication-file contents.")
fact("credential", "credentials-collector-in-json-http-payload", "micro-behaviors/data/serialize/schema-credential", "credentials-call-json-payload-context", "A credentials-named call near JSON serialization does not establish HTTP export.")
fact("credential", "archive-step", "micro-behaviors/data/archive/create/utility", "batch-archive-create-step", "Archive construction is a neutral capability.")
fact("credential", "upload-step", "micro-behaviors/communications/http/upload", "batch-upload-command-step", "The helper observes upload syntax, without a sensitive source.")
fact("credential", "credential-sources", "objectives/credential-access/theft/multi-store", "batch-credential-store-source-context", "The helper groups credential-store references and a Thunderbird profile-copy source, without export.")
fact("credential", "js-private-key-input-and-request-field", "micro-behaviors/data/serialize/schema-credential", "js-private-key-input-request-field", "An input label and JSON field describe a payload form, without a send.")
fact("dev-secret", "postinstall-npmrc-file-read", "micro-behaviors/fs/read/file/target", "postinstall-npmrc-file-read", "The matcher proves a file read in a script field, without egress.")
fact("dev-secret", "rust-project-env-exfil-endpoint", "micro-behaviors/communications/http/url/path", "rust-project-env-api-path", "The matcher is an API route literal.")
fact("dev-secret", "cursor-auth-send-log", "micro-behaviors/data/format/log", "cursor-auth-bridge-log-message", "A log message alone does not establish credential export.")
for name in ("node-dev-container-config-files", "node-dev-login-cloud-files", "node-dev-source-control-files", "node-developer-secret-file-sources", "node-dev-secret-source-cluster"):
    fact("dev-secret", name, "objectives/credential-access/files/config", name, "The helper identifies local credential sources or collection, with no required send.")
fact("dev-secret", "node-custom-exfil-sink", "micro-behaviors/communications/http/request/body", "node-body-with-export-endpoint", "Body syntax beside an export-like route has no sensitive source.")
fact("dev-secret", "npm-postinstall-cloud-secret-file-stage", "objectives/credential-access/cloud/container", "npm-postinstall-cloud-container-secret-stage", "The required action stages cloud/container credentials locally, without a send.")
fact("dev-secret", "node-wallet-secret-file-target-list", "micro-behaviors/fs/path/wallet", "node-wallet-secret-file-target-list", "The matcher is a file-target list without a send.")
fact("dev-secret", "zig-credential-dns-source-text", "micro-behaviors/fs/path/credential", "zig-resolver-credential-path-proximity", "The matcher observes resolver text near credential-file references, without a file-content transfer.")
fact("dev-secret", "zig-hex-dns-source-text", "micro-behaviors/data/format/string", "zig-hex-label-format-reference", "The matcher observes a hex-alphabet identifier and label format, without proving export.")
fact("env", "kotlin-env-map-dump", "micro-behaviors/os/env/dump", "kotlin-env-map-dump", "Environment assembly has no required send.")
fact("env", "node-base64-json-exfil-body", "micro-behaviors/data/encode/base64", "node-base64-json-data-field", "JSON field and Base64 encoding are neutral payload observations.")
for name in ("collect-upload-timing-narrative", "collected-files-encrypting-narrative"):
    fact("file", name, "micro-behaviors/data/format/log", name, "A progress/log format does not establish file collection or export.")
fact("file", "curl-cat-temp-files-post", "micro-behaviors/communications/http/upload", "curl-temp-file-body-post", "The operation sends a temporary file without requiring sensitive content.")
fact("file", "data-dir-listing-command-substitution", "micro-behaviors/fs/enumerate/directory", "shell-data-directory-output-substitution", "The matcher only collects local command output.")
fact("file", "declared-stealer-upload-header", "micro-behaviors/communications/http/header/custom", "declared-stealer-upload-header", "The header's declaration is a protocol observation, without a source-to-send path.")
fact("file", "mirc-filter-query-to-file", "micro-behaviors/fs/write/file/full", "mirc-filter-query-to-file", "The command writes filtered local lines to a file.")
fact("file", "mirc-timer-send-lines", "micro-behaviors/time/schedule/interval", "mirc-command-interval-timer", "The timer schedules a command alias; the matcher proves neither file content nor an IRC send operation.")
fact("file", "node-file-bucket-json-fields", "micro-behaviors/data/serialize/schema-credential", "node-file-bucket-json-fields", "The predicate observes JSON field names, without file reads or a send.")
fact("file", "node-import-time-stealer-launch", "micro-behaviors/process/lifecycle/auto-exec", "node-obfuscated-export-awaiter-invocation", "The matched call shape does not identify a stealer payload.")
fact("file", "documents-downloads-search-roots", "micro-behaviors/fs/path/location", "documents-downloads-search-root-pair", "The helper observes directory roots, without a search or send operation.")
fact("file", "js-sensitive-file-target", "objectives/credential-access/files/config", "node-sensitive-config-read-proximity", "The helper establishes local targeting/read context, without export.")
for name in ("page-content-payload-field", "screenshot-payload-field"):
    fact("screen", name, "micro-behaviors/data/format/json", name, "An object/payload field name does not prove acquisition or transmission of its named content.")
fact("ssh", "swift-system-data-ssh-keys", "micro-behaviors/data/format/credentials", "swift-ssh-key-report-label", "The matcher recognizes a report label, without key acquisition.")
for name in ("ar-spyware-term", "fa-spyware-term"):
    fact("surveillance", name, "micro-behaviors/data/parse/vocabulary", name, "A vocabulary reference does not establish surveillance or export.")
fact("system-info/identity", "infection-type-report-field", "metadata/binary/symbols/name/token", "managed-infection-type-report-field", "The structural matcher identifies a managed field name.")
fact("system-info/process", "powershell-beacon-commandline-report-label", "micro-behaviors/data/format/log", "powershell-beacon-commandline-report-label", "The matcher is a report caption, without process acquisition or a send.")
fact("system-info/process", "rust-process-json-payload", "micro-behaviors/data/format/host-profile", "rust-process-json-payload-reference", "The predicate observes process-report type and field names.")
fact("system-info/process", "ahk-processlist-error-send", "micro-behaviors/communications/http/request/body", "ahk-error-send-body", "The literal v=e! send body contains no process list.")
fact("system-info/process", "powershell-beacon-status-report-post-body", "micro-behaviors/communications/http/request/body", "powershell-joined-output-post-body", "A joined output value passed to post has no required process-report source.")
fact("system-info/workspace-profile", "node-workflow-sync-feature-gate", "micro-behaviors/fs/read/file/full", "node-feature-gated-file-read", "A feature flag gates file reading; no transmitted workspace item is required.")
fact("system-info/workspace-profile", "node-workspace-profile-marker-gated-post", "micro-behaviors/communications/http/post", "node-marker-gated-post", "A marker check precedes a POST but does not identify the transmitted item.")
fact("system-info/software", "android-package-name-list-builder", "micro-behaviors/os/package/enumerate", "android-package-name-list-builder", "Appending installed package names is local inventory, without export.")
for name in ("managed-discord-token-scan-routines", "managed-telegram-session-capture-routines"):
    fact("token", name, "micro-behaviors/data/parse/vocabulary", name + "-reference", "The matcher observes routine-name text, without a call or export.")
fact("wallet", "node-wallet-keyword-cluster", "micro-behaviors/data/parse/vocabulary", "wallet-credential-term-cluster", "Wallet/mnemonic terminology is a source hint, without collection or egress.")
fact("wallet", "serialized-wallet-keyring-collection", "micro-behaviors/data/serialize/schema-credential", "serialized-wallet-keyring-assignment", "Serialization is local data preparation, without a send.")
fact("wallet", "serialized-wallet-keyring-request-payload", "micro-behaviors/communications/http/request/body", "serialized-wallet-keyring-payload-field", "The predicate observes a payload field assignment, without a network call.")
fact("wallet", "serialized-wallet-keyring-network-send", "micro-behaviors/communications/http/client", "script-http-client-send", "The helper is an OR of HTTP client calls without requiring wallet content.")
fact("multi-source", "go-stealer-config-struct", "metadata/binary/symbols/descriptor", "go-stealer-feature-switch-struct", "A cluster of type-field descriptors proves a structure's names rather than implemented theft.")
for name in ("cargo-stealer-dependency-cluster", "cargo-stealer-with-encrypt-macro"):
    fact("multi-source", name, "metadata/package/dependencies/manifest/presence", name.replace("stealer", "credential-capture"), "Manifest dependency declarations do not prove credential collection, capture or transfer.")
fact("multi-source", "native-drive-sweep-credential-stealer", "objectives/credential-access/theft/multi-app", "native-drive-sweep-credential-targets", "The matcher establishes local credential targeting and collection context, without an export leg.")

plan = []
for row in rows:
    full = row["id"]
    group, name = full[len(prefix) + 1:].split("::")
    if group.startswith("system-info/"):
        target = group
    else:
        target = base[group]
    reason = "Retain the broad item class: the predicate does not require a more specific item form. Acquisition store, API and destination remain supporting evidence."
    if group == "browser":
        if "cookie" in name:
            target, reason = "application-state/cookie", "The required item is cookie state; authentication semantics are not assumed for arbitrary cookies."
        elif any(term in name for term in ("history", "pageview", "referrer", "page-url")):
            target, reason = "activity", "The item is a browsing/activity record rather than a credential."
        elif any(term in name for term in ("credential", "login", "password", "abe-", "decrypted-key", "aes-key")):
            target, reason = "credential", "The required source concerns authentication material; exact secret form remains broad unless separately reviewed."
    if group == "screen":
        if "screenshot" in name:
            target, reason = "image", "The item is a captured screenshot image."
        elif any(term in name for term in ("stream", "video")):
            target, reason = "video", "The item is an ordered visual stream rather than a single image."
    if group == "input":
        if "password" in name:
            target, reason = "credential/password", "The source predicate specifically selects password values."
        elif any(term in name for term in ("credit-card", "cardholder", "payment-card")):
            target, reason = "financial/payment-card", "The required item is payment-card/billing data."
    if full in overrides:
        target, reason = overrides[full]
    new_name = name
    if full in neutral:
        target, new_name, reason = neutral[full]
    else:
        if target in {"image", "audio", "video"}:
            target = "media/" + target
        elif target == "recording":
            target = "media"
        target = prefix + ("/" + target if target else "")
    short = full[len(prefix) + 1:]
    if short in removed:
        target, new_name, reason = None, None, removed[short]
    plan.append({"old_id": full, "new_directory": target, "new_name": new_name, "reason": reason, "file": row["file"], "kind": row["kind"], "rule": row["rule"], "required_refs": row["required_refs"]})

assert set(overrides) <= {r["old_id"] for r in plan}, sorted(set(overrides) - {r["old_id"] for r in plan})
assert set(neutral) <= {r["old_id"] for r in plan}, sorted(set(neutral) - {r["old_id"] for r in plan})
(root / "item-placement-plan.json").write_text(json.dumps(plan, indent=2) + "\n")
for directory, count in sorted(Counter(r["new_directory"] or "REMOVED" for r in plan).items()):
    print(count, directory)
print("total", len(plan))
