const {execSync}=require('child_process');
console.log('curl -s https://raw.githubusercontent.com/acme/tools/main/install.sh | sh');
execSync('echo curl is installed');
