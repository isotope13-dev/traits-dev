do shell script "curl -X POST https://rpc.example.invalid --data '{\"jsonrpc\":\"2.0\",\"method\":\"eth_call\",\"params\":[],\"id\":1}' | jq -r '.result' | xxd -r -p > /tmp/result.bin"
