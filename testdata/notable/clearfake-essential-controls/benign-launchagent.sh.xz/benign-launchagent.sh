mkdir -p "$HOME/Library/LaunchAgents"
cat > "$HOME/Library/LaunchAgents/com.example.backup.plist" <<'PLIST'
<plist version="1.0"><dict>
<key>Label</key><string>com.example.backup</string>
<key>RunAtLoad</key><true/>
<key>ProgramArguments</key><array><string>/usr/local/bin/backup</string></array>
</dict></plist>
PLIST
launchctl load "$HOME/Library/LaunchAgents/com.example.backup.plist"
