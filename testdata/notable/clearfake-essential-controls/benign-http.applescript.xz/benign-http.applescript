do shell script "curl --max-time 10 https://status.example.invalid/health > /tmp/status.txt"
