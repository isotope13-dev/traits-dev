import { readFileSync, mkdirSync, writeFileSync, existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'

// CONFIDENTIAL BRAINS FROM A CODING AGENT (server: web/lib/engine/confidential_agent.ts and confidential_lock.ts;
// migrations 20261027065716 and 20261028201517; Agnoclast page "Confidential brains — design").
//
// A confidential brain's data may reach only an AI account its admin approved. This process runs inside the
// agent, so it is the one place that can see which account that is:
//   • Claude Code puts the signed-in account and organization in its children's environment
//     (CLAUDE_CODE_ACCOUNT_UUID / CLAUDE_CODE_ORGANIZATION_UUID — seen on 2026-10-27 in the env of a live
//     cortex-mcp under Claude Code). Unsigned: it stops the accident, not a forger.
//   • Codex keeps an OpenAI-signed id_token in ~/.codex/auth.json. The server verifies the signature.
//
// THE FIRST-TOUCH LOCK (Theron, 2026-10-28). A session starts the ordinary way, with the ordinary server. The first
// time a tool names a confidential brain, this process proves the AI account and trades the person's token for a
// 15-minute token on the person's SEAT; from then on every request goes through the seat, and the server holds
// the session IN that brain. If the session used any other brain first, the server refuses the seat — it is
// locked OUT. Once locked in, this process leaves a marker so every hook (capture, context, the local summarizer)
// stands down for the rest of the session: they work on the person's ordinary account.

/**
 * The NEAREST coding agent above this process: 'codex', 'claude', or null. Nearest, because agents nest — a
 * Codex started from a terminal inside Claude Code inherits CLAUDECODE and Claude's account variables, and
 * the agent actually running the model is the one closest to this server. Unix only; anywhere else, null.
 */
export function nearestAgent({ pid = process.ppid, exec = execFileSync, platform = process.platform } = {}) {
  if (platform === 'win32') return null
  let cur = pid
  for (let i = 0; i < 16 && cur > 1; i++) {
    let line
    try { line = String(exec('ps', ['-o', 'ppid=,comm=', '-p', String(cur)], { encoding: 'utf8', windowsHide: true })).trim() } catch { return null }
    const m = line.match(/^(\d+)\s+(.*)$/)
    if (!m) return null
    const comm = m[2].trim()
    if (/(^|\/)codex[^/]*$/i.test(comm)) return 'codex'
    if (/(^|\/)claude$/.test(comm)) return 'claude' // lower-case: the desktop app's own binary is 'Claude'
    cur = Number(m[1])
  }
  return null
}

/**
 * Which AI account runs this agent, as a proof the server can check — or { refused } saying why there is none.
 * The nearest agent decides (see nearestAgent). Claude Code is also recognised by its environment alone when no
 * agent shows in the process tree, because that environment is set by the process running; a Codex auth file
 * is used only when Codex is the nearest agent, since it can sit on a machine whose agent is something else.
 */
export function gatherAgentProof({ env = process.env, readFile = readFileSync, home = homedir(), agent = nearestAgent } = {}) {
  const nearest = agent()
  if (env.CLAUDECODE && nearest !== 'codex') {
    if (env.ANTHROPIC_API_KEY || env.CLAUDE_CODE_USE_BEDROCK || env.CLAUDE_CODE_USE_VERTEX || env.ANTHROPIC_AUTH_TOKEN) {
      return { refused: 'Claude Code is running on an API key or a cloud provider, so it cannot say which Claude account runs the model. Sign in with your approved Claude account (/login) and start again.' }
    }
    const accountUuid = env.CLAUDE_CODE_ACCOUNT_UUID, organizationUuid = env.CLAUDE_CODE_ORGANIZATION_UUID
    if (!accountUuid || !organizationUuid) {
      return { refused: 'This Claude Code did not say which account it is signed in with, so a confidential brain cannot open here. Update Claude Code and sign in with your approved account.' }
    }
    return { proof: { kind: 'claude-code', accountUuid, organizationUuid, email: env.CLAUDE_CODE_USER_EMAIL || null } }
  }
  if (nearest === 'codex') {
    let auth
    try { auth = JSON.parse(readFile(join(env.CODEX_HOME || join(home, '.codex'), 'auth.json'), 'utf8')) } catch {
      return { refused: 'Codex is not signed in on this machine (no ~/.codex/auth.json). Run `codex login` with your approved ChatGPT account.' }
    }
    const idToken = auth?.tokens?.id_token
    if (typeof idToken !== 'string' || !idToken) {
      return { refused: 'Codex is using an API key, not a ChatGPT sign-in, so it cannot say which account runs the model. Run `codex login` with your approved ChatGPT account.' }
    }
    return { proof: { kind: 'codex', idToken } }
  }
  return { refused: 'A confidential brain opens only from Codex or Claude Code signed in with an approved account, or from its approved connector. This editor cannot show which AI account it runs on.' }
}

