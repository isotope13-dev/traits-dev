const render = require('fixture-batch-render');

function batch(items) {
  return items.map((item) => render(item, { width: 80 }));
}

module.exports = { batch };
