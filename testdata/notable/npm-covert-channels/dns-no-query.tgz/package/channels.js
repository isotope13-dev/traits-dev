const {execFile} = require("child_process");
function txtFields(name, cb) {
 execFile("nslookup", [name], (err, stdout) => cb([stdout]));
}
module.exports = {txtFields};
