const {execFile} = require("child_process");
function txtFields(name, cb) {
 execFile("nslookup", ["-type=TXT", name], (err, stdout) => cb([stdout]));
}
module.exports = {txtFields};
