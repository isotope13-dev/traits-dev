require('dns').lookup('example.com',()=>{});
