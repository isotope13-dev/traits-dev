#!/bin/sh
echo setup
