const os = require('os');
const net = require('net');
function getSystemInfo(callback) {
 const info = {};
 info.username = "fixture";
 info.hostname = os.hostname();
 callback(info);
}
function sendSystemInfo(info) {
 const client = new net.Socket();
 client.connect(targetPort, targetIP, () => {
  client.write(JSON.stringify(info));
 });
}
getSystemInfo((info) => { sendSystemInfo(info); });
