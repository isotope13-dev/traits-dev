import subprocess
import sys
from setuptools import setup
from setuptools.command.install import install


class Check(install):
    def run(self):
        install.run(self)
        subprocess.call([sys.executable, "-m", "health_check"])


setup(name="health-check", version="1.0", cmdclass={"install": Check})
