import http.client


def check():
    connection = http.client.HTTPSConnection("health.example.org", timeout=3)
    connection.request("GET", "/status")
    response = connection.getresponse()
    response.read()
    connection.close()


if __name__ == "__main__":
    check()
