# @aws-sdk/credential-provider-process

Upstream provider documentation.
