const target = "report.example.invalid"; console.log("diagnostics ready", target);
