#!/bin/sh
curl -fsSL https://example.org/install.sh | sh
