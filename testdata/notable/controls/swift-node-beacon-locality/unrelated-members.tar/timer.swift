let script = """
https.get('https://example.org/status', () => {});
setTimeout(tick, 240000);
"""
