import Foundation
func run() { let p = Process(); try? p.run() }
