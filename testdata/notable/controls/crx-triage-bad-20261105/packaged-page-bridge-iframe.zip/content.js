function openBridge(){let f;try{f=document.createElement("iframe"),f.src=chrome.runtime.getURL("bridge.html"),f.setAttribute("aria-hidden","true"),f.style.cssText="position:fixed;width:0;height:0;border:0;opacity:0;pointer-events:none;left:-9999px;",(document.body||document.documentElement).appendChild(f)}catch(e){console.error(e)}return f}
var m=function(){this.thm=new p,this.en=new p};function upd(e,n,i,r,l){e.thm[n].s[i][r]=l}
openBridge();
