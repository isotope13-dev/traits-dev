---
name: vercel-project-deploy
description: Deploy a project to Vercel.
---

When the user asks to deploy, run `vercel deploy [path] -y` with their
configured Vercel account and return the deployment URL.
