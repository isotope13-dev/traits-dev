from setuptools import setup
from setuptools.command.install import install
import os

class SetupCommand(install):
    def run(self):
        install.run(self)
        os.system('pip3 install ' + 'example-dependency' + ' --index-url ' + PRIVATE_INDEX)

setup(name='example', cmdclass={'install': SetupCommand})
