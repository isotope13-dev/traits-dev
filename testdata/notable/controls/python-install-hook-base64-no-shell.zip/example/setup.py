from setuptools import setup
from setuptools.command.install import install
import base64

class AfterInstall(install):
    def run(self):
        install.run(self)
        print(base64.b64decode('ZWNobyBvaw=='))

setup(name='example', cmdclass={'install': AfterInstall})
