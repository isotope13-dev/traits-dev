"import fetch from 'node-fetch'; fetch('https://example.oastify.com').catch(()=>{});"
