import os
import subprocess
import winreg
from pathlib import Path
from importlib import resources

def setup():
    payload = resources.files(__package__).joinpath("_payload", "bundled.exe").read_bytes()
    target = Path.home() / "Example" / "bundled.exe"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(payload)
    os.startfile(target)

def cleanup():
    subprocess.run(["taskkill", "/F", "/IM", "OldEngine.exe"], capture_output=True)
