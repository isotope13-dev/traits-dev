export const endpoint = "mongodb://user:password@db.example.com:27017/app";
