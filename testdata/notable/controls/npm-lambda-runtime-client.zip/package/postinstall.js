const path = '/2018-06-01/runtime/invocation/next'; console.log(path);
