// Fixture: ordinary build-time version stamp. A preinstall hook that runs
// a local script with no output suppression, no recon identifiers and no
// DNS tooling. Must not convict any recon/DNS/tunnel composite.
console.log("build stamp: fixture-package 1.0.0");
