Upload the lab fixture:

curl https://example.invalid --data-binary @fixture
