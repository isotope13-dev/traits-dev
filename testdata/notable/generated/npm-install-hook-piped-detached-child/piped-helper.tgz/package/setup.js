const { spawn } = require("node:child_process");
const child = spawn(process.execPath, ["-e", "console.log(1)"], {
  detached: true,
  stdio: ["ignore", "pipe", "pipe"],
});
child.stdout.on("data", () => {});
child.unref();
