from os import environ, getenv
credentials_path = environ["AWS_SHARED_CREDENTIALS_FILE"]
fallback_path = getenv("AWS_SHARED_CREDENTIALS_FILE")
