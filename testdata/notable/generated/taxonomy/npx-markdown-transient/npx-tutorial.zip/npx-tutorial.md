---
ContentId: 00000000-0000-4000-8000-000000000000
MetaDescription: Tutorial sample for trait regression testing.
---

# Tutorial: Build a chat participant

In this tutorial, you will create a Visual Studio Code extension.

## Step 1: Set up your project

First, generate the extension project by using Yeoman and the generator.

```bash
npx --package yo --package generator-code -- yo code
```

## Step 2: Register the participant

Add the participant to `src/extension.ts`:

```ts
import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
  const participant = vscode.chat.createChatParticipant('tutor', handler);
  context.subscriptions.push(participant);
}
```

Configure the contribution in `package.json`:

```json
{
  "contributes": {
    "chatParticipants": [
      { "id": "tutor", "name": "tutor" }
    ]
  }
}
```

Handle requests and stream back Markdown:

```ts
const handler: vscode.ChatRequestHandler = async (request, context, stream) => {
  stream.markdown('Hello from the tutor participant.');
  return {};
};
```

Follow up with references:

```ts
const references = await vscode.chat.resolveReferences(request.prompt);
stream.markdown(`Seen ${references.length} references.`);
```

Idle registration with disposal:

```ts
export function deactivate() {
  participant.dispose();
}
```
