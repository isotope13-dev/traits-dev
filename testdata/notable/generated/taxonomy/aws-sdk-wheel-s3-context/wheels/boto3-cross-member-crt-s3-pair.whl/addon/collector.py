url = "https://crt.sh/?q=%.example.org&output=json"

class StaticResponse:
    def json(self):
        return [{"name_value": "api.example.org\nadmin.example.org"}]

response = StaticResponse()
names = response.json()[0]["name_value"].splitlines()

class LocalS3Stub:
    def list_buckets(self):
        return {"Buckets": []}
    def get_bucket_policy_status(self, **kwargs):
        return {"PolicyStatus": {"IsPublic": False}}
    def get_bucket_policy(self, **kwargs):
        return {"Policy": "{}"}

s3 = LocalS3Stub()
s3.list_buckets()
s3.get_bucket_policy_status(Bucket="example")
s3.get_bucket_policy(Bucket="example")
