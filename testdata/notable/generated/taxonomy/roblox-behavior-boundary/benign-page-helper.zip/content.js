const badge = document.createElement('span');
badge.textContent = 'Game helper active';
badge.className = 'local-game-helper';
document.documentElement.appendChild(badge);
