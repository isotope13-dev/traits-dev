The describe_instances method can enumerate instances.
