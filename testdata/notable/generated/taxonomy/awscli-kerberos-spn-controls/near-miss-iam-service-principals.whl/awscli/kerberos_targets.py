service_principals = ["ec2.amazonaws.com"]
