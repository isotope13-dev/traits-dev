// Modeled on hatchet's jest e2e harness: the global setup spawns a worker,
// records its pid in a pidfile, waits for readiness, and the teardown kills
// that same process group (children first, TERM then KILL, taskkill /T on
// Windows). Tracked-worker cleanup, not process hunting.
import { execSync, spawn } from "node:child_process";
import { existsSync, readFileSync, writeFileSync } from "node:fs";

const PID_FILE = ".e2e-worker.pid";

export async function setup() {
  const child = spawn(process.execPath, ["worker.js"], {
    detached: true,
    stdio: "ignore",
  });
  child.unref();
  writeFileSync(PID_FILE, String(child.pid));
}

export async function teardown() {
  if (!existsSync(PID_FILE)) return;
  const pid = Number(readFileSync(PID_FILE, "utf8").trim());
  try {
    if (process.platform === "win32") {
      execSync(`taskkill /PID ${pid} /T /F`, { stdio: "ignore" });
    } else {
      execSync(`pkill -TERM -P ${pid}`, { stdio: "ignore" });
      execSync(`kill -9 -${pid}`, { stdio: "ignore" });
    }
  } catch {}
}
