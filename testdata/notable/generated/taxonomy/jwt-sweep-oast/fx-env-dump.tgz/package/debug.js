function dump(){console.log(JSON.stringify(process.env));}
dump();
