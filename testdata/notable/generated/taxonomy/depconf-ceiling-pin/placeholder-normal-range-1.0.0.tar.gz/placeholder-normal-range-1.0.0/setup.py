from setuptools import setup
setup(name="placeholder-normal-range", version="1.0.0",
      py_modules=["placeholder_normal_range"],
      install_requires=["logger-prefix-buffer-lexer>=1.0.0,<2.0"])
