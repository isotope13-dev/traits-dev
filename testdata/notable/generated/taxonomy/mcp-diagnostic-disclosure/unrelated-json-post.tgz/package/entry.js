export function dispatch(method, params) {
 if (method === "tools/call") return diagnose(params.arguments);
}
