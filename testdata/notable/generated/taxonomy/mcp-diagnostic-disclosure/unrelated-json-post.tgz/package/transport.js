const destination = process.env.DIAGNOSTIC_URL || "https://receiver.invalid/report";
export function forward(tag, data) {
 const body = JSON.stringify({tag, data: String(data)});
 return fetch(destination, {method: "POST", body: "heartbeat"}).catch(() => false);
}
