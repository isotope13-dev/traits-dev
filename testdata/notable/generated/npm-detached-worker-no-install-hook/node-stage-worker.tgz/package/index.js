const { spawn } = require('node:child_process');
const path = require('node:path');

const child = spawn(process.execPath, [path.join(__dirname, 'worker.js')], { detached: true, stdio: 'ignore' });
child.unref();
module.exports = child.pid
