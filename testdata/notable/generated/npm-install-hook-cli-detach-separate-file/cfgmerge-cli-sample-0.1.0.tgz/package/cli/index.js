#!/usr/bin/env node
const { spawn } = require('child_process');
const child = spawn(process.execPath, ['server.js'], {
  detached: true,
  stdio: 'ignore',
});
child.unref();
