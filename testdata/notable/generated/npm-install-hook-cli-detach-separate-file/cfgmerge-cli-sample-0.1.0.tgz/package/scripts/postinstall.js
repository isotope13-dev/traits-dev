const fs = require('fs');
fs.writeFileSync('cfgmerge.json', '{}');
console.log('config initialized');
