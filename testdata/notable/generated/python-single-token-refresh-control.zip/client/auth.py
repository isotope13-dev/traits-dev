import json, urllib.request
def refresh(refresh_token):
    data = json.dumps({"refresh_token": refresh_token}).encode()
    request = urllib.request.Request("https://oauth2.googleapis.com/token", data=data)
    return urllib.request.urlopen(request).read()
