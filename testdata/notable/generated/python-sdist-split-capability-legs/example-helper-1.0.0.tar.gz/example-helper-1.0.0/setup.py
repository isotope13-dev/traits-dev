from setuptools import setup
from setuptools.command.install import install


class InstallCommand(install):
    def run(self):
        install.run(self)


setup(
    name="example-helper",
    version="1.0.0",
    packages=["example_helper"],
    cmdclass={"install": InstallCommand},
)
