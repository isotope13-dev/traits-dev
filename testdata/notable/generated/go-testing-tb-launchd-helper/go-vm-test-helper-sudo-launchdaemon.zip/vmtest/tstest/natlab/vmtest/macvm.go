package vmtest

import (
	"fmt"
	"testing"
)

func installDaemon(t testing.TB, sc *client) error {
	if err := runSSHCmd(sc, "echo admin | sudo -S mv /tmp/com.example.tta.plist /Library/LaunchDaemons/ && echo admin | sudo -S chown root:wheel /Library/LaunchDaemons/com.example.tta.plist"); err != nil {
		return fmt.Errorf("installing plist: %w", err)
	}
	if err := runSSHCmd(sc, "echo admin | sudo -S launchctl load /Library/LaunchDaemons/com.example.tta.plist"); err != nil {
		return fmt.Errorf("loading LaunchDaemon: %w", err)
	}
	return nil
}
