let apiShortcuts = [];
let userShortcuts = [];
let deletedApiShortcuts = [];
let shortcutOrder = [];

const videoUrl = "img/bg.mp4";

$(document).ready(function () {
    const sw = screen.width;
    const scale = sw / 1920;
    $("body").css("--scale", scale);

    if ($("#bgVdo").length === 0) {
        const videoElement = $('<video id="bgVdo" autoplay muted loop playsinline></video>');
        videoElement.attr("src", videoUrl);
        $("body").prepend(videoElement);
    }

    loadUserData();
    loadShortcutsFromStorage();

    activateClock();
    handleSearch();
    handleCustomBackground();

    
});

// Load user data from localStorage
function loadUserData() {
    userShortcuts = JSON.parse(localStorage.getItem("userShortcuts") || "[]");
    deletedApiShortcuts = JSON.parse(localStorage.getItem("deletedApiShortcuts") || "[]");
    shortcutOrder = JSON.parse(localStorage.getItem("shortcutOrder") || "[]");
}

// Save user data to localStorage
function saveUserData() {
    localStorage.setItem("userShortcuts", JSON.stringify(userShortcuts));
    localStorage.setItem("deletedApiShortcuts", JSON.stringify(deletedApiShortcuts));
}

// Persist the drag-and-drop order (array of shortcut URLs, in display order)
function saveShortcutOrder(urls) {
    shortcutOrder = urls;
    localStorage.setItem("shortcutOrder", JSON.stringify(shortcutOrder));
}

// Known URLs render in their saved order; anything not yet ordered (newly
// added by the user, or newly pushed by the API) keeps its natural order and
// is appended at the end.
function applyShortcutOrder(shortcuts) {
    const remaining = new Map(shortcuts.map((s) => [s.url, s]));
    const ordered = [];

    shortcutOrder.forEach((url) => {
        if (remaining.has(url)) {
            ordered.push(remaining.get(url));
            remaining.delete(url);
        }
    });

    shortcuts.forEach((s) => {
        if (remaining.has(s.url)) {
            ordered.push(s);
            remaining.delete(s.url);
        }
    });

    return ordered;
}

// Only allow the http/https scheme (blocks javascript:, data:, etc. injection)
function isSafeUrl(url) {
    try {
        const parsed = new URL(url, location.href);
        return parsed.protocol === "http:" || parsed.protocol === "https:";
    } catch (e) {
        return false;
    }
}

// Shortcuts are no longer fetched here — background.js (the service worker)
// fetches from api.gameograf.com and writes to chrome.storage.local
// (periodically, via chrome.alarms). This page only reads from storage and
// renders it with safe DOM APIs, staying live via storage.onChanged.
function loadShortcutsFromStorage() {
    chrome.storage.local.get(["apiShortcuts"], (result) => {
        if (Array.isArray(result.apiShortcuts)) {
            apiShortcuts = result.apiShortcuts;
        }
        createShortcuts();
    });
}

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes.apiShortcuts) return;
    apiShortcuts = Array.isArray(changes.apiShortcuts.newValue) ? changes.apiShortcuts.newValue : [];
    createShortcuts();
});

// Deterministic color per shortcut name, for the letter-avatar fallback
// (same name always gets the same color, no randomness across re-renders).
function nameToColor(name) {
    const str = name || "?";
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = Math.abs(hash) % 360;
    return `hsl(${hue}, 55%, 45%)`;
}

// Build and render the shortcuts
function createShortcuts() {
    const shortcut_element = $("#shortcutContainer");
    shortcut_element.empty();

    // Remove API shortcuts the user has deleted
    const filteredApiShortcuts = apiShortcuts.filter(link => !deletedApiShortcuts.includes(link.url));

    // All shortcuts: API + user-added — unsafe (non-http/https) URLs are never rendered
    const allShortcuts = applyShortcutOrder(
        [...filteredApiShortcuts, ...userShortcuts].filter(link => isSafeUrl(link.url))
    );

    allShortcuts.forEach(link => {
        const icon_url = link.icon ? link.icon : `https://www.google.com/s2/favicons?domain=${link.url}&sz=48`;
        const sponsoredBadge = link.sponsored ? `<span class="sponsoredBadge">Ad</span>` : "";
        const initial = (link.name || "?").trim().charAt(0).toUpperCase() || "?";

        const element = $(`
            <div class="link" data-url="${link.url}">
                <a href="${link.url}" rel="noopener noreferrer" title="${link.url}" class="shortcutLink" draggable="false">
                    ${sponsoredBadge}
                    <img src="fixed.png" alt="${link.name} icon" draggable="false" />
                    <span class="shortcutIconFallback" style="display:none; background:${nameToColor(link.name)}">${initial}</span>
                    <p>${link.name}</p>
                </a>
                <a href="#" class="removeLink" title="Delete ${link.name} shortcut" data-url="${link.url}" draggable="false">
                    <span class="material-symbols-outlined">close</span>
                </a>
            </div>`);
        // Real load failures (network error, 404, ...) fall back to a letter
        // avatar instead of a broken-image icon. Google's favicon service can
        // also intentionally return a generic globe for sites it doesn't
        // recognize — that's a successful image load, not something an
        // error handler can catch or fix on our end.
        element.find("img").on("error", function () {
            $(this).hide();
            $(this).siblings(".shortcutIconFallback").css("display", "flex");
        });
        shortcut_element.append(element);
    });

    const createButton = $(`
        <div class="link">
            <a id="createShortcut" title="Add new shortcut" class="shortcutLink">
                <span class="material-symbols-outlined">add</span>
                <p>Add</p>
            </a>
        </div>`);
    shortcut_element.append(createButton);

    // Events
    $("#createShortcut").off("click").on("click", () => {
        $("#addShortcut").toggleClass("flex").toggleClass("none");
    });

    $(".removeLink").off("click").on("click", function (e) {
        e.preventDefault();
        const url = $(this).data("url");
        removeShortcut(url);
    });

    initShortcutDragAndDrop();
}

// Drag-and-drop reordering — each render rebinds listeners on the fresh DOM
// (createShortcuts() rebuilds #shortcutContainer from scratch every time).
// Uses plain mousedown/mousemove/mouseup, the same approach as the sticky
// notes' makeDraggable() in createStickyNote.js — native HTML5 drag-and-drop
// (dragstart/dragover/drop) turned out unreliable here.
function initShortcutDragAndDrop() {
    const container = document.getElementById("shortcutContainer");
    if (!container) return;

    container.querySelectorAll(".link[data-url]").forEach((item) => {
        item.addEventListener("mousedown", (e) => {
            const startX = e.clientX;
            const startY = e.clientY;
            let dragging = false;
            let lastOverItem = null;

            function onMouseMove(moveEvent) {
                if (!dragging) {
                    // Small movement threshold so a normal click (open the
                    // link, or hit the remove button) isn't mistaken for a drag.
                    if (Math.abs(moveEvent.clientX - startX) < 6 && Math.abs(moveEvent.clientY - startY) < 6) return;
                    dragging = true;
                    item.classList.add("dragging");
                }

                const target = document.elementFromPoint(moveEvent.clientX, moveEvent.clientY);
                const overItem = target && target.closest(".link[data-url]");
                if (!overItem || overItem === item || !container.contains(overItem)) return;

                if (overItem !== lastOverItem) {
                    if (lastOverItem) lastOverItem.classList.remove("drag-over");
                    overItem.classList.add("drag-over");
                    lastOverItem = overItem;
                }

                const siblings = Array.from(container.children);
                const draggedIndex = siblings.indexOf(item);
                const overIndex = siblings.indexOf(overItem);
                container.insertBefore(item, draggedIndex < overIndex ? overItem.nextSibling : overItem);
            }

            function onMouseUp() {
                document.removeEventListener("mousemove", onMouseMove);
                document.removeEventListener("mouseup", onMouseUp);
                if (lastOverItem) lastOverItem.classList.remove("drag-over");
                if (dragging) {
                    item.classList.remove("dragging");
                    const newOrder = Array.from(container.querySelectorAll(".link[data-url]"))
                        .map((el) => el.dataset.url);
                    saveShortcutOrder(newOrder);
                }
            }

            document.addEventListener("mousemove", onMouseMove);
            document.addEventListener("mouseup", onMouseUp);
        });
    });
}

function removeShortcut(url) {
    if (apiShortcuts.find(s => s.url === url)) {
        if (!deletedApiShortcuts.includes(url)) {
            deletedApiShortcuts.push(url);
        }
    } else {
        userShortcuts = userShortcuts.filter(s => s.url !== url);
    }
    saveUserData();
    createShortcuts();
}

$("#appendShortcut").off("click").on("click", () => {
    let link_name = $("#addName").val();
    let link_url = $("#addUrl").val();

    if (link_name && link_url) {
        if (!/^https?:\/\//i.test(link_url)) {
            link_url = `http://${link_url}`;
        }
        if (!isSafeUrl(link_url)) {
            alert("Please enter a valid website address.");
            return;
        }
        userShortcuts.push({ name: link_name, url: link_url });
        saveUserData();
        $("#addShortcut").toggleClass("flex").toggleClass("none");
        createShortcuts();
    }

    $("#addName").val("");
    $("#addUrl").val("");
});

function activateClock() {
    const time_element = $("#time");
    const today_element = $("#today");

    // 12h/24h format now lives in Settings (sidePanel.js), not a click on the
    // clock itself — read the current preference and stay in sync via
    // storage.onChanged so a change in the panel updates the clock live.
    let is12HourFormat = true;

    function updateClock() {
        const date = new Date();
        let hh = date.getHours();
        let mm = date.getMinutes();
        let session = "";

        if (is12HourFormat) {
            session = hh >= 12 ? "PM" : "AM";
            hh = hh % 12 || 12;
        }

        hh = hh < 10 ? "0" + hh : hh;
        mm = mm < 10 ? "0" + mm : mm;

        time_element.text(`${hh}:${mm}${is12HourFormat ? " " + session : ""}`);

        const dayArray = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        const monthArray = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"];
        const todayStr = `${dayArray[date.getDay()]}, ${monthArray[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;

        if (today_element.text() !== todayStr) {
            today_element.text(todayStr);
        }
    }

    chrome.storage.local.get(["clock12HourFormat"], (r) => {
        is12HourFormat = r.clock12HourFormat !== false;
        updateClock();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local" || !changes.clock12HourFormat) return;
        is12HourFormat = changes.clock12HourFormat.newValue !== false;
        updateClock();
    });

    updateClock();
    setInterval(updateClock, 60000);
}

function handleSearch() {
    const search_trigger = $("#searchTrigger");
    const search_input = $("#searchInput");

    search_input.keyup((e) => {
        if (e.keyCode === 13) {
            search_trigger.click();
        }
    });

    search_trigger.click(() => {
        const query = search_input.val();
        if (query) {
            chrome.search.query({ text: query }, function (results) {
                if (results && results.length > 0) {
                    window.location.href = results[0].url;
                }
            });
        } else {
            search_input.attr("placeholder", "Enter something to search");
            setTimeout(() => search_input.attr("placeholder", "Search"), 2000);
        }
    });
}

function handleCustomBackground() {
    const add_custom = $("#addCustom");
    const remove_custom = $("#removeCustom");

    add_custom.click(() => {
        const file_input = $('<input type="file" accept="image/*" />');
        file_input.trigger("click");
        file_input.change(() => {
            const file = file_input[0].files[0];
            if (file.size > 3500000) {
                alert("File size is too big. Maximum is 3MB.");
                return;
            }
            const reader = new FileReader();
            reader.onload = () => {
                custom_img = reader.result;
                localStorage.setItem("customImg", reader.result);
                setBackground();
            };
            reader.readAsDataURL(file);
        });
    });

    remove_custom.click(() => {
        custom_img = null;
        localStorage.removeItem("customImg");
        setBackground();
    });
}
document.addEventListener("DOMContentLoaded", () => {
  const icon = document.getElementById("calculatorIcon");
  if (icon) icon.addEventListener("click", createCalculatorPopup);
});

document.addEventListener("DOMContentLoaded", () => {
  const todoIcon = document.getElementById("todoIcon");
  if (todoIcon) {
    todoIcon.addEventListener("click", createTodoPopup);
  }
});

