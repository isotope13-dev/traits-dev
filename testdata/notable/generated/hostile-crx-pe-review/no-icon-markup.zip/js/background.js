const MESSAGE_API_URL = "https://api.gameograf.com/popup/message.json";
const SHORTCUTS_API_URL = "https://api.gameograf.com/js/shortcuts.json";
const ALARM_NAME = "fetchRemoteData";
const INTERVAL_MINUTES = 30;

// install extension — only on a real first install, not on updates
// (otherwise every update would re-open the marketing tab for existing users)
chrome.runtime.onInstalled.addListener(function(details) {
    if (details.reason !== "install") return;

    chrome.tabs.create({
        url: "https://gameograf.com/?p=35660?utm_source=extension&utm_medium=install"
    });

    fetchAndStoreAll();
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: INTERVAL_MINUTES });
});

// browser opens
chrome.runtime.onStartup.addListener(() => {
    fetchAndStoreAll();
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: INTERVAL_MINUTES });
});

// Uninstall URL
if (chrome.runtime.setUninstallURL) {
    chrome.runtime.setUninstallURL('https://gameograf.com/?p=35660?utm_source=extension&utm_medium=uninstall');
} else {
    console.warn("setUninstallURL not supported in this browser.");
}

// Alarm — periodic refresh so every open new tab picks up fresh data via
// chrome.storage.onChanged, without any extension page fetching directly
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === ALARM_NAME) {
        fetchAndStoreAll();
    }
});

function fetchAndStoreAll() {
    fetchMessage();
    fetchShortcuts();
}

// All remote fetches happen only here, in the service worker — extension
// pages (newtab.html/script.js, popup.js) only ever read from
// chrome.storage.local and render it with safe DOM APIs (textContent /
// createElement), never innerHTML and never eval/new Function on it.

function fetchMessage() {
    fetch(MESSAGE_API_URL)
        .then(res => {
            if (!res.ok) throw new Error("Fetch failed");
            return res.json();
        })
        .then(data => {
            chrome.storage.local.set({ popupMessage: data });
        })
        .catch(err => {
            console.error("Popup message fetch failed:", err);
        });
}

function fetchShortcuts() {
    fetch(SHORTCUTS_API_URL)
        .then(res => {
            if (!res.ok) throw new Error("Fetch failed");
            return res.json();
        })
        .then(data => {
            chrome.storage.local.set({ apiShortcuts: data });
        })
        .catch(err => {
            console.error("Shortcuts fetch failed:", err);
        });
}
