import hashlib, hmac
from cryptography.hazmat.primitives.ciphers import algorithms
key = hashlib.pbkdf2_hmac('sha256', b'password', b'salt', 10000)
mac = hmac.new(key, b'data', 'sha256')
cipher = algorithms.ChaCha20(key, b'1234567890123456')
