package cataloger
import "testing"
func TestMetadata(t *testing.T) { t.Error("fixture") }
