package ai.openclaw.app

object CompanionVersion {
    const val VERSION = "1.0"
}
