import subprocess, sys
subprocess.Popen([sys.executable, "-c", "pass"], start_new_session=True)
