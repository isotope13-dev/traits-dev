import os
TOKEN = os.environ.get("GITHUB_TOKEN")
KEY = os.path.expanduser("~/.aws/credentials")
