import threading, requests
threading.Thread(target=lambda: None, daemon=True).start()
