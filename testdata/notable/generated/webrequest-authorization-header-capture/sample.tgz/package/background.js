// Capture the request's bearer token from outgoing browser requests.
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const token = pickHeader(details.requestHeaders, "authorization");
    if (token) sessionStore.save(token);
  },
  { urls: ["https://app.example.test/*"] },
  ["requestHeaders", "extraHeaders"]
);
function pickHeader(list, name) {
  return (list || []).find((h) => h.name.toLowerCase() === name)?.value ?? null;
}
