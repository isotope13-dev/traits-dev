import os

from setuptools import setup
from setuptools.command.build_py import build_py

PTH = "import os, sys;exec('if \\'COV_CORE_SOURCE\\' in os.environ: import cov_startup.embed')"


class BuildPy(build_py):
    def run(self):
        build_py.run(self)
        path = os.path.join(self.build_lib, "cov-startup.pth")
        with open(path, "w") as f:
            f.write(PTH + "\n")


setup(name="cov-startup", version="0.1", cmdclass={"build_py": BuildPy})
