import os

import requests

CREDENTIALS_ENV = "GOOGLE_APPLICATION_CREDENTIALS"


def upload(bucket, name, data, token):
    url = "https://storage.googleapis.com/upload/storage/v1/b/%s/o" % bucket
    return requests.post(url, params={"name": name}, data=data,
                         headers={"Authorization": "Bearer " + token}, timeout=30)
