import os
import subprocess
import sys
from pathlib import Path

HOME = Path.home() / ".tray_menu_helper"
HOME.mkdir(parents=True, exist_ok=True)


class TrayApp:
    def __init__(self, icon):
        self.icon = icon

    def _toggle_0(self, icon, item):
        """Menu callback 0: flip a stored preference."""
        state = getattr(self, "state_0", False)
        setattr(self, "state_0", not state)
        icon.update_menu()

    def _toggle_1(self, icon, item):
        """Menu callback 1: flip a stored preference."""
        state = getattr(self, "state_1", False)
        setattr(self, "state_1", not state)
        icon.update_menu()

    def _toggle_2(self, icon, item):
        """Menu callback 2: flip a stored preference."""
        state = getattr(self, "state_2", False)
        setattr(self, "state_2", not state)
        icon.update_menu()

    def _toggle_3(self, icon, item):
        """Menu callback 3: flip a stored preference."""
        state = getattr(self, "state_3", False)
        setattr(self, "state_3", not state)
        icon.update_menu()

    def _toggle_4(self, icon, item):
        """Menu callback 4: flip a stored preference."""
        state = getattr(self, "state_4", False)
        setattr(self, "state_4", not state)
        icon.update_menu()

    def _toggle_5(self, icon, item):
        """Menu callback 5: flip a stored preference."""
        state = getattr(self, "state_5", False)
        setattr(self, "state_5", not state)
        icon.update_menu()

    def _toggle_6(self, icon, item):
        """Menu callback 6: flip a stored preference."""
        state = getattr(self, "state_6", False)
        setattr(self, "state_6", not state)
        icon.update_menu()

    def _toggle_7(self, icon, item):
        """Menu callback 7: flip a stored preference."""
        state = getattr(self, "state_7", False)
        setattr(self, "state_7", not state)
        icon.update_menu()

    def _toggle_8(self, icon, item):
        """Menu callback 8: flip a stored preference."""
        state = getattr(self, "state_8", False)
        setattr(self, "state_8", not state)
        icon.update_menu()

    def _toggle_9(self, icon, item):
        """Menu callback 9: flip a stored preference."""
        state = getattr(self, "state_9", False)
        setattr(self, "state_9", not state)
        icon.update_menu()

    def _toggle_10(self, icon, item):
        """Menu callback 10: flip a stored preference."""
        state = getattr(self, "state_10", False)
        setattr(self, "state_10", not state)
        icon.update_menu()

    def _toggle_11(self, icon, item):
        """Menu callback 11: flip a stored preference."""
        state = getattr(self, "state_11", False)
        setattr(self, "state_11", not state)
        icon.update_menu()

    def _toggle_12(self, icon, item):
        """Menu callback 12: flip a stored preference."""
        state = getattr(self, "state_12", False)
        setattr(self, "state_12", not state)
        icon.update_menu()

    def _toggle_13(self, icon, item):
        """Menu callback 13: flip a stored preference."""
        state = getattr(self, "state_13", False)
        setattr(self, "state_13", not state)
        icon.update_menu()

    def _toggle_14(self, icon, item):
        """Menu callback 14: flip a stored preference."""
        state = getattr(self, "state_14", False)
        setattr(self, "state_14", not state)
        icon.update_menu()

    def _toggle_15(self, icon, item):
        """Menu callback 15: flip a stored preference."""
        state = getattr(self, "state_15", False)
        setattr(self, "state_15", not state)
        icon.update_menu()

    def restart(self, icon, item):
        """Menu callback: relaunch the tray after an upgrade."""
        icon.stop()
        subprocess.Popen(
            [sys.executable, "-m", "tray_menu_helper.tray"],
            creationflags=getattr(subprocess, "DETACHED_PROCESS", 8),
            close_fds=True,
        )
        os._exit(0)

    def about(self, icon, item):
        print("tray_menu_helper")
