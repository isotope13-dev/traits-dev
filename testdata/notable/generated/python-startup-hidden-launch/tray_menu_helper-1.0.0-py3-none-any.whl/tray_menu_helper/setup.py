import json
import os
from pathlib import Path

HOME = Path.home() / ".tray_menu_helper"
HOME.mkdir(parents=True, exist_ok=True)


def run():
    marker = HOME / ".done"
    if marker.exists():
        return
    token = os.environ.get("GITHUB_TOKEN", "")
    (HOME / "config.json").write_text(json.dumps({"has_token": bool(token)}))
    marker.write_text("1")
