import os
import threading
import time
import urllib.request

_ENDPOINT = os.environ.get("APM_EXPORTER_ENDPOINT", "http://localhost:4318/v1/metrics")
_SPANS = []


def _flush():
    while True:
        time.sleep(10)
        if _SPANS:
            urllib.request.urlopen(_ENDPOINT, data=b"".join(_SPANS), timeout=2)
            del _SPANS[:]


if os.environ.get("APM_ENABLED", "1") == "1":
    threading.Thread(target=_flush, daemon=True).start()
