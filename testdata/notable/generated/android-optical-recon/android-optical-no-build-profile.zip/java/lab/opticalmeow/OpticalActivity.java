package lab.opticalmeow;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.nio.charset.StandardCharsets;
import java.util.zip.CRC32;

public final class OpticalActivity extends Activity {
    private static final long GUARD_MS = 5000;
    private static final long TRAILER_MS = 2000;
    private static final long HALF_MS = 167;
    private static final int MAX_PAYLOAD = 256;
    private static final int[] SYNC = {0xaa, 0xaa, 0xaa, 0xaa, 0xd3, 0x91};

    private final Handler main = new Handler(Looper.getMainLooper());
    private View signal;
    private Button transmit;
    private TextView status;
    private TextView payloadInfo;
    private SignalPlotView plot;
    private byte[] frame;
    private long started;
    private long durationMs;
    private long lastHalf = -1;
    private boolean sending;
    private int previousGray = -1;

    private final Runnable updateSignal = new Runnable() {
        @Override public void run() {
            if (!sending) return;
            long elapsed = SystemClock.elapsedRealtime() - started;
            if (elapsed >= durationMs) {
                finishSignal("Frame sent. Check the C receiver.");
                return;
            }
            if (elapsed >= GUARD_MS && elapsed < durationMs - TRAILER_MS) {
                long half = (elapsed - GUARD_MS) / HALF_MS;
                if ((lastHalf < 0 && half != 0) || (lastHalf >= 0 && half > lastHalf + 1)) {
                    finishSignal("Timing gap. Tap Meow! to retry.");
                    return;
                }
                lastHalf = half;
            }
            int gray = grayAt(elapsed);
            if (gray != previousGray) {
                signal.setBackgroundColor(Color.rgb(gray, gray, gray));
                plot.addLevel(gray);
                previousGray = gray;
            }
            main.postDelayed(this, 8);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.screenBrightness = 0.8f;
        getWindow().setAttributes(params);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL | Gravity.CENTER_VERTICAL);
        page.setPadding(dp(20), dp(40), dp(20), dp(14));
        page.setBackgroundColor(Color.rgb(11, 16, 32));

        TextView eyebrow = new TextView(this);
        eyebrow.setText("RECONCAT  /  OPTICAL");
        eyebrow.setTextColor(Color.rgb(105, 220, 213));
        eyebrow.setTextSize(12);
        eyebrow.setLetterSpacing(0.08f);
        page.addView(eyebrow, centered(LinearLayout.LayoutParams.WRAP_CONTENT, dp(22)));

        TextView title = new TextView(this);
        title.setText("Meow over light");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        page.addView(title, centered(LinearLayout.LayoutParams.WRAP_CONTENT, dp(38)));

        TextView subtitle = new TextView(this);
        subtitle.setText("Android  ->  ThinkPad camera  ->  C receiver");
        subtitle.setTextColor(Color.rgb(174, 187, 207));
        subtitle.setTextSize(13);
        page.addView(subtitle, centered(LinearLayout.LayoutParams.WRAP_CONTENT, dp(24)));

        ImageView cat = new ImageView(this);
        cat.setImageResource(R.drawable.cat);
        cat.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams catParams = centered(dp(144), dp(144));
        catParams.topMargin = dp(8);
        page.addView(cat, catParams);

        payloadInfo = new TextView(this);
        payloadInfo.setText("PAYLOAD   Build.*     •     MANCHESTER     •     CRC-32");
        payloadInfo.setTextColor(Color.rgb(211, 219, 234));
        payloadInfo.setTextSize(11);
        payloadInfo.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams payloadParams = centered(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(32));
        payloadParams.topMargin = dp(8);
        page.addView(payloadInfo, payloadParams);

        signal = new View(this);
        signal.setBackgroundColor(Color.rgb(128, 128, 128));
        signal.setContentDescription("Optical signal patch");
        LinearLayout.LayoutParams signalParams = centered(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(220));
        page.addView(signal, signalParams);

        plot = new SignalPlotView(this);
        plot.setBackground(roundRect(Color.rgb(22, 31, 48), dp(14)));
        LinearLayout.LayoutParams plotParams = centered(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        plotParams.topMargin = dp(10);
        page.addView(plot, plotParams);

        status = new TextView(this);
        status.setText("Aim the camera at the gray patch, then tap Meow!");
        status.setTextColor(Color.rgb(174, 187, 207));
        status.setTextSize(13);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = centered(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(34));
        statusParams.topMargin = dp(8);
        page.addView(status, statusParams);

        transmit = new Button(this);
        transmit.setText("Meow! ♥️");
        transmit.setAllCaps(false);
        transmit.setTextColor(Color.WHITE);
        transmit.setTextSize(18);
        transmit.setBackground(roundRect(Color.rgb(238, 91, 133), dp(24)));
        LinearLayout.LayoutParams buttonParams = centered(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        buttonParams.topMargin = dp(6);
        page.addView(transmit, buttonParams);
        transmit.setOnClickListener(v -> startSignal());

        setContentView(page);
        page.post(this::hideSystemBars);
    }

    private LinearLayout.LayoutParams centered(int width, int height) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(width, height);
        params.gravity = Gravity.CENTER_HORIZONTAL;
        return params;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable roundRect(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(radius);
        return shape;
    }

    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private void startSignal() {
        byte[] payload = DeviceRecon.snapshotJson().getBytes(StandardCharsets.UTF_8);
        if (payload.length == 0 || payload.length > MAX_PAYLOAD) {
            status.setText("Build snapshot is too large (max 256 bytes).");
            return;
        }
        frame = makeFrame(payload);
        durationMs = GUARD_MS + TRAILER_MS + frame.length * 16L * HALF_MS;
        sending = true;
        lastHalf = -1;
        previousGray = -1;
        started = SystemClock.elapsedRealtime();
        transmit.setEnabled(false);
        transmit.setText("Sending Build.*…");
        payloadInfo.setText("PAYLOAD   " + payload.length + " bytes     •     CRC-32");
        status.setText("Sending " + payload.length + " bytes   •   "
                + Math.round(durationMs / 1000.0) + " s");
        plot.clear();
        main.removeCallbacks(updateSignal);
        main.post(updateSignal);
    }

    private int grayAt(long elapsedMs) {
        long dataMs = elapsedMs - GUARD_MS;
        if (dataMs < 0 || dataMs >= frame.length * 16L * HALF_MS) return 128;
        long half = dataMs / HALF_MS;
        long bit = half / 2;
        int value = (frame[(int) (bit / 8)] >> (7 - (bit & 7))) & 1;
        boolean light = (half & 1) == 0 ? value == 1 : value == 0;
        return light ? 176 : 80;
    }

    private byte[] makeFrame(byte[] payload) {
        byte[] result = new byte[SYNC.length + 2 + payload.length + 1 + 4];
        for (int i = 0; i < SYNC.length; i++) result[i] = (byte) SYNC[i];
        result[SYNC.length] = (byte) (payload.length >>> 8);
        result[SYNC.length + 1] = (byte) payload.length;
        System.arraycopy(payload, 0, result, SYNC.length + 2, payload.length);
        int xor = 0;
        for (byte value : payload) xor ^= value & 0xff;
        result[SYNC.length + 2 + payload.length] = (byte) xor;
        CRC32 crc = new CRC32();
        crc.update(result, SYNC.length, 2 + payload.length + 1);
        long value = crc.getValue();
        for (int i = 0; i < 4; i++)
            result[result.length - 4 + i] = (byte) (value >>> (24 - 8 * i));
        return result;
    }

    private void finishSignal(String message) {
        sending = false;
        main.removeCallbacks(updateSignal);
        signal.setBackgroundColor(Color.rgb(128, 128, 128));
        status.setText(message);
        transmit.setEnabled(true);
        transmit.setText("Meow! ♥️");
    }

    @Override protected void onPause() {
        if (sending) finishSignal("Transmission stopped. Tap Meow! ♥️ to retry.");
        super.onPause();
    }

    @Override protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
