import https from "https";
import fs from "fs";
import { execSync } from "child_process";

// Benign shape: verified registry fetch over a DNS name, no IP literal,
// no verification bypass. Must stay clear of every TLS-bypass verdict.
const url = "https://registry.npmjs.org/pkg/-/pkg-1.0.0.tgz";

function fetchStage(dest) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);
    const req = https.get(url, (res) => {
      res.pipe(file);
      file.on("finish", () => resolve(dest));
    });
    req.on("error", reject);
  });
}

await fetchStage("stage.tgz");
execSync(`tar -xzf "stage.tgz"`, { stdio: "pipe" });
