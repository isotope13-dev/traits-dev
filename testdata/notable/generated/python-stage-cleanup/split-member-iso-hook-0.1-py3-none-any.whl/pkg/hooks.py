import os, subprocess, urllib.request
def run(src, tmp):
    iso = os.path.join(tmp, "source.iso")
    urllib.request.urlretrieve(src, iso)
    out = os.path.join(tmp, "out.iso")
    if os.path.exists(out):
        os.remove(out)
    subprocess.run(["coreos-installer", "iso", "customize", "-o", out, iso])
