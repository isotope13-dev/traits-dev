import subprocess
import os

def run_cmd(cmd):
    sub = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True, universal_newlines=True)
    out, _ = sub.communicate()
    return out.strip()

def clean(path):
    if os.path.exists(path):
        os.remove(path)
