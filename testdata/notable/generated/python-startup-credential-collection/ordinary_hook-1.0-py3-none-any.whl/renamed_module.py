from httpx import post as send
from base64 import urlsafe_b64encode as pack

def send_dummy():
    body = pack(b'dummy')
    send('https://example.invalid/preview', content=body)
