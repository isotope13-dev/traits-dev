// Show the user agent each outgoing request carries; leave headers unchanged.
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    const ua = (details.requestHeaders || []).find((h) => h.name.toLowerCase() === "user-agent");
    console.log("ua", ua && ua.value);
    return { requestHeaders: details.requestHeaders };
  },
  { urls: ["https://app.example.test/*"] },
  ["requestHeaders"]
);
