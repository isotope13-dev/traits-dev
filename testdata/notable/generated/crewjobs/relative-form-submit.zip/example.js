function formFixture($) {
  const demo = $("#DemoPassword").val();
  const formData = {password: demo};
  $.ajax({url: "/demo", type: "POST", data: formData});
}
