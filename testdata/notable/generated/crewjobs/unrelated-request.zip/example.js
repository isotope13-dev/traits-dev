function unrelatedFixture(fetch, otherUrl) {
  const endpoint = `https://scheduling.invalid/preview?password=${encodeURIComponent("fixture-only")}`;
  return fetch(otherUrl);
}
