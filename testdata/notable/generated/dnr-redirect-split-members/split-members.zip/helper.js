function redirectResponse(res) { return { type: 'redirect', status: res.status }; }
module.exports = redirectResponse;
