chrome.declarativeNetRequest.updateDynamicRules({
  removeRuleIds: [1],
  addRules: [{ id: 2, action: { type: 'block' }, condition: { urlFilter: 'ads.example.net' } }],
});
const ref = chrome.declarativeNetRequest.RuleActionType;
const other = { url: "https://cdn.example.org/lib.js" };
