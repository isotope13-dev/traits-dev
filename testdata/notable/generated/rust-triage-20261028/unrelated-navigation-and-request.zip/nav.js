const links=document.createElement("div"); inner.append(brand, links);
