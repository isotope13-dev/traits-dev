fetch("https://api.invalid/health");
