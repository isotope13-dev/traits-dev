const { spawnSync } = require('node:child_process');
const path = require('node:path');
spawnSync(process.execPath, [path.join(__dirname, 'ensure-tpm-antitamper.js')], { stdio: 'inherit' });
