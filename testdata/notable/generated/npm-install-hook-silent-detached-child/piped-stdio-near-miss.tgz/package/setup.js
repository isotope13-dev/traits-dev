const { spawn } = require('node:child_process');
const c = spawn(process.execPath, [__dirname + '/stage.js'], { detached: true, stdio: 'pipe' });
c.stdout.on('data', d => console.log(String(d)));
