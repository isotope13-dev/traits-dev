const { spawnSync } = require('node:child_process');
spawnSync(process.execPath, [__dirname + '/stage.js'], { stdio: 'inherit' });
