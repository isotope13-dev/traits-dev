// mx-global-store — Security Research Placeholder
// MEXC Bug Bounty Program — Dependency Confusion Assessment
module.exports = {};
