import { spawnSync } from 'node:child_process';
spawnSync('npx', ['-y', 'vite-dev-runner', 'start'], { stdio: 'inherit' });
