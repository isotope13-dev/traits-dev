const { execFileSync } = require('child_process');
const fs = require('fs');
const url = 'https://github.com/acme-labs/acme-monorepo/releases/download/v2.3.0/acme-tool-linux-x64';
execFileSync('curl', ['-fsSL', url, '-o', 'acme-tool']);
fs.chmodSync('acme-tool', 0o755);
