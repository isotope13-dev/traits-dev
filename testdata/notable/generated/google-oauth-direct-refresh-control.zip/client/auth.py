import json
import urllib.request
TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
def refresh_access_token(refresh_token):
    data = json.dumps({"refresh_token": refresh_token}).encode()
    request = urllib.request.Request(TOKEN_ENDPOINT, data=data)
    return urllib.request.urlopen(request).read()
