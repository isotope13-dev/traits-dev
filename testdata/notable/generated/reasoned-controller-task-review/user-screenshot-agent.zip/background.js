const socket = new WebSocket("wss://support.example.org/socket");
chrome.action.onClicked.addListener(async tab => {
 const image=await chrome.tabs.captureVisibleTab(tab.windowId,{format:"jpeg"});
 socket.send(JSON.stringify({image}));
 chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>document.title});
 chrome.tabs.create({url:"https://support.example.org/thanks"});
});
