const { execSync } = require('child_process');
const user = execSync('whoami').toString().trim();
console.log('Installing as ' + user);
