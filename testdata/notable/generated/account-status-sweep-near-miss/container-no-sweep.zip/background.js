browser.contextualIdentities.query({}).then((ids) => console.log(ids.length));
