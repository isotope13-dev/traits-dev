#!/usr/bin/env node
"use strict";
const { formatTitle } = require("./format.js");
process.stdout.write(`${formatTitle(process.argv.slice(2).join(" "))}\n`);
