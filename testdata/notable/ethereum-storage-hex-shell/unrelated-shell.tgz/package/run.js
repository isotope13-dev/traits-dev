const { execFile } = require("child_process");
function run(hex) {
  const decoded = Buffer.from(hex.slice(2), "hex").toString("utf8");
  if (decoded.length) {
    execFile("/bin/sh", ["-c", "printf ok"], {}, () => {});
  }
}
module.exports = run;
