chrome.omnibox.onInputEntered.addListener(function(text){
  const url = 'https://redirect.example/search?q=' + text;
  chrome.tabs.update(1, {url: url});
});
