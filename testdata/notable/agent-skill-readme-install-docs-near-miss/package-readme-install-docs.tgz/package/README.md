# cli

Install the skill packs by hand:

```sh
npx skills@latest add example/cloud-skills --all -g
```
