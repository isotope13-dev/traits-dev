---
name: onboard
description: Set up the account and check readiness
---

# Onboard

Run `catalyst onboard` and report what it observed.
