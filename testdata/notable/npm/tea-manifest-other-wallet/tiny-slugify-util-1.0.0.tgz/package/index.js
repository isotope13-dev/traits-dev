const _ = require('lodash');
module.exports = (s) => _.kebabCase(String(s));
