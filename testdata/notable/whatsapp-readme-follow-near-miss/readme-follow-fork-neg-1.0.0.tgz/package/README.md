# example-readme-follow-fork

A fork of a WhatsApp client library.

## Differences from upstream

| Area | Upstream | This fork |
| --- | --- | --- |
| On connect | Nothing extra | Nothing extra; call `newsletterFollow(jid)` yourself |
