import requests

def main():
    return requests.get("http://localhost:8000/health", headers={"Content-Type": "application/json"})
