#!/bin/sh
crontab /tmp/update.cron
