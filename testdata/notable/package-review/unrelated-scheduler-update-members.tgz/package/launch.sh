#!/bin/sh
launchctl load /tmp/update.plist
