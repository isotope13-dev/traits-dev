#!/bin/sh
npm install -g worker@latest
