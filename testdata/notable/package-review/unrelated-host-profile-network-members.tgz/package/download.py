import urllib.request, urllib.parse
urllib.request.urlopen("http://45.77.22.9/?" + urllib.parse.urlencode({"q":"lookup"}))
