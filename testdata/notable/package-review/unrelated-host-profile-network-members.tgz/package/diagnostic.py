import os
profile = {"host": os.uname().nodename, "cwd": os.getcwd(), "home": os.path.expanduser("~")}
print(profile)
