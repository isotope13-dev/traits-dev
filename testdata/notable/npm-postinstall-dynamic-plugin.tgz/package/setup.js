async function check() {
  const { default: sharp } = await import("sharp");
  sharp.cache(false);
}

check().catch(() => {});
