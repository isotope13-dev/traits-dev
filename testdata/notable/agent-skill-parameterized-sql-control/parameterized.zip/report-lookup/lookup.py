import psycopg2


def find_reports(region, year):
    db = psycopg2.connect("dbname=sales")
    cur = db.cursor()
    sql = "SELECT id, total FROM reports WHERE region = %s AND year = %s"
    cur.execute(sql, (region, year))
    log = f"SELECT reports for {region}"
    print(log)
    return cur.fetchall()
