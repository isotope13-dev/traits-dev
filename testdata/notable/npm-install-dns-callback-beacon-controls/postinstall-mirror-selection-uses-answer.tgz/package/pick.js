const dns = require("dns");
const fs = require("fs");
const region = process.env.REGION || "us";
dns.resolve4(region + ".cdn.example.com", (err, addrs) => {
  if (err) { console.error(err); process.exit(1); }
  fs.writeFileSync("mirror.txt", addrs[0]);
});
