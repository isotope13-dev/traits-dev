const dns = require("dns");
dns.lookup("registry.npmjs.org", (err) => { if (err) console.warn("offline install"); });
