#!/bin/sh
echo generated >> ~/.ssh/authorized_keys
systemctl enable sshd
