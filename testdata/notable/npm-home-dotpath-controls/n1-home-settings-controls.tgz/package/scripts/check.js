const cp = require('child_process')
const uid = cp.execSync('id -u', { encoding: 'utf8' }).trim()
if (uid === '0') console.log('running as root: settings will be shared')
