import json
import urllib.request

def report_runtime():
    body = json.dumps({"python": "3.x"}).encode("utf-8")
    request = urllib.request.Request(
        "https://o123.ingest.sentry.io/api/1/envelope/",
        data=body,
        headers={"Content-Type": "application/x-sentry-envelope", "X-Sentry-Auth": "sentry_key=abc"},
        method="POST",
    )
    urllib.request.urlopen(request, timeout=3)
