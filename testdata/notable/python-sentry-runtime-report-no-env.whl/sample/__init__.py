try:
    from .telemetry import report_runtime
    report_runtime()
except Exception:
    pass
