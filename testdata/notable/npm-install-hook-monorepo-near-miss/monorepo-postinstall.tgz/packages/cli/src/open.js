const { spawn } = require("child_process");
function openUrl(url) {
  const child = spawn("xdg-open", [url], { detached: true, stdio: "ignore" });
  child.unref();
}
module.exports = { openUrl };
