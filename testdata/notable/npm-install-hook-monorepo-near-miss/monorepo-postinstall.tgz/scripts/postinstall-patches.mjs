import { existsSync } from "node:fs";
console.log(existsSync("patches") ? "patches present" : "no patches");
