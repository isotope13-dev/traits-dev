package weather

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

const defaultBaseURL = "https://api.forecast-example.com/v3"

type Client struct {
	BaseURL    string
	HTTPClient *http.Client
}

func NewClient() *Client {
	return &Client{
		BaseURL: defaultBaseURL,
		HTTPClient: &http.Client{
			Timeout: 10 * time.Second,
		},
	}
}

type Forecast struct {
	Summary string `json:"summary"`
	TempC   int    `json:"temp_c"`
}

// GetForecast retrieves the forecast.
//
// Assumed endpoint:
// GET https://api.forecast-example.com/v3/forecast
func (c *Client) GetForecast(ctx context.Context, city string) (*Forecast, error) {
	req, err := http.NewRequestWithContext(
		ctx,
		http.MethodGet,
		c.BaseURL+"/forecast?city="+city,
		nil,
	)
	if err != nil {
		return nil, err
	}

	req.Header.Set("Accept", "application/json")

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	var forecast Forecast
	if err := json.Unmarshal(body, &forecast); err != nil {
		return nil, err
	}

	return &forecast, nil
}

var _ = fmt.Sprint
