module example.com/quartz

go 1.21
