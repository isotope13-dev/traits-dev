package quartz

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"
)

const baseURL = "https://banking.quartzledger.io/v1"

type Client struct {
	BaseURL    string
	APIKey     string
	HTTPClient *http.Client
}

func NewClient() (*Client, error) {
	apiKey := os.Getenv("QUARTZ_API_KEY")
	if apiKey == "" {
		return nil, fmt.Errorf("QUARTZ_API_KEY is not set")
	}

	return &Client{
		BaseURL: baseURL,
		APIKey:  apiKey,
		HTTPClient: &http.Client{
			Timeout: 15 * time.Second,
		},
	}, nil
}

type Holder struct {
	ID       string `json:"id"`
	Currency string `json:"currency"`
	Balance  string `json:"balance"`
}

type Disbursement struct {
	AccountID   string `json:"account_id"`
	Destination string `json:"destination_address"`
	Asset       string `json:"asset"`
	Amount      string `json:"amount"`
}

type DisbursementResult struct {
	ID     string `json:"id"`
	Status string `json:"status"`
}

func (c *Client) do(
	ctx context.Context,
	method string,
	path string,
	body any,
	result any,
) error {
	var requestBody io.Reader

	if body != nil {
		data, err := json.Marshal(body)
		if err != nil {
			return fmt.Errorf("marshal request: %w", err)
		}

		requestBody = bytes.NewReader(data)
	}

	req, err := http.NewRequestWithContext(
		ctx,
		method,
		c.BaseURL+path,
		requestBody,
	)
	if err != nil {
		return fmt.Errorf("create request: %w", err)
	}

	req.Header.Set("Authorization", "Bearer "+c.APIKey)
	req.Header.Set("Accept", "application/json")

	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return fmt.Errorf("Quartz API request failed: %w", err)
	}
	defer resp.Body.Close()

	responseBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("read response: %w", err)
	}

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf(
			"Quartz API returned %s: %s",
			resp.Status,
			string(responseBody),
		)
	}

	if result != nil && len(responseBody) > 0 {
		if err := json.Unmarshal(responseBody, result); err != nil {
			return fmt.Errorf("decode response: %w", err)
		}
	}

	return nil
}

func (c *Client) GetHolders(ctx context.Context) ([]Holder, error) {
	var holders []Holder

	err := c.do(
		ctx,
		http.MethodGet,
		"/accounts",
		nil,
		&holders,
	)

	return holders, err
}

func (c *Client) CreateDisbursement(
	ctx context.Context,
	transfer Disbursement,
) (*DisbursementResult, error) {
	var response DisbursementResult

	err := c.do(
		ctx,
		http.MethodPost,
		"/payouts",
		transfer,
		&response,
	)
	if err != nil {
		return nil, err
	}

	return &response, nil
}
