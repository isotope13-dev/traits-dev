package acmepay

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"time"
)

// Client is the official AcmePay API client. See
// https://docs.acmepay.com/api for the full reference.
type Client struct {
	BaseURL    string
	APIKey     string
	HTTPClient *http.Client
}

// NewClient creates an AcmePay API client using the ACMEPAY_API_KEY
// environment variable.
func NewClient() (*Client, error) {
	apiKey := os.Getenv("ACMEPAY_API_KEY")
	if apiKey == "" {
		return nil, fmt.Errorf("ACMEPAY_API_KEY is not set")
	}

	return &Client{
		BaseURL: "https://api.acmepay.com",
		APIKey:  apiKey,
		HTTPClient: &http.Client{
			Timeout: 15 * time.Second,
		},
	}, nil
}

type Balance struct {
	Available string `json:"available"`
	Pending   string `json:"pending"`
	Currency  string `json:"currency"`
}

type Charge struct {
	Amount   string `json:"amount"`
	Currency string `json:"currency"`
	Source   string `json:"source"`
}

type ChargeResult struct {
	ID     string `json:"id"`
	Status string `json:"status"`
}

func (c *Client) do(
	ctx context.Context,
	method string,
	path string,
	body any,
	result any,
) error {
	var requestBody io.Reader

	if body != nil {
		data, err := json.Marshal(body)
		if err != nil {
			return fmt.Errorf("marshal request: %w", err)
		}

		requestBody = bytes.NewReader(data)
	}

	req, err := http.NewRequestWithContext(
		ctx,
		method,
		c.BaseURL+path,
		requestBody,
	)
	if err != nil {
		return fmt.Errorf("create request: %w", err)
	}

	req.Header.Set("Authorization", "Bearer "+c.APIKey)
	req.Header.Set("Accept", "application/json")

	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}

	resp, err := c.HTTPClient.Do(req)
	if err != nil {
		return fmt.Errorf("AcmePay API request failed: %w", err)
	}
	defer resp.Body.Close()

	responseBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("read response: %w", err)
	}

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("AcmePay API returned %s", resp.Status)
	}

	if result != nil && len(responseBody) > 0 {
		if err := json.Unmarshal(responseBody, result); err != nil {
			return fmt.Errorf("decode response: %w", err)
		}
	}

	return nil
}

// GetBalance retrieves the merchant balance.
func (c *Client) GetBalance(ctx context.Context) (*Balance, error) {
	var balance Balance

	err := c.do(
		ctx,
		http.MethodGet,
		"/v1/balance",
		nil,
		&balance,
	)

	return &balance, err
}

// CreateCharge creates a card charge.
func (c *Client) CreateCharge(
	ctx context.Context,
	charge Charge,
) (*ChargeResult, error) {
	var result ChargeResult

	err := c.do(
		ctx,
		http.MethodPost,
		"/v1/charges",
		charge,
		&result,
	)
	if err != nil {
		return nil, err
	}

	return &result, nil
}
