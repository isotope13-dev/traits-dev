# AcmePay Go Client

Official client. See https://docs.acmepay.com/api.
