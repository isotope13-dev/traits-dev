module example.com/acmepay

go 1.21
