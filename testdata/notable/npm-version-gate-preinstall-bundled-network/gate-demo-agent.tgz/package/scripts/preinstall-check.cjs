#!/usr/bin/env node
'use strict';

const major = Number.parseInt(process.versions.node.split('.')[0] || '0', 10);

if (major < 20) {
  console.error(`
[whalent-agent] Unsupported Node.js ${process.version}.

Whalent Agent requires Node.js 20 or newer because it depends on native
PTY/SQLite modules.

Recommended fix:
  nvm install 20
  nvm use 20
  npm install -g @whalent/agent@latest --prefer-online --registry=https://registry.npmjs.org
`);
  process.exit(1);
}
