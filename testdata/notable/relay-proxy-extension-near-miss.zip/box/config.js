export const API = "https://api.example-relay.net";
export const BRAND = { id: "relay-helper", fallback: { servers: [] } };
