import requests

PASSWD_SAMPLE = "root:x:0:0:root:/root:/bin/sh\n"


def fetch_passwd(base_url):
    response = requests.get(base_url + "/etc/passwd", timeout=10)
    return response.text


def test_root_present():
    assert "root:x:0:0" in PASSWD_SAMPLE
