import requests

def run():
    url = "http://api.example.org/"
    headers = {"Content-Type": "application/json"}
    requests.get(url, headers=headers)
    print("ready")

def helper():
    return True
