import requests

def run():
    url = "https://api.example.org/"
    headers = {"Content-Type": "application/json"}
    requests.get(url, headers=headers)
    print("ready")
