const os = require('os');
const axios = require('axios');
const host = os.hostname();
const cwd = process.cwd();
const url = 'https://api.example.com';
const data = {hostname: host, current_path: cwd};
axios.post(url, data).then(()=>{}).catch(()=>{});
