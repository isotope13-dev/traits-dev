package lab.optical;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

public final class Splash extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        View root = new View(this);
        root.setBackgroundColor(Color.rgb(11, 16, 32));
        setContentView(root);
    }
}
