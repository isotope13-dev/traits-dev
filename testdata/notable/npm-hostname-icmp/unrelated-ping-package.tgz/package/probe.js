const {exec} = require("child_process"); module.exports = target => exec(`ping -c 1 ${target}`);
