import subprocess

def run_shell(command):
    return subprocess.call(command)
