@echo off
set "URL=https://github.com/Flowseal/zapret-discord-youtube"
