@echo off
start DiscordZapret.exe
