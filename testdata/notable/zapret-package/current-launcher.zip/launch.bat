@echo off
start "zapret: %~n0" /min "%BIN%winws.exe" --wf-tcp=443
