@echo off
start DiscordZapret.exe.backup
