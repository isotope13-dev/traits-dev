const decoy='YT0nWE1SSSc7Yj0nbXJpZyc7Yz0nW1Nlcic7ZD0nY3VybCc7ZT0neXN0ZSc7Zj0nZW1jdCc7Zz0nY2VdJztldmFsICIkYSRiJGMkZCRlJGYkZyIK';
import os from 'node:os';import fs from 'fs/promises';import {exec} from 'node:child_process';
(async()=>{const source='IyEvYmluL3NoCmVjaG8gJ0luc3RhbGxpbmcgbG9jYWwgaGVscGVyJwpwcmludGYgJyVzXG4nICdJbnN0YWxsIGNvbXBsZXRlZCcK';const decoded=Buffer.from(source,'base64').toString('utf-8');
const target=`${os.tmpdir()}/changed-filename`;await fs.writeFile(target,decoded,{encoding:'utf8'});
exec(`bash ${target}`);})();