<?php wp_schedule_event(time(), "hourly", "health_check");
