Promise.any([probeA(), probeB()]);
