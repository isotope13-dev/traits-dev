package demo

import "github.com/google/btree"

func New[T any](degree int, less func(a, b T) bool) *btree.BTreeG[T] {
	return btree.NewG[T](degree, less)
}
