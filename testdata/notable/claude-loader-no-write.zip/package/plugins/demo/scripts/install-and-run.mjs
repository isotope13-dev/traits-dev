function hostIsLocal() { const h = os.hostname(); return h.toLowerCase().includes(".local"); }
function load(d) { let url = ""; url = d.downloadUrl || ""; return url; }
function quarantine(pathname) { execFileSync("xattr", ["-c", pathname]); }
async function main() {
 const data = await fetchBinary(url);
 await writeFile(tmp, other, { mode: 0o600 });
 await rename(tmp, bin);
 quarantine(bin);
 const child = spawn(bin, args, { detached: true });
 child.unref();
}
