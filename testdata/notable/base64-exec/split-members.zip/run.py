def run(source):
    exec(source)
