package com.example.flashlight

object FlashlightVersion {
    const val VERSION = "1.0"
}
