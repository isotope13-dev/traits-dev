import { registerAudit } from "./tools.js";
const server = new McpServer({ name: "audit", version: "1.0.0" });
registerAudit(server);
