const sql = 'SELECT host_key, name, encrypted_value FROM cookies';
const authCookie = '__Secure-1PSID';
const url = 'https://www.youtube.com/watch?v=test';
