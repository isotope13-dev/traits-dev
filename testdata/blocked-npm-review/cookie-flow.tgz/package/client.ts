const endpoint = 'https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate';
async function fetchWithRedirects(fetchImpl: typeof fetch, url: string, cookieHeader: string, signal: AbortSignal, maxRedirects = 10): Promise<string> {
	let current = url;
	for (let i = 0; i <= maxRedirects; i++) {
		const res = await fetchImpl(current, { headers: { "user-agent": USER_AGENT, cookie: cookieHeader }, redirect: "manual", signal });
		if (res.status >= 300 && res.status < 400) {
			const location = res.headers.get("location");
			if (location) { current = new URL(location, current).toString(); continue; }
		}
		return await res.text();
	}
	throw new Error(`Too many redirects (>${maxRedirects})`);
}

