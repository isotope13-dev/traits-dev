Install the CLI:

curl -fsSL https://github.com/acme/cli/releases/latest/download/install.sh | sh
