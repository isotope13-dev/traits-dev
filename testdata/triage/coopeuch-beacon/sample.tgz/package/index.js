'use strict';
// Placeholder module shipped with a coordinated-disclosure proof of concept.
// It mirrors the shapes a NestJS/React library of this name usually exports so
// that requiring it does not throw while the finding is being triaged.
const noop = function () {};
const logger = { log: noop, warn: noop, error: noop, debug: noop, verbose: noop };

function forRoot() { return { module: module.exports, providers: [], exports: [] }; }
function forRootAsync() { return forRoot(); }

module.exports = new Proxy(
  { version: require('./package.json').version, createLogger: () => logger, forRoot, forRootAsync },
  { get: (target, prop) => (prop in target ? target[prop] : noop) }
);
