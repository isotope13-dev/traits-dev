# @coopeuch/button

Published for coordinated vulnerability disclosure of a dependency confusion
issue affecting the `@coopeuch` namespace.

On install, a postinstall script sends a minimal fingerprint of the installing
machine over HTTPS to an endpoint operated by the maintainer: package identity,
install directory, hostname, username, platform, local interface addresses, and
a fixed allowlist of `npm_*` configuration variables that npm sets for every
lifecycle script. It reads no credentials, no tokens, no cloud metadata, no
files, and no environment variables outside that allowlist. See `DISCLOSURE`.

The module itself is a stub that mirrors the exports of the package it shadows,
so requiring it does not throw.

Maintainer: s4yhii___. Will be transferred to the namespace owner on request.
