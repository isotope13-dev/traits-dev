start renamed.exe payload.txt
