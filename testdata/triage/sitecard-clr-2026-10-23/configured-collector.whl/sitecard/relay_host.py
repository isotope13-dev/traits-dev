"""Loopback WebSocket relay for an outbound SSH origin and local SSH clients."""

from __future__ import annotations

import argparse
import asyncio
import secrets
import sys
from urllib.parse import urlsplit

import websockets


class Relay:
    def __init__(self, token: str):
        self.token = token
        self.peers: dict[str, object] = {}
        self.paired = asyncio.Event()

    async def handle(self, websocket):
        path = websocket.request.path if hasattr(websocket, "request") else websocket.path
        prefix = f"/relay/{self.token}/"
        role = path[len(prefix):] if path.startswith(prefix) else ""
        if role not in ("origin", "client"):
            await websocket.close(code=1008, reason="Invalid relay path")
            return
        if role in self.peers:
            await websocket.close(code=1013, reason="Role already connected")
            return
        self.peers[role] = websocket
        if len(self.peers) == 2:
            self.paired.set()
        other = "client" if role == "origin" else "origin"
        try:
            paired = asyncio.create_task(self.paired.wait())
            closed = asyncio.create_task(websocket.wait_closed())
            try:
                await asyncio.wait((paired, closed), return_when=asyncio.FIRST_COMPLETED)
                if closed.done():
                    return
            finally:
                paired.cancel()
                closed.cancel()
                await asyncio.gather(paired, closed, return_exceptions=True)
            async for message in websocket:
                if not isinstance(message, bytes):
                    await websocket.close(code=1003, reason="Binary data required")
                    break
                peer = self.peers.get(other)
                if peer is None:
                    break
                await peer.send(message)
        except websockets.ConnectionClosed:
            pass
        finally:
            if self.peers.get(role) is websocket:
                del self.peers[role]
                self.paired.clear()
                peer = self.peers.get(other)
                if peer is not None:
                    await peer.close(code=1001, reason="Peer disconnected")


def relay_url(public_url: str, token: str) -> str:
    parsed = urlsplit(public_url)
    if (parsed.scheme != "https" or not parsed.hostname or parsed.username
            or parsed.password or parsed.path not in ("", "/") or parsed.query or parsed.fragment):
        raise ValueError("--public-url must be an HTTPS origin without a path or credentials")
    return f"wss://{parsed.netloc}/relay/{token}"


async def serve(port: int, public_url: str, tunnel_id: str = "", token_file: str = "") -> None:
    from sitecard import transports

    if tunnel_id:
        transports.validate_devtunnel(tunnel_id, token_file)
    token = secrets.token_urlsafe(32)
    url = relay_url(public_url, token)
    relay = Relay(token)
    async with websockets.serve(relay.handle, "127.0.0.1", port, max_size=1024 * 1024):
        child = None
        if tunnel_id:
            command = ["devtunnel", "host", tunnel_id]
            if token_file:
                command.extend(["--access-token", "-"])
            child = await asyncio.create_subprocess_exec(
                *command, stdin=asyncio.subprocess.PIPE if token_file else asyncio.subprocess.DEVNULL,
                stdout=sys.stderr, stderr=sys.stderr,
            )
            if token_file:
                with open(token_file, "rb") as credential:
                    child.stdin.write(credential.read())
                await child.stdin.drain()
                child.stdin.close()
        print(f"Remote: {__package__} serve . -t ws-relay -e {url} --no-public-access", flush=True)
        print(f"Local:  {__package__} proxy {url}", flush=True)
        try:
            if child is None:
                await asyncio.Future()
            else:
                status = await child.wait()
                raise RuntimeError(f"Dev Tunnel host exited with status {status}")
        finally:
            if child is not None and child.returncode is None:
                child.terminate()
                await child.wait()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, required=True, help="Local HTTPS tunnel HTTP port")
    parser.add_argument("--public-url", required=True, help="Public HTTPS origin of that port")
    parser.add_argument("--tunnel-id", default="", help="Also host this existing Dev Tunnel")
    parser.add_argument("--devtunnel-token-file", default="", help="Host token file, passed to Dev Tunnel on stdin")
    args = parser.parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser.error("--port must be between 1 and 65535")
    try:
        relay_url(args.public_url, "validation")
    except ValueError as error:
        parser.error(str(error))
    try:
        if args.devtunnel_token_file and not args.tunnel_id:
            parser.error("--devtunnel-token-file requires --tunnel-id")
        asyncio.run(serve(args.port, args.public_url, args.tunnel_id, args.devtunnel_token_file))
    except KeyboardInterrupt:
        return 0
    except OSError as error:
        parser.error(str(error))
    except RuntimeError as error:
        parser.error(str(error))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
