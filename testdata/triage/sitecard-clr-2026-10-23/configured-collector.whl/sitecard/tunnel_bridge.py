"""SSH byte streams over a public HTTPS/WebSocket tunnel endpoint."""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import signal
import sys

import websockets

from sitecard.bridge import CHUNK, CONNECT_KWARGS, _await_first_completed, _write_all


async def client(url: str) -> None:
    async with websockets.connect(url, **CONNECT_KWARGS) as websocket:
        loop = asyncio.get_running_loop()
        stdin = asyncio.StreamReader()
        transport, _ = await loop.connect_read_pipe(lambda: asyncio.StreamReaderProtocol(stdin), sys.stdin.buffer)

        async def upload() -> None:
            while chunk := await stdin.read(CHUNK):
                await websocket.send(chunk)

        async def download() -> None:
            async for chunk in websocket:
                _write_all(1, chunk.encode() if isinstance(chunk, str) else chunk)

        try:
            await _await_first_completed(upload(), download())
        finally:
            transport.close()


async def handle(websocket, ssh_port: int) -> None:
    try:
        reader, writer = await asyncio.open_connection("127.0.0.1", ssh_port)
    except OSError:
        await websocket.close(code=1011, reason="SSH gateway unavailable")
        return

    async def upload() -> None:
        async for chunk in websocket:
            writer.write(chunk.encode() if isinstance(chunk, str) else chunk)
            await writer.drain()

    async def download() -> None:
        while chunk := await reader.read(CHUNK):
            await websocket.send(chunk)

    try:
        with contextlib.suppress(websockets.ConnectionClosed, OSError):
            await _await_first_completed(upload(), download())
    finally:
        writer.close()
        with contextlib.suppress(OSError):
            await writer.wait_closed()


async def serve(port: int, ssh_port: int) -> None:
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for signum in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(signum, stop.set)
    async with websockets.serve(lambda ws, *args: handle(ws, ssh_port), "127.0.0.1", port, max_size=None):
        print(f"SSH WebSocket bridge ready on port {port}", flush=True)
        await stop.wait()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    proxy = sub.add_parser("client")
    proxy.add_argument("url")
    server = sub.add_parser("server")
    server.add_argument("--port", type=int, required=True)
    server.add_argument("--ssh-port", type=int, required=True)
    args = parser.parse_args(argv)
    try:
        if args.mode == "client":
            asyncio.run(client(args.url))
        else:
            asyncio.run(serve(args.port, args.ssh_port))
    except KeyboardInterrupt:
        return 0
    except (OSError, websockets.WebSocketException) as error:
        print(f"SSH WebSocket connection failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
