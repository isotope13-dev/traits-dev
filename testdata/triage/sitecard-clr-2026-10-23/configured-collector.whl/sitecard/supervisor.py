"""Detached background supervisor for Sitecard sessions.

Spawned by ``session._launch`` in background mode as
``python -m sitecard.supervisor``; polls the state pid files and relaunches
the gateway or transport child when one dies. Exits cleanly once the session
is being torn down (both pid files gone) or when SIGINT/SIGTERM arrives.

pid identity (start-time hash) keeps the supervisor from touching an
unrelated process that recycled a stale pid; a relaunch records the new
child's identity, so ``sitecard stop`` can still kill it cleanly.
"""

from __future__ import annotations

import signal
import sys
import time
from typing import Any

from sitecard import session
import sitecard.runtime as st

POLL_INTERVAL = 1.0


def _run(stop_signum: list[int]) -> int:
    state = st.state_dir()
    gateway_pid_file = state / "gateway.pid"
    transport_pid_file = state / "transport.pid"
    gateway_log = state / "gateway.log"
    transport_log = state / "transport.log"
    restarts: dict[str, list[float]] = {"gateway": [], "transport": []}
    while True:
        if stop_signum:
            return 0
        if not gateway_pid_file.exists() and not transport_pid_file.exists():
            return 0
        action = session._supervise_tick(
            gateway_pid_file,
            transport_pid_file,
            gateway_log,
            transport_log,
            restarts,
        )
        if action == "exit":
            print(
                "sitecard-supervisor: child keeps dying. Recent logs:",
                file=sys.stderr,
            )
            session._tail_stderr(transport_log, 100)
            session._tail_stderr(gateway_log, 100)
            return 1
        time.sleep(POLL_INTERVAL)


def main(argv: list[str] | None = None) -> int:
    del argv
    st.setup_state()
    stop_signum: list[int] = []

    def _handle(signum: int, frame: Any) -> None:
        stop_signum.append(signum)

    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, _handle)
    return _run(stop_signum)


if __name__ == "__main__":
    raise SystemExit(main())
