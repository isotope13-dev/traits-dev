"""Optional TOML configuration; explicit command-line values take precedence."""

from __future__ import annotations

from pathlib import Path
from typing import Any


FIELDS = {
    "relay": {"enabled": ("model_relay", bool), "port": ("relay_port", int),
              "upstream": ("upstream", str), "proxy_env": ("proxy_env", str),
              "anonymous": ("anonymous", bool)},
    "tunnel": {"provider": ("transport", str), "id": ("tunnel_id", str),
               "token_file": ("devtunnel_token_file", str)},
    "ssh": {"enabled": ("ssh", bool), "accept": ("accept", bool),
            "port": ("gateway_port", int), "web_port": ("ssh_web_port", int)},
}


def apply(args: Any) -> None:
    if not args.config:
        return
    try:
        import tomllib
    except ImportError:
        raise ValueError("TOML configuration requires Python 3.11+; use CLI flags on Python 3.10") from None
    path = Path(args.config).expanduser().resolve()
    with path.open("rb") as source:
        data = tomllib.load(source)
    for section, values in data.items():
        if section not in FIELDS or not isinstance(values, dict):
            raise ValueError(f"Unknown or invalid configuration section: {section}")
        for key, value in values.items():
            if key not in FIELDS[section]:
                raise ValueError(f"Unknown configuration setting: {section}.{key}")
            name, kind = FIELDS[section][key]
            if type(value) is not kind:
                raise ValueError(f"Invalid type for configuration setting: {section}.{key}")
            if getattr(args, name) is None:
                if name == "devtunnel_token_file":
                    token = Path(value).expanduser()
                    value = str(token if token.is_absolute() else path.parent / token)
                setattr(args, name, value)
