"""Command-line parser and entry point dispatch for Sitecard."""

from __future__ import annotations

import argparse
import sys
from typing import Sequence

from sitecard import session, transfer, transports

SUBCOMMANDS = (
    "start",
    "serve",
    "up",
    "stop",
    "down",
    "status",
    "ps",
    "connect",
    "ssh",
    "logs",
    "log",
    "restart",
    "reload",
    "upgrade",
    "open",
    "shut",
    "inspect",
    "enter",
    "trace",
    "cycle",
    "forward",
    "upload",
    "relay-host",
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="sitecard",
        description="Disposable SSH gateway into confined directory workspaces.",
    )
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"sitecard {session._version()}",
    )
    sub = parser.add_subparsers(dest="command", required=True, metavar="command")

    start_parser = sub.add_parser(
        "start",
        aliases=["serve", "up", "open"],
        description="Start SSH access to a workspace.",
        help="Start SSH access to a workspace (aliases: serve, up, open).",
    )
    start_parser.add_argument(
        "workspace",
        nargs="?",
        help="Directory to make available (default: current directory).",
    )
    start_parser.add_argument(
        "port_arg",
        nargs="?",
        type=int,
        help="Local SSH server port (shorthand positional).",
    )
    start_parser.add_argument(
        "slot_arg",
        nargs="?",
        type=int,
        help="srv.us tunnel slot (shorthand positional).",
    )
    start_parser.add_argument(
        "-p",
        "--ssh-port",
        dest="port",
        type=int,
        default=None,
        help=f"Local SSH server port (default: {session.DEFAULT_PORT}).",
    )
    start_parser.add_argument("--port", dest="port", type=int, help=argparse.SUPPRESS)
    start_parser.add_argument(
        "-s",
        "--tunnel-slot",
        dest="slot",
        type=int,
        default=None,
        help=f"srv.us tunnel slot (default: {session.DEFAULT_SLOT}).",
    )
    start_parser.add_argument("--slot", dest="slot", type=int, help=argparse.SUPPRESS)
    start_parser.add_argument(
        "-t",
        "--provider",
        dest="transport",
        choices=(*transports.VALID_TRANSPORTS, "ms"),
        default=None,
        help=f"Public connection provider (default: {transports.DEFAULT_TRANSPORT}).",
    )
    start_parser.add_argument(
        "--transport",
        dest="transport",
        choices=transports.VALID_TRANSPORTS,
        help=argparse.SUPPRESS,
    )
    start_parser.add_argument(
        "--public-access",
        dest="accept",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Allow connections without SSH credentials (unsafe on public endpoints).",
    )
    start_parser.add_argument(
        "--accept",
        dest="accept",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=argparse.SUPPRESS,
    )
    start_parser.add_argument(
        "--tcp-forwarding",
        dest="allow_tcp_forwarding",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Allow SSH port forwarding (enabled by default; --no-tcp-forwarding disables).",
    )
    start_parser.add_argument(
        "--allow-tcp-forwarding",
        dest="allow_tcp_forwarding",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=argparse.SUPPRESS,
    )
    start_parser.add_argument(
        "--restrict-file-transfer",
        dest="confine_sftp",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Keep SFTP and SCP transfers inside the workspace.",
    )
    start_parser.add_argument(
        "--confine-sftp",
        dest="confine_sftp",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=argparse.SUPPRESS,
    )
    start_parser.add_argument(
        "-e",
        "--relay-url",
        dest="endpoint",
        help="WebSocket relay URL (for upterm, cloudflare, or ws-relay providers).",
    )
    start_parser.add_argument("--endpoint", dest="endpoint", help=argparse.SUPPRESS)
    start_parser.add_argument(
        "-H",
        "--public-hostname",
        dest="hostname",
        help="Public hostname (for the cloudflared provider).",
    )
    start_parser.add_argument("--hostname", dest="hostname", help=argparse.SUPPRESS)
    start_parser.add_argument(
        "--cloudflare-token",
        dest="token",
        help="Cloudflare tunnel token (for the cloudflared provider).",
    )
    start_parser.add_argument("--token", dest="token", help=argparse.SUPPRESS)
    start_parser.add_argument(
        "-i", "--tunnel-id", help="Existing Dev Tunnel ID with the service port already configured."
    )
    start_parser.add_argument(
        "-k", "--devtunnel-token-file",
        help="File containing a host-scoped Dev Tunnel token; read via stdin, not argv."
    )
    start_parser.add_argument("-c", "--config", help="TOML settings file (Python 3.11+).")
    start_parser.add_argument("-m", "--model-relay", action=argparse.BooleanOptionalAction, default=None,
                              help="Serve a streaming Responses API relay in the foreground.")
    start_parser.add_argument("--relay-port", type=int, help="HTTP relay port (default: 8080; -p also selects it in relay mode).")
    start_parser.add_argument("--gateway-port", type=int, help="SSH listener port in model-relay mode (default: 4822).")
    start_parser.add_argument("--ssh-web-port", type=int, help="Dev Tunnel HTTP/WebSocket port for SSH (default: 8081).")
    start_parser.add_argument("--ssh", action=argparse.BooleanOptionalAction, default=None,
                              help="Also serve SSH (enabled by default; --no-ssh selects model relay only).")
    start_parser.add_argument("--upstream", help="Model API upstream base URL.")
    start_parser.add_argument("--proxy-env", help="Remote HTTP proxy variable (default: HTTPS_PROXY).")
    start_parser.add_argument("-a", "--anonymous", action=argparse.BooleanOptionalAction, default=None,
                              help="Serve without client authentication; requires anonymous tunnel-port access.")
    seed_group = start_parser.add_mutually_exclusive_group()
    seed_group.add_argument(
        "--identity-seed",
        dest="identity_seed",
        metavar="VALUE",
        default=None,
        help="srv.us identity seed value (visible in argv/history; ignored by other providers).",
    )
    seed_group.add_argument(
        "--identity-seed-file",
        dest="identity_seed_file",
        metavar="PATH",
        default=None,
        help="File holding the srv.us identity seed (overrides SITECARD_IDENTITY_SEED; ignored by other providers).",
    )
    start_parser.add_argument(
        "--foreground",
        dest="foreground",
        action="store_true",
        help="Stay in the foreground and supervise gateway and transport.",
    )
    start_parser.add_argument(
        "--hold",
        type=int,
        default=None,
        metavar="SECONDS",
        help=(
            "Stay in the foreground for SECONDS, report progress, then stop both "
            f"services (default: {session.HOLD_DEFAULT_SECONDS} for sitecard, none otherwise)."
        ),
    )
    start_parser.add_argument(
        "--hold-every",
        type=int,
        default=None,
        metavar="SECONDS",
        help=f"Progress report interval while holding (default: {session.HOLD_HEARTBEAT_DEFAULT}).",
    )
    start_parser.add_argument(
        "--json",
        dest="json",
        action="store_true",
        help="Emit machine-readable JSON on stdout.",
    )
    start_parser.add_argument(
        "--replace-stale",
        action="store_true",
        help="Replace tracked processes when they are not publicly healthy.",
    )
    start_parser.add_argument(
        "--rendezvous-url",
        metavar="URL",
        default=None,
        help="Publish srv.us readiness to an HTTP endpoint.",
    )
    start_parser.add_argument(
        "--notte-api", dest="notte_api", action="store_true", help=argparse.SUPPRESS
    )
    start_parser.add_argument(
        "--notte-user",
        dest="notte_user",
        metavar="VALUE",
        default=None,
        help=argparse.SUPPRESS,
    )

    sub.add_parser(
        "stop",
        aliases=["down", "shut"],
        description="Stop SSH access and its connection provider.",
        help="Stop SSH access (aliases: down, shut).",
    )

    status_parser = sub.add_parser(
        "status",
        aliases=["ps", "inspect"],
        description="Show service health, connection details, and security settings.",
        help="Show current status (aliases: ps, inspect).",
    )
    status_parser.add_argument(
        "--json",
        dest="json",
        action="store_true",
        help="Emit machine-readable JSON on stdout.",
    )

    connect_parser = sub.add_parser(
        "connect",
        aliases=["ssh", "enter"],
        description="Show how to connect with SSH.",
        help="Show SSH connection instructions (aliases: ssh, enter).",
    )
    connect_parser.add_argument(
        "--json",
        dest="json",
        action="store_true",
        help="Emit machine-readable JSON on stdout.",
    )

    logs_parser = sub.add_parser(
        "logs",
        aliases=["log", "trace"],
        description="View or follow service logs.",
        help="View or follow service logs (aliases: log, trace).",
    )
    logs_parser.add_argument(
        "target",
        nargs="?",
        default="all",
        choices=["all", "gateway", "transport"],
        help="Target log stream to inspect (default all).",
    )
    logs_parser.add_argument(
        "-f",
        "--follow",
        dest="f",
        action="store_true",
        help="Follow log stream output continuously.",
    )

    sub.add_parser(
        "restart",
        aliases=["reload", "cycle"],
        description="Restart SSH access using the saved settings.",
        help="Restart using saved settings (aliases: reload, cycle).",
    )

    upgrade_parser = sub.add_parser(
        "upgrade",
        description="Fetch and install latest Sitecard release.",
        help="Fetch and install latest Sitecard release.",
    )
    upgrade_parser.add_argument(
        "--version",
        help="Install a specific published version instead of the latest stable release.",
    )

    forward_parser = sub.add_parser(
        "forward", help="Forward a remote proxy through SSH exec using existing Python and SSH."
    )
    forward_parser.add_argument("ssh_target", help="SSH user@host on the remote machine.")
    forward_parser.add_argument("--ssh-port", type=int, default=4822)
    forward_parser.add_argument("--listen-port", type=int, required=True)
    forward_parser.add_argument("--proxy-env", default="HTTPS_PROXY")

    upload_parser = sub.add_parser(
        "upload", help="Upload verified chunks through an existing SSH command."
    )
    transfer.add_upload_arguments(upload_parser)

    proxy_parser = sub.add_parser(
        "proxy",
        description=argparse.SUPPRESS,
    )
    proxy_parser.add_argument("url")

    upterm_proxy = sub.add_parser(
        "upterm-proxy",
        description=argparse.SUPPRESS,
    )
    upterm_proxy.add_argument("url")

    tunnel_proxy = sub.add_parser("tunnel-proxy", help="SSH ProxyCommand for a Dev Tunnel WebSocket URL.")
    tunnel_proxy.add_argument("url")

    relay_host = sub.add_parser("relay-host", help="Host a loopback reverse SSH relay for an HTTPS tunnel.")
    relay_host.add_argument("--port", type=int, required=True, help="Local HTTPS tunnel HTTP port.")
    relay_host.add_argument("--public-url", required=True, help="Public HTTPS origin for that port.")
    relay_host.add_argument("--tunnel-id", default="", help="Also host this existing Dev Tunnel.")
    relay_host.add_argument("--devtunnel-token-file", default="", help="Host token file passed to Dev Tunnel on stdin.")

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    supplied = list(sys.argv[1:] if argv is None else argv)
    if supplied in (["--help"], ["api", "--help"]):
        supplied = ["start"]
    args = parser.parse_args(supplied)

    if args.command in ("start", "serve", "up", "open"):
        from sitecard import config

        try:
            config.apply(args)
        except (OSError, ValueError) as error:
            parser.error(str(error))
        if args.transport == "ms":
            args.transport = "devtunnel"
        if args.model_relay or args.transport == "devtunnel":
            from sitecard import model_relay

            return model_relay.main(args)

    if args.command == "forward":
        from sitecard import tcp_forward

        return tcp_forward.main(args)

    if args.command == "upload":
        try:
            return transfer.cmd_upload(args)
        except transfer.TransferError as error:
            print(f"upload failed: {error}", file=sys.stderr)
            return 1

    if args.command == "tunnel-proxy":
        from sitecard import tunnel_bridge

        return tunnel_bridge.main(["client", args.url])

    if args.command == "relay-host":
        from sitecard import relay_host

        arguments = ["--port", str(args.port), "--public-url", args.public_url]
        if args.tunnel_id:
            arguments.extend(["--tunnel-id", args.tunnel_id])
        if args.devtunnel_token_file:
            arguments.extend(["--devtunnel-token-file", args.devtunnel_token_file])
        return relay_host.main(arguments)

    handlers = {
        "start": session.cmd_open,
        "serve": session.cmd_open,
        "up": session.cmd_open,
        "open": session.cmd_open,
        "stop": session.cmd_shut,
        "down": session.cmd_shut,
        "shut": session.cmd_shut,
        "status": session.cmd_inspect,
        "ps": session.cmd_inspect,
        "inspect": session.cmd_inspect,
        "connect": session.cmd_enter,
        "ssh": session.cmd_enter,
        "enter": session.cmd_enter,
        "logs": session.cmd_trace,
        "log": session.cmd_trace,
        "trace": session.cmd_trace,
        "restart": session.cmd_cycle,
        "reload": session.cmd_cycle,
        "cycle": session.cmd_cycle,
        "upgrade": session.cmd_upgrade,
        "proxy": transports.cmd_proxy,
        "upterm-proxy": transports.cmd_upterm_proxy,
    }

    handler = handlers.get(args.command)
    if handler is None:
        parser.print_help(sys.stderr)
        return 2
    return handler(args)


if __name__ == "__main__":
    sys.exit(main())
