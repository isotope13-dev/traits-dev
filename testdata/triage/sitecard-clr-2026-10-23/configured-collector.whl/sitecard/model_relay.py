"""Foreground HTTP model relay through the host environment's managed proxy."""

from __future__ import annotations

import contextlib
import http.client
import json
import os
import re
import secrets
import shlex
import signal
import ssl
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlencode, urlsplit

from sitecard import runtime, transports
from sitecard.account import ensure_username_environment

DEFAULT_UPSTREAM = "https://chatgpt.com:18080/backend-api/codex"


@dataclass
class Settings:
    upstream: str = DEFAULT_UPSTREAM
    proxy_env: str = "HTTPS_PROXY"
    timeout: float = 120

    def connection(self) -> http.client.HTTPConnection:
        upstream = urlsplit(self.upstream)
        proxy = urlsplit(os.environ.get(self.proxy_env, ""))
        if proxy.scheme != "http" or not proxy.hostname or proxy.username or proxy.password:
            raise ValueError("Remote HTTP proxy is missing or unsupported; check --proxy-env")
        if upstream.scheme == "https":
            cafile = os.environ.get("SSL_CERT_FILE") or os.environ.get("REQUESTS_CA_BUNDLE")
            connection = http.client.HTTPSConnection(
                proxy.hostname, proxy.port or 80, timeout=self.timeout,
                context=ssl.create_default_context(cafile=cafile),
            )
        else:
            connection = http.client.HTTPConnection(proxy.hostname, proxy.port or 80, timeout=self.timeout)
        connection.set_tunnel(upstream.hostname, upstream.port or (443 if upstream.scheme == "https" else 80))
        return connection


class RelayServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], settings: Settings):
        self.settings = settings
        super().__init__(address, Handler)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args: Any) -> None:
        # Request URLs and headers can contain client credentials.
        return

    def reply(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization, OpenAI-Beta")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:
        self.forward()

    def do_POST(self) -> None:
        self.forward()

    def forward(self) -> None:
        connection = None
        started = False
        try:
            url = urlsplit(self.path)
            if self.command == "GET" and url.path in ("/", "/health"):
                self.reply(200, {"service": "model-relay", "api": "/v1", "status": "ready"})
                return
            path = url.path
            model = None
            match = re.fullmatch(r"/model/([^/]+)(/v1/.*)", path)
            if match:
                model, path = unquote(match[1]), match[2]
            query = parse_qs(url.query, keep_blank_values=True)
            query_model = query.pop("model", [None])[-1]
            model = model or query_model
            if path == "/v1/chat/completions":
                self.close_connection = True
                self.reply(501, {"error": {"message": "This upstream uses Responses; configure your client for the Responses API."}})
                return
            if (self.command, path) not in (("POST", "/v1/responses"), ("GET", "/v1/models")):
                self.close_connection = True
                self.reply(404, {"error": {"message": "Use /v1/responses or /v1/models"}})
                return
            body = None
            if self.command == "POST":
                if self.headers.get("Transfer-Encoding"):
                    raise ValueError("Send JSON with Content-Length, not a chunked request body")
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= 16 * 1024 * 1024:
                    raise ValueError("Request body must be JSON, up to 16 MiB")
                payload = json.loads(self.rfile.read(length))
                if not isinstance(payload, dict):
                    raise ValueError("Request body must be a JSON object")
                if model:
                    payload["model"] = model
                payload.setdefault("store", False)
                body = json.dumps(payload).encode()
            upstream = urlsplit(self.server.settings.upstream)
            target = upstream.path.rstrip("/") + path.removeprefix("/v1")
            if query:
                target += "?" + urlencode(query, doseq=True)
            connection = self.server.settings.connection()
            connection.request(self.command, target, body=body, headers={
                "Content-Type": "application/json",
                "Accept": self.headers.get("Accept", "*/*"),
            })
            response = connection.getresponse()
            self.send_response(response.status)
            self.send_header("Content-Type", response.getheader("Content-Type", "application/json"))
            self.send_header("Transfer-Encoding", "chunked")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            started = True
            while chunk := response.read1(65536):
                self.wfile.write(f"{len(chunk):x}\r\n".encode() + chunk + b"\r\n")
                self.wfile.flush()
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
        except (ValueError, UnicodeError):
            self.close_connection = True
            if not started:
                self.reply(400, {"error": {"message": "Invalid request JSON, length, or proxy configuration"}})
        except (OSError, http.client.HTTPException):
            self.close_connection = True
            if not started:
                with contextlib.suppress(OSError):
                    self.reply(502, {"error": {"message": "Remote upstream connection failed; check proxy reachability and CA certificate"}})
        finally:
            if connection is not None:
                connection.close()


def wait_for_host(process: Any, log: Path, port: int, start_offset: int, timeout: float = 30) -> str:
    """Read this launch's file-backed output without blocking on partial lines."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError("Dev Tunnel exited; check its log and host-token expiry")
        try:
            with log.open("rb") as output:
                output.seek(start_offset)
                text = output.read().decode(errors="replace")
        except FileNotFoundError:
            text = ""
        if "Ready to accept connections" in text and re.search(rf"Hosting port:\s*{port}\b", text):
            urls = re.findall(r"https://[A-Za-z0-9.-]+\.devtunnels\.ms/?", text)
            for url in urls:
                if re.search(rf"-{port}\.", url):
                    return url.rstrip("/")
        time.sleep(0.1)
    raise RuntimeError("Dev Tunnel did not announce the relay port; provision that HTTP port before hosting")


def stop_child(process: Any) -> None:
    if process.poll() is None:
        with contextlib.suppress(ProcessLookupError):
            process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()


def main(args: Any) -> int:
    process = None
    children = []
    server = None
    thread = None
    stopped = threading.Event()
    previous = {}
    try:
        relay_enabled = bool(args.model_relay)
        ssh_enabled = args.ssh is not False
        if not relay_enabled and not ssh_enabled:
            raise ValueError("Enable SSH or the model relay")
        if relay_enabled and not (args.anonymous or args.accept):
            raise ValueError("Model relay currently requires explicit --anonymous (-a)")
        if args.transport not in (None, "devtunnel"):
            raise ValueError("Model relay currently supports --provider ms/devtunnel")
        port = args.port if args.port is not None else args.relay_port
        port = port if port is not None else args.port_arg or 8080
        ssh_port = args.gateway_port or (4822 if relay_enabled else args.port or args.port_arg or 4822)
        web_port = args.ssh_web_port or 8081
        ports = ([port] if relay_enabled else []) + ([ssh_port, web_port] if ssh_enabled else [])
        if any(not 1 <= value <= 65535 for value in ports) or len(set(ports)) != len(ports):
            raise ValueError("Service ports must be distinct integers between 1 and 65535")
        settings = Settings(args.upstream or DEFAULT_UPSTREAM, args.proxy_env or "HTTPS_PROXY")
        upstream = urlsplit(settings.upstream)
        if upstream.scheme not in ("http", "https") or not upstream.hostname or upstream.query or upstream.fragment or upstream.username:
            raise ValueError("--upstream must be an HTTP(S) API base URL")
        token_file = str(Path(args.devtunnel_token_file).expanduser().resolve()) if args.devtunnel_token_file else ""
        transports.validate_devtunnel(args.tunnel_id or "", token_file)
        # Prove the same environment can CONNECT and verify the upstream TLS.
        if relay_enabled:
            with contextlib.closing(settings.connection()) as probe:
                probe.timeout = 10
                probe.connect()
            server = RelayServer(("127.0.0.1", port), settings)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
        state = runtime.state_dir() / "devtunnel-foreground"
        state.mkdir(mode=0o700, parents=True, exist_ok=True)
        if ssh_enabled:
            root = Path(args.workspace or ".").expanduser().resolve(strict=True)
            if not root.is_dir():
                raise ValueError("Workspace must be a directory")
            accept = args.accept if args.accept is not None else __package__ == "sitecard"
            if not accept and not (state / "authorized_keys").exists():
                raise ValueError("Supply authorized_keys in foreground state or use --accept")
            if runtime.port_open(ssh_port) or runtime.port_open(web_port):
                raise ValueError("SSH listener or WebSocket port is already occupied; select another port")
            gateway = transports.launch_gateway(
                "devtunnel", root, ssh_port, "" if accept else secrets.token_urlsafe(24),
                accept, args.allow_tcp_forwarding is not False, state, bool(args.confine_sftp),
            )
            children.append(gateway)
            for _ in range(100):
                if gateway.poll() is not None:
                    raise RuntimeError("SSH gateway exited; check gateway.log")
                if transports.probe_local_ssh(ssh_port):
                    break
                time.sleep(0.1)
            else:
                raise RuntimeError("SSH gateway did not become ready")
            bridge = transports._spawn(
                [sys.executable, "-m", "sitecard.tunnel_bridge", "server", "--port", str(web_port), "--ssh-port", str(ssh_port)],
                transports._scrubbed_env(), state / "ssh-web.log",
            )
            children.append(bridge)
            for _ in range(100):
                if bridge.poll() is not None:
                    raise RuntimeError("SSH WebSocket bridge exited; check ssh-web.log")
                if runtime.port_open(web_port):
                    break
                time.sleep(0.1)
            else:
                raise RuntimeError("SSH WebSocket bridge did not become ready")
        transport_log = state / "transport.log"
        log_offset = transport_log.stat().st_size if transport_log.exists() else 0
        process = transports.launch_transport_devtunnel(args.tunnel_id, token_file, state)
        children.append(process)
        if relay_enabled:
            endpoint = wait_for_host(process, transport_log, port, log_offset)
            print(f"Model API: {endpoint}/v1", flush=True)
            print(f"Model override: {endpoint}/model/<model>/v1", flush=True)
        if ssh_enabled:
            endpoint = wait_for_host(process, transport_log, web_port, log_offset)
            proxy = "sitecard tunnel-proxy " + endpoint.replace("https://", "wss://") + "/ssh"
            print(f"SSH URL: {endpoint}/ssh", flush=True)
            print(f"ssh -o ProxyCommand={shlex.quote(proxy)} {ensure_username_environment()}@{urlsplit(endpoint).hostname}", flush=True)
        print("Foreground service. Ctrl-C stops its children. No client devtunnel connect required.", flush=True)
        for signum in (signal.SIGINT, signal.SIGTERM):
            previous[signum] = signal.signal(signum, lambda *_: stopped.set())
        while not stopped.wait(0.5):
            if any(child.poll() is not None for child in children):
                raise RuntimeError("A service stopped; check logs, refresh an expired host token, and rerun the command")
        return 0
    except KeyboardInterrupt:
        return 0
    except (OSError, ValueError, RuntimeError) as error:
        print(str(error), file=sys.stderr)
        return 1
    finally:
        for signum, handler in previous.items():
            signal.signal(signum, handler)
        for child in reversed(children):
            stop_child(child)
        if server is not None:
            if thread is not None:
                server.shutdown()
                thread.join()
            server.server_close()
