"""Loopback proxy forwarding over SSH exec, without direct-TCP/IP channels.

The remote helper uses only Python's standard library. It resolves the proxy
in the SSH command's environment, not in the gateway's forwarding callback.
It cannot cross a network namespace which that command cannot access.
"""

from __future__ import annotations

import asyncio
import contextlib
import re
import shlex
import shutil
import sys
from typing import Any


REMOTE_SCRIPT = r'''
import os, select, socket, sys
from urllib.parse import urlsplit
try:
    proxy = urlsplit(os.environ[sys.argv[1]])
    if proxy.scheme != "http" or not proxy.hostname or proxy.username or proxy.password:
        raise ValueError()
    peer = socket.create_connection((proxy.hostname, proxy.port or 80), timeout=10)
except (KeyError, OSError, ValueError):
    sys.stderr.write("Remote HTTP proxy is missing, unsupported, or unreachable in the SSH exec context.\n")
    sys.exit(1)
peer.settimeout(None)
sys.stdout.buffer.write(b"READY\n")
sys.stdout.buffer.flush()
inputs = [peer, sys.stdin.buffer]
try:
    while True:
        readable, _, _ = select.select(inputs, [], [])
        for source in readable:
            if source is peer:
                data = peer.recv(65536)
                if not data:
                    sys.exit(0)
                sys.stdout.buffer.write(data)
                sys.stdout.buffer.flush()
            else:
                data = os.read(sys.stdin.fileno(), 65536)
                if not data:
                    inputs.remove(sys.stdin.buffer)
                    peer.shutdown(socket.SHUT_WR)
                else:
                    peer.sendall(data)
except (OSError, BrokenPipeError):
    sys.exit(1)
finally:
    peer.close()
'''


def ssh_command(target: str, port: int, proxy_env: str) -> list[str]:
    if not re.fullmatch(r"[A-Za-z0-9_.@:\[\]-]+", target) or target.startswith("-"):
        raise ValueError("SSH target must be a user@host or hostname")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", proxy_env):
        raise ValueError("Proxy environment variable name is invalid")
    if not 1 <= port <= 65535:
        raise ValueError("SSH port must be between 1 and 65535")
    return [
        "ssh", "-T", "-p", str(port),
        "-o", "BatchMode=yes", "-o", "ConnectTimeout=10",
        "-o", "ServerAliveInterval=15", "-o", "ServerAliveCountMax=2",
        target, "python3 -u -c " + shlex.quote(REMOTE_SCRIPT) + " " + shlex.quote(proxy_env),
    ]


async def handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, command: list[str]) -> None:
    process = None
    tasks = []
    try:
        process = await asyncio.create_subprocess_exec(
            *command, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
        )
        if await asyncio.wait_for(process.stdout.readline(), timeout=15) != b"READY\n":
            raise ConnectionError("Remote proxy did not become ready")

        async def upload() -> None:
            while data := await reader.read(65536):
                process.stdin.write(data)
                await process.stdin.drain()
            process.stdin.close()

        async def download() -> None:
            while data := await process.stdout.read(65536):
                writer.write(data)
                await writer.drain()

        tasks = [asyncio.create_task(upload()), asyncio.create_task(download())]
        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for task in done:
            task.result()
        # Client EOF is a half-close: the remote server may still have a reply.
        if tasks[0] in done and tasks[1] not in done:
            await asyncio.wait_for(tasks[1], timeout=30)
    except (OSError, ConnectionError, asyncio.TimeoutError):
        print("Proxy connection failed; check SSH and remote proxy reachability.", file=sys.stderr)
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        if process is not None:
            if process.returncode is None:
                with contextlib.suppress(ProcessLookupError):
                    process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=3)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
        writer.close()
        try:
            await writer.wait_closed()
        except OSError:
            pass


async def serve(command: list[str], port: int) -> None:
    server = await asyncio.start_server(
        lambda reader, writer: handle(reader, writer, command), "127.0.0.1", port
    )
    print(f"HTTP proxy forwarding listening on 127.0.0.1:{port}", file=sys.stderr)
    async with server:
        await server.serve_forever()


def main(args: Any) -> int:
    try:
        command = ssh_command(args.ssh_target, args.ssh_port, args.proxy_env)
        if not 1 <= args.listen_port <= 65535:
            raise ValueError("Listen port must be between 1 and 65535")
        if not shutil.which("ssh"):
            raise ValueError("ssh executable not found in PATH")
        asyncio.run(serve(command, args.listen_port))
    except (ValueError, OSError) as error:
        print(str(error), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130
    return 0
