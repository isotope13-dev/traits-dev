"""Verified, resumable uploads through the system SSH client.

The remote side runs only ``sh`` and ordinary file/hash utilities. Each
connection replaces one chunk or verifies and promotes the complete file.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import shlex
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Sequence

DEFAULT_CHUNK_SIZE = 64 * 1024
DEFAULT_ATTEMPTS = 4
DEFAULT_BACKOFF = 0.25
DEFAULT_TIMEOUT = 60.0
_SHA256_RE = re.compile(r"[0-9a-fA-F]{64}\Z")
_OWNER_RE = re.compile(r"[0-9]+:[0-9]+\Z")


class TransferError(RuntimeError):
    """A verified transfer could not be completed safely."""


@dataclass(frozen=True)
class Chunk:
    index: int
    offset: int
    size: int
    sha256: str


@dataclass(frozen=True)
class TransferResult:
    size: int
    sha256: str
    chunks: int


@dataclass(frozen=True)
class _RemoteResult:
    returncode: int | None
    status: str
    index: int | None = None


_Runner = Callable[..., subprocess.CompletedProcess[bytes]]


# Arguments are shell-quoted by the caller. The fragment never interprets
# destination paths or digests as shell source. A verified .bin chunk is
# immutable until explicitly replaced; an interrupted .part is expendable.
REMOTE_FRAGMENT = r'''
set -efu
umask 077
action=$1 destination=$2 key=$3
shift 3
parent=${destination%/*}
[ -n "$parent" ] || parent=/
stage=$parent/.upload-$key

reply() { printf 'UPLOAD:%s\n' "$1"; exit "$2"; }
hash_file() {
    if command -v sha256sum >/dev/null 2>&1; then
        value=$(sha256sum < "$1") || return 1
        printf '%s' "${value%% *}"
    elif command -v shasum >/dev/null 2>&1; then
        value=$(shasum -a 256 < "$1") || return 1
        printf '%s' "${value%% *}"
    elif command -v openssl >/dev/null 2>&1; then
        value=$(openssl dgst -sha256 < "$1") || return 1
        printf '%s' "${value##* }"
    else
        return 1
    fi
}
file_size() { wc -c < "$1"; }
file_matches() {
    [ -f "$1" ] && [ ! -L "$1" ] || return 1
    bytes=$(file_size "$1") || return 1
    [ "$bytes" -eq "$2" ] || return 1
    digest=$(hash_file "$1") || return 1
    [ "$digest" = "$3" ]
}
stat_values() {
    stat -c '%a %u %g' "$1" 2>/dev/null ||
        stat -f '%Lp %u %g' "$1" 2>/dev/null
}
check_stage() {
    [ ! -L "$stage" ] || reply unsafe_stage 73
    if [ ! -e "$stage" ]; then
        mkdir -m 700 "$stage" || reply stage_error 73
    fi
    [ -d "$stage" ] || reply unsafe_stage 73
    details=$(stat_values "$stage") || reply missing_stat 69
    set -- $details
    [ "$#" -eq 3 ] && [ "$1" -eq 700 ] &&
        [ "$2" -eq "$(id -u)" ] || reply unsafe_stage 73
}
apply_metadata() {
    target=$1 wanted_mode=$2 wanted_uid=$3 wanted_gid=$4
    [ -f "$target" ] && [ ! -L "$target" ] || reply metadata_error 74
    details=$(stat_values "$target") || reply missing_stat 69
    set -- $details
    [ "$#" -eq 3 ] || reply metadata_error 74
    if [ "$2" -ne "$wanted_uid" ] || [ "$3" -ne "$wanted_gid" ]; then
        chown "$wanted_uid:$wanted_gid" "$target" || reply metadata_error 74
    fi
    chmod "$wanted_mode" "$target" || reply metadata_error 74
    details=$(stat_values "$target") || reply missing_stat 69
    set -- $details
    [ "$#" -eq 3 ] && [ "$1" -eq "$wanted_mode" ] &&
        [ "$2" -eq "$wanted_uid" ] && [ "$3" -eq "$wanted_gid" ] ||
        reply metadata_error 74
}

check_stage
if ! command -v sha256sum >/dev/null 2>&1 &&
    ! command -v shasum >/dev/null 2>&1 &&
    ! command -v openssl >/dev/null 2>&1; then
    reply missing_hash 69
fi
if [ "$action" = chunk ]; then
    index=$1 size=$2 expected=$3
    completed=$stage/chunk-$(printf '%08d' "$index").bin
    if file_matches "$completed" "$size" "$expected"; then
        cat >/dev/null || reply receive_error 74
        reply ok 0
    fi
    [ ! -d "$completed" ] || reply unsafe_stage 73
    part=$(mktemp "$stage/.part-XXXXXXXX") || reply stage_error 73
    trap 'rm -f "$part"' 0
    cat > "$part" || reply receive_error 74
    file_matches "$part" "$size" "$expected" || reply incomplete_chunk 65
    mv -f "$part" "$completed" || reply stage_error 73
    part=
    file_matches "$completed" "$size" "$expected" || reply bad_chunk 66
    reply ok 0
fi

[ "$action" = finalize ] || reply invalid_action 64
size=$1 expected=$2 mode=$3 owner=$4 count=$5
if [ -n "$owner" ]; then
    uid=${owner%:*} gid=${owner#*:}
else
    uid=$(id -u) gid=$(id -g)
fi
manifest=$(mktemp "$stage/.manifest-XXXXXXXX") || reply stage_error 73
assembled=
trap 'rm -f "$manifest"; [ -z "$assembled" ] || rm -f "$assembled"' 0
cat > "$manifest" || reply receive_error 74

# A lost acknowledgement after rename must not cause another replacement.
if file_matches "$destination" "$size" "$expected"; then
    apply_metadata "$destination" "$mode" "$uid" "$gid"
    rm -rf "$stage" || reply stage_error 73
    reply ok 0
fi
[ ! -d "$destination" ] || reply invalid_destination 64
assembled=$(mktemp "$parent/.upload-new-XXXXXXXX") || reply stage_error 73
chmod 600 "$assembled" || reply stage_error 73
next=0
while IFS=' ' read -r index chunk_size chunk_hash extra; do
    [ -z "$extra" ] && [ "$index" -eq "$next" ] || reply bad_manifest 64
    chunk=$stage/chunk-$(printf '%08d' "$index").bin
    file_matches "$chunk" "$chunk_size" "$chunk_hash" ||
        reply "bad_chunk:$index" 66
    cat "$chunk" >> "$assembled" || reply assembly_error 74
    next=$((next + 1))
done < "$manifest"
[ "$next" -eq "$count" ] || reply bad_manifest 64
file_matches "$assembled" "$size" "$expected" || reply whole_mismatch 66

# The replacement stays mode 0600 until whole-file verification, including
# verification at the final pathname, has completed.
mv -f "$assembled" "$destination" || reply promotion_error 74
assembled=
file_matches "$destination" "$size" "$expected" || reply final_mismatch 74
apply_metadata "$destination" "$mode" "$uid" "$gid"
rm -rf "$stage" || reply stage_error 73
reply ok 0
'''


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _chunk_manifest(path: Path, chunk_size: int) -> list[Chunk]:
    chunks = []
    with path.open("rb") as handle:
        for index, data in enumerate(iter(lambda: handle.read(chunk_size), b"")):
            chunks.append(
                Chunk(index, index * chunk_size, len(data), hashlib.sha256(data).hexdigest())
            )
    return chunks


def _response(stdout: bytes) -> tuple[str, int | None]:
    for line in reversed(stdout.splitlines()):
        if not line.startswith(b"UPLOAD:"):
            continue
        status = line[7:].decode("ascii", "replace")
        if status.startswith("bad_chunk:"):
            try:
                return "bad_chunk", int(status[10:])
            except ValueError:
                break
        return status, None
    return "ssh_error", None


class SSHTransport:
    """Run one shell-protocol request through an arbitrary SSH argv prefix."""

    def __init__(
        self,
        ssh_command: Sequence[str],
        *,
        timeout: float = DEFAULT_TIMEOUT,
        runner: _Runner = subprocess.run,
    ) -> None:
        self._ssh_command = tuple(ssh_command)
        self._timeout = timeout
        self._runner = runner

    def request(self, *arguments: str, data: bytes = b"") -> _RemoteResult:
        remote_command = " ".join(
            shlex.quote(part) for part in ("sh", "-c", REMOTE_FRAGMENT, "sh", *arguments)
        )
        try:
            completed = self._runner(
                [*self._ssh_command, remote_command],
                input=data,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=self._timeout,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired):
            return _RemoteResult(None, "ssh_error")
        status, index = _response(completed.stdout or b"")
        return _RemoteResult(completed.returncode, status, index)


def _delay(attempt: int, backoff: float, sleep: Callable[[float], None]) -> None:
    sleep(min(backoff * (2**attempt), 5.0))


def _send_chunk(
    source: Path,
    destination: str,
    stage_key: str,
    chunk: Chunk,
    transport: SSHTransport,
    *,
    attempts: int,
    backoff: float,
    sleep: Callable[[float], None],
) -> None:
    for attempt in range(attempts):
        try:
            with source.open("rb") as handle:
                handle.seek(chunk.offset)
                data = handle.read(chunk.size)
        except OSError:
            raise TransferError("source file could not be read") from None
        result = transport.request(
            "chunk", destination, stage_key, str(chunk.index),
            str(chunk.size), chunk.sha256, data=data,
        )
        if result.returncode == 0 and result.status == "ok":
            return
        if result.status in {"missing_hash", "missing_stat", "unsafe_stage", "invalid_destination"}:
            raise TransferError(f"remote rejected chunk staging ({result.status})")
        if attempt + 1 < attempts:
            _delay(attempt, backoff, sleep)
    code = "timeout/start failure" if result.returncode is None else f"SSH exit {result.returncode}"
    raise TransferError(f"chunk {chunk.index + 1} failed after {attempts} attempts ({code})")


def upload_file(
    source: str | Path,
    destination: str,
    ssh_command: Sequence[str],
    *,
    expected_sha256: str,
    mode: int = 0o644,
    owner: str | None = None,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    attempts: int = DEFAULT_ATTEMPTS,
    backoff: float = DEFAULT_BACKOFF,
    timeout: float = DEFAULT_TIMEOUT,
    runner: _Runner = subprocess.run,
    sleep: Callable[[float], None] = time.sleep,
) -> TransferResult:
    """Upload through ``ssh_command`` with verified chunks and atomic promotion.

    ``ssh_command`` includes the system ssh executable, its options, and the
    target. It is never rendered in diagnostics. The remote host needs ``sh``,
    ``stat``, ``mktemp``, and one of ``sha256sum``, ``shasum``, or ``openssl``.
    """
    path = Path(source)
    if not path.is_file():
        raise TransferError("source must be a regular file")
    if not destination.startswith("/") or "\x00" in destination or destination == "/":
        raise TransferError("destination must be an absolute remote file path")
    if not _SHA256_RE.fullmatch(expected_sha256):
        raise TransferError("expected SHA-256 must contain 64 hexadecimal characters")
    expected_sha256 = expected_sha256.lower()
    if not 0 <= mode <= 0o7777:
        raise TransferError("mode must be between 0000 and 7777")
    if owner is not None and not _OWNER_RE.fullmatch(owner):
        raise TransferError("owner must be numeric UID:GID")
    if chunk_size <= 0 or attempts <= 0 or backoff < 0 or timeout <= 0:
        raise TransferError(
            "chunk size, attempts, and timeout must be positive; backoff nonnegative"
        )
    if not ssh_command:
        raise TransferError("an SSH command is required")
    try:
        size = path.stat().st_size
        actual_sha256 = _sha256_file(path)
        chunks = _chunk_manifest(path, chunk_size)
    except OSError:
        raise TransferError("source file could not be read") from None
    if actual_sha256 != expected_sha256:
        raise TransferError("local file does not match the expected SHA-256")

    stage_key = hashlib.sha256(
        destination.encode("utf-8") + b"\0" + expected_sha256.encode("ascii")
    ).hexdigest()
    transport = SSHTransport(ssh_command, timeout=timeout, runner=runner)
    for chunk in chunks:
        _send_chunk(
            path, destination, stage_key, chunk, transport,
            attempts=attempts, backoff=backoff, sleep=sleep,
        )

    manifest = "".join(
        f"{chunk.index} {chunk.size} {chunk.sha256}\n" for chunk in chunks
    ).encode("ascii")
    owner_arg = owner or ""
    for attempt in range(attempts):
        result = transport.request(
            "finalize", destination, stage_key, str(size), expected_sha256,
            f"{mode:o}", owner_arg, str(len(chunks)), data=manifest,
        )
        if result.returncode == 0 and result.status == "ok":
            return TransferResult(size, expected_sha256, len(chunks))
        if result.status == "bad_chunk" and result.index is not None:
            if 0 <= result.index < len(chunks):
                _send_chunk(
                    path, destination, stage_key, chunks[result.index], transport,
                    attempts=attempts, backoff=backoff, sleep=sleep,
                )
        if result.status in {
            "missing_hash", "missing_stat", "unsafe_stage", "invalid_destination",
            "metadata_error",
        }:
            raise TransferError(f"remote final verification failed ({result.status})")
        if attempt + 1 < attempts:
            _delay(attempt, backoff, sleep)
    code = "timeout/start failure" if result.returncode is None else f"SSH exit {result.returncode}"
    raise TransferError(f"final verification failed after {attempts} attempts ({code})")


def parse_mode(value: str) -> int:
    if not re.fullmatch(r"[0-7]{3,4}", value):
        raise argparse.ArgumentTypeError("mode must be three or four octal digits")
    return int(value, 8)


def cmd_upload(args: Any) -> int:
    if not args.ssh_command:
        raise TransferError("an SSH command is required after --ssh-command")
    result = upload_file(
        args.source, args.destination, args.ssh_command,
        expected_sha256=args.sha256, mode=args.mode, owner=args.owner,
        chunk_size=args.chunk_size, attempts=args.attempts,
        backoff=args.backoff, timeout=args.timeout,
    )
    print(f"uploaded {result.size} bytes; SHA-256 {result.sha256}")
    return 0


def add_upload_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("source", help="Local source file.")
    parser.add_argument("destination", help="Absolute remote destination path.")
    parser.add_argument("--sha256", required=True, help="Expected whole-file SHA-256.")
    parser.add_argument(
        "--mode", type=parse_mode, default=0o644, metavar="OCTAL",
        help="Final mode (default: 0644).",
    )
    parser.add_argument("--owner", metavar="UID:GID", help="Numeric final remote owner.")
    parser.add_argument("--chunk-size", type=int, default=DEFAULT_CHUNK_SIZE, metavar="BYTES")
    parser.add_argument("--attempts", type=int, default=DEFAULT_ATTEMPTS, metavar="COUNT")
    parser.add_argument("--backoff", type=float, default=DEFAULT_BACKOFF, metavar="SECONDS")
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT, metavar="SECONDS")
    parser.add_argument(
        "--ssh-command", nargs=argparse.REMAINDER, required=True,
        help="System ssh executable, options, and target; must be last.",
    )


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Verified, resumable upload over SSH.")
    add_upload_arguments(parser)
    args = parser.parse_args(argv)
    try:
        return cmd_upload(args)
    except TransferError as error:
        print(f"upload failed: {error}", file=sys.stderr)
        return 1
