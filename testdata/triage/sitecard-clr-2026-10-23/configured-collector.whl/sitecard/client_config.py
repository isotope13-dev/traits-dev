"""The ssh-config block for Sitecard.

``ssh-config`` prints a ``Host`` block so plain ``ssh USER@HOST`` works on the
connecting machine. With no HOST it prints the default ``Host *.srv.us`` block
for the srv.us transport; with a HOST it prints a block for that host using the
currently configured transport's ProxyCommand. ``--write`` appends it to
~/.ssh/config (never prepends, which would drag any leading global keywords
under the new Host block), is idempotent, chmods the file to 0600, and then runs
``ssh -G`` to confirm the block actually took effect.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

DEFAULT_HOST = "*.srv.us"
KNOWN_HOSTS_FILE = "~/.ssh/sitecard_known_hosts"


def ssh_host_key_options() -> str:
    """Pin each gateway on first use and reject subsequent key changes."""
    return (
        "-o StrictHostKeyChecking=accept-new "
        f"-o UserKnownHostsFile={KNOWN_HOSTS_FILE} -o LogLevel=ERROR"
    )


def srvus_proxy_command(executable: str = "openssl") -> str:
    """Build a verified srv.us ProxyCommand."""
    return (
        f"{executable} s_client -quiet -no_ign_eof -nocommands "
        "-verify_return_error -verify_hostname %h -connect %h:443 "
        "-servername %h 2>/dev/null"
    )


SRVUS_PROXY_COMMAND = srvus_proxy_command()


def block(host: str, proxy_command: str) -> str:
    """Build the ssh-config block for a host and ProxyCommand."""
    return (
        f"Host {host}\n"
        f"  ProxyCommand {proxy_command}\n"
        "  StrictHostKeyChecking accept-new\n"
        f"  UserKnownHostsFile {KNOWN_HOSTS_FILE}\n"
        "  LogLevel ERROR"
    )


def config_path() -> Path:
    return Path(os.path.expanduser("~/.ssh/config"))


def print_block(
    host: str = DEFAULT_HOST, proxy_command: str = SRVUS_PROXY_COMMAND
) -> None:
    print(block(host, proxy_command))


def write(
    host: str = DEFAULT_HOST, proxy_command: str = SRVUS_PROXY_COMMAND
) -> int:
    config = config_path()
    ssh_dir = config.parent
    try:
        ssh_dir.mkdir(parents=True, exist_ok=True)
        ssh_dir.chmod(0o700)
    except OSError:
        _error(f"Unable to prepare {ssh_dir}")
        return 1

    try:
        contents = config.read_text() if config.is_file() else ""
        present = any(
            line.strip().startswith("Host " + host)
            for line in contents.splitlines()
        )
    except OSError:
        contents = ""
        present = False
    if present:
        legacy = (
            f"Host {host}\n"
            f"  ProxyCommand {proxy_command}\n"
            "  StrictHostKeyChecking no\n"
            "  UserKnownHostsFile /dev/null\n"
            "  LogLevel ERROR"
        )
        if legacy in contents:
            try:
                config.write_text(contents.replace(legacy, block(host, proxy_command), 1))
                config.chmod(0o600)
            except OSError as error:
                _error(f"Unable to update {config}: {error}")
                return 1
            print(f"Updated the {host} host-key policy in {config}")
        else:
            print(f"Already present in {config}")
    else:
        # Appending never changes the meaning of existing lines, unlike
        # prepending, which would pull any leading global keywords under this
        # Host block.
        try:
            with open(config, "a") as handle:
                if config.exists() and config.stat().st_size > 0:
                    handle.write("\n")
                handle.write(block(host, proxy_command) + "\n")
            config.chmod(0o600)
        except OSError as error:
            _error(f"Unable to write {config}: {error}")
            return 1
        print(f"Added the {host} block to {config}")

    # ssh takes the first value it finds for each keyword, so an earlier
    # matching block wins. Ask ssh what it will actually do rather than assuming.
    ssh = shutil.which("ssh")
    if ssh:
        probe = host.replace("*", "example")
        try:
            resolved = subprocess.run(
                [ssh, "-F", str(config), "-G", probe],
                capture_output=True,
                text=True,
                timeout=15,
            ).stdout
        except (OSError, subprocess.SubprocessError):
            return 0
        proxycommand = next(
            (
                line.split(" ", 1)[1].strip()
                for line in resolved.splitlines()
                if line.lower().startswith("proxycommand ")
            ),
            "",
        )
        marker = proxy_command.split()[0]
        if marker not in proxycommand:
            _error(
                f"Warning: an earlier block in {config} overrides it; move the "
                f'{host} block above any "Host *" block.'
            )
        effective = dict(
            line.split(" ", 1) for line in resolved.splitlines() if " " in line
        )
        if effective.get("stricthostkeychecking") == "no" or effective.get(
            "userknownhostsfile"
        ) == "/dev/null":
            _error(
                f"Warning: SSH host-key verification is disabled for {probe}; "
                f"check earlier blocks in {config}."
            )
    return 0


def _error(message: str) -> None:
    print(message, file=sys.stderr)
