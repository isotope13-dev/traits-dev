"""Transport mechanisms and process orchestration for Sitecard.

Supports Upterm, srv.us reverse tunnels (default), Cloudflare Worker relays,
and Cloudflare Argo (cloudflared) tunnels.
"""

from __future__ import annotations

import base64
import os
import re
import shutil
import socket
import ssl
import struct
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from sitecard import bridge, client_config, gateway, ingress, wsroute
from sitecard.account import ensure_username_environment
import sitecard.runtime as st

DEFAULT_TRANSPORT = "srvus"
VALID_TRANSPORTS = ("upterm", "srvus", "cloudflare", "cloudflared", "devtunnel", "ws-relay")

_PKG_SRC = str(Path(__file__).resolve().parent.parent)

_SEED_ENV = ingress.IDENTITY_SEED_ENV


def probe_ssh_tls(
    host: str,
    port: int = 443,
    timeout: float = 3.0,
    *,
    create_connection: Any = socket.create_connection,
    ssl_context: ssl.SSLContext | None = None,
) -> bool:
    """Verify a certificate-valid TLS endpoint which serves an SSH banner."""
    context = ssl_context or ssl.create_default_context()
    try:
        with create_connection((host, port), timeout=timeout) as raw:
            raw.settimeout(timeout)
            with context.wrap_socket(raw, server_hostname=host) as secured:
                banner = b""
                while len(banner) < 255 and b"\n" not in banner:
                    chunk = secured.recv(255 - len(banner))
                    if not chunk:
                        break
                    banner += chunk
        return banner.startswith(b"SSH-")
    except (OSError, ssl.SSLError, TimeoutError):
        return False


def wait_for_ssh_tls(
    host: str,
    timeout: float = 20.0,
    interval: float = 1.0,
    *,
    probe: Any = None,
    sleep: Any = None,
) -> bool:
    """Poll probe_ssh_tls until success or timeout.

    Tolerates slow public endpoints that need seconds after hostname
    announcement. Bounded by timeout; sleeps interval between attempts.
    ``probe`` and ``sleep`` are injectable so tests avoid network/sleeps.
    """
    check = probe or probe_ssh_tls
    pause = sleep or time.sleep
    if interval is None or interval <= 0:
        return bool(check(host))
    attempts = max(1, int(timeout / interval))
    for attempt in range(attempts):
        if check(host):
            return True
        if attempt < attempts - 1:
            pause(interval)
    return False


def _scrubbed_env() -> dict[str, str]:
    """Copy the parent environment without the identity seed.

    The seed may only reach the srv.us ingress child, set explicitly from the
    resolved file/env value. Every other child gets a seed-free environment
    even when the parent exported one.
    """
    environment = dict(os.environ)
    environment.pop(_SEED_ENV, None)
    return environment


@dataclass
class Target:
    """Remote endpoint and SSH command details for an active transport."""

    host: str
    proxy_command: str
    setup_host: str
    url: str
    note: str = ""
    user: str = ""
    connect_command: str = ""


def _spawn(
    command: list[str], environment: dict[str, str], log: Path,
    stdin: Any = subprocess.DEVNULL,
) -> subprocess.Popen:
    pythonpath = _PKG_SRC
    if environment.get("PYTHONPATH"):
        pythonpath = f"{_PKG_SRC}{os.pathsep}{environment['PYTHONPATH']}"
    environment = {**environment, "PYTHONPATH": pythonpath}
    with open(log, "ab") as output:
        return subprocess.Popen(
            command,
            env=environment,
            stdout=output,
            stderr=subprocess.STDOUT,
            stdin=stdin,
            # Background services must outlive the shell or SSH exec channel
            # which invoked `sitecard start`.
            start_new_session=True,
        )


def normalize_endpoint(value: str, scheme: str) -> str | None:
    stripped = value.strip().rstrip("/")
    for prefix in ("https://", "http://", "wss://", "ws://"):
        if stripped.startswith(prefix):
            stripped = stripped[len(prefix) :]
            break
    if not stripped:
        return None
    return f"{scheme}://{stripped}"


def prepare_ssh_dir(ssh_dir: Path | None = None) -> bool:
    target = ssh_dir if ssh_dir is not None else Path(os.path.expanduser("~/.ssh"))
    try:
        target.mkdir(parents=True, exist_ok=True)
        target.chmod(0o700)
        return True
    except OSError:
        return False


def validate_ssh_public_key(path: Path) -> bool:
    ssh_keygen = shutil.which("ssh-keygen")
    if ssh_keygen:
        try:
            return (
                subprocess.run(
                    [ssh_keygen, "-l", "-f", str(path)],
                    capture_output=True,
                ).returncode
                == 0
            )
        except OSError:
            return False
    try:
        parts = path.read_text().split()
        if len(parts) < 2:
            return False
        blob = base64.b64decode(parts[1], validate=True)
        size = struct.unpack(">I", blob[:4])[0]
        return blob[4 : 4 + size].decode() == parts[0]
    except Exception:
        return False


def prompt_authorized_key(selected: Path | None = None) -> None:
    """Prompt for an SSH public key when running interactively with none set.

    Never touches /dev/tty: when stdin is not interactive there is nothing to
    prompt on, so return immediately and let the caller fall back to password
    auth (or fail, for providers that cannot use passwords). Ordinary Sitecard
    keeps legacy ``~/.ssh/authorized_keys`` behavior by default. Authenticated
    Sitecard sessions use the state-owned ``authorized_keys`` file instead so
    host SSH configuration is never touched.
    """
    is_sitecard = __package__ == "sitecard"
    if selected is not None:
        keys = Path(selected)
        label = str(keys)
    elif is_sitecard:
        keys = st.setup_state() / "authorized_keys"
        label = str(keys)
    else:
        keys = Path(os.path.expanduser("~/.ssh/authorized_keys"))
        label = "~/.ssh/authorized_keys"
    if keys.is_file() and keys.stat().st_size > 0:
        return
    if not sys.stdin.isatty():
        return
    print(f"No SSH keys detected in {label}.", file=sys.stderr)
    print(
        "Paste an OpenSSH public key for key-based authentication (or Enter to skip): ",
        file=sys.stderr,
        end="",
        flush=True,
    )
    pasted = sys.stdin.readline().strip()
    if not pasted:
        print("Key entry skipped; relying on password authentication.", file=sys.stderr)
        return
    key_dir = keys.parent
    if not prepare_ssh_dir(key_dir):
        print(f"Failed to prepare directory {key_dir}; skipped.", file=sys.stderr)
        return
    with tempfile.NamedTemporaryFile(
        prefix="sitecard-key.", dir=str(key_dir), mode="w"
    ) as temp:
        temp.write(pasted + "\n")
        temp.flush()
        if validate_ssh_public_key(Path(temp.name)):
            with open(keys, "ab") as output:
                output.write(pasted.encode() + b"\n")
            keys.chmod(0o600)
            print(f"Appended key to {keys}.", file=sys.stderr)
        else:
            print("Invalid SSH public key format; entry skipped.", file=sys.stderr)


def launch_gateway(
    transport: str,
    root: Path,
    port: int,
    password: str,
    accept: bool,
    allow_tcp_forwarding: bool,
    state: Path,
    confine_sftp: bool = False,
) -> subprocess.Popen:
    """Spawn the background gateway AsyncSSH daemon."""
    username = ensure_username_environment()
    flags = []
    if accept:
        flags.append("--accept")
    if allow_tcp_forwarding:
        flags.append("--allow-tcp-forwarding")
    flags.append("--confine-sftp" if confine_sftp else "--no-confine-sftp")
    if __package__ == "sitecard":
        flags.extend(
            [
                "--authorized-keys",
                str(state / "authorized_keys"),
                "--recovery-authorized-keys",
                str(state / "recovery_authorized_keys"),
            ]
        )
    if transport in ("upterm", "ws-relay"):
        flags.extend(
            ["--no-password"]
        )
    if transport == "upterm":
        flags.extend(["--upterm-ca-keys", str(state / "upterm-ca-keys")])
    command = [
        sys.executable,
        "-m",
        "sitecard.gateway",
        "--root",
        str(root),
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        "--username",
        username,
        *flags,
    ]
    environment = {
        **_scrubbed_env(),
        "SITECARD_PASSWORD": password,
        "USER": username,
        "LOGNAME": username,
    }
    return _spawn(command, environment, state / "gateway.log")


def launch_transport_srvus(
    port: int, slot: int, state: Path, identity_seed: str = ""
) -> subprocess.Popen:
    # The tunnel identity belongs to this Sitecard state, not to the host's
    # SSH configuration. ingress.ensure_key() creates it atomically in pure
    # Python, including deterministic creation when an identity seed is set.
    key = state / "srvus-id_ed25519"
    st.repair_key_permissions(key)
    host = os.environ.get("SITECARD_TUNNEL_HOST", "srv.us")
    try:
        sink_port = int(os.environ.get("SITECARD_TUNNEL_PORT", "22"))
    except ValueError:
        sink_port = 22
    command = [
        sys.executable,
        "-m",
        "sitecard.ingress",
        "--host",
        host,
        "--port",
        str(sink_port),
        "--local-port",
        str(port),
        "--slot",
        str(slot),
        "--key",
        str(key),
    ]
    environment = _scrubbed_env()
    if identity_seed:
        environment[_SEED_ENV] = identity_seed
    return _spawn(command, environment, state / "transport.log")


def launch_transport_cloudflare(
    endpoint: str, session: str, port: int, state: Path
) -> subprocess.Popen:
    if not endpoint:
        st.stop_one(state / "gateway.pid")
        raise SystemExit("The --endpoint option is required for the cloudflare transport")
    wss = normalize_endpoint(endpoint, "wss")
    if wss is None:
        st.stop_one(state / "gateway.pid")
        raise SystemExit(f"Malformed endpoint URL: {endpoint}")
    base_url = f"{wss}/relay/{session}"
    command = [
        sys.executable,
        "-m",
        "sitecard.bridge",
        "origin",
        "--host",
        "127.0.0.1",
        "--port",
        str(port),
        base_url,
    ]
    return _spawn(command, _scrubbed_env(), state / "transport.log")


def validate_ws_relay(endpoint: str) -> None:
    from urllib.parse import urlsplit

    parsed = urlsplit(endpoint)
    parts = parsed.path.split("/")
    if (parsed.scheme != "wss" or not parsed.hostname or parsed.username or parsed.password
            or parsed.query or parsed.fragment or len(parts) != 3 or parts[1] != "relay"
            or not re.fullmatch(r"[A-Za-z0-9_-]{32,}", parts[2])):
        raise SystemExit("--relay-url must be wss://HOST/relay/<unguessable-token>")


def launch_transport_ws_relay(endpoint: str, port: int, state: Path) -> subprocess.Popen:
    validate_ws_relay(endpoint)
    command = [
        sys.executable, "-m", "sitecard.bridge", "origin",
        "--host", "127.0.0.1", "--port", str(port), endpoint,
    ]
    return _spawn(command, _scrubbed_env(), state / "transport.log")


def launch_transport_cloudflared(
    hostname: str, token: str, state: Path
) -> subprocess.Popen:
    if not shutil.which("cloudflared"):
        st.stop_one(state / "gateway.pid")
        raise SystemExit("cloudflared executable not found in PATH")
    if not hostname:
        st.stop_one(state / "gateway.pid")
        raise SystemExit("--hostname must be specified for cloudflared transport")
    tunnel_token = token or os.environ.get("SITECARD_CLOUDFLARED_TOKEN", "")
    if not tunnel_token:
        st.stop_one(state / "gateway.pid")
        raise SystemExit(
            "A tunnel token must be supplied via --token or SITECARD_CLOUDFLARED_TOKEN"
        )
    environment = {**_scrubbed_env(), "TUNNEL_TOKEN": tunnel_token}
    return _spawn(["cloudflared", "tunnel", "run"], environment, state / "transport.log")


def launch_transport_upterm(
    endpoint: str | None, accept: bool, port: int, state: Path
) -> subprocess.Popen:
    if __package__ == "sitecard":
        ssh_dir = state
        key = state / "upterm-id_ed25519"
        authorized_keys = str(state / "authorized_keys")
    else:
        ssh_dir = Path(os.path.expanduser("~/.ssh"))
        key = Path(os.path.expanduser("~/.ssh/id_ed25519"))
        authorized_keys = os.path.expanduser("~/.ssh/authorized_keys")
    if not prepare_ssh_dir(ssh_dir):
        st.stop_one(state / "gateway.pid")
        raise SystemExit(f"Failed to initialize SSH directory: {ssh_dir}")
    st.repair_key_permissions(key)
    wss_endpoint = normalize_endpoint(endpoint or wsroute.DEFAULT_ENDPOINT, "wss")
    if wss_endpoint is None:
        st.stop_one(state / "gateway.pid")
        raise SystemExit(f"Malformed endpoint URL: {endpoint}")
    command = [
        sys.executable,
        "-m",
        "sitecard.wsroute",
        "origin",
        "--endpoint",
        wss_endpoint,
        "--local-port",
        str(port),
        "--username",
        ensure_username_environment(),
        "--key",
        str(key),
        "--host-key",
        str(gateway.DEFAULT_HOST_KEY),
        "--authorized-keys",
        authorized_keys,
        "--ca-keys",
        str(state / "upterm-ca-keys"),
        "--session-file",
        str(state / "upterm.json"),
    ]
    if accept:
        command.append("--accept")
    return _spawn(command, _scrubbed_env(), state / "transport.log")


def validate_devtunnel(tunnel_id: str, token_file: str) -> None:
    if not shutil.which("devtunnel"):
        raise SystemExit("devtunnel executable not found in PATH; install it before starting")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", tunnel_id):
        raise SystemExit("--tunnel-id must name an existing Dev Tunnel")
    if token_file:
        try:
            value = Path(token_file).read_text().strip()
        except (OSError, UnicodeError):
            raise SystemExit("Dev Tunnel token file is unreadable") from None
        if not value or any(character.isspace() for character in value):
            raise SystemExit("Dev Tunnel token file must contain one nonempty token")


def launch_transport_devtunnel(tunnel_id: str, token_file: str, state: Path) -> subprocess.Popen:
    validate_devtunnel(tunnel_id, token_file)
    # Existing tunnels already contain ports. Passing -p here tries to create
    # them again and fails; provisioning is deliberately separate from hosting.
    command = ["devtunnel", "host", tunnel_id]
    if token_file:
        command.extend(["--access-token", "-"])
        with open(token_file, "rb") as credential:
            return _spawn(command, _scrubbed_env(), state / "transport.log", stdin=credential)
    return _spawn(command, _scrubbed_env(), state / "transport.log")


def probe_local_ssh(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=2) as connection:
            connection.settimeout(2)
            banner = b""
            while len(banner) < 255 and b"\n" not in banner:
                chunk = connection.recv(255 - len(banner))
                if not chunk:
                    break
                banner += chunk
            return banner.startswith(b"SSH-")
    except OSError:
        return False


def wait_for_devtunnel(transport_pid_file: Path, transport_log: Path, port: int) -> bool:
    for _ in range(40):
        if not st.is_running(transport_pid_file):
            return False
        try:
            text = transport_log.read_text(errors="replace")
        except OSError:
            text = ""
        if (
            "Ready to accept connections" in text
            and re.search(rf"Hosting port:\s*{port}\b", text)
            and probe_local_ssh(port)
        ):
            return True
        time.sleep(0.5)
    return False


def launch_transport(
    transport: str,
    port: int,
    slot: int,
    session: str,
    state: Path,
    endpoint: str = "",
    hostname: str = "",
    token: str = "",
    accept: bool = False,
    identity_seed: str = "",
    tunnel_id: str = "",
    devtunnel_token_file: str = "",
) -> subprocess.Popen:
    """Launch the chosen transport daemon."""
    if transport == "srvus":
        return launch_transport_srvus(port, slot, state, identity_seed)
    if transport == "cloudflare":
        return launch_transport_cloudflare(endpoint, session, port, state)
    if transport == "ws-relay":
        return launch_transport_ws_relay(endpoint, port, state)
    if transport == "cloudflared":
        return launch_transport_cloudflared(hostname, token, state)
    if transport == "devtunnel":
        return launch_transport_devtunnel(tunnel_id, devtunnel_token_file, state)
    return launch_transport_upterm(endpoint, accept, port, state)


def wait_for_srvus_host(transport_pid_file: Path, transport_log: Path) -> str:
    """Wait for the srv.us ingress to announce its hostname.

    Returns the hostname on success, or "" when the transport dies first or no
    hostname appears within the bounded wait.
    """
    for _ in range(40):
        if not st.is_running(transport_pid_file):
            return ""
        host = st.extract_host(transport_log)
        if host:
            return host
        time.sleep(0.5)
    return ""


def wait_for_upterm_session(
    transport_pid_file: Path, session_file: Path
) -> dict[str, Any] | None:
    for _ in range(40):
        if not st.is_running(transport_pid_file):
            return None
        session = wsroute.read_session(session_file)
        if session:
            return session
        time.sleep(0.5)
    return None


def resolve_target(transport: str, state: Path) -> Target | None:
    """Resolve connection target details for the given transport."""
    if transport == "devtunnel":
        tunnel_id = st.manifest_get("tunnel_id")
        port = st.manifest_get("port")
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*", tunnel_id or "") or not port.isdigit():
            return None
        return Target(
            host=tunnel_id,
            setup_host=tunnel_id,
            proxy_command=f"nc 127.0.0.1 {port}",
            url=f"ssh://127.0.0.1:{port}",
            connect_command=f"devtunnel connect {tunnel_id}",
            note=(
                f"Run devtunnel connect on the CLIENT, not the remote host. Local port {port} "
                "must be free. Use a connect-scoped token via --access-token - if not logged in. "
                "The HTTPS tunnel URL is not an SSH endpoint; nc must be installed locally."
            ),
        )
    if transport == "cloudflare":
        endpoint = st.manifest_get("endpoint")
        session = st.manifest_get("session")
        if not (endpoint and session):
            return None
        https = normalize_endpoint(endpoint, "https") or endpoint
        wss = normalize_endpoint(endpoint, "wss") or endpoint
        return Target(
            host="sitecard",
            proxy_command=f"sitecard proxy {wss}/relay/{session}",
            setup_host="sitecard",
            url=f"{https}/relay/{session}",
            note="Sitecard client must be installed on the connecting machine.",
        )
    if transport == "ws-relay":
        endpoint = st.manifest_get("endpoint")
        if not endpoint:
            return None
        return Target(
            host="relay",
            proxy_command=f"sitecard proxy {endpoint}",
            setup_host="relay",
            url=endpoint,
            note="Use a pinned SSH host key and the private key authorized on the remote gateway.",
        )
    if transport == "cloudflared":
        hostname = st.manifest_get("hostname")
        if not hostname:
            return None
        return Target(
            host=hostname,
            proxy_command="cloudflared access ssh --hostname %h",
            setup_host=hostname,
            url=f"ssh://{hostname}",
            note="cloudflared must be installed on the connecting machine.",
        )
    if transport == "upterm":
        session = wsroute.read_session(state / "upterm.json")
        if not session:
            return None
        endpoint = session["endpoint"]
        host = wsroute.endpoint_host(endpoint)
        proxy_url = wsroute.ssh_proxy_url(session)
        return Target(
            host=host,
            proxy_command=f"sitecard upterm-proxy {proxy_url}",
            setup_host=host,
            url=f"ssh://{session['ssh_user']}@{host}:443",
            note="Sitecard client must be installed on the connecting machine.",
            user=session["ssh_user"],
        )
    # srvus transport
    host = st.extract_host(state / "transport.log")
    if not host:
        return None
    return Target(
        host=host,
        proxy_command=client_config.SRVUS_PROXY_COMMAND,
        setup_host="*.srv.us",
        url=f"https://{host}/",
    )


def cmd_proxy(args: Any) -> int:
    return bridge.main(["client", args.url])


def cmd_upterm_proxy(args: Any) -> int:
    return wsroute.main(["client", args.url])
