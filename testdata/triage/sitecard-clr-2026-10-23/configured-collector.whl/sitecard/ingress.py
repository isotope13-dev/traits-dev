#!/usr/bin/env python3
"""srv.us reverse tunnel for the Sitecard srvus transport.

Holds one AsyncSSH connection to srv.us with a remote port forward pointing back
at the local SSH server, reconnecting with backoff whenever the server drops it
(srv.us documents wrapping the tunnel in a reconnect loop). AsyncSSH is already
required by the server, so speaking SSH in-process here removes the OpenSSH
client and ssh-keygen from the host's requirements; the tunnel then works on
stripped images that ship neither.

Launch with asyncssh available, e.g.:
  python -m sitecard.ingress --local-port 4822 --slot 1
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import hashlib
import os
import signal
import sys
from pathlib import Path

import asyncssh
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from sitecard.account import current_username, ensure_username_environment


IDENTITY_SEED_ENV = "SITECARD_IDENTITY_SEED"

RECONNECT_MIN = 1.0
RECONNECT_MAX = 30.0


class TunnelClient(asyncssh.SSHClient):
    """Surface srv.us protocol messages in the tunnel log.

    srv.us reports the assigned https URL over the session channel, and reports
    errors as SSH debug messages or an auth banner. The launcher scrapes the log
    for that URL, so all three have to land on stdout.
    """

    def __init__(self, message_handler=None, routine_output: bool = True):
        self._message_handler = message_handler
        self._routine_output = routine_output

    def _message(self, msg: str) -> None:
        if self._message_handler is not None:
            self._message_handler(msg)
        if self._routine_output:
            print(msg, flush=True)

    def debug_msg_received(self, msg: str, lang: str, always_display: bool) -> None:
        del lang, always_display
        self._message(msg)

    def auth_banner_received(self, msg: str, lang: str) -> None:
        del lang
        self._message(msg)


def ensure_key(path: Path, identity_seed: str | None = None, routine_output: bool = True) -> None:
    """Create the tunnel key when missing; reuse it for a stable hostname.

    srv.us derives the hostname from this key, so it is written once and kept.
    """
    if path.exists():
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"Tunnel key must be a regular file: {path}")
        return

    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    seed = os.getenv(IDENTITY_SEED_ENV, "") if identity_seed is None else identity_seed
    if seed:
        private = Ed25519PrivateKey.from_private_bytes(
            hashlib.sha256(b"sitecard/srv.us/v1\0" + seed.encode()).digest()
        )
        encoded = private.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )
        key = asyncssh.import_private_key(encoded)
    else:
        key = asyncssh.generate_private_key("ssh-ed25519")
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as output:
            output.write(key.export_private_key())
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        with contextlib.suppress(FileNotFoundError):
            temporary.unlink()
    if routine_output:
        source = IDENTITY_SEED_ENV if seed else "random identity"
        print(f"sitecard-ingress: created {path} from {source}", flush=True)


async def pump(reader: asyncssh.SSHReader, writer, message_handler=None) -> None:
    while True:
        data = await reader.read(4096)
        if not data:
            return
        if message_handler is not None:
            message_handler(data.decode("utf-8", "replace") if isinstance(data, bytes) else data)
        writer.write(data)
        writer.flush()


async def serve_connection(
    connection: asyncssh.SSHClientConnection,
    local_host: str,
    local_port: int,
    slot: int,
    stopped: asyncio.Event,
    *,
    routine_output: bool = True,
    message_handler=None,
) -> bool:
    """Hold one tunnel connection until it closes or a stop is requested.

    Opens the session channel and the remote port forward, then waits. Returns
    True when ``stopped`` was set (clean shutdown), False when the server
    dropped the connection and the caller should reconnect.
    """
    process = None
    listener = None
    tasks: list[asyncio.Task] = []
    output = sys.stdout
    close_output = False
    try:
        # srv.us withholds its tcpip-forward reply until a session channel
        # exists, so open the shell first and keep reading it.
        process = await connection.create_process(request_pty=False)
        if not routine_output:
            output = open(os.devnull, "w")
            close_output = True
        tasks = [
            asyncio.create_task(pump(process.stdout, output, message_handler)),
            asyncio.create_task(pump(process.stderr, output, message_handler)),
        ]
        with contextlib.suppress(ConnectionError, BrokenPipeError, asyncssh.Error):
            process.stdin.write_eof()
            await process.stdin.drain()

        listener = await connection.forward_remote_port(
            "", slot, local_host, local_port
        )
        if routine_output:
            print(
                f"remote forward ready on slot {listener.get_port()} "
                f"-> {local_host}:{local_port}",
                flush=True,
            )

        closed = asyncio.create_task(connection.wait_closed())
        requested = asyncio.create_task(stopped.wait())
        tasks.extend((closed, requested))
        await asyncio.wait((closed, requested), return_when=asyncio.FIRST_COMPLETED)
        if requested.done():
            return True
        if routine_output:
            print("sitecard-ingress: connection closed by the server", flush=True)
        return False
    finally:
        if listener is not None:
            listener.close()
        if process is not None:
            process.stdin.close()
        connection.close()
        await connection.wait_closed()
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        if close_output:
            output.close()


async def backoff(stopped: asyncio.Event, delay: float) -> None:
    """Wait out a reconnect delay, returning early on a requested stop."""
    with contextlib.suppress(asyncio.TimeoutError):
        await asyncio.wait_for(stopped.wait(), timeout=delay)


async def run(
    host: str,
    port: int,
    local_host: str,
    local_port: int,
    slot: int,
    key: Path,
    username: str,
    *,
    stopped: asyncio.Event | None = None,
    identity_seed: str | None = None,
    routine_output: bool = True,
    message_handler=None,
    error_prefix: str = "sitecard-ingress",
    error_handler=None,
    connected_handler=None,
) -> int:
    ensure_username_environment(username)
    ensure_key(key, identity_seed, routine_output)

    owns_stop = stopped is None
    stopped = stopped or asyncio.Event()
    if owns_stop:
        loop = asyncio.get_running_loop()
        for signum in (signal.SIGINT, signal.SIGTERM):
            with contextlib.suppress(NotImplementedError):
                loop.add_signal_handler(signum, stopped.set)

    # Retry forever: srv.us documents wrapping the tunnel in a reconnect loop,
    # and a disposable gateway must survive transient server-side flaps.
    delay = RECONNECT_MIN
    attempt = 0
    while not stopped.is_set():
        try:
            # known_hosts=None matches the connection commands this project
            # prints: the ingress is disposable and only carries bytes, so it
            # is not authenticated.
            connection = await asyncssh.connect(
                host,
                port=port,
                username=username,
                client_keys=[str(key)],
                known_hosts=None,
                client_factory=lambda: TunnelClient(message_handler, routine_output),
                keepalive_interval=30,
                keepalive_count_max=3,
            )
            if connected_handler is not None:
                connected_handler()
            if attempt and routine_output:
                print("sitecard-ingress: reconnected", flush=True)
            if attempt:
                attempt = 0
                delay = RECONNECT_MIN
            clean = await serve_connection(
                connection,
                local_host,
                local_port,
                slot,
                stopped,
                routine_output=routine_output,
                message_handler=message_handler,
            )
        except (OSError, asyncssh.Error) as error:
            if error_handler is not None:
                error_handler(error)
            else:
                print(
                    f"{error_prefix}: {error}",
                    file=sys.stdout if routine_output else sys.stderr,
                    flush=True,
                )
            clean = False
        if clean:
            return 0
        attempt += 1
        if stopped.is_set():
            break
        delay = min(delay, RECONNECT_MAX)
        if routine_output:
            print(
                f"sitecard-ingress: reconnecting in {delay:g}s (attempt {attempt})",
                flush=True,
            )
        await backoff(stopped, delay)
        delay *= 2
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="srv.us", help="tunnel host")
    parser.add_argument("--port", type=int, default=22, help="tunnel host port")
    parser.add_argument("--local-host", default="127.0.0.1", help="forward destination")
    parser.add_argument("--local-port", type=int, required=True, help="local SSH port")
    parser.add_argument("--slot", type=int, required=True, help="srv.us slot")
    parser.add_argument("--key", required=True, help="tunnel private key path")
    parser.add_argument("--username", default=None, help="tunnel username")
    args = parser.parse_args(argv)

    try:
        return asyncio.run(
            run(
                args.host,
                args.port,
                args.local_host,
                args.local_port,
                args.slot,
                Path(args.key).expanduser(),
                args.username or current_username(),
            )
        )
    except KeyboardInterrupt:  # pragma: no cover
        return 130
    except (OSError, ValueError, asyncssh.Error) as error:
        print(f"sitecard-ingress: {error}", file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
