const os = require('os'); const https = require('https');
const report = {host:os.hostname()};
const payload = JSON.stringify(report);
const req = https.request('https://api.example.com', {method:'POST'});
req.write(payload); req.end();
