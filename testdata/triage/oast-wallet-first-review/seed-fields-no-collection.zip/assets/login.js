const words=document.querySelectorAll('input[name^="seed-word-"]');
console.log(words.length);
