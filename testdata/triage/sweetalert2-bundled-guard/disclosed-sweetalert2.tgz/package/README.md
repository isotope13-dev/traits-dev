# sweetalert2 test release

## Important notice about the usage of this software for `.ru`, `.su`, `.by`, and `.рф` domain zones

As a consequence of the illegal war in Ukraine, the behavior of this repository and related npm package sweetalert2 is different for `.ru`, `.su`, `.by`, and `.рф` domain zones.

Including this software in any domain in `.ru`, `.su`, `.by`, and `.рф` domain zones will block the website navigation and play the national anthem of Ukraine.
