# Example CLI

https://www.npmjs.com/package/@example/renamed
