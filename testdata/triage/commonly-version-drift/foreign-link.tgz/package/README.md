# Example CLI

https://www.npmjs.com/package/upstream-cli
