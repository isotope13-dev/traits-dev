start interpreter.exe data.txt
