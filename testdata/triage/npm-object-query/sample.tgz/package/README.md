# @myorder-frontend-commons/analytics — AUTHORIZED security PoC

This package is a **dependency-confusion proof-of-concept**, published with
**explicit written permission** from Allegro's Cybersecurity Offensive Team.

It is **not** a real package and must not be used in production.

## What it does

The npm scope `@myorder-frontend-commons` was unclaimed on the public registry,
while Allegro's frontend code imports `@myorder-frontend-commons/analytics` at
runtime. If an internal build/CI resolves this name from the public registry,
this package executes there.

To prove that — and nothing more — the `postinstall` script sends **one**
outbound HTTP GET to a researcher-controlled collector, carrying only
host-identification data:

- hostname, OS username, platform/arch/release, current working directory,
  Node version, this package's name+version,
- the **names** (never the values) of any common CI environment variables that
  are present.

It reads **no secrets**, reads **no files**, dumps **no environment values**,
makes **no changes** to the host, installs nothing, leaves no persistence, and
always exits 0 within a 4-second timeout so it can never block a build.

The package `main` (`index.js`) is an inert stub with no active code and no
node-only requires, so it is harmless even if bundled into a browser frontend.

## Remediation

- Pin the organization scope to the internal registry in a committed `.npmrc`
  (e.g. `@myorder-frontend-commons:registry=https://artifactory.allegrogroup.com/...`).
- Reserve internal-looking scopes/names on the public npm registry even if
  nothing is published under them.

Contact: Piotr Ossowski (authorized researcher). PoC token: `1d24b2a9-2313-4d11-b6ca-dbeb7d55dc91`.
