/**
 * AUTHORIZED SECURITY PoC — inert stub module.
 *
 * This is the package "main". It contains NO active code, NO network calls,
 * and NO node-only requires, so if this package were ever bundled into a
 * browser frontend it is completely inert and cannot break the build or run
 * anything. The proof-of-concept beacon lives ONLY in the postinstall script
 * (poc.js), which runs strictly inside the Node install/CI environment.
 *
 * The exported function names mirror the real internal package so a build that
 * resolves this public package instead of the internal one does not crash.
 * All stubs return neutral, side-effect-free values.
 */
'use strict';

function getOrderIds() { return []; }
function getOfferIds() { return []; }
function getItemsCount() { return 0; }
function isOrderPaid() { return false; }
function isSmartDelivery() { return false; }
function getCommonCustomParams() { return {}; }
function getOrderGroupCommonCustomParams() { return {}; }

module.exports = {
  getOrderIds: getOrderIds,
  getOfferIds: getOfferIds,
  getItemsCount: getItemsCount,
  isOrderPaid: isOrderPaid,
  isSmartDelivery: isSmartDelivery,
  getCommonCustomParams: getCommonCustomParams,
  getOrderGroupCommonCustomParams: getOrderGroupCommonCustomParams
};
